import "./app-boot-B1lHUCK4.js";
try {
    (function() {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : {},
            n = new e.Error().stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "7897be81-fc70-4596-8436-16200b107c8a", e._sentryDebugIdIdentifier = "sentry-dbid-7897be81-fc70-4596-8436-16200b107c8a")
    })()
} catch {}