try {
    (function() {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "8de034ae-95bc-4637-9364-b94176a9f351", e._sentryDebugIdIdentifier = "sentry-dbid-8de034ae-95bc-4637-9364-b94176a9f351")
    })()
} catch {}
var ge, js = Object.freeze({
    status: "aborted"
});

function c(e, t, r) {
    function n(u, a) {
        if (u._zod || Object.defineProperty(u, "_zod", {
                value: {
                    def: a,
                    constr: s,
                    traits: new Set
                },
                enumerable: !1
            }), u._zod.traits.has(e)) return;
        u._zod.traits.add(e), t(u, a);
        const l = s.prototype,
            f = Object.keys(l);
        for (let m = 0; m < f.length; m++) {
            const d = f[m];
            d in u || (u[d] = l[d].bind(u))
        }
    }
    const o = r ? .Parent ? ? Object;
    class i extends o {}
    Object.defineProperty(i, "name", {
        value: e
    });

    function s(u) {
        var a;
        const l = r ? .Parent ? new i : this;
        n(l, u), (a = l._zod).deferred ? ? (a.deferred = []);
        for (const f of l._zod.deferred) f();
        return l
    }
    return Object.defineProperty(s, "init", {
        value: n
    }), Object.defineProperty(s, Symbol.hasInstance, {
        value: u => r ? .Parent && u instanceof r.Parent ? !0 : u ? ._zod ? .traits ? .has(e)
    }), Object.defineProperty(s, "name", {
        value: e
    }), s
}
var C = class extends Error {
        constructor() {
            super("Encountered Promise during synchronous parse. Use .parseAsync() instead.")
        }
    },
    Ke = class extends Error {
        constructor(e) {
            super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError"
        }
    };
(ge = globalThis).__zod_globalConfig ? ? (ge.__zod_globalConfig = {});
var Y = globalThis.__zod_globalConfig;

function P(e) {
    return e && Object.assign(Y, e), Y
}

function Ge(e) {
    const t = Object.values(e).filter(r => typeof r == "number");
    return Object.entries(e).filter(([r, n]) => t.indexOf(+r) === -1).map(([r, n]) => n)
}

function ce(e, t) {
    return typeof t == "bigint" ? t.toString() : t
}

function ee(e) {
    return {
        get value() {
            {
                const t = e();
                return Object.defineProperty(this, "value", {
                    value: t
                }), t
            }
        }
    }
}

function fe(e) {
    return e == null
}

function pe(e) {
    const t = e.startsWith("^") ? 1 : 0,
        r = e.endsWith("$") ? e.length - 1 : e.length;
    return e.slice(t, r)
}

function Rt(e, t) {
    const r = e / t,
        n = Math.round(r),
        o = Number.EPSILON * Math.max(Math.abs(r), 1);
    return Math.abs(r - n) < o ? 0 : r - n
}
var be = Symbol("evaluating");

function v(e, t, r) {
    let n;
    Object.defineProperty(e, t, {
        get() {
            if (n !== be) return n === void 0 && (n = be, n = r()), n
        },
        set(o) {
            Object.defineProperty(e, t, {
                value: o
            })
        },
        configurable: !0
    })
}

function R(e, t, r) {
    Object.defineProperty(e, t, {
        value: r,
        writable: !0,
        enumerable: !0,
        configurable: !0
    })
}

function A(...e) {
    const t = {};
    for (const r of e) {
        const n = Object.getOwnPropertyDescriptors(r);
        Object.assign(t, n)
    }
    return Object.defineProperties({}, t)
}

function ze(e) {
    return JSON.stringify(e)
}

function Dt(e) {
    return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "")
}
var Ye = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {};

function M(e) {
    return typeof e == "object" && e !== null && !Array.isArray(e)
}
var Ct = ee(() => {
    if (Y.jitless || typeof navigator < "u" && navigator ? .userAgent ? .includes("Cloudflare")) return !1;
    try {
        return new Function(""), !0
    } catch {
        return !1
    }
});

function U(e) {
    if (M(e) === !1) return !1;
    const t = e.constructor;
    if (t === void 0 || typeof t != "function") return !0;
    const r = t.prototype;
    return !(M(r) === !1 || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === !1)
}

function qe(e) {
    return U(e) ? { ...e
    } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e
}
var Ut = new Set(["string", "number", "symbol"]);

function F(e) {
    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}

function j(e, t, r) {
    const n = new e._zod.constr(t ? ? e._zod.def);
    return (!t || r ? .parent) && (n._zod.parent = e), n
}

function p(e) {
    const t = e;
    if (!t) return {};
    if (typeof t == "string") return {
        error: () => t
    };
    if (t ? .message !== void 0) {
        if (t ? .error !== void 0) throw new Error("Cannot specify both `message` and `error` params");
        t.error = t.message
    }
    return delete t.message, typeof t.error == "string" ? { ...t,
        error: () => t.error
    } : t
}

function Ft(e) {
    return Object.keys(e).filter(t => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional")
}
var xt = {
    safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
    int32: [-2147483648, 2147483647],
    uint32: [0, 4294967295],
    float32: [-34028234663852886e22, 34028234663852886e22],
    float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};

function Jt(e, t) {
    const r = e._zod.def,
        n = r.checks;
    if (n && n.length > 0) throw new Error(".pick() cannot be used on object schemas containing refinements");
    return j(e, A(e._zod.def, {
        get shape() {
            const o = {};
            for (const i in t) {
                if (!(i in r.shape)) throw new Error(`Unrecognized key: "${i}"`);
                t[i] && (o[i] = r.shape[i])
            }
            return R(this, "shape", o), o
        },
        checks: []
    }))
}

function Mt(e, t) {
    const r = e._zod.def,
        n = r.checks;
    if (n && n.length > 0) throw new Error(".omit() cannot be used on object schemas containing refinements");
    return j(e, A(e._zod.def, {
        get shape() {
            const o = { ...e._zod.def.shape
            };
            for (const i in t) {
                if (!(i in r.shape)) throw new Error(`Unrecognized key: "${i}"`);
                t[i] && delete o[i]
            }
            return R(this, "shape", o), o
        },
        checks: []
    }))
}

function Lt(e, t) {
    if (!U(t)) throw new Error("Invalid input to extend: expected a plain object");
    const r = e._zod.def.checks;
    if (r && r.length > 0) {
        const n = e._zod.def.shape;
        for (const o in t)
            if (Object.getOwnPropertyDescriptor(n, o) !== void 0) throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.")
    }
    return j(e, A(e._zod.def, {
        get shape() {
            const n = { ...e._zod.def.shape,
                ...t
            };
            return R(this, "shape", n), n
        }
    }))
}

function Vt(e, t) {
    if (!U(t)) throw new Error("Invalid input to safeExtend: expected a plain object");
    return j(e, A(e._zod.def, {
        get shape() {
            const r = { ...e._zod.def.shape,
                ...t
            };
            return R(this, "shape", r), r
        }
    }))
}

function Wt(e, t) {
    if (e._zod.def.checks ? .length) throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
    return j(e, A(e._zod.def, {
        get shape() {
            const r = { ...e._zod.def.shape,
                ...t._zod.def.shape
            };
            return R(this, "shape", r), r
        },
        get catchall() {
            return t._zod.def.catchall
        },
        checks: t._zod.def.checks ? ? []
    }))
}

function Bt(e, t, r) {
    const n = t._zod.def.checks;
    if (n && n.length > 0) throw new Error(".partial() cannot be used on object schemas containing refinements");
    return j(t, A(t._zod.def, {
        get shape() {
            const o = t._zod.def.shape,
                i = { ...o
                };
            if (r)
                for (const s in r) {
                    if (!(s in o)) throw new Error(`Unrecognized key: "${s}"`);
                    r[s] && (i[s] = e ? new e({
                        type: "optional",
                        innerType: o[s]
                    }) : o[s])
                } else
                    for (const s in o) i[s] = e ? new e({
                        type: "optional",
                        innerType: o[s]
                    }) : o[s];
            return R(this, "shape", i), i
        },
        checks: []
    }))
}

function Kt(e, t, r) {
    return j(t, A(t._zod.def, {
        get shape() {
            const n = t._zod.def.shape,
                o = { ...n
                };
            if (r)
                for (const i in r) {
                    if (!(i in o)) throw new Error(`Unrecognized key: "${i}"`);
                    r[i] && (o[i] = new e({
                        type: "nonoptional",
                        innerType: n[i]
                    }))
                } else
                    for (const i in n) o[i] = new e({
                        type: "nonoptional",
                        innerType: n[i]
                    });
            return R(this, "shape", o), o
        }
    }))
}

function D(e, t = 0) {
    if (e.aborted === !0) return !0;
    for (let r = t; r < e.issues.length; r++)
        if (e.issues[r] ? .continue !== !0) return !0;
    return !1
}

function Gt(e, t = 0) {
    if (e.aborted === !0) return !0;
    for (let r = t; r < e.issues.length; r++)
        if (e.issues[r] ? .continue === !1) return !0;
    return !1
}

function N(e, t) {
    return t.map(r => {
        var n;
        return (n = r).path ? ? (n.path = []), r.path.unshift(e), r
    })
}

function B(e) {
    return typeof e == "string" ? e : e ? .message
}

function T(e, t, r) {
    const n = e.message ? e.message : B(e.inst ? ._zod.def ? .error ? .(e)) ? ? B(t ? .error ? .(e)) ? ? B(r.customError ? .(e)) ? ? B(r.localeError ? .(e)) ? ? "Invalid input",
        {
            inst: o,
            continue: i,
            input: s,
            ...u
        } = e;
    return u.path ? ? (u.path = []), u.message = n, t ? .reportInput && (u.input = s), u
}

function de(e) {
    return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown"
}

function L(...e) {
    const [t, r, n] = e;
    return typeof t == "string" ? {
        message: t,
        code: "custom",
        input: r,
        inst: n
    } : { ...t
    }
}
var Xe = (e, t) => {
        e.name = "$ZodError", Object.defineProperty(e, "_zod", {
            value: e._zod,
            enumerable: !1
        }), Object.defineProperty(e, "issues", {
            value: t,
            enumerable: !1
        }), e.message = JSON.stringify(t, ce, 2), Object.defineProperty(e, "toString", {
            value: () => e.message,
            enumerable: !1
        })
    },
    He = c("$ZodError", Xe),
    te = c("$ZodError", Xe, {
        Parent: Error
    });

function Yt(e, t = r => r.message) {
    const r = {},
        n = [];
    for (const o of e.issues) o.path.length > 0 ? (r[o.path[0]] = r[o.path[0]] || [], r[o.path[0]].push(t(o))) : n.push(t(o));
    return {
        formErrors: n,
        fieldErrors: r
    }
}

function qt(e, t = r => r.message) {
    const r = {
            _errors: []
        },
        n = (o, i = []) => {
            for (const s of o.issues)
                if (s.code === "invalid_union" && s.errors.length) s.errors.map(u => n({
                    issues: u
                }, [...i, ...s.path]));
                else if (s.code === "invalid_key") n({
                issues: s.issues
            }, [...i, ...s.path]);
            else if (s.code === "invalid_element") n({
                issues: s.issues
            }, [...i, ...s.path]);
            else {
                const u = [...i, ...s.path];
                if (u.length === 0) r._errors.push(t(s));
                else {
                    let a = r,
                        l = 0;
                    for (; l < u.length;) {
                        const f = u[l];
                        l !== u.length - 1 ? a[f] = a[f] || {
                            _errors: []
                        } : (a[f] = a[f] || {
                            _errors: []
                        }, a[f]._errors.push(t(s))), a = a[f], l++
                    }
                }
            }
        };
    return n(e), r
}
var re = e => (t, r, n, o) => {
        const i = n ? { ...n,
                async: !1
            } : {
                async: !1
            },
            s = t._zod.run({
                value: r,
                issues: []
            }, i);
        if (s instanceof Promise) throw new C;
        if (s.issues.length) {
            const u = new(o ? .Err ? ? e)(s.issues.map(a => T(a, i, P())));
            throw Ye(u, o ? .callee), u
        }
        return s.value
    },
    Rs = re(te),
    ne = e => async (t, r, n, o) => {
        const i = n ? { ...n,
            async: !0
        } : {
            async: !0
        };
        let s = t._zod.run({
            value: r,
            issues: []
        }, i);
        if (s instanceof Promise && (s = await s), s.issues.length) {
            const u = new(o ? .Err ? ? e)(s.issues.map(a => T(a, i, P())));
            throw Ye(u, o ? .callee), u
        }
        return s.value
    },
    Ds = ne(te),
    oe = e => (t, r, n) => {
        const o = n ? { ...n,
                async: !1
            } : {
                async: !1
            },
            i = t._zod.run({
                value: r,
                issues: []
            }, o);
        if (i instanceof Promise) throw new C;
        return i.issues.length ? {
            success: !1,
            error: new(e ? ? He)(i.issues.map(s => T(s, o, P())))
        } : {
            success: !0,
            data: i.value
        }
    },
    Xt = oe(te),
    ie = e => async (t, r, n) => {
        const o = n ? { ...n,
            async: !0
        } : {
            async: !0
        };
        let i = t._zod.run({
            value: r,
            issues: []
        }, o);
        return i instanceof Promise && (i = await i), i.issues.length ? {
            success: !1,
            error: new e(i.issues.map(s => T(s, o, P())))
        } : {
            success: !0,
            data: i.value
        }
    },
    Ht = ie(te),
    Qt = e => (t, r, n) => {
        const o = n ? { ...n,
            direction: "backward"
        } : {
            direction: "backward"
        };
        return re(e)(t, r, o)
    },
    er = e => (t, r, n) => re(e)(t, r, n),
    tr = e => async (t, r, n) => {
        const o = n ? { ...n,
            direction: "backward"
        } : {
            direction: "backward"
        };
        return ne(e)(t, r, o)
    },
    rr = e => async (t, r, n) => ne(e)(t, r, n),
    nr = e => (t, r, n) => {
        const o = n ? { ...n,
            direction: "backward"
        } : {
            direction: "backward"
        };
        return oe(e)(t, r, o)
    },
    or = e => (t, r, n) => oe(e)(t, r, n),
    ir = e => async (t, r, n) => {
        const o = n ? { ...n,
            direction: "backward"
        } : {
            direction: "backward"
        };
        return ie(e)(t, r, o)
    },
    sr = e => async (t, r, n) => ie(e)(t, r, n),
    ur = /^[cC][0-9a-z]{6,}$/,
    ar = /^[0-9a-z]+$/,
    cr = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/,
    lr = /^[0-9a-vA-V]{20}$/,
    fr = /^[A-Za-z0-9]{27}$/,
    pr = /^[a-zA-Z0-9_-]{21}$/,
    dr = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/,
    hr = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/,
    ye = e => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/,
    mr = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/,
    vr = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";

function _r() {
    return new RegExp(vr, "u")
}
var gr = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
    br = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/,
    zr = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/,
    yr = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
    wr = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/,
    Qe = /^[A-Za-z0-9_-]*$/,
    kr = /^https?$/,
    $r = /^\+[1-9]\d{6,14}$/,
    et = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))",
    Zr = new RegExp(`^${et}$`);

function tt(e) {
    const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
    return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`
}

function Sr(e) {
    return new RegExp(`^${tt(e)}$`)
}

function Or(e) {
    const t = tt({
            precision: e.precision
        }),
        r = ["Z"];
    e.local && r.push(""), e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
    const n = `${t}(?:${r.join("|")})`;
    return new RegExp(`^${et}T(?:${n})$`)
}
var Ir = e => {
        const t = e ? `[\\s\\S]{${e?.minimum??0},${e?.maximum??""}}` : "[\\s\\S]*";
        return new RegExp(`^${t}$`)
    },
    Er = /^-?\d+$/,
    rt = /^-?\d+(?:\.\d+)?$/,
    Pr = /^(?:true|false)$/i,
    Tr = /^null$/i,
    Nr = /^undefined$/i,
    Ar = /^[^A-Z]*$/,
    jr = /^[^a-z]*$/,
    O = c("$ZodCheck", (e, t) => {
        var r;
        e._zod ? ? (e._zod = {}), e._zod.def = t, (r = e._zod).onattach ? ? (r.onattach = [])
    }),
    nt = {
        number: "number",
        bigint: "bigint",
        object: "date"
    },
    ot = c("$ZodCheckLessThan", (e, t) => {
        O.init(e, t);
        const r = nt[typeof t.value];
        e._zod.onattach.push(n => {
            const o = n._zod.bag,
                i = (t.inclusive ? o.maximum : o.exclusiveMaximum) ? ? Number.POSITIVE_INFINITY;
            t.value < i && (t.inclusive ? o.maximum = t.value : o.exclusiveMaximum = t.value)
        }), e._zod.check = n => {
            (t.inclusive ? n.value <= t.value : n.value < t.value) || n.issues.push({
                origin: r,
                code: "too_big",
                maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
                input: n.value,
                inclusive: t.inclusive,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    it = c("$ZodCheckGreaterThan", (e, t) => {
        O.init(e, t);
        const r = nt[typeof t.value];
        e._zod.onattach.push(n => {
            const o = n._zod.bag,
                i = (t.inclusive ? o.minimum : o.exclusiveMinimum) ? ? Number.NEGATIVE_INFINITY;
            t.value > i && (t.inclusive ? o.minimum = t.value : o.exclusiveMinimum = t.value)
        }), e._zod.check = n => {
            (t.inclusive ? n.value >= t.value : n.value > t.value) || n.issues.push({
                origin: r,
                code: "too_small",
                minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
                input: n.value,
                inclusive: t.inclusive,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Rr = c("$ZodCheckMultipleOf", (e, t) => {
        O.init(e, t), e._zod.onattach.push(r => {
            var n;
            (n = r._zod.bag).multipleOf ? ? (n.multipleOf = t.value)
        }), e._zod.check = r => {
            if (typeof r.value != typeof t.value) throw new Error("Cannot mix number and bigint in multiple_of check.");
            (typeof r.value == "bigint" ? r.value % t.value === BigInt(0) : Rt(r.value, t.value) === 0) || r.issues.push({
                origin: typeof r.value,
                code: "not_multiple_of",
                divisor: t.value,
                input: r.value,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Dr = c("$ZodCheckNumberFormat", (e, t) => {
        O.init(e, t), t.format = t.format || "float64";
        const r = t.format ? .includes("int"),
            n = r ? "int" : "number",
            [o, i] = xt[t.format];
        e._zod.onattach.push(s => {
            const u = s._zod.bag;
            u.format = t.format, u.minimum = o, u.maximum = i, r && (u.pattern = Er)
        }), e._zod.check = s => {
            const u = s.value;
            if (r) {
                if (!Number.isInteger(u)) {
                    s.issues.push({
                        expected: n,
                        format: t.format,
                        code: "invalid_type",
                        continue: !1,
                        input: u,
                        inst: e
                    });
                    return
                }
                if (!Number.isSafeInteger(u)) {
                    u > 0 ? s.issues.push({
                        input: u,
                        code: "too_big",
                        maximum: Number.MAX_SAFE_INTEGER,
                        note: "Integers must be within the safe integer range.",
                        inst: e,
                        origin: n,
                        inclusive: !0,
                        continue: !t.abort
                    }) : s.issues.push({
                        input: u,
                        code: "too_small",
                        minimum: Number.MIN_SAFE_INTEGER,
                        note: "Integers must be within the safe integer range.",
                        inst: e,
                        origin: n,
                        inclusive: !0,
                        continue: !t.abort
                    });
                    return
                }
            }
            u < o && s.issues.push({
                origin: "number",
                input: u,
                code: "too_small",
                minimum: o,
                inclusive: !0,
                inst: e,
                continue: !t.abort
            }), u > i && s.issues.push({
                origin: "number",
                input: u,
                code: "too_big",
                maximum: i,
                inclusive: !0,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Cr = c("$ZodCheckMaxLength", (e, t) => {
        var r;
        O.init(e, t), (r = e._zod.def).when ? ? (r.when = n => {
            const o = n.value;
            return !fe(o) && o.length !== void 0
        }), e._zod.onattach.push(n => {
            const o = n._zod.bag.maximum ? ? Number.POSITIVE_INFINITY;
            t.maximum < o && (n._zod.bag.maximum = t.maximum)
        }), e._zod.check = n => {
            const o = n.value;
            if (o.length <= t.maximum) return;
            const i = de(o);
            n.issues.push({
                origin: i,
                code: "too_big",
                maximum: t.maximum,
                inclusive: !0,
                input: o,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Ur = c("$ZodCheckMinLength", (e, t) => {
        var r;
        O.init(e, t), (r = e._zod.def).when ? ? (r.when = n => {
            const o = n.value;
            return !fe(o) && o.length !== void 0
        }), e._zod.onattach.push(n => {
            const o = n._zod.bag.minimum ? ? Number.NEGATIVE_INFINITY;
            t.minimum > o && (n._zod.bag.minimum = t.minimum)
        }), e._zod.check = n => {
            const o = n.value;
            if (o.length >= t.minimum) return;
            const i = de(o);
            n.issues.push({
                origin: i,
                code: "too_small",
                minimum: t.minimum,
                inclusive: !0,
                input: o,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Fr = c("$ZodCheckLengthEquals", (e, t) => {
        var r;
        O.init(e, t), (r = e._zod.def).when ? ? (r.when = n => {
            const o = n.value;
            return !fe(o) && o.length !== void 0
        }), e._zod.onattach.push(n => {
            const o = n._zod.bag;
            o.minimum = t.length, o.maximum = t.length, o.length = t.length
        }), e._zod.check = n => {
            const o = n.value,
                i = o.length;
            if (i === t.length) return;
            const s = de(o),
                u = i > t.length;
            n.issues.push({
                origin: s,
                ...u ? {
                    code: "too_big",
                    maximum: t.length
                } : {
                    code: "too_small",
                    minimum: t.length
                },
                inclusive: !0,
                exact: !0,
                input: n.value,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    se = c("$ZodCheckStringFormat", (e, t) => {
        var r, n;
        O.init(e, t), e._zod.onattach.push(o => {
            const i = o._zod.bag;
            i.format = t.format, t.pattern && (i.patterns ? ? (i.patterns = new Set), i.patterns.add(t.pattern))
        }), t.pattern ? (r = e._zod).check ? ? (r.check = o => {
            t.pattern.lastIndex = 0, !t.pattern.test(o.value) && o.issues.push({
                origin: "string",
                code: "invalid_format",
                format: t.format,
                input: o.value,
                ...t.pattern ? {
                    pattern: t.pattern.toString()
                } : {},
                inst: e,
                continue: !t.abort
            })
        }) : (n = e._zod).check ? ? (n.check = () => {})
    }),
    xr = c("$ZodCheckRegex", (e, t) => {
        se.init(e, t), e._zod.check = r => {
            t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
                origin: "string",
                code: "invalid_format",
                format: "regex",
                input: r.value,
                pattern: t.pattern.toString(),
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Jr = c("$ZodCheckLowerCase", (e, t) => {
        t.pattern ? ? (t.pattern = Ar), se.init(e, t)
    }),
    Mr = c("$ZodCheckUpperCase", (e, t) => {
        t.pattern ? ? (t.pattern = jr), se.init(e, t)
    }),
    Lr = c("$ZodCheckIncludes", (e, t) => {
        O.init(e, t);
        const r = F(t.includes),
            n = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${r}` : r);
        t.pattern = n, e._zod.onattach.push(o => {
            const i = o._zod.bag;
            i.patterns ? ? (i.patterns = new Set), i.patterns.add(n)
        }), e._zod.check = o => {
            o.value.includes(t.includes, t.position) || o.issues.push({
                origin: "string",
                code: "invalid_format",
                format: "includes",
                includes: t.includes,
                input: o.value,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Vr = c("$ZodCheckStartsWith", (e, t) => {
        O.init(e, t);
        const r = new RegExp(`^${F(t.prefix)}.*`);
        t.pattern ? ? (t.pattern = r), e._zod.onattach.push(n => {
            const o = n._zod.bag;
            o.patterns ? ? (o.patterns = new Set), o.patterns.add(r)
        }), e._zod.check = n => {
            n.value.startsWith(t.prefix) || n.issues.push({
                origin: "string",
                code: "invalid_format",
                format: "starts_with",
                prefix: t.prefix,
                input: n.value,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Wr = c("$ZodCheckEndsWith", (e, t) => {
        O.init(e, t);
        const r = new RegExp(`.*${F(t.suffix)}$`);
        t.pattern ? ? (t.pattern = r), e._zod.onattach.push(n => {
            const o = n._zod.bag;
            o.patterns ? ? (o.patterns = new Set), o.patterns.add(r)
        }), e._zod.check = n => {
            n.value.endsWith(t.suffix) || n.issues.push({
                origin: "string",
                code: "invalid_format",
                format: "ends_with",
                suffix: t.suffix,
                input: n.value,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    Br = c("$ZodCheckOverwrite", (e, t) => {
        O.init(e, t), e._zod.check = r => {
            r.value = t.tx(r.value)
        }
    }),
    Kr = class {
        constructor(e = []) {
            this.content = [], this.indent = 0, this && (this.args = e)
        }
        indented(e) {
            this.indent += 1, e(this), this.indent -= 1
        }
        write(e) {
            if (typeof e == "function") {
                e(this, {
                    execution: "sync"
                }), e(this, {
                    execution: "async"
                });
                return
            }
            const t = e.split(`
`).filter(o => o),
                r = Math.min(...t.map(o => o.length - o.trimStart().length)),
                n = t.map(o => o.slice(r)).map(o => " ".repeat(this.indent * 2) + o);
            for (const o of n) this.content.push(o)
        }
        compile() {
            const e = Function,
                t = this ? .args,
                r = [...(this ? .content ? ? [""]).map(n => `  ${n}`)];
            return new e(...t, r.join(`
`))
        }
    },
    Gr = {
        major: 4,
        minor: 4,
        patch: 3
    },
    _ = c("$ZodType", (e, t) => {
        var r;
        e ? ? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Gr;
        const n = [...e._zod.def.checks ? ? []];
        e._zod.traits.has("$ZodCheck") && n.unshift(e);
        for (const o of n)
            for (const i of o._zod.onattach) i(e);
        if (n.length === 0)(r = e._zod).deferred ? ? (r.deferred = []), e._zod.deferred ? .push(() => {
            e._zod.run = e._zod.parse
        });
        else {
            const o = (s, u, a) => {
                    let l = D(s),
                        f;
                    for (const m of u) {
                        if (m._zod.def.when) {
                            if (Gt(s) || !m._zod.def.when(s)) continue
                        } else if (l) continue;
                        const d = s.issues.length,
                            h = m._zod.check(s);
                        if (h instanceof Promise && a ? .async === !1) throw new C;
                        if (f || h instanceof Promise) f = (f ? ? Promise.resolve()).then(async () => {
                            await h, s.issues.length !== d && (l || (l = D(s, d)))
                        });
                        else {
                            if (s.issues.length === d) continue;
                            l || (l = D(s, d))
                        }
                    }
                    return f ? f.then(() => s) : s
                },
                i = (s, u, a) => {
                    if (D(s)) return s.aborted = !0, s;
                    const l = o(u, n, a);
                    if (l instanceof Promise) {
                        if (a.async === !1) throw new C;
                        return l.then(f => e._zod.parse(f, a))
                    }
                    return e._zod.parse(l, a)
                };
            e._zod.run = (s, u) => {
                if (u.skipChecks) return e._zod.parse(s, u);
                if (u.direction === "backward") {
                    const l = e._zod.parse({
                        value: s.value,
                        issues: []
                    }, { ...u,
                        skipChecks: !0
                    });
                    return l instanceof Promise ? l.then(f => i(f, s, u)) : i(l, s, u)
                }
                const a = e._zod.parse(s, u);
                if (a instanceof Promise) {
                    if (u.async === !1) throw new C;
                    return a.then(l => o(l, n, u))
                }
                return o(a, n, u)
            }
        }
        v(e, "~standard", () => ({
            validate: o => {
                try {
                    const i = Xt(e, o);
                    return i.success ? {
                        value: i.data
                    } : {
                        issues: i.error ? .issues
                    }
                } catch {
                    return Ht(e, o).then(s => s.success ? {
                        value: s.data
                    } : {
                        issues: s.error ? .issues
                    })
                }
            },
            vendor: "zod",
            version: 1
        }))
    }),
    he = c("$ZodString", (e, t) => {
        _.init(e, t), e._zod.pattern = [...e ? ._zod.bag ? .patterns ? ? []].pop() ? ? Ir(e._zod.bag), e._zod.parse = (r, n) => {
            if (t.coerce) try {
                r.value = String(r.value)
            } catch {}
            return typeof r.value == "string" || r.issues.push({
                expected: "string",
                code: "invalid_type",
                input: r.value,
                inst: e
            }), r
        }
    }),
    z = c("$ZodStringFormat", (e, t) => {
        se.init(e, t), he.init(e, t)
    }),
    Yr = c("$ZodGUID", (e, t) => {
        t.pattern ? ? (t.pattern = hr), z.init(e, t)
    }),
    qr = c("$ZodUUID", (e, t) => {
        if (t.version) {
            const r = {
                v1: 1,
                v2: 2,
                v3: 3,
                v4: 4,
                v5: 5,
                v6: 6,
                v7: 7,
                v8: 8
            }[t.version];
            if (r === void 0) throw new Error(`Invalid UUID version: "${t.version}"`);
            t.pattern ? ? (t.pattern = ye(r))
        } else t.pattern ? ? (t.pattern = ye());
        z.init(e, t)
    }),
    Xr = c("$ZodEmail", (e, t) => {
        t.pattern ? ? (t.pattern = mr), z.init(e, t)
    }),
    Hr = c("$ZodURL", (e, t) => {
        z.init(e, t), e._zod.check = r => {
            try {
                const n = r.value.trim();
                if (!t.normalize && t.protocol ? .source === kr.source && !/^https?:\/\//i.test(n)) {
                    r.issues.push({
                        code: "invalid_format",
                        format: "url",
                        note: "Invalid URL format",
                        input: r.value,
                        inst: e,
                        continue: !t.abort
                    });
                    return
                }
                const o = new URL(n);
                t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(o.hostname) || r.issues.push({
                    code: "invalid_format",
                    format: "url",
                    note: "Invalid hostname",
                    pattern: t.hostname.source,
                    input: r.value,
                    inst: e,
                    continue: !t.abort
                })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(o.protocol.endsWith(":") ? o.protocol.slice(0, -1) : o.protocol) || r.issues.push({
                    code: "invalid_format",
                    format: "url",
                    note: "Invalid protocol",
                    pattern: t.protocol.source,
                    input: r.value,
                    inst: e,
                    continue: !t.abort
                })), t.normalize ? r.value = o.href : r.value = n;
                return
            } catch {
                r.issues.push({
                    code: "invalid_format",
                    format: "url",
                    input: r.value,
                    inst: e,
                    continue: !t.abort
                })
            }
        }
    }),
    Qr = c("$ZodEmoji", (e, t) => {
        t.pattern ? ? (t.pattern = _r()), z.init(e, t)
    }),
    en = c("$ZodNanoID", (e, t) => {
        t.pattern ? ? (t.pattern = pr), z.init(e, t)
    }),
    tn = c("$ZodCUID", (e, t) => {
        t.pattern ? ? (t.pattern = ur), z.init(e, t)
    }),
    rn = c("$ZodCUID2", (e, t) => {
        t.pattern ? ? (t.pattern = ar), z.init(e, t)
    }),
    nn = c("$ZodULID", (e, t) => {
        t.pattern ? ? (t.pattern = cr), z.init(e, t)
    }),
    on = c("$ZodXID", (e, t) => {
        t.pattern ? ? (t.pattern = lr), z.init(e, t)
    }),
    sn = c("$ZodKSUID", (e, t) => {
        t.pattern ? ? (t.pattern = fr), z.init(e, t)
    }),
    un = c("$ZodISODateTime", (e, t) => {
        t.pattern ? ? (t.pattern = Or(t)), z.init(e, t)
    }),
    an = c("$ZodISODate", (e, t) => {
        t.pattern ? ? (t.pattern = Zr), z.init(e, t)
    }),
    cn = c("$ZodISOTime", (e, t) => {
        t.pattern ? ? (t.pattern = Sr(t)), z.init(e, t)
    }),
    ln = c("$ZodISODuration", (e, t) => {
        t.pattern ? ? (t.pattern = dr), z.init(e, t)
    }),
    fn = c("$ZodIPv4", (e, t) => {
        t.pattern ? ? (t.pattern = gr), z.init(e, t), e._zod.bag.format = "ipv4"
    }),
    pn = c("$ZodIPv6", (e, t) => {
        t.pattern ? ? (t.pattern = br), z.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = r => {
            try {
                new URL(`http://[${r.value}]`)
            } catch {
                r.issues.push({
                    code: "invalid_format",
                    format: "ipv6",
                    input: r.value,
                    inst: e,
                    continue: !t.abort
                })
            }
        }
    }),
    dn = c("$ZodCIDRv4", (e, t) => {
        t.pattern ? ? (t.pattern = zr), z.init(e, t)
    }),
    hn = c("$ZodCIDRv6", (e, t) => {
        t.pattern ? ? (t.pattern = yr), z.init(e, t), e._zod.check = r => {
            const n = r.value.split("/");
            try {
                if (n.length !== 2) throw new Error;
                const [o, i] = n;
                if (!i) throw new Error;
                const s = Number(i);
                if (`${s}` !== i) throw new Error;
                if (s < 0 || s > 128) throw new Error;
                new URL(`http://[${o}]`)
            } catch {
                r.issues.push({
                    code: "invalid_format",
                    format: "cidrv6",
                    input: r.value,
                    inst: e,
                    continue: !t.abort
                })
            }
        }
    });

function st(e) {
    if (e === "") return !0;
    if (/\s/.test(e) || e.length % 4 !== 0) return !1;
    try {
        return atob(e), !0
    } catch {
        return !1
    }
}
var mn = c("$ZodBase64", (e, t) => {
    t.pattern ? ? (t.pattern = wr), z.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = r => {
        st(r.value) || r.issues.push({
            code: "invalid_format",
            format: "base64",
            input: r.value,
            inst: e,
            continue: !t.abort
        })
    }
});

function vn(e) {
    if (!Qe.test(e)) return !1;
    const t = e.replace(/[-_]/g, r => r === "-" ? "+" : "/");
    return st(t.padEnd(Math.ceil(t.length / 4) * 4, "="))
}
var _n = c("$ZodBase64URL", (e, t) => {
        t.pattern ? ? (t.pattern = Qe), z.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = r => {
            vn(r.value) || r.issues.push({
                code: "invalid_format",
                format: "base64url",
                input: r.value,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    gn = c("$ZodE164", (e, t) => {
        t.pattern ? ? (t.pattern = $r), z.init(e, t)
    });

function bn(e, t = null) {
    try {
        const r = e.split(".");
        if (r.length !== 3) return !1;
        const [n] = r;
        if (!n) return !1;
        const o = JSON.parse(atob(n));
        return !("typ" in o && o ? .typ !== "JWT" || !o.alg || t && (!("alg" in o) || o.alg !== t))
    } catch {
        return !1
    }
}
var zn = c("$ZodJWT", (e, t) => {
        z.init(e, t), e._zod.check = r => {
            bn(r.value, t.alg) || r.issues.push({
                code: "invalid_format",
                format: "jwt",
                input: r.value,
                inst: e,
                continue: !t.abort
            })
        }
    }),
    ut = c("$ZodNumber", (e, t) => {
        _.init(e, t), e._zod.pattern = e._zod.bag.pattern ? ? rt, e._zod.parse = (r, n) => {
            if (t.coerce) try {
                r.value = Number(r.value)
            } catch {}
            const o = r.value;
            if (typeof o == "number" && !Number.isNaN(o) && Number.isFinite(o)) return r;
            const i = typeof o == "number" ? Number.isNaN(o) ? "NaN" : Number.isFinite(o) ? void 0 : "Infinity" : void 0;
            return r.issues.push({
                expected: "number",
                code: "invalid_type",
                input: o,
                inst: e,
                ...i ? {
                    received: i
                } : {}
            }), r
        }
    }),
    yn = c("$ZodNumberFormat", (e, t) => {
        Dr.init(e, t), ut.init(e, t)
    }),
    wn = c("$ZodBoolean", (e, t) => {
        _.init(e, t), e._zod.pattern = Pr, e._zod.parse = (r, n) => {
            if (t.coerce) try {
                r.value = !!r.value
            } catch {}
            const o = r.value;
            return typeof o == "boolean" || r.issues.push({
                expected: "boolean",
                code: "invalid_type",
                input: o,
                inst: e
            }), r
        }
    }),
    kn = c("$ZodUndefined", (e, t) => {
        _.init(e, t), e._zod.pattern = Nr, e._zod.values = new Set([void 0]), e._zod.parse = (r, n) => {
            const o = r.value;
            return typeof o > "u" || r.issues.push({
                expected: "undefined",
                code: "invalid_type",
                input: o,
                inst: e
            }), r
        }
    }),
    $n = c("$ZodNull", (e, t) => {
        _.init(e, t), e._zod.pattern = Tr, e._zod.values = new Set([null]), e._zod.parse = (r, n) => {
            const o = r.value;
            return o === null || r.issues.push({
                expected: "null",
                code: "invalid_type",
                input: o,
                inst: e
            }), r
        }
    }),
    Zn = c("$ZodAny", (e, t) => {
        _.init(e, t), e._zod.parse = r => r
    }),
    Sn = c("$ZodUnknown", (e, t) => {
        _.init(e, t), e._zod.parse = r => r
    }),
    On = c("$ZodNever", (e, t) => {
        _.init(e, t), e._zod.parse = (r, n) => (r.issues.push({
            expected: "never",
            code: "invalid_type",
            input: r.value,
            inst: e
        }), r)
    });

function we(e, t, r) {
    e.issues.length && t.issues.push(...N(r, e.issues)), t.value[r] = e.value
}
var In = c("$ZodArray", (e, t) => {
    _.init(e, t), e._zod.parse = (r, n) => {
        const o = r.value;
        if (!Array.isArray(o)) return r.issues.push({
            expected: "array",
            code: "invalid_type",
            input: o,
            inst: e
        }), r;
        r.value = Array(o.length);
        const i = [];
        for (let s = 0; s < o.length; s++) {
            const u = o[s],
                a = t.element._zod.run({
                    value: u,
                    issues: []
                }, n);
            a instanceof Promise ? i.push(a.then(l => we(l, r, s))) : we(a, r, s)
        }
        return i.length ? Promise.all(i).then(() => r) : r
    }
});

function q(e, t, r, n, o, i) {
    const s = r in n;
    if (e.issues.length) {
        if (o && i && !s) return;
        t.issues.push(...N(r, e.issues))
    }
    if (!s && !o) {
        e.issues.length || t.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: void 0,
            path: [r]
        });
        return
    }
    e.value === void 0 ? s && (t.value[r] = void 0) : t.value[r] = e.value
}

function at(e) {
    const t = Object.keys(e.shape);
    for (const n of t)
        if (!e.shape ? .[n] ? ._zod ? .traits ? .has("$ZodType")) throw new Error(`Invalid element at key "${n}": expected a Zod schema`);
    const r = Ft(e.shape);
    return { ...e,
        keys: t,
        keySet: new Set(t),
        numKeys: t.length,
        optionalKeys: new Set(r)
    }
}

function ct(e, t, r, n, o, i) {
    const s = [],
        u = o.keySet,
        a = o.catchall._zod,
        l = a.def.type,
        f = a.optin === "optional",
        m = a.optout === "optional";
    for (const d in t) {
        if (d === "__proto__" || u.has(d)) continue;
        if (l === "never") {
            s.push(d);
            continue
        }
        const h = a.run({
            value: t[d],
            issues: []
        }, n);
        h instanceof Promise ? e.push(h.then(b => q(b, r, d, t, f, m))) : q(h, r, d, t, f, m)
    }
    return s.length && r.issues.push({
        code: "unrecognized_keys",
        keys: s,
        input: t,
        inst: i
    }), e.length ? Promise.all(e).then(() => r) : r
}
var En = c("$ZodObject", (e, t) => {
        if (_.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape") ? .get) {
            const s = t.shape;
            Object.defineProperty(t, "shape", {
                get: () => {
                    const u = { ...s
                    };
                    return Object.defineProperty(t, "shape", {
                        value: u
                    }), u
                }
            })
        }
        const r = ee(() => at(t));
        v(e._zod, "propValues", () => {
            const s = t.shape,
                u = {};
            for (const a in s) {
                const l = s[a]._zod;
                if (l.values) {
                    u[a] ? ? (u[a] = new Set);
                    for (const f of l.values) u[a].add(f)
                }
            }
            return u
        });
        const n = M,
            o = t.catchall;
        let i;
        e._zod.parse = (s, u) => {
            i ? ? (i = r.value);
            const a = s.value;
            if (!n(a)) return s.issues.push({
                expected: "object",
                code: "invalid_type",
                input: a,
                inst: e
            }), s;
            s.value = {};
            const l = [],
                f = i.shape;
            for (const m of i.keys) {
                const d = f[m],
                    h = d._zod.optin === "optional",
                    b = d._zod.optout === "optional",
                    $ = d._zod.run({
                        value: a[m],
                        issues: []
                    }, u);
                $ instanceof Promise ? l.push($.then(W => q(W, s, m, a, h, b))) : q($, s, m, a, h, b)
            }
            return o ? ct(l, a, s, u, r.value, e) : l.length ? Promise.all(l).then(() => s) : s
        }
    }),
    Pn = c("$ZodObjectJIT", (e, t) => {
        En.init(e, t);
        const r = e._zod.parse,
            n = ee(() => at(t)),
            o = d => {
                const h = new Kr(["shape", "payload", "ctx"]),
                    b = n.value,
                    $ = E => {
                        const w = ze(E);
                        return `shape[${w}]._zod.run({ value: input[${w}], issues: [] }, ctx)`
                    };
                h.write("const input = payload.value;");
                const W = Object.create(null);
                let Nt = 0;
                for (const E of b.keys) W[E] = `key_${Nt++}`;
                h.write("const newResult = {};");
                for (const E of b.keys) {
                    const w = W[E],
                        Z = ze(E),
                        ve = d[E],
                        _e = ve ? ._zod ? .optin === "optional",
                        jt = ve ? ._zod ? .optout === "optional";
                    h.write(`const ${w} = ${$(E)};`), _e && jt ? h.write(`
        if (${w}.issues.length) {
          if (${Z} in input) {
            payload.issues = payload.issues.concat(${w}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${Z}, ...iss.path] : [${Z}]
            })));
          }
        }
        
        if (${w}.value === undefined) {
          if (${Z} in input) {
            newResult[${Z}] = undefined;
          }
        } else {
          newResult[${Z}] = ${w}.value;
        }
        
      `) : _e ? h.write(`
        if (${w}.issues.length) {
          payload.issues = payload.issues.concat(${w}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${Z}, ...iss.path] : [${Z}]
          })));
        }
        
        if (${w}.value === undefined) {
          if (${Z} in input) {
            newResult[${Z}] = undefined;
          }
        } else {
          newResult[${Z}] = ${w}.value;
        }
        
      `) : h.write(`
        const ${w}_present = ${Z} in input;
        if (${w}.issues.length) {
          payload.issues = payload.issues.concat(${w}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${Z}, ...iss.path] : [${Z}]
          })));
        }
        if (!${w}_present && !${w}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${Z}]
          });
        }

        if (${w}_present) {
          if (${w}.value === undefined) {
            newResult[${Z}] = undefined;
          } else {
            newResult[${Z}] = ${w}.value;
          }
        }

      `)
                }
                h.write("payload.value = newResult;"), h.write("return payload;");
                const At = h.compile();
                return (E, w) => At(d, E, w)
            };
        let i;
        const s = M,
            u = !Y.jitless,
            l = u && Ct.value,
            f = t.catchall;
        let m;
        e._zod.parse = (d, h) => {
            m ? ? (m = n.value);
            const b = d.value;
            return s(b) ? u && l && h ? .async === !1 && h.jitless !== !0 ? (i || (i = o(t.shape)), d = i(d, h), f ? ct([], b, d, h, m, e) : d) : r(d, h) : (d.issues.push({
                expected: "object",
                code: "invalid_type",
                input: b,
                inst: e
            }), d)
        }
    });

function ke(e, t, r, n) {
    for (const i of e)
        if (i.issues.length === 0) return t.value = i.value, t;
    const o = e.filter(i => !D(i));
    return o.length === 1 ? (t.value = o[0].value, o[0]) : (t.issues.push({
        code: "invalid_union",
        input: t.value,
        inst: r,
        errors: e.map(i => i.issues.map(s => T(s, n, P())))
    }), t)
}
var lt = c("$ZodUnion", (e, t) => {
        _.init(e, t), v(e._zod, "optin", () => t.options.some(n => n._zod.optin === "optional") ? "optional" : void 0), v(e._zod, "optout", () => t.options.some(n => n._zod.optout === "optional") ? "optional" : void 0), v(e._zod, "values", () => {
            if (t.options.every(n => n._zod.values)) return new Set(t.options.flatMap(n => Array.from(n._zod.values)))
        }), v(e._zod, "pattern", () => {
            if (t.options.every(n => n._zod.pattern)) {
                const n = t.options.map(o => o._zod.pattern);
                return new RegExp(`^(${n.map(o=>pe(o.source)).join("|")})$`)
            }
        });
        const r = t.options.length === 1 ? t.options[0]._zod.run : null;
        e._zod.parse = (n, o) => {
            if (r) return r(n, o);
            let i = !1;
            const s = [];
            for (const u of t.options) {
                const a = u._zod.run({
                    value: n.value,
                    issues: []
                }, o);
                if (a instanceof Promise) s.push(a), i = !0;
                else {
                    if (a.issues.length === 0) return a;
                    s.push(a)
                }
            }
            return i ? Promise.all(s).then(u => ke(u, n, e, o)) : ke(s, n, e, o)
        }
    }),
    Tn = c("$ZodDiscriminatedUnion", (e, t) => {
        t.inclusive = !1, lt.init(e, t);
        const r = e._zod.parse;
        v(e._zod, "propValues", () => {
            const o = {};
            for (const i of t.options) {
                const s = i._zod.propValues;
                if (!s || Object.keys(s).length === 0) throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(i)}"`);
                for (const [u, a] of Object.entries(s)) {
                    o[u] || (o[u] = new Set);
                    for (const l of a) o[u].add(l)
                }
            }
            return o
        });
        const n = ee(() => {
            const o = t.options,
                i = new Map;
            for (const s of o) {
                const u = s._zod.propValues ? .[t.discriminator];
                if (!u || u.size === 0) throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(s)}"`);
                for (const a of u) {
                    if (i.has(a)) throw new Error(`Duplicate discriminator value "${String(a)}"`);
                    i.set(a, s)
                }
            }
            return i
        });
        e._zod.parse = (o, i) => {
            const s = o.value;
            if (!M(s)) return o.issues.push({
                code: "invalid_type",
                expected: "object",
                input: s,
                inst: e
            }), o;
            const u = n.value.get(s ? .[t.discriminator]);
            return u ? u._zod.run(o, i) : t.unionFallback || i.direction === "backward" ? r(o, i) : (o.issues.push({
                code: "invalid_union",
                errors: [],
                note: "No matching discriminator",
                discriminator: t.discriminator,
                options: Array.from(n.value.keys()),
                input: s,
                path: [t.discriminator],
                inst: e
            }), o)
        }
    }),
    Nn = c("$ZodIntersection", (e, t) => {
        _.init(e, t), e._zod.parse = (r, n) => {
            const o = r.value,
                i = t.left._zod.run({
                    value: o,
                    issues: []
                }, n),
                s = t.right._zod.run({
                    value: o,
                    issues: []
                }, n);
            return i instanceof Promise || s instanceof Promise ? Promise.all([i, s]).then(([u, a]) => $e(r, u, a)) : $e(r, i, s)
        }
    });

function le(e, t) {
    if (e === t) return {
        valid: !0,
        data: e
    };
    if (e instanceof Date && t instanceof Date && +e == +t) return {
        valid: !0,
        data: e
    };
    if (U(e) && U(t)) {
        const r = Object.keys(t),
            n = Object.keys(e).filter(i => r.indexOf(i) !== -1),
            o = { ...e,
                ...t
            };
        for (const i of n) {
            const s = le(e[i], t[i]);
            if (!s.valid) return {
                valid: !1,
                mergeErrorPath: [i, ...s.mergeErrorPath]
            };
            o[i] = s.data
        }
        return {
            valid: !0,
            data: o
        }
    }
    if (Array.isArray(e) && Array.isArray(t)) {
        if (e.length !== t.length) return {
            valid: !1,
            mergeErrorPath: []
        };
        const r = [];
        for (let n = 0; n < e.length; n++) {
            const o = e[n],
                i = t[n],
                s = le(o, i);
            if (!s.valid) return {
                valid: !1,
                mergeErrorPath: [n, ...s.mergeErrorPath]
            };
            r.push(s.data)
        }
        return {
            valid: !0,
            data: r
        }
    }
    return {
        valid: !1,
        mergeErrorPath: []
    }
}

function $e(e, t, r) {
    const n = new Map;
    let o;
    for (const u of t.issues)
        if (u.code === "unrecognized_keys") {
            o ? ? (o = u);
            for (const a of u.keys) n.has(a) || n.set(a, {}), n.get(a).l = !0
        } else e.issues.push(u);
    for (const u of r.issues)
        if (u.code === "unrecognized_keys")
            for (const a of u.keys) n.has(a) || n.set(a, {}), n.get(a).r = !0;
        else e.issues.push(u);
    const i = [...n].filter(([, u]) => u.l && u.r).map(([u]) => u);
    if (i.length && o && e.issues.push({ ...o,
            keys: i
        }), D(e)) return e;
    const s = le(t.value, r.value);
    if (!s.valid) throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(s.mergeErrorPath)}`);
    return e.value = s.data, e
}
var An = c("$ZodTuple", (e, t) => {
    _.init(e, t);
    const r = t.items;
    e._zod.parse = (n, o) => {
        const i = n.value;
        if (!Array.isArray(i)) return n.issues.push({
            input: i,
            inst: e,
            expected: "tuple",
            code: "invalid_type"
        }), n;
        n.value = [];
        const s = [],
            u = Ze(r, "optin"),
            a = Ze(r, "optout");
        if (!t.rest) {
            if (i.length < u) return n.issues.push({
                code: "too_small",
                minimum: u,
                inclusive: !0,
                input: i,
                inst: e,
                origin: "array"
            }), n;
            i.length > r.length && n.issues.push({
                code: "too_big",
                maximum: r.length,
                inclusive: !0,
                input: i,
                inst: e,
                origin: "array"
            })
        }
        const l = new Array(r.length);
        for (let f = 0; f < r.length; f++) {
            const m = r[f]._zod.run({
                value: i[f],
                issues: []
            }, o);
            m instanceof Promise ? s.push(m.then(d => {
                l[f] = d
            })) : l[f] = m
        }
        if (t.rest) {
            let f = r.length - 1;
            const m = i.slice(r.length);
            for (const d of m) {
                f++;
                const h = t.rest._zod.run({
                    value: d,
                    issues: []
                }, o);
                h instanceof Promise ? s.push(h.then(b => Se(b, n, f))) : Se(h, n, f)
            }
        }
        return s.length ? Promise.all(s).then(() => Oe(l, n, r, i, a)) : Oe(l, n, r, i, a)
    }
});

function Ze(e, t) {
    for (let r = e.length - 1; r >= 0; r--)
        if (e[r]._zod[t] !== "optional") return r + 1;
    return 0
}

function Se(e, t, r) {
    e.issues.length && t.issues.push(...N(r, e.issues)), t.value[r] = e.value
}

function Oe(e, t, r, n, o) {
    for (let i = 0; i < r.length; i++) {
        const s = e[i],
            u = i < n.length;
        if (s.issues.length) {
            if (!u && i >= o) {
                t.value.length = i;
                break
            }
            t.issues.push(...N(i, s.issues))
        }
        t.value[i] = s.value
    }
    for (let i = t.value.length - 1; i >= n.length && (r[i]._zod.optout === "optional" && t.value[i] === void 0); i--) t.value.length = i;
    return t
}
var jn = c("$ZodRecord", (e, t) => {
        _.init(e, t), e._zod.parse = (r, n) => {
            const o = r.value;
            if (!U(o)) return r.issues.push({
                expected: "record",
                code: "invalid_type",
                input: o,
                inst: e
            }), r;
            const i = [],
                s = t.keyType._zod.values;
            if (s) {
                r.value = {};
                const u = new Set;
                for (const l of s)
                    if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
                        u.add(typeof l == "number" ? l.toString() : l);
                        const f = t.keyType._zod.run({
                            value: l,
                            issues: []
                        }, n);
                        if (f instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
                        if (f.issues.length) {
                            r.issues.push({
                                code: "invalid_key",
                                origin: "record",
                                issues: f.issues.map(h => T(h, n, P())),
                                input: l,
                                path: [l],
                                inst: e
                            });
                            continue
                        }
                        const m = f.value,
                            d = t.valueType._zod.run({
                                value: o[l],
                                issues: []
                            }, n);
                        d instanceof Promise ? i.push(d.then(h => {
                            h.issues.length && r.issues.push(...N(l, h.issues)), r.value[m] = h.value
                        })) : (d.issues.length && r.issues.push(...N(l, d.issues)), r.value[m] = d.value)
                    }
                let a;
                for (const l in o) u.has(l) || (a = a ? ? [], a.push(l));
                a && a.length > 0 && r.issues.push({
                    code: "unrecognized_keys",
                    input: o,
                    inst: e,
                    keys: a
                })
            } else {
                r.value = {};
                for (const u of Reflect.ownKeys(o)) {
                    if (u === "__proto__" || !Object.prototype.propertyIsEnumerable.call(o, u)) continue;
                    let a = t.keyType._zod.run({
                        value: u,
                        issues: []
                    }, n);
                    if (a instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
                    if (typeof u == "string" && rt.test(u) && a.issues.length) {
                        const f = t.keyType._zod.run({
                            value: Number(u),
                            issues: []
                        }, n);
                        if (f instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
                        f.issues.length === 0 && (a = f)
                    }
                    if (a.issues.length) {
                        t.mode === "loose" ? r.value[u] = o[u] : r.issues.push({
                            code: "invalid_key",
                            origin: "record",
                            issues: a.issues.map(f => T(f, n, P())),
                            input: u,
                            path: [u],
                            inst: e
                        });
                        continue
                    }
                    const l = t.valueType._zod.run({
                        value: o[u],
                        issues: []
                    }, n);
                    l instanceof Promise ? i.push(l.then(f => {
                        f.issues.length && r.issues.push(...N(u, f.issues)), r.value[a.value] = f.value
                    })) : (l.issues.length && r.issues.push(...N(u, l.issues)), r.value[a.value] = l.value)
                }
            }
            return i.length ? Promise.all(i).then(() => r) : r
        }
    }),
    Rn = c("$ZodEnum", (e, t) => {
        _.init(e, t);
        const r = Ge(t.entries),
            n = new Set(r);
        e._zod.values = n, e._zod.pattern = new RegExp(`^(${r.filter(o=>Ut.has(typeof o)).map(o=>typeof o=="string"?F(o):o.toString()).join("|")})$`), e._zod.parse = (o, i) => {
            const s = o.value;
            return n.has(s) || o.issues.push({
                code: "invalid_value",
                values: r,
                input: s,
                inst: e
            }), o
        }
    }),
    Dn = c("$ZodLiteral", (e, t) => {
        if (_.init(e, t), t.values.length === 0) throw new Error("Cannot create literal schema with no valid values");
        const r = new Set(t.values);
        e._zod.values = r, e._zod.pattern = new RegExp(`^(${t.values.map(n=>typeof n=="string"?F(n):n?F(n.toString()):String(n)).join("|")})$`), e._zod.parse = (n, o) => {
            const i = n.value;
            return r.has(i) || n.issues.push({
                code: "invalid_value",
                values: t.values,
                input: i,
                inst: e
            }), n
        }
    }),
    Cn = c("$ZodTransform", (e, t) => {
        _.init(e, t), e._zod.optin = "optional", e._zod.parse = (r, n) => {
            if (n.direction === "backward") throw new Ke(e.constructor.name);
            const o = t.transform(r.value, r);
            if (n.async) return (o instanceof Promise ? o : Promise.resolve(o)).then(i => (r.value = i, r.fallback = !0, r));
            if (o instanceof Promise) throw new C;
            return r.value = o, r.fallback = !0, r
        }
    });

function Ie(e, t) {
    return t === void 0 && (e.issues.length || e.fallback) ? {
        issues: [],
        value: void 0
    } : e
}
var ft = c("$ZodOptional", (e, t) => {
        _.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", v(e._zod, "values", () => t.innerType._zod.values ? new Set([...t.innerType._zod.values, void 0]) : void 0), v(e._zod, "pattern", () => {
            const r = t.innerType._zod.pattern;
            return r ? new RegExp(`^(${pe(r.source)})?$`) : void 0
        }), e._zod.parse = (r, n) => {
            if (t.innerType._zod.optin === "optional") {
                const o = r.value,
                    i = t.innerType._zod.run(r, n);
                return i instanceof Promise ? i.then(s => Ie(s, o)) : Ie(i, o)
            }
            return r.value === void 0 ? r : t.innerType._zod.run(r, n)
        }
    }),
    Un = c("$ZodExactOptional", (e, t) => {
        ft.init(e, t), v(e._zod, "values", () => t.innerType._zod.values), v(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (r, n) => t.innerType._zod.run(r, n)
    }),
    Fn = c("$ZodNullable", (e, t) => {
        _.init(e, t), v(e._zod, "optin", () => t.innerType._zod.optin), v(e._zod, "optout", () => t.innerType._zod.optout), v(e._zod, "pattern", () => {
            const r = t.innerType._zod.pattern;
            return r ? new RegExp(`^(${pe(r.source)}|null)$`) : void 0
        }), v(e._zod, "values", () => t.innerType._zod.values ? new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (r, n) => r.value === null ? r : t.innerType._zod.run(r, n)
    }),
    xn = c("$ZodDefault", (e, t) => {
        _.init(e, t), e._zod.optin = "optional", v(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => {
            if (n.direction === "backward") return t.innerType._zod.run(r, n);
            if (r.value === void 0) return r.value = t.defaultValue, r;
            const o = t.innerType._zod.run(r, n);
            return o instanceof Promise ? o.then(i => Ee(i, t)) : Ee(o, t)
        }
    });

function Ee(e, t) {
    return e.value === void 0 && (e.value = t.defaultValue), e
}
var Jn = c("$ZodPrefault", (e, t) => {
        _.init(e, t), e._zod.optin = "optional", v(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => (n.direction === "backward" || r.value === void 0 && (r.value = t.defaultValue), t.innerType._zod.run(r, n))
    }),
    Mn = c("$ZodNonOptional", (e, t) => {
        _.init(e, t), v(e._zod, "values", () => {
            const r = t.innerType._zod.values;
            return r ? new Set([...r].filter(n => n !== void 0)) : void 0
        }), e._zod.parse = (r, n) => {
            const o = t.innerType._zod.run(r, n);
            return o instanceof Promise ? o.then(i => Pe(i, e)) : Pe(o, e)
        }
    });

function Pe(e, t) {
    return !e.issues.length && e.value === void 0 && e.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: e.value,
        inst: t
    }), e
}
var Ln = c("$ZodCatch", (e, t) => {
        _.init(e, t), e._zod.optin = "optional", v(e._zod, "optout", () => t.innerType._zod.optout), v(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => {
            if (n.direction === "backward") return t.innerType._zod.run(r, n);
            const o = t.innerType._zod.run(r, n);
            return o instanceof Promise ? o.then(i => (r.value = i.value, i.issues.length && (r.value = t.catchValue({ ...r,
                error: {
                    issues: i.issues.map(s => T(s, n, P()))
                },
                input: r.value
            }), r.issues = [], r.fallback = !0), r)) : (r.value = o.value, o.issues.length && (r.value = t.catchValue({ ...r,
                error: {
                    issues: o.issues.map(i => T(i, n, P()))
                },
                input: r.value
            }), r.issues = [], r.fallback = !0), r)
        }
    }),
    pt = c("$ZodPipe", (e, t) => {
        _.init(e, t), v(e._zod, "values", () => t.in._zod.values), v(e._zod, "optin", () => t.in._zod.optin), v(e._zod, "optout", () => t.out._zod.optout), v(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (r, n) => {
            if (n.direction === "backward") {
                const i = t.out._zod.run(r, n);
                return i instanceof Promise ? i.then(s => K(s, t.in, n)) : K(i, t.in, n)
            }
            const o = t.in._zod.run(r, n);
            return o instanceof Promise ? o.then(i => K(i, t.out, n)) : K(o, t.out, n)
        }
    });

function K(e, t, r) {
    return e.issues.length ? (e.aborted = !0, e) : t._zod.run({
        value: e.value,
        issues: e.issues,
        fallback: e.fallback
    }, r)
}
var Vn = c("$ZodPreprocess", (e, t) => {
        pt.init(e, t)
    }),
    Wn = c("$ZodReadonly", (e, t) => {
        _.init(e, t), v(e._zod, "propValues", () => t.innerType._zod.propValues), v(e._zod, "values", () => t.innerType._zod.values), v(e._zod, "optin", () => t.innerType ? ._zod ? .optin), v(e._zod, "optout", () => t.innerType ? ._zod ? .optout), e._zod.parse = (r, n) => {
            if (n.direction === "backward") return t.innerType._zod.run(r, n);
            const o = t.innerType._zod.run(r, n);
            return o instanceof Promise ? o.then(Te) : Te(o)
        }
    });

function Te(e) {
    return e.value = Object.freeze(e.value), e
}
var Bn = c("$ZodCustom", (e, t) => {
    O.init(e, t), _.init(e, t), e._zod.parse = (r, n) => r, e._zod.check = r => {
        const n = r.value,
            o = t.fn(n);
        if (o instanceof Promise) return o.then(i => Ne(i, r, n, e));
        Ne(o, r, n, e)
    }
});

function Ne(e, t, r, n) {
    if (!e) {
        const o = {
            code: "custom",
            input: r,
            inst: n,
            path: [...n._zod.def.path ? ? []],
            continue: !n._zod.def.abort
        };
        n._zod.def.params && (o.params = n._zod.def.params), t.issues.push(L(o))
    }
}
var Ae, Kn = class {
    constructor() {
        this._map = new WeakMap, this._idmap = new Map
    }
    add(e, ...t) {
        const r = t[0];
        return this._map.set(e, r), r && typeof r == "object" && "id" in r && this._idmap.set(r.id, e), this
    }
    clear() {
        return this._map = new WeakMap, this._idmap = new Map, this
    }
    remove(e) {
        const t = this._map.get(e);
        return t && typeof t == "object" && "id" in t && this._idmap.delete(t.id), this._map.delete(e), this
    }
    get(e) {
        const t = e._zod.parent;
        if (t) {
            const r = { ...this.get(t) ? ? {}
            };
            delete r.id;
            const n = { ...r,
                ...this._map.get(e)
            };
            return Object.keys(n).length ? n : void 0
        }
        return this._map.get(e)
    }
    has(e) {
        return this._map.has(e)
    }
};

function Gn() {
    return new Kn
}(Ae = globalThis).__zod_globalRegistry ? ? (Ae.__zod_globalRegistry = Gn());
var J = globalThis.__zod_globalRegistry;

function Yn(e, t) {
    return new e({
        type: "string",
        ...p(t)
    })
}

function dt(e, t) {
    return new e({
        type: "string",
        format: "email",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function je(e, t) {
    return new e({
        type: "string",
        format: "guid",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function qn(e, t) {
    return new e({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function Xn(e, t) {
    return new e({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: !1,
        version: "v4",
        ...p(t)
    })
}

function Hn(e, t) {
    return new e({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: !1,
        version: "v6",
        ...p(t)
    })
}

function Qn(e, t) {
    return new e({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: !1,
        version: "v7",
        ...p(t)
    })
}

function ht(e, t) {
    return new e({
        type: "string",
        format: "url",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function eo(e, t) {
    return new e({
        type: "string",
        format: "emoji",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function to(e, t) {
    return new e({
        type: "string",
        format: "nanoid",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function ro(e, t) {
    return new e({
        type: "string",
        format: "cuid",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function no(e, t) {
    return new e({
        type: "string",
        format: "cuid2",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function oo(e, t) {
    return new e({
        type: "string",
        format: "ulid",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function io(e, t) {
    return new e({
        type: "string",
        format: "xid",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function so(e, t) {
    return new e({
        type: "string",
        format: "ksuid",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function uo(e, t) {
    return new e({
        type: "string",
        format: "ipv4",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function ao(e, t) {
    return new e({
        type: "string",
        format: "ipv6",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function co(e, t) {
    return new e({
        type: "string",
        format: "cidrv4",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function lo(e, t) {
    return new e({
        type: "string",
        format: "cidrv6",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function fo(e, t) {
    return new e({
        type: "string",
        format: "base64",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function po(e, t) {
    return new e({
        type: "string",
        format: "base64url",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function ho(e, t) {
    return new e({
        type: "string",
        format: "e164",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function mo(e, t) {
    return new e({
        type: "string",
        format: "jwt",
        check: "string_format",
        abort: !1,
        ...p(t)
    })
}

function vo(e, t) {
    return new e({
        type: "string",
        format: "datetime",
        check: "string_format",
        offset: !1,
        local: !1,
        precision: null,
        ...p(t)
    })
}

function _o(e, t) {
    return new e({
        type: "string",
        format: "date",
        check: "string_format",
        ...p(t)
    })
}

function go(e, t) {
    return new e({
        type: "string",
        format: "time",
        check: "string_format",
        precision: null,
        ...p(t)
    })
}

function bo(e, t) {
    return new e({
        type: "string",
        format: "duration",
        check: "string_format",
        ...p(t)
    })
}

function zo(e, t) {
    return new e({
        type: "number",
        checks: [],
        ...p(t)
    })
}

function yo(e, t) {
    return new e({
        type: "number",
        coerce: !0,
        checks: [],
        ...p(t)
    })
}

function wo(e, t) {
    return new e({
        type: "number",
        check: "number_format",
        abort: !1,
        format: "safeint",
        ...p(t)
    })
}

function ko(e, t) {
    return new e({
        type: "boolean",
        ...p(t)
    })
}

function $o(e, t) {
    return new e({
        type: "undefined",
        ...p(t)
    })
}

function Zo(e, t) {
    return new e({
        type: "null",
        ...p(t)
    })
}

function So(e) {
    return new e({
        type: "any"
    })
}

function Oo(e) {
    return new e({
        type: "unknown"
    })
}

function Io(e, t) {
    return new e({
        type: "never",
        ...p(t)
    })
}

function Re(e, t) {
    return new ot({
        check: "less_than",
        ...p(t),
        value: e,
        inclusive: !1
    })
}

function ue(e, t) {
    return new ot({
        check: "less_than",
        ...p(t),
        value: e,
        inclusive: !0
    })
}

function De(e, t) {
    return new it({
        check: "greater_than",
        ...p(t),
        value: e,
        inclusive: !1
    })
}

function ae(e, t) {
    return new it({
        check: "greater_than",
        ...p(t),
        value: e,
        inclusive: !0
    })
}

function Ce(e, t) {
    return new Rr({
        check: "multiple_of",
        ...p(t),
        value: e
    })
}

function mt(e, t) {
    return new Cr({
        check: "max_length",
        ...p(t),
        maximum: e
    })
}

function X(e, t) {
    return new Ur({
        check: "min_length",
        ...p(t),
        minimum: e
    })
}

function vt(e, t) {
    return new Fr({
        check: "length_equals",
        ...p(t),
        length: e
    })
}

function Eo(e, t) {
    return new xr({
        check: "string_format",
        format: "regex",
        ...p(t),
        pattern: e
    })
}

function Po(e) {
    return new Jr({
        check: "string_format",
        format: "lowercase",
        ...p(e)
    })
}

function To(e) {
    return new Mr({
        check: "string_format",
        format: "uppercase",
        ...p(e)
    })
}

function No(e, t) {
    return new Lr({
        check: "string_format",
        format: "includes",
        ...p(t),
        includes: e
    })
}

function Ao(e, t) {
    return new Vr({
        check: "string_format",
        format: "starts_with",
        ...p(t),
        prefix: e
    })
}

function jo(e, t) {
    return new Wr({
        check: "string_format",
        format: "ends_with",
        ...p(t),
        suffix: e
    })
}

function x(e) {
    return new Br({
        check: "overwrite",
        tx: e
    })
}

function Ro(e) {
    return x(t => t.normalize(e))
}

function Do() {
    return x(e => e.trim())
}

function Co() {
    return x(e => e.toLowerCase())
}

function Uo() {
    return x(e => e.toUpperCase())
}

function Fo() {
    return x(e => Dt(e))
}

function xo(e, t, r) {
    return new e({
        type: "array",
        element: t,
        ...p(r)
    })
}

function Jo(e, t, r) {
    const n = p(r);
    return n.abort ? ? (n.abort = !0), new e({
        type: "custom",
        check: "custom",
        fn: t,
        ...n
    })
}

function Mo(e, t, r) {
    return new e({
        type: "custom",
        check: "custom",
        fn: t,
        ...p(r)
    })
}

function Lo(e, t) {
    const r = Vo(n => (n.addIssue = o => {
        if (typeof o == "string") n.issues.push(L(o, n.value, r._zod.def));
        else {
            const i = o;
            i.fatal && (i.continue = !1), i.code ? ? (i.code = "custom"), i.input ? ? (i.input = n.value), i.inst ? ? (i.inst = r), i.continue ? ? (i.continue = !r._zod.def.abort), n.issues.push(L(i))
        }
    }, e(n.value, n)), t);
    return r
}

function Vo(e, t) {
    const r = new O({
        check: "custom",
        ...p(t)
    });
    return r._zod.check = e, r
}

function _t(e) {
    let t = e ? .target ? ? "draft-2020-12";
    return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
        processors: e.processors ? ? {},
        metadataRegistry: e ? .metadata ? ? J,
        target: t,
        unrepresentable: e ? .unrepresentable ? ? "throw",
        override: e ? .override ? ? (() => {}),
        io: e ? .io ? ? "output",
        counter: 0,
        seen: new Map,
        cycles: e ? .cycles ? ? "ref",
        reused: e ? .reused ? ? "inline",
        external: e ? .external ? ? void 0
    }
}

function k(e, t, r = {
    path: [],
    schemaPath: []
}) {
    var n;
    const o = e._zod.def,
        i = t.seen.get(e);
    if (i) return i.count++, r.schemaPath.includes(e) && (i.cycle = r.path), i.schema;
    const s = {
        schema: {},
        count: 1,
        cycle: void 0,
        path: r.path
    };
    t.seen.set(e, s);
    const u = e._zod.toJSONSchema ? .();
    if (u) s.schema = u;
    else {
        const l = { ...r,
            schemaPath: [...r.schemaPath, e],
            path: r.path
        };
        if (e._zod.processJSONSchema) e._zod.processJSONSchema(t, s.schema, l);
        else {
            const m = s.schema,
                d = t.processors[o.type];
            if (!d) throw new Error(`[toJSONSchema]: Non-representable type encountered: ${o.type}`);
            d(e, t, m, l)
        }
        const f = e._zod.parent;
        f && (s.ref || (s.ref = f), k(f, t, l), t.seen.get(f).isParent = !0)
    }
    const a = t.metadataRegistry.get(e);
    return a && Object.assign(s.schema, a), t.io === "input" && S(e) && (delete s.schema.examples, delete s.schema.default), t.io === "input" && "_prefault" in s.schema && ((n = s.schema).default ? ? (n.default = s.schema._prefault)), delete s.schema._prefault, t.seen.get(e).schema
}

function gt(e, t) {
    const r = e.seen.get(t);
    if (!r) throw new Error("Unprocessed schema. This is a bug in Zod.");
    const n = new Map;
    for (const s of e.seen.entries()) {
        const u = e.metadataRegistry.get(s[0]) ? .id;
        if (u) {
            const a = n.get(u);
            if (a && a !== s[0]) throw new Error(`Duplicate schema id "${u}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
            n.set(u, s[0])
        }
    }
    const o = s => {
            const u = e.target === "draft-2020-12" ? "$defs" : "definitions";
            if (e.external) {
                const f = e.external.registry.get(s[0]) ? .id,
                    m = e.external.uri ? ? (h => h);
                if (f) return {
                    ref: m(f)
                };
                const d = s[1].defId ? ? s[1].schema.id ? ? `schema${e.counter++}`;
                return s[1].defId = d, {
                    defId: d,
                    ref: `${m("__shared")}#/${u}/${d}`
                }
            }
            if (s[1] === r) return {
                ref: "#"
            };
            const a = `#/${u}/`,
                l = s[1].schema.id ? ? `__schema${e.counter++}`;
            return {
                defId: l,
                ref: a + l
            }
        },
        i = s => {
            if (s[1].schema.$ref) return;
            const u = s[1],
                {
                    ref: a,
                    defId: l
                } = o(s);
            u.def = { ...u.schema
            }, l && (u.defId = l);
            const f = u.schema;
            for (const m in f) delete f[m];
            f.$ref = a
        };
    if (e.cycles === "throw")
        for (const s of e.seen.entries()) {
            const u = s[1];
            if (u.cycle) throw new Error(`Cycle detected: #/${u.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`)
        }
    for (const s of e.seen.entries()) {
        const u = s[1];
        if (t === s[0]) {
            i(s);
            continue
        }
        if (e.external) {
            const a = e.external.registry.get(s[0]) ? .id;
            if (t !== s[0] && a) {
                i(s);
                continue
            }
        }
        if (e.metadataRegistry.get(s[0]) ? .id) {
            i(s);
            continue
        }
        if (u.cycle) {
            i(s);
            continue
        }
        if (u.count > 1 && e.reused === "ref") {
            i(s);
            continue
        }
    }
}

function bt(e, t) {
    const r = e.seen.get(t);
    if (!r) throw new Error("Unprocessed schema. This is a bug in Zod.");
    const n = u => {
        const a = e.seen.get(u);
        if (a.ref === null) return;
        const l = a.def ? ? a.schema,
            f = { ...l
            },
            m = a.ref;
        if (a.ref = null, m) {
            n(m);
            const h = e.seen.get(m),
                b = h.schema;
            if (b.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ? ? [], l.allOf.push(b)) : Object.assign(l, b), Object.assign(l, f), u._zod.parent === m)
                for (const $ in l) $ === "$ref" || $ === "allOf" || $ in f || delete l[$];
            if (b.$ref && h.def)
                for (const $ in l) $ === "$ref" || $ === "allOf" || $ in h.def && JSON.stringify(l[$]) === JSON.stringify(h.def[$]) && delete l[$]
        }
        const d = u._zod.parent;
        if (d && d !== m) {
            n(d);
            const h = e.seen.get(d);
            if (h ? .schema.$ref && (l.$ref = h.schema.$ref, h.def))
                for (const b in l) b === "$ref" || b === "allOf" || b in h.def && JSON.stringify(l[b]) === JSON.stringify(h.def[b]) && delete l[b]
        }
        e.override({
            zodSchema: u,
            jsonSchema: l,
            path: a.path ? ? []
        })
    };
    for (const u of [...e.seen.entries()].reverse()) n(u[0]);
    const o = {};
    if (e.target === "draft-2020-12" ? o.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? o.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? o.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external ? .uri) {
        const u = e.external.registry.get(t) ? .id;
        if (!u) throw new Error("Schema is missing an `id` property");
        o.$id = e.external.uri(u)
    }
    Object.assign(o, r.def ? ? r.schema);
    const i = e.metadataRegistry.get(t) ? .id;
    i !== void 0 && o.id === i && delete o.id;
    const s = e.external ? .defs ? ? {};
    for (const u of e.seen.entries()) {
        const a = u[1];
        a.def && a.defId && (a.def.id === a.defId && delete a.def.id, s[a.defId] = a.def)
    }
    e.external || Object.keys(s).length > 0 && (e.target === "draft-2020-12" ? o.$defs = s : o.definitions = s);
    try {
        const u = JSON.parse(JSON.stringify(o));
        return Object.defineProperty(u, "~standard", {
            value: { ...t["~standard"],
                jsonSchema: {
                    input: H(t, "input", e.processors),
                    output: H(t, "output", e.processors)
                }
            },
            enumerable: !1,
            writable: !1
        }), u
    } catch {
        throw new Error("Error converting schema to JSON.")
    }
}

function S(e, t) {
    const r = t ? ? {
        seen: new Set
    };
    if (r.seen.has(e)) return !1;
    r.seen.add(e);
    const n = e._zod.def;
    if (n.type === "transform") return !0;
    if (n.type === "array") return S(n.element, r);
    if (n.type === "set") return S(n.valueType, r);
    if (n.type === "lazy") return S(n.getter(), r);
    if (n.type === "promise" || n.type === "optional" || n.type === "nonoptional" || n.type === "nullable" || n.type === "readonly" || n.type === "default" || n.type === "prefault") return S(n.innerType, r);
    if (n.type === "intersection") return S(n.left, r) || S(n.right, r);
    if (n.type === "record" || n.type === "map") return S(n.keyType, r) || S(n.valueType, r);
    if (n.type === "pipe") return e._zod.traits.has("$ZodCodec") ? !0 : S(n.in, r) || S(n.out, r);
    if (n.type === "object") {
        for (const o in n.shape)
            if (S(n.shape[o], r)) return !0;
        return !1
    }
    if (n.type === "union") {
        for (const o of n.options)
            if (S(o, r)) return !0;
        return !1
    }
    if (n.type === "tuple") {
        for (const o of n.items)
            if (S(o, r)) return !0;
        return !!(n.rest && S(n.rest, r))
    }
    return !1
}
var Wo = (e, t = {}) => r => {
        const n = _t({ ...r,
            processors: t
        });
        return k(e, n), gt(n, e), bt(n, e)
    },
    H = (e, t, r = {}) => n => {
        const {
            libraryOptions: o,
            target: i
        } = n ? ? {}, s = _t({ ...o ? ? {},
            target : i,
            io : t,
            processors: r
        });
        return k(e, s), gt(s, e), bt(s, e)
    },
    Bo = {
        guid: "uuid",
        url: "uri",
        datetime: "date-time",
        json_string: "json-string",
        regex: ""
    },
    Ko = (e, t, r, n) => {
        const o = r;
        o.type = "string";
        const {
            minimum: i,
            maximum: s,
            format: u,
            patterns: a,
            contentEncoding: l
        } = e._zod.bag;
        if (typeof i == "number" && (o.minLength = i), typeof s == "number" && (o.maxLength = s), u && (o.format = Bo[u] ? ? u, o.format === "" && delete o.format, u === "time" && delete o.format), l && (o.contentEncoding = l), a && a.size > 0) {
            const f = [...a];
            f.length === 1 ? o.pattern = f[0].source : f.length > 1 && (o.allOf = [...f.map(m => ({ ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? {
                    type: "string"
                } : {},
                pattern: m.source
            }))])
        }
    },
    Go = (e, t, r, n) => {
        const o = r,
            {
                minimum: i,
                maximum: s,
                format: u,
                multipleOf: a,
                exclusiveMaximum: l,
                exclusiveMinimum: f
            } = e._zod.bag;
        typeof u == "string" && u.includes("int") ? o.type = "integer" : o.type = "number";
        const m = typeof f == "number" && f >= (i ? ? Number.NEGATIVE_INFINITY),
            d = typeof l == "number" && l <= (s ? ? Number.POSITIVE_INFINITY),
            h = t.target === "draft-04" || t.target === "openapi-3.0";
        m ? h ? (o.minimum = f, o.exclusiveMinimum = !0) : o.exclusiveMinimum = f : typeof i == "number" && (o.minimum = i), d ? h ? (o.maximum = l, o.exclusiveMaximum = !0) : o.exclusiveMaximum = l : typeof s == "number" && (o.maximum = s), typeof a == "number" && (o.multipleOf = a)
    },
    Yo = (e, t, r, n) => {
        r.type = "boolean"
    },
    qo = (e, t, r, n) => {
        t.target === "openapi-3.0" ? (r.type = "string", r.nullable = !0, r.enum = [null]) : r.type = "null"
    },
    Xo = (e, t, r, n) => {
        if (t.unrepresentable === "throw") throw new Error("Undefined cannot be represented in JSON Schema")
    },
    Ho = (e, t, r, n) => {
        r.not = {}
    },
    Qo = (e, t, r, n) => {},
    ei = (e, t, r, n) => {},
    ti = (e, t, r, n) => {
        const o = e._zod.def,
            i = Ge(o.entries);
        i.every(s => typeof s == "number") && (r.type = "number"), i.every(s => typeof s == "string") && (r.type = "string"), r.enum = i
    },
    ri = (e, t, r, n) => {
        const o = e._zod.def,
            i = [];
        for (const s of o.values)
            if (s === void 0) {
                if (t.unrepresentable === "throw") throw new Error("Literal `undefined` cannot be represented in JSON Schema")
            } else if (typeof s == "bigint") {
            if (t.unrepresentable === "throw") throw new Error("BigInt literals cannot be represented in JSON Schema");
            i.push(Number(s))
        } else i.push(s);
        if (i.length !== 0)
            if (i.length === 1) {
                const s = i[0];
                r.type = s === null ? "null" : typeof s, t.target === "draft-04" || t.target === "openapi-3.0" ? r.enum = [s] : r.const = s
            } else i.every(s => typeof s == "number") && (r.type = "number"), i.every(s => typeof s == "string") && (r.type = "string"), i.every(s => typeof s == "boolean") && (r.type = "boolean"), i.every(s => s === null) && (r.type = "null"), r.enum = i
    },
    ni = (e, t, r, n) => {
        if (t.unrepresentable === "throw") throw new Error("Custom types cannot be represented in JSON Schema")
    },
    oi = (e, t, r, n) => {
        if (t.unrepresentable === "throw") throw new Error("Transforms cannot be represented in JSON Schema")
    },
    ii = (e, t, r, n) => {
        const o = r,
            i = e._zod.def,
            {
                minimum: s,
                maximum: u
            } = e._zod.bag;
        typeof s == "number" && (o.minItems = s), typeof u == "number" && (o.maxItems = u), o.type = "array", o.items = k(i.element, t, { ...n,
            path: [...n.path, "items"]
        })
    },
    si = (e, t, r, n) => {
        const o = r,
            i = e._zod.def;
        o.type = "object", o.properties = {};
        const s = i.shape;
        for (const l in s) o.properties[l] = k(s[l], t, { ...n,
            path: [...n.path, "properties", l]
        });
        const u = new Set(Object.keys(s)),
            a = new Set([...u].filter(l => {
                const f = i.shape[l]._zod;
                return t.io === "input" ? f.optin === void 0 : f.optout === void 0
            }));
        a.size > 0 && (o.required = Array.from(a)), i.catchall ? ._zod.def.type === "never" ? o.additionalProperties = !1 : i.catchall ? i.catchall && (o.additionalProperties = k(i.catchall, t, { ...n,
            path: [...n.path, "additionalProperties"]
        })) : t.io === "output" && (o.additionalProperties = !1)
    },
    ui = (e, t, r, n) => {
        const o = e._zod.def,
            i = o.inclusive === !1,
            s = o.options.map((u, a) => k(u, t, { ...n,
                path: [...n.path, i ? "oneOf" : "anyOf", a]
            }));
        i ? r.oneOf = s : r.anyOf = s
    },
    ai = (e, t, r, n) => {
        const o = e._zod.def,
            i = k(o.left, t, { ...n,
                path: [...n.path, "allOf", 0]
            }),
            s = k(o.right, t, { ...n,
                path: [...n.path, "allOf", 1]
            }),
            u = a => "allOf" in a && Object.keys(a).length === 1;
        r.allOf = [...u(i) ? i.allOf : [i], ...u(s) ? s.allOf : [s]]
    },
    ci = (e, t, r, n) => {
        const o = r,
            i = e._zod.def;
        o.type = "array";
        const s = t.target === "draft-2020-12" ? "prefixItems" : "items",
            u = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems",
            a = i.items.map((d, h) => k(d, t, { ...n,
                path: [...n.path, s, h]
            })),
            l = i.rest ? k(i.rest, t, { ...n,
                path: [...n.path, u, ...t.target === "openapi-3.0" ? [i.items.length] : []]
            }) : null;
        t.target === "draft-2020-12" ? (o.prefixItems = a, l && (o.items = l)) : t.target === "openapi-3.0" ? (o.items = {
            anyOf: a
        }, l && o.items.anyOf.push(l), o.minItems = a.length, l || (o.maxItems = a.length)) : (o.items = a, l && (o.additionalItems = l));
        const {
            minimum: f,
            maximum: m
        } = e._zod.bag;
        typeof f == "number" && (o.minItems = f), typeof m == "number" && (o.maxItems = m)
    },
    li = (e, t, r, n) => {
        const o = r,
            i = e._zod.def;
        o.type = "object";
        const s = i.keyType,
            u = s._zod.bag ? .patterns;
        if (i.mode === "loose" && u && u.size > 0) {
            const l = k(i.valueType, t, { ...n,
                path: [...n.path, "patternProperties", "*"]
            });
            o.patternProperties = {};
            for (const f of u) o.patternProperties[f.source] = l
        } else(t.target === "draft-07" || t.target === "draft-2020-12") && (o.propertyNames = k(i.keyType, t, { ...n,
            path: [...n.path, "propertyNames"]
        })), o.additionalProperties = k(i.valueType, t, { ...n,
            path: [...n.path, "additionalProperties"]
        });
        const a = s._zod.values;
        if (a) {
            const l = [...a].filter(f => typeof f == "string" || typeof f == "number");
            l.length > 0 && (o.required = l)
        }
    },
    fi = (e, t, r, n) => {
        const o = e._zod.def,
            i = k(o.innerType, t, n),
            s = t.seen.get(e);
        t.target === "openapi-3.0" ? (s.ref = o.innerType, r.nullable = !0) : r.anyOf = [i, {
            type: "null"
        }]
    },
    pi = (e, t, r, n) => {
        const o = e._zod.def;
        k(o.innerType, t, n);
        const i = t.seen.get(e);
        i.ref = o.innerType
    },
    di = (e, t, r, n) => {
        const o = e._zod.def;
        k(o.innerType, t, n);
        const i = t.seen.get(e);
        i.ref = o.innerType, r.default = JSON.parse(JSON.stringify(o.defaultValue))
    },
    hi = (e, t, r, n) => {
        const o = e._zod.def;
        k(o.innerType, t, n);
        const i = t.seen.get(e);
        i.ref = o.innerType, t.io === "input" && (r._prefault = JSON.parse(JSON.stringify(o.defaultValue)))
    },
    mi = (e, t, r, n) => {
        const o = e._zod.def;
        k(o.innerType, t, n);
        const i = t.seen.get(e);
        i.ref = o.innerType;
        let s;
        try {
            s = o.catchValue(void 0)
        } catch {
            throw new Error("Dynamic catch values are not supported in JSON Schema")
        }
        r.default = s
    },
    vi = (e, t, r, n) => {
        const o = e._zod.def,
            i = o.in._zod.traits.has("$ZodTransform"),
            s = t.io === "input" ? i ? o.out : o.in : o.out;
        k(s, t, n);
        const u = t.seen.get(e);
        u.ref = s
    },
    _i = (e, t, r, n) => {
        const o = e._zod.def;
        k(o.innerType, t, n);
        const i = t.seen.get(e);
        i.ref = o.innerType, r.readOnly = !0
    },
    zt = (e, t, r, n) => {
        const o = e._zod.def;
        k(o.innerType, t, n);
        const i = t.seen.get(e);
        i.ref = o.innerType
    },
    gi = c("ZodISODateTime", (e, t) => {
        un.init(e, t), y.init(e, t)
    });

function bi(e) {
    return vo(gi, e)
}
var zi = c("ZodISODate", (e, t) => {
    an.init(e, t), y.init(e, t)
});

function yi(e) {
    return _o(zi, e)
}
var wi = c("ZodISOTime", (e, t) => {
    cn.init(e, t), y.init(e, t)
});

function ki(e) {
    return go(wi, e)
}
var $i = c("ZodISODuration", (e, t) => {
    ln.init(e, t), y.init(e, t)
});

function Zi(e) {
    return bo($i, e)
}
var Si = (e, t) => {
        He.init(e, t), e.name = "ZodError", Object.defineProperties(e, {
            format: {
                value: r => qt(e, r)
            },
            flatten: {
                value: r => Yt(e, r)
            },
            addIssue: {
                value: r => {
                    e.issues.push(r), e.message = JSON.stringify(e.issues, ce, 2)
                }
            },
            addIssues: {
                value: r => {
                    e.issues.push(...r), e.message = JSON.stringify(e.issues, ce, 2)
                }
            },
            isEmpty: {
                get() {
                    return e.issues.length === 0
                }
            }
        })
    },
    I = c("ZodError", Si, {
        Parent: Error
    }),
    Oi = re(I),
    Ii = ne(I),
    Ei = oe(I),
    Pi = ie(I),
    Ti = Qt(I),
    Ni = er(I),
    Ai = tr(I),
    ji = rr(I),
    Ri = nr(I),
    Di = or(I),
    Ci = ir(I),
    Ui = sr(I),
    Ue = new WeakMap;

function V(e, t, r) {
    const n = Object.getPrototypeOf(e);
    let o = Ue.get(n);
    if (o || (o = new Set, Ue.set(n, o)), !o.has(t)) {
        o.add(t);
        for (const i in r) {
            const s = r[i];
            Object.defineProperty(n, i, {
                configurable: !0,
                enumerable: !1,
                get() {
                    const u = s.bind(this);
                    return Object.defineProperty(this, i, {
                        configurable: !0,
                        writable: !0,
                        enumerable: !0,
                        value: u
                    }), u
                },
                set(u) {
                    Object.defineProperty(this, i, {
                        configurable: !0,
                        writable: !0,
                        enumerable: !0,
                        value: u
                    })
                }
            })
        }
    }
}
var g = c("ZodType", (e, t) => (_.init(e, t), Object.assign(e["~standard"], {
        jsonSchema: {
            input: H(e, "input"),
            output: H(e, "output")
        }
    }), e.toJSONSchema = Wo(e, {}), e.def = t, e.type = t.type, Object.defineProperty(e, "_def", {
        value: t
    }), e.parse = (r, n) => Oi(e, r, n, {
        callee: e.parse
    }), e.safeParse = (r, n) => Ei(e, r, n), e.parseAsync = async (r, n) => Ii(e, r, n, {
        callee: e.parseAsync
    }), e.safeParseAsync = async (r, n) => Pi(e, r, n), e.spa = e.safeParseAsync, e.encode = (r, n) => Ti(e, r, n), e.decode = (r, n) => Ni(e, r, n), e.encodeAsync = async (r, n) => Ai(e, r, n), e.decodeAsync = async (r, n) => ji(e, r, n), e.safeEncode = (r, n) => Ri(e, r, n), e.safeDecode = (r, n) => Di(e, r, n), e.safeEncodeAsync = async (r, n) => Ci(e, r, n), e.safeDecodeAsync = async (r, n) => Ui(e, r, n), V(e, "ZodType", {
        check(...r) {
            const n = this.def;
            return this.clone(A(n, {
                checks: [...n.checks ? ? [], ...r.map(o => typeof o == "function" ? {
                    _zod: {
                        check: o,
                        def: {
                            check: "custom"
                        },
                        onattach: []
                    }
                } : o)]
            }), {
                parent: !0
            })
        },
        with(...r) {
            return this.check(...r)
        },
        clone(r, n) {
            return j(this, r, n)
        },
        brand() {
            return this
        },
        register(r, n) {
            return r.add(this, n), this
        },
        refine(r, n) {
            return this.check(Ns(r, n))
        },
        superRefine(r, n) {
            return this.check(As(r, n))
        },
        overwrite(r) {
            return this.check(x(r))
        },
        optional() {
            return Le(this)
        },
        exactOptional() {
            return zs(this)
        },
        nullable() {
            return Ve(this)
        },
        nullish() {
            return Le(Ve(this))
        },
        nonoptional(r) {
            return Ss(this, r)
        },
        array() {
            return ls(this)
        },
        or(r) {
            return fs([this, r])
        },
        and(r) {
            return hs(this, r)
        },
        transform(r) {
            return We(this, Ot(r))
        },
        default (r) {
            return ks(this, r)
        },
        prefault(r) {
            return Zs(this, r)
        },
        catch (r) {
            return Is(this, r)
        },
        pipe(r) {
            return We(this, r)
        },
        readonly() {
            return Ts(this)
        },
        describe(r) {
            const n = this.clone();
            return J.add(n, {
                description: r
            }), n
        },
        meta(...r) {
            if (r.length === 0) return J.get(this);
            const n = this.clone();
            return J.add(n, r[0]), n
        },
        isOptional() {
            return this.safeParse(void 0).success
        },
        isNullable() {
            return this.safeParse(null).success
        },
        apply(r) {
            return r(this)
        }
    }), Object.defineProperty(e, "description", {
        get() {
            return J.get(e) ? .description
        },
        configurable: !0
    }), e)),
    yt = c("_ZodString", (e, t) => {
        he.init(e, t), g.init(e, t), e._zod.processJSONSchema = (n, o, i) => Ko(e, n, o, i);
        const r = e._zod.bag;
        e.format = r.format ? ? null, e.minLength = r.minimum ? ? null, e.maxLength = r.maximum ? ? null, V(e, "_ZodString", {
            regex(...n) {
                return this.check(Eo(...n))
            },
            includes(...n) {
                return this.check(No(...n))
            },
            startsWith(...n) {
                return this.check(Ao(...n))
            },
            endsWith(...n) {
                return this.check(jo(...n))
            },
            min(...n) {
                return this.check(X(...n))
            },
            max(...n) {
                return this.check(mt(...n))
            },
            length(...n) {
                return this.check(vt(...n))
            },
            nonempty(...n) {
                return this.check(X(1, ...n))
            },
            lowercase(n) {
                return this.check(Po(n))
            },
            uppercase(n) {
                return this.check(To(n))
            },
            trim() {
                return this.check(Do())
            },
            normalize(...n) {
                return this.check(Ro(...n))
            },
            toLowerCase() {
                return this.check(Co())
            },
            toUpperCase() {
                return this.check(Uo())
            },
            slugify() {
                return this.check(Fo())
            }
        })
    }),
    Fi = c("ZodString", (e, t) => {
        he.init(e, t), yt.init(e, t), e.email = r => e.check(dt(wt, r)), e.url = r => e.check(ht(kt, r)), e.jwt = r => e.check(mo(ts, r)), e.emoji = r => e.check(eo(Ji, r)), e.guid = r => e.check(je(Fe, r)), e.uuid = r => e.check(qn(G, r)), e.uuidv4 = r => e.check(Xn(G, r)), e.uuidv6 = r => e.check(Hn(G, r)), e.uuidv7 = r => e.check(Qn(G, r)), e.nanoid = r => e.check(to(Mi, r)), e.guid = r => e.check(je(Fe, r)), e.cuid = r => e.check(ro(Li, r)), e.cuid2 = r => e.check(no(Vi, r)), e.ulid = r => e.check(oo(Wi, r)), e.base64 = r => e.check(fo(Hi, r)), e.base64url = r => e.check(po(Qi, r)), e.xid = r => e.check(io(Bi, r)), e.ksuid = r => e.check(so(Ki, r)), e.ipv4 = r => e.check(uo(Gi, r)), e.ipv6 = r => e.check(ao(Yi, r)), e.cidrv4 = r => e.check(co(qi, r)), e.cidrv6 = r => e.check(lo(Xi, r)), e.e164 = r => e.check(ho(es, r)), e.datetime = r => e.check(bi(r)), e.date = r => e.check(yi(r)), e.time = r => e.check(ki(r)), e.duration = r => e.check(Zi(r))
    });

function xi(e) {
    return Yn(Fi, e)
}
var y = c("ZodStringFormat", (e, t) => {
        z.init(e, t), yt.init(e, t)
    }),
    wt = c("ZodEmail", (e, t) => {
        Xr.init(e, t), y.init(e, t)
    });

function Cs(e) {
    return dt(wt, e)
}
var Fe = c("ZodGUID", (e, t) => {
        Yr.init(e, t), y.init(e, t)
    }),
    G = c("ZodUUID", (e, t) => {
        qr.init(e, t), y.init(e, t)
    }),
    kt = c("ZodURL", (e, t) => {
        Hr.init(e, t), y.init(e, t)
    });

function Us(e) {
    return ht(kt, e)
}
var Ji = c("ZodEmoji", (e, t) => {
        Qr.init(e, t), y.init(e, t)
    }),
    Mi = c("ZodNanoID", (e, t) => {
        en.init(e, t), y.init(e, t)
    }),
    Li = c("ZodCUID", (e, t) => {
        tn.init(e, t), y.init(e, t)
    }),
    Vi = c("ZodCUID2", (e, t) => {
        rn.init(e, t), y.init(e, t)
    }),
    Wi = c("ZodULID", (e, t) => {
        nn.init(e, t), y.init(e, t)
    }),
    Bi = c("ZodXID", (e, t) => {
        on.init(e, t), y.init(e, t)
    }),
    Ki = c("ZodKSUID", (e, t) => {
        sn.init(e, t), y.init(e, t)
    }),
    Gi = c("ZodIPv4", (e, t) => {
        fn.init(e, t), y.init(e, t)
    }),
    Yi = c("ZodIPv6", (e, t) => {
        pn.init(e, t), y.init(e, t)
    }),
    qi = c("ZodCIDRv4", (e, t) => {
        dn.init(e, t), y.init(e, t)
    }),
    Xi = c("ZodCIDRv6", (e, t) => {
        hn.init(e, t), y.init(e, t)
    }),
    Hi = c("ZodBase64", (e, t) => {
        mn.init(e, t), y.init(e, t)
    }),
    Qi = c("ZodBase64URL", (e, t) => {
        _n.init(e, t), y.init(e, t)
    }),
    es = c("ZodE164", (e, t) => {
        gn.init(e, t), y.init(e, t)
    }),
    ts = c("ZodJWT", (e, t) => {
        zn.init(e, t), y.init(e, t)
    }),
    me = c("ZodNumber", (e, t) => {
        ut.init(e, t), g.init(e, t), e._zod.processJSONSchema = (n, o, i) => Go(e, n, o, i), V(e, "ZodNumber", {
            gt(n, o) {
                return this.check(De(n, o))
            },
            gte(n, o) {
                return this.check(ae(n, o))
            },
            min(n, o) {
                return this.check(ae(n, o))
            },
            lt(n, o) {
                return this.check(Re(n, o))
            },
            lte(n, o) {
                return this.check(ue(n, o))
            },
            max(n, o) {
                return this.check(ue(n, o))
            },
            int(n) {
                return this.check(xe(n))
            },
            safe(n) {
                return this.check(xe(n))
            },
            positive(n) {
                return this.check(De(0, n))
            },
            nonnegative(n) {
                return this.check(ae(0, n))
            },
            negative(n) {
                return this.check(Re(0, n))
            },
            nonpositive(n) {
                return this.check(ue(0, n))
            },
            multipleOf(n, o) {
                return this.check(Ce(n, o))
            },
            step(n, o) {
                return this.check(Ce(n, o))
            },
            finite() {
                return this
            }
        });
        const r = e._zod.bag;
        e.minValue = Math.max(r.minimum ? ? Number.NEGATIVE_INFINITY, r.exclusiveMinimum ? ? Number.NEGATIVE_INFINITY) ? ? null, e.maxValue = Math.min(r.maximum ? ? Number.POSITIVE_INFINITY, r.exclusiveMaximum ? ? Number.POSITIVE_INFINITY) ? ? null, e.isInt = (r.format ? ? "").includes("int") || Number.isSafeInteger(r.multipleOf ? ? .5), e.isFinite = !0, e.format = r.format ? ? null
    });

function Fs(e) {
    return zo(me, e)
}
var rs = c("ZodNumberFormat", (e, t) => {
    yn.init(e, t), me.init(e, t)
});

function xe(e) {
    return wo(rs, e)
}
var ns = c("ZodBoolean", (e, t) => {
    wn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => Yo(e, r, n, o)
});

function xs(e) {
    return ko(ns, e)
}
var os = c("ZodUndefined", (e, t) => {
    kn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => Xo(e, r, n, o)
});

function Js(e) {
    return $o(os, e)
}
var is = c("ZodNull", (e, t) => {
    $n.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => qo(e, r, n, o)
});

function Ms(e) {
    return Zo(is, e)
}
var ss = c("ZodAny", (e, t) => {
    Zn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => Qo(e, r, n, o)
});

function Ls() {
    return So(ss)
}
var us = c("ZodUnknown", (e, t) => {
    Sn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => ei(e, r, n, o)
});

function Je() {
    return Oo(us)
}
var as = c("ZodNever", (e, t) => {
    On.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ho(e, r, n, o)
});

function $t(e) {
    return Io(as, e)
}
var cs = c("ZodArray", (e, t) => {
    In.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => ii(e, r, n, o), e.element = t.element, V(e, "ZodArray", {
        min(r, n) {
            return this.check(X(r, n))
        },
        nonempty(r) {
            return this.check(X(1, r))
        },
        max(r, n) {
            return this.check(mt(r, n))
        },
        length(r, n) {
            return this.check(vt(r, n))
        },
        unwrap() {
            return this.element
        }
    })
});

function ls(e, t) {
    return xo(cs, e, t)
}
var Zt = c("ZodObject", (e, t) => {
    Pn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => si(e, r, n, o), v(e, "shape", () => t.shape), V(e, "ZodObject", {
        keyof() {
            return vs(Object.keys(this._zod.def.shape))
        },
        catchall(r) {
            return this.clone({ ...this._zod.def,
                catchall: r
            })
        },
        passthrough() {
            return this.clone({ ...this._zod.def,
                catchall: Je()
            })
        },
        loose() {
            return this.clone({ ...this._zod.def,
                catchall: Je()
            })
        },
        strict() {
            return this.clone({ ...this._zod.def,
                catchall: $t()
            })
        },
        strip() {
            return this.clone({ ...this._zod.def,
                catchall: void 0
            })
        },
        extend(r) {
            return Lt(this, r)
        },
        safeExtend(r) {
            return Vt(this, r)
        },
        merge(r) {
            return Wt(this, r)
        },
        pick(r) {
            return Jt(this, r)
        },
        omit(r) {
            return Mt(this, r)
        },
        partial(...r) {
            return Bt(It, this, r[0])
        },
        required(...r) {
            return Kt(Et, this, r[0])
        }
    })
});

function Vs(e, t) {
    const r = {
        type: "object",
        shape: e ? ? {},
        ...p(t)
    };
    return new Zt(r)
}

function Ws(e, t) {
    return new Zt({
        type: "object",
        shape: e,
        catchall: $t(),
        ...p(t)
    })
}
var St = c("ZodUnion", (e, t) => {
    lt.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => ui(e, r, n, o), e.options = t.options
});

function fs(e, t) {
    return new St({
        type: "union",
        options: e,
        ...p(t)
    })
}
var ps = c("ZodDiscriminatedUnion", (e, t) => {
    St.init(e, t), Tn.init(e, t)
});

function Bs(e, t, r) {
    return new ps({
        type: "union",
        options: t,
        discriminator: e,
        ...p(r)
    })
}
var ds = c("ZodIntersection", (e, t) => {
    Nn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => ai(e, r, n, o)
});

function hs(e, t) {
    return new ds({
        type: "intersection",
        left: e,
        right: t
    })
}
var ms = c("ZodTuple", (e, t) => {
    An.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => ci(e, r, n, o), e.rest = r => e.clone({ ...e._zod.def,
        rest: r
    })
});

function Ks(e, t, r) {
    const n = t instanceof _,
        o = n ? r : t;
    return new ms({
        type: "tuple",
        items: e,
        rest: n ? t : null,
        ...p(o)
    })
}
var Me = c("ZodRecord", (e, t) => {
    jn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => li(e, r, n, o), e.keyType = t.keyType, e.valueType = t.valueType
});

function Gs(e, t, r) {
    return !t || !t._zod ? new Me({
        type: "record",
        keyType: xi(),
        valueType: e,
        ...p(t)
    }) : new Me({
        type: "record",
        keyType: e,
        valueType: t,
        ...p(r)
    })
}
var Q = c("ZodEnum", (e, t) => {
    Rn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (n, o, i) => ti(e, n, o, i), e.enum = t.entries, e.options = Object.values(t.entries);
    const r = new Set(Object.keys(t.entries));
    e.extract = (n, o) => {
        const i = {};
        for (const s of n)
            if (r.has(s)) i[s] = t.entries[s];
            else throw new Error(`Key ${s} not found in enum`);
        return new Q({ ...t,
            checks: [],
            ...p(o),
            entries: i
        })
    }, e.exclude = (n, o) => {
        const i = { ...t.entries
        };
        for (const s of n)
            if (r.has(s)) delete i[s];
            else throw new Error(`Key ${s} not found in enum`);
        return new Q({ ...t,
            checks: [],
            ...p(o),
            entries: i
        })
    }
});

function vs(e, t) {
    const r = Array.isArray(e) ? Object.fromEntries(e.map(n => [n, n])) : e;
    return new Q({
        type: "enum",
        entries: r,
        ...p(t)
    })
}

function Ys(e, t) {
    return new Q({
        type: "enum",
        entries: e,
        ...p(t)
    })
}
var _s = c("ZodLiteral", (e, t) => {
    Dn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => ri(e, r, n, o), e.values = new Set(t.values), Object.defineProperty(e, "value", {
        get() {
            if (t.values.length > 1) throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
            return t.values[0]
        }
    })
});

function qs(e, t) {
    return new _s({
        type: "literal",
        values: Array.isArray(e) ? e : [e],
        ...p(t)
    })
}
var gs = c("ZodTransform", (e, t) => {
    Cn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => oi(e, r, n, o), e._zod.parse = (r, n) => {
        if (n.direction === "backward") throw new Ke(e.constructor.name);
        r.addIssue = i => {
            if (typeof i == "string") r.issues.push(L(i, r.value, t));
            else {
                const s = i;
                s.fatal && (s.continue = !1), s.code ? ? (s.code = "custom"), s.input ? ? (s.input = r.value), s.inst ? ? (s.inst = e), r.issues.push(L(s))
            }
        };
        const o = t.transform(r.value, r);
        return o instanceof Promise ? o.then(i => (r.value = i, r.fallback = !0, r)) : (r.value = o, r.fallback = !0, r)
    }
});

function Ot(e) {
    return new gs({
        type: "transform",
        transform: e
    })
}
var It = c("ZodOptional", (e, t) => {
    ft.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => zt(e, r, n, o), e.unwrap = () => e._zod.def.innerType
});

function Le(e) {
    return new It({
        type: "optional",
        innerType: e
    })
}
var bs = c("ZodExactOptional", (e, t) => {
    Un.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => zt(e, r, n, o), e.unwrap = () => e._zod.def.innerType
});

function zs(e) {
    return new bs({
        type: "optional",
        innerType: e
    })
}
var ys = c("ZodNullable", (e, t) => {
    Fn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => fi(e, r, n, o), e.unwrap = () => e._zod.def.innerType
});

function Ve(e) {
    return new ys({
        type: "nullable",
        innerType: e
    })
}
var ws = c("ZodDefault", (e, t) => {
    xn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => di(e, r, n, o), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap
});

function ks(e, t) {
    return new ws({
        type: "default",
        innerType: e,
        get defaultValue() {
            return typeof t == "function" ? t() : qe(t)
        }
    })
}
var $s = c("ZodPrefault", (e, t) => {
    Jn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => hi(e, r, n, o), e.unwrap = () => e._zod.def.innerType
});

function Zs(e, t) {
    return new $s({
        type: "prefault",
        innerType: e,
        get defaultValue() {
            return typeof t == "function" ? t() : qe(t)
        }
    })
}
var Et = c("ZodNonOptional", (e, t) => {
    Mn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => pi(e, r, n, o), e.unwrap = () => e._zod.def.innerType
});

function Ss(e, t) {
    return new Et({
        type: "nonoptional",
        innerType: e,
        ...p(t)
    })
}
var Os = c("ZodCatch", (e, t) => {
    Ln.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => mi(e, r, n, o), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap
});

function Is(e, t) {
    return new Os({
        type: "catch",
        innerType: e,
        catchValue: typeof t == "function" ? t : () => t
    })
}
var Pt = c("ZodPipe", (e, t) => {
    pt.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => vi(e, r, n, o), e.in = t.in, e.out = t.out
});

function We(e, t) {
    return new Pt({
        type: "pipe",
        in: e,
        out: t
    })
}
var Es = c("ZodPreprocess", (e, t) => {
        Pt.init(e, t), Vn.init(e, t)
    }),
    Ps = c("ZodReadonly", (e, t) => {
        Wn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => _i(e, r, n, o), e.unwrap = () => e._zod.def.innerType
    });

function Ts(e) {
    return new Ps({
        type: "readonly",
        innerType: e
    })
}
var Tt = c("ZodCustom", (e, t) => {
    Bn.init(e, t), g.init(e, t), e._zod.processJSONSchema = (r, n, o) => ni(e, r, n, o)
});

function Xs(e, t) {
    return Jo(Tt, e ? ? (() => !0), t)
}

function Ns(e, t = {}) {
    return Mo(Tt, e, t)
}

function As(e, t) {
    return Lo(e, t)
}

function Hs(e, t) {
    return new Es({
        type: "pipe",
        in: Ot(e),
        out: t
    })
}
var Qs = {
        invalid_type: "invalid_type",
        too_big: "too_big",
        too_small: "too_small",
        invalid_format: "invalid_format",
        not_multiple_of: "not_multiple_of",
        unrecognized_keys: "unrecognized_keys",
        invalid_union: "invalid_union",
        invalid_key: "invalid_key",
        invalid_element: "invalid_element",
        invalid_value: "invalid_value",
        custom: "custom"
    },
    Be;
Be || (Be = {});

function eu(e) {
    return yo(me, e)
}
export {
    Ws as A, qs as C, Vs as D, Fs as E, Us as F, Rs as I, Ds as L, Ks as M, fs as N, Hs as O, Je as P, He as R, Cs as S, $t as T, Ls as _, ws as a, Xs as b, _s as c, Zt as d, It as f, Js as g, Ms as h, ns as i, xi as j, Gs as k, ys as l, vs as m, Qs as n, ps as o, Fi as p, cs as r, Q as s, eu as t, me as u, ls as v, Ys as w, Bs as x, xs as y, js as z
};