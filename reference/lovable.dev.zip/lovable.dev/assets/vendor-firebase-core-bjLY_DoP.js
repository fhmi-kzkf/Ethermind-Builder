try {
    (function() {
        var e = typeof window < "u" ? window : typeof global < "u" ? global : typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : {},
            t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "99ff05f5-4cc1-4795-956f-3a76e52ee629", e._sentryDebugIdIdentifier = "sentry-dbid-99ff05f5-4cc1-4795-956f-3a76e52ee629")
    })()
} catch {}
var ve = () => {},
    M = {
        NODE_CLIENT: !1,
        NODE_ADMIN: !1,
        SDK_VERSION: "${JSCORE_VERSION}"
    },
    _e = function(e, t) {
        if (!e) throw ye(t)
    },
    ye = function(e) {
        return new Error("Firebase Database (" + M.SDK_VERSION + ") INTERNAL ASSERT FAILED: " + e)
    },
    ie = function(e) {
        const t = [];
        let r = 0;
        for (let i = 0; i < e.length; i++) {
            let n = e.charCodeAt(i);
            n < 128 ? t[r++] = n : n < 2048 ? (t[r++] = n >> 6 | 192, t[r++] = n & 63 | 128) : (n & 64512) === 55296 && i + 1 < e.length && (e.charCodeAt(i + 1) & 64512) === 56320 ? (n = 65536 + ((n & 1023) << 10) + (e.charCodeAt(++i) & 1023), t[r++] = n >> 18 | 240, t[r++] = n >> 12 & 63 | 128, t[r++] = n >> 6 & 63 | 128, t[r++] = n & 63 | 128) : (t[r++] = n >> 12 | 224, t[r++] = n >> 6 & 63 | 128, t[r++] = n & 63 | 128)
        }
        return t
    },
    Ee = function(e) {
        const t = [];
        let r = 0,
            i = 0;
        for (; r < e.length;) {
            const n = e[r++];
            if (n < 128) t[i++] = String.fromCharCode(n);
            else if (n > 191 && n < 224) {
                const s = e[r++];
                t[i++] = String.fromCharCode((n & 31) << 6 | s & 63)
            } else if (n > 239 && n < 365) {
                const s = e[r++],
                    a = e[r++],
                    l = e[r++],
                    c = ((n & 7) << 18 | (s & 63) << 12 | (a & 63) << 6 | l & 63) - 65536;
                t[i++] = String.fromCharCode(55296 + (c >> 10)), t[i++] = String.fromCharCode(56320 + (c & 1023))
            } else {
                const s = e[r++],
                    a = e[r++];
                t[i++] = String.fromCharCode((n & 15) << 12 | (s & 63) << 6 | a & 63)
            }
        }
        return t.join("")
    },
    se = {
        byteToCharMap_: null,
        charToByteMap_: null,
        byteToCharMapWebSafe_: null,
        charToByteMapWebSafe_: null,
        ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
        get ENCODED_VALS() {
            return this.ENCODED_VALS_BASE + "+/="
        },
        get ENCODED_VALS_WEBSAFE() {
            return this.ENCODED_VALS_BASE + "-_."
        },
        HAS_NATIVE_SUPPORT: typeof atob == "function",
        encodeByteArray(e, t) {
            if (!Array.isArray(e)) throw Error("encodeByteArray takes an array as a parameter");
            this.init_();
            const r = t ? this.byteToCharMapWebSafe_ : this.byteToCharMap_,
                i = [];
            for (let n = 0; n < e.length; n += 3) {
                const s = e[n],
                    a = n + 1 < e.length,
                    l = a ? e[n + 1] : 0,
                    c = n + 2 < e.length,
                    u = c ? e[n + 2] : 0,
                    h = s >> 2,
                    o = (s & 3) << 4 | l >> 4;
                let f = (l & 15) << 2 | u >> 6,
                    g = u & 63;
                c || (g = 64, a || (f = 64)), i.push(r[h], r[o], r[f], r[g])
            }
            return i.join("")
        },
        encodeString(e, t) {
            return this.HAS_NATIVE_SUPPORT && !t ? btoa(e) : this.encodeByteArray(ie(e), t)
        },
        decodeString(e, t) {
            return this.HAS_NATIVE_SUPPORT && !t ? atob(e) : Ee(this.decodeStringToByteArray(e, t))
        },
        decodeStringToByteArray(e, t) {
            this.init_();
            const r = t ? this.charToByteMapWebSafe_ : this.charToByteMap_,
                i = [];
            for (let n = 0; n < e.length;) {
                const s = r[e.charAt(n++)],
                    a = n < e.length ? r[e.charAt(n)] : 0;
                ++n;
                const l = n < e.length ? r[e.charAt(n)] : 64;
                ++n;
                const c = n < e.length ? r[e.charAt(n)] : 64;
                if (++n, s == null || a == null || l == null || c == null) throw new we;
                const u = s << 2 | a >> 4;
                if (i.push(u), l !== 64) {
                    const h = a << 4 & 240 | l >> 2;
                    if (i.push(h), c !== 64) {
                        const o = l << 6 & 192 | c;
                        i.push(o)
                    }
                }
            }
            return i
        },
        init_() {
            if (!this.byteToCharMap_) {
                this.byteToCharMap_ = {}, this.charToByteMap_ = {}, this.byteToCharMapWebSafe_ = {}, this.charToByteMapWebSafe_ = {};
                for (let e = 0; e < this.ENCODED_VALS.length; e++) this.byteToCharMap_[e] = this.ENCODED_VALS.charAt(e), this.charToByteMap_[this.byteToCharMap_[e]] = e, this.byteToCharMapWebSafe_[e] = this.ENCODED_VALS_WEBSAFE.charAt(e), this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]] = e, e >= this.ENCODED_VALS_BASE.length && (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)] = e, this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)] = e)
            }
        }
    },
    we = class extends Error {
        constructor() {
            super(...arguments), this.name = "DecodeBase64StringError"
        }
    },
    Ce = function(e) {
        const t = ie(e);
        return se.encodeByteArray(t, !0)
    },
    I = function(e) {
        return Ce(e).replace(/\./g, "")
    },
    R = function(e) {
        try {
            return se.decodeString(e, !0)
        } catch (t) {
            console.error("base64Decode failed: ", t)
        }
        return null
    };

function Yt(e) {
    return ae(void 0, e)
}

function ae(e, t) {
    if (!(t instanceof Object)) return t;
    switch (t.constructor) {
        case Date:
            return new Date(t.getTime());
        case Object:
            e === void 0 && (e = {});
            break;
        case Array:
            e = [];
            break;
        default:
            return t
    }
    for (const r in t) !t.hasOwnProperty(r) || !Ie(r) || (e[r] = ae(e[r], t[r]));
    return e
}

function Ie(e) {
    return e !== "__proto__"
}

function De() {
    if (typeof self < "u") return self;
    if (typeof window < "u") return window;
    if (typeof global < "u") return global;
    throw new Error("Unable to locate global object.")
}
var Se = () => De().__FIREBASE_DEFAULTS__,
    Ae = () => {
        if (typeof process > "u") return;
        const e = {}.__FIREBASE_DEFAULTS__;
        if (e) return JSON.parse(e)
    },
    Oe = () => {
        if (typeof document > "u") return;
        let e;
        try {
            e = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)
        } catch {
            return
        }
        const t = e && R(e[1]);
        return t && JSON.parse(t)
    },
    V = () => {
        try {
            return ve() || Se() || Ae() || Oe()
        } catch (e) {
            console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);
            return
        }
    },
    Be = e => {
        var t, r;
        return (r = (t = V()) === null || t === void 0 ? void 0 : t.emulatorHosts) === null || r === void 0 ? void 0 : r[e]
    },
    qt = e => {
        const t = Be(e);
        if (!t) return;
        const r = t.lastIndexOf(":");
        if (r <= 0 || r + 1 === t.length) throw new Error(`Invalid host ${t} with no separate hostname and port!`);
        const i = parseInt(t.substring(r + 1), 10);
        return t[0] === "[" ? [t.substring(1, r - 1), i] : [t.substring(0, r), i]
    },
    oe = () => {
        var e;
        return (e = V()) === null || e === void 0 ? void 0 : e.config
    },
    Xt = e => {
        var t;
        return (t = V()) === null || t === void 0 ? void 0 : t[`_${e}`]
    },
    Te = class {
        constructor() {
            this.reject = () => {}, this.resolve = () => {}, this.promise = new Promise((e, t) => {
                this.resolve = e, this.reject = t
            })
        }
        wrapCallback(e) {
            return (t, r) => {
                t ? this.reject(t) : this.resolve(r), typeof e == "function" && (this.promise.catch(() => {}), e.length === 1 ? e(t) : e(t, r))
            }
        }
    };

function Ne(e) {
    try {
        return (e.startsWith("http://") || e.startsWith("https://") ? new URL(e).hostname : e).endsWith(".cloudworkstations.dev")
    } catch {
        return !1
    }
}
async function Qt(e) {
    return (await fetch(e, {
        credentials: "include"
    })).ok
}

function er(e, t) {
    if (e.uid) throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');
    const r = {
            alg: "none",
            type: "JWT"
        },
        i = t || "demo-project",
        n = e.iat || 0,
        s = e.sub || e.user_id;
    if (!s) throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");
    const a = Object.assign({
        iss: `https://securetoken.google.com/${i}`,
        aud: i,
        iat: n,
        exp: n + 3600,
        auth_time: n,
        sub: s,
        user_id: s,
        firebase: {
            sign_in_provider: "custom",
            identities: {}
        }
    }, e);
    return [I(JSON.stringify(r)), I(JSON.stringify(a)), ""].join(".")
}
var y = {};

function Me() {
    const e = {
        prod: [],
        emulator: []
    };
    for (const t of Object.keys(y)) y[t] ? e.emulator.push(t) : e.prod.push(t);
    return e
}

function Re(e) {
    let t = document.getElementById(e),
        r = !1;
    return t || (t = document.createElement("div"), t.setAttribute("id", e), r = !0), {
        created: r,
        element: t
    }
}
var J = !1;

function tr(e, t) {
    if (typeof window > "u" || typeof document > "u" || !Ne(window.location.host) || y[e] === t || y[e] || J) return;
    y[e] = t;

    function r(o) {
        return `__firebase__banner__${o}`
    }
    const i = "__firebase__banner",
        n = Me().prod.length > 0;

    function s() {
        const o = document.getElementById(i);
        o && o.remove()
    }

    function a(o) {
        o.style.display = "flex", o.style.background = "#7faaf0", o.style.position = "fixed", o.style.bottom = "5px", o.style.left = "5px", o.style.padding = ".5em", o.style.borderRadius = "5px", o.style.alignItems = "center"
    }

    function l(o, f) {
        o.setAttribute("width", "24"), o.setAttribute("id", f), o.setAttribute("height", "24"), o.setAttribute("viewBox", "0 0 24 24"), o.setAttribute("fill", "none"), o.style.marginLeft = "-6px"
    }

    function c() {
        const o = document.createElement("span");
        return o.style.cursor = "pointer", o.style.marginLeft = "16px", o.style.fontSize = "24px", o.innerHTML = " &times;", o.onclick = () => {
            J = !0, s()
        }, o
    }

    function u(o, f) {
        o.setAttribute("id", f), o.innerText = "Learn more", o.href = "https://firebase.google.com/docs/studio/preview-apps#preview-backend", o.setAttribute("target", "__blank"), o.style.paddingLeft = "5px", o.style.textDecoration = "underline"
    }

    function h() {
        const o = Re(i),
            f = r("text"),
            g = document.getElementById(f) || document.createElement("span"),
            U = r("learnmore"),
            W = document.getElementById(U) || document.createElement("a"),
            G = r("preprendIcon"),
            w = document.getElementById(G) || document.createElementNS("http://www.w3.org/2000/svg", "svg");
        if (o.created) {
            const S = o.element;
            a(S), u(W, U);
            const ge = c();
            l(w, G), S.append(w, g, W, ge), document.body.appendChild(S)
        }
        n ? (g.innerText = "Preview backend disconnected.", w.innerHTML = `<g clip-path="url(#clip0_6013_33858)">
<path d="M4.8 17.6L12 5.6L19.2 17.6H4.8ZM6.91667 16.4H17.0833L12 7.93333L6.91667 16.4ZM12 15.6C12.1667 15.6 12.3056 15.5444 12.4167 15.4333C12.5389 15.3111 12.6 15.1667 12.6 15C12.6 14.8333 12.5389 14.6944 12.4167 14.5833C12.3056 14.4611 12.1667 14.4 12 14.4C11.8333 14.4 11.6889 14.4611 11.5667 14.5833C11.4556 14.6944 11.4 14.8333 11.4 15C11.4 15.1667 11.4556 15.3111 11.5667 15.4333C11.6889 15.5444 11.8333 15.6 12 15.6ZM11.4 13.6H12.6V10.4H11.4V13.6Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6013_33858">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`) : (w.innerHTML = `<g clip-path="url(#clip0_6083_34804)">
<path d="M11.4 15.2H12.6V11.2H11.4V15.2ZM12 10C12.1667 10 12.3056 9.94444 12.4167 9.83333C12.5389 9.71111 12.6 9.56667 12.6 9.4C12.6 9.23333 12.5389 9.09444 12.4167 8.98333C12.3056 8.86111 12.1667 8.8 12 8.8C11.8333 8.8 11.6889 8.86111 11.5667 8.98333C11.4556 9.09444 11.4 9.23333 11.4 9.4C11.4 9.56667 11.4556 9.71111 11.5667 9.83333C11.6889 9.94444 11.8333 10 12 10ZM12 18.4C11.1222 18.4 10.2944 18.2333 9.51667 17.9C8.73889 17.5667 8.05556 17.1111 7.46667 16.5333C6.88889 15.9444 6.43333 15.2611 6.1 14.4833C5.76667 13.7056 5.6 12.8778 5.6 12C5.6 11.1111 5.76667 10.2833 6.1 9.51667C6.43333 8.73889 6.88889 8.06111 7.46667 7.48333C8.05556 6.89444 8.73889 6.43333 9.51667 6.1C10.2944 5.76667 11.1222 5.6 12 5.6C12.8889 5.6 13.7167 5.76667 14.4833 6.1C15.2611 6.43333 15.9389 6.89444 16.5167 7.48333C17.1056 8.06111 17.5667 8.73889 17.9 9.51667C18.2333 10.2833 18.4 11.1111 18.4 12C18.4 12.8778 18.2333 13.7056 17.9 14.4833C17.5667 15.2611 17.1056 15.9444 16.5167 16.5333C15.9389 17.1111 15.2611 17.5667 14.4833 17.9C13.7167 18.2333 12.8889 18.4 12 18.4ZM12 17.2C13.4444 17.2 14.6722 16.6944 15.6833 15.6833C16.6944 14.6722 17.2 13.4444 17.2 12C17.2 10.5556 16.6944 9.32778 15.6833 8.31667C14.6722 7.30555 13.4444 6.8 12 6.8C10.5556 6.8 9.32778 7.30555 8.31667 8.31667C7.30556 9.32778 6.8 10.5556 6.8 12C6.8 13.4444 7.30556 14.6722 8.31667 15.6833C9.32778 16.6944 10.5556 17.2 12 17.2Z" fill="#212121"/>
</g>
<defs>
<clipPath id="clip0_6083_34804">
<rect width="24" height="24" fill="white"/>
</clipPath>
</defs>`, g.innerText = "Preview backend running in this workspace."), g.setAttribute("id", f)
    }
    document.readyState === "loading" ? window.addEventListener("DOMContentLoaded", h) : h()
}

function ce() {
    return typeof navigator < "u" && typeof navigator.userAgent == "string" ? navigator.userAgent : ""
}

function rr() {
    return typeof window < "u" && !!(window.cordova || window.phonegap || window.PhoneGap) && /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(ce())
}

function nr() {
    return typeof navigator < "u" && navigator.userAgent === "Cloudflare-Workers"
}

function ir() {
    const e = typeof chrome == "object" ? chrome.runtime : typeof browser == "object" ? browser.runtime : void 0;
    return typeof e == "object" && e.id !== void 0
}

function sr() {
    return typeof navigator == "object" && navigator.product === "ReactNative"
}

function ar() {
    const e = ce();
    return e.indexOf("MSIE ") >= 0 || e.indexOf("Trident/") >= 0
}

function or() {
    return M.NODE_CLIENT === !0 || M.NODE_ADMIN === !0
}

function Pe() {
    try {
        return typeof indexedDB == "object"
    } catch {
        return !1
    }
}

function $e() {
    return new Promise((e, t) => {
        try {
            let r = !0;
            const i = "validate-browser-context-for-indexeddb-analytics-module",
                n = self.indexedDB.open(i);
            n.onsuccess = () => {
                n.result.close(), r || self.indexedDB.deleteDatabase(i), e(!0)
            }, n.onupgradeneeded = () => {
                r = !1
            }, n.onerror = () => {
                var s;
                t(((s = n.error) === null || s === void 0 ? void 0 : s.message) || "")
            }
        } catch (r) {
            t(r)
        }
    })
}
var xe = "FirebaseError",
    j = class le extends Error {
        constructor(t, r, i) {
            super(r), this.code = t, this.customData = i, this.name = xe, Object.setPrototypeOf(this, le.prototype), Error.captureStackTrace && Error.captureStackTrace(this, he.prototype.create)
        }
    },
    he = class {
        constructor(e, t, r) {
            this.service = e, this.serviceName = t, this.errors = r
        }
        create(e, ...t) {
            const r = t[0] || {},
                i = `${this.service}/${e}`,
                n = this.errors[e],
                s = n ? ke(n, r) : "Error",
                a = `${this.serviceName}: ${s} (${i}).`;
            return new j(i, a, r)
        }
    };

function ke(e, t) {
    return e.replace(Le, (r, i) => {
        const n = t[i];
        return n != null ? String(n) : `<${i}?>`
    })
}
var Le = /\{\$([^}]+)}/g;

function K(e) {
    return JSON.parse(e)
}

function cr(e) {
    return JSON.stringify(e)
}
var de = function(e) {
        let t = {},
            r = {},
            i = {},
            n = "";
        try {
            const s = e.split(".");
            t = K(R(s[0]) || ""), r = K(R(s[1]) || ""), n = s[2], i = r.d || {}, delete r.d
        } catch {}
        return {
            header: t,
            claims: r,
            data: i,
            signature: n
        }
    },
    lr = function(e) {
        const t = de(e).claims;
        return !!t && typeof t == "object" && t.hasOwnProperty("iat")
    },
    hr = function(e) {
        const t = de(e).claims;
        return typeof t == "object" && t.admin === !0
    };

function dr(e, t) {
    return Object.prototype.hasOwnProperty.call(e, t)
}

function ur(e, t) {
    if (Object.prototype.hasOwnProperty.call(e, t)) return e[t]
}

function fr(e) {
    for (const t in e)
        if (Object.prototype.hasOwnProperty.call(e, t)) return !1;
    return !0
}

function pr(e, t, r) {
    const i = {};
    for (const n in e) Object.prototype.hasOwnProperty.call(e, n) && (i[n] = t.call(r, e[n], n, e));
    return i
}

function P(e, t) {
    if (e === t) return !0;
    const r = Object.keys(e),
        i = Object.keys(t);
    for (const n of r) {
        if (!i.includes(n)) return !1;
        const s = e[n],
            a = t[n];
        if (Z(s) && Z(a)) {
            if (!P(s, a)) return !1
        } else if (s !== a) return !1
    }
    for (const n of i)
        if (!r.includes(n)) return !1;
    return !0
}

function Z(e) {
    return e !== null && typeof e == "object"
}

function mr(e) {
    const t = [];
    for (const [r, i] of Object.entries(e)) Array.isArray(i) ? i.forEach(n => {
        t.push(encodeURIComponent(r) + "=" + encodeURIComponent(n))
    }) : t.push(encodeURIComponent(r) + "=" + encodeURIComponent(i));
    return t.length ? "&" + t.join("&") : ""
}

function br(e) {
    const t = {};
    return e.replace(/^\?/, "").split("&").forEach(r => {
        if (r) {
            const [i, n] = r.split("=");
            t[decodeURIComponent(i)] = decodeURIComponent(n)
        }
    }), t
}

function gr(e) {
    const t = e.indexOf("?");
    if (!t) return "";
    const r = e.indexOf("#", t);
    return e.substring(t, r > 0 ? r : void 0)
}
var vr = class {
    constructor() {
        this.chain_ = [], this.buf_ = [], this.W_ = [], this.pad_ = [], this.inbuf_ = 0, this.total_ = 0, this.blockSize = 512 / 8, this.pad_[0] = 128;
        for (let e = 1; e < this.blockSize; ++e) this.pad_[e] = 0;
        this.reset()
    }
    reset() {
        this.chain_[0] = 1732584193, this.chain_[1] = 4023233417, this.chain_[2] = 2562383102, this.chain_[3] = 271733878, this.chain_[4] = 3285377520, this.inbuf_ = 0, this.total_ = 0
    }
    compress_(e, t) {
        t || (t = 0);
        const r = this.W_;
        if (typeof e == "string")
            for (let h = 0; h < 16; h++) r[h] = e.charCodeAt(t) << 24 | e.charCodeAt(t + 1) << 16 | e.charCodeAt(t + 2) << 8 | e.charCodeAt(t + 3), t += 4;
        else
            for (let h = 0; h < 16; h++) r[h] = e[t] << 24 | e[t + 1] << 16 | e[t + 2] << 8 | e[t + 3], t += 4;
        for (let h = 16; h < 80; h++) {
            const o = r[h - 3] ^ r[h - 8] ^ r[h - 14] ^ r[h - 16];
            r[h] = (o << 1 | o >>> 31) & 4294967295
        }
        let i = this.chain_[0],
            n = this.chain_[1],
            s = this.chain_[2],
            a = this.chain_[3],
            l = this.chain_[4],
            c, u;
        for (let h = 0; h < 80; h++) {
            h < 40 ? h < 20 ? (c = a ^ n & (s ^ a), u = 1518500249) : (c = n ^ s ^ a, u = 1859775393) : h < 60 ? (c = n & s | a & (n | s), u = 2400959708) : (c = n ^ s ^ a, u = 3395469782);
            const o = (i << 5 | i >>> 27) + c + l + u + r[h] & 4294967295;
            l = a, a = s, s = (n << 30 | n >>> 2) & 4294967295, n = i, i = o
        }
        this.chain_[0] = this.chain_[0] + i & 4294967295, this.chain_[1] = this.chain_[1] + n & 4294967295, this.chain_[2] = this.chain_[2] + s & 4294967295, this.chain_[3] = this.chain_[3] + a & 4294967295, this.chain_[4] = this.chain_[4] + l & 4294967295
    }
    update(e, t) {
        if (e == null) return;
        t === void 0 && (t = e.length);
        const r = t - this.blockSize;
        let i = 0;
        const n = this.buf_;
        let s = this.inbuf_;
        for (; i < t;) {
            if (s === 0)
                for (; i <= r;) this.compress_(e, i), i += this.blockSize;
            if (typeof e == "string") {
                for (; i < t;)
                    if (n[s] = e.charCodeAt(i), ++s, ++i, s === this.blockSize) {
                        this.compress_(n), s = 0;
                        break
                    }
            } else
                for (; i < t;)
                    if (n[s] = e[i], ++s, ++i, s === this.blockSize) {
                        this.compress_(n), s = 0;
                        break
                    }
        }
        this.inbuf_ = s, this.total_ += t
    }
    digest() {
        const e = [];
        let t = this.total_ * 8;
        this.inbuf_ < 56 ? this.update(this.pad_, 56 - this.inbuf_) : this.update(this.pad_, this.blockSize - (this.inbuf_ - 56));
        for (let i = this.blockSize - 1; i >= 56; i--) this.buf_[i] = t & 255, t /= 256;
        this.compress_(this.buf_);
        let r = 0;
        for (let i = 0; i < 5; i++)
            for (let n = 24; n >= 0; n -= 8) e[r] = this.chain_[i] >> n & 255, ++r;
        return e
    }
};

function _r(e, t) {
    const r = new He(e, t);
    return r.subscribe.bind(r)
}
var He = class {
    constructor(e, t) {
        this.observers = [], this.unsubscribes = [], this.observerCount = 0, this.task = Promise.resolve(), this.finalized = !1, this.onNoObservers = t, this.task.then(() => {
            e(this)
        }).catch(r => {
            this.error(r)
        })
    }
    next(e) {
        this.forEachObserver(t => {
            t.next(e)
        })
    }
    error(e) {
        this.forEachObserver(t => {
            t.error(e)
        }), this.close(e)
    }
    complete() {
        this.forEachObserver(e => {
            e.complete()
        }), this.close()
    }
    subscribe(e, t, r) {
        let i;
        if (e === void 0 && t === void 0 && r === void 0) throw new Error("Missing Observer.");
        Fe(e, ["next", "error", "complete"]) ? i = e : i = {
            next: e,
            error: t,
            complete: r
        }, i.next === void 0 && (i.next = A), i.error === void 0 && (i.error = A), i.complete === void 0 && (i.complete = A);
        const n = this.unsubscribeOne.bind(this, this.observers.length);
        return this.finalized && this.task.then(() => {
            try {
                this.finalError ? i.error(this.finalError) : i.complete()
            } catch {}
        }), this.observers.push(i), n
    }
    unsubscribeOne(e) {
        this.observers === void 0 || this.observers[e] === void 0 || (delete this.observers[e], this.observerCount -= 1, this.observerCount === 0 && this.onNoObservers !== void 0 && this.onNoObservers(this))
    }
    forEachObserver(e) {
        if (!this.finalized)
            for (let t = 0; t < this.observers.length; t++) this.sendOne(t, e)
    }
    sendOne(e, t) {
        this.task.then(() => {
            if (this.observers !== void 0 && this.observers[e] !== void 0) try {
                t(this.observers[e])
            } catch (r) {
                typeof console < "u" && console.error && console.error(r)
            }
        })
    }
    close(e) {
        this.finalized || (this.finalized = !0, e !== void 0 && (this.finalError = e), this.task.then(() => {
            this.observers = void 0, this.onNoObservers = void 0
        }))
    }
};

function Fe(e, t) {
    if (typeof e != "object" || e === null) return !1;
    for (const r of t)
        if (r in e && typeof e[r] == "function") return !0;
    return !1
}

function A() {}

function yr(e, t) {
    return `${e} failed: ${t} argument `
}
var Er = function(e) {
        const t = [];
        let r = 0;
        for (let i = 0; i < e.length; i++) {
            let n = e.charCodeAt(i);
            if (n >= 55296 && n <= 56319) {
                const s = n - 55296;
                i++, _e(i < e.length, "Surrogate pair missing trail surrogate.");
                const a = e.charCodeAt(i) - 56320;
                n = 65536 + (s << 10) + a
            }
            n < 128 ? t[r++] = n : n < 2048 ? (t[r++] = n >> 6 | 192, t[r++] = n & 63 | 128) : n < 65536 ? (t[r++] = n >> 12 | 224, t[r++] = n >> 6 & 63 | 128, t[r++] = n & 63 | 128) : (t[r++] = n >> 18 | 240, t[r++] = n >> 12 & 63 | 128, t[r++] = n >> 6 & 63 | 128, t[r++] = n & 63 | 128)
        }
        return t
    },
    wr = function(e) {
        let t = 0;
        for (let r = 0; r < e.length; r++) {
            const i = e.charCodeAt(r);
            i < 128 ? t++ : i < 2048 ? t += 2 : i >= 55296 && i <= 56319 ? (t += 4, r++) : t += 3
        }
        return t
    };

function Cr(e) {
    return e && e._delegate ? e._delegate : e
}
var D = class {
        constructor(e, t, r) {
            this.name = e, this.instanceFactory = t, this.type = r, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY", this.onInstanceCreated = null
        }
        setInstantiationMode(e) {
            return this.instantiationMode = e, this
        }
        setMultipleInstances(e) {
            return this.multipleInstances = e, this
        }
        setServiceProps(e) {
            return this.serviceProps = e, this
        }
        setInstanceCreatedCallback(e) {
            return this.onInstanceCreated = e, this
        }
    },
    v = "[DEFAULT]",
    Ve = class {
        constructor(e, t) {
            this.name = e, this.container = t, this.component = null, this.instances = new Map, this.instancesDeferred = new Map, this.instancesOptions = new Map, this.onInitCallbacks = new Map
        }
        get(e) {
            const t = this.normalizeInstanceIdentifier(e);
            if (!this.instancesDeferred.has(t)) {
                const r = new Te;
                if (this.instancesDeferred.set(t, r), this.isInitialized(t) || this.shouldAutoInitialize()) try {
                    const i = this.getOrInitializeService({
                        instanceIdentifier: t
                    });
                    i && r.resolve(i)
                } catch {}
            }
            return this.instancesDeferred.get(t).promise
        }
        getImmediate(e) {
            var t;
            const r = this.normalizeInstanceIdentifier(e ? .identifier),
                i = (t = e ? .optional) !== null && t !== void 0 ? t : !1;
            if (this.isInitialized(r) || this.shouldAutoInitialize()) try {
                return this.getOrInitializeService({
                    instanceIdentifier: r
                })
            } catch (n) {
                if (i) return null;
                throw n
            } else {
                if (i) return null;
                throw Error(`Service ${this.name} is not available`)
            }
        }
        getComponent() {
            return this.component
        }
        setComponent(e) {
            if (e.name !== this.name) throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);
            if (this.component) throw Error(`Component for ${this.name} has already been provided`);
            if (this.component = e, !!this.shouldAutoInitialize()) {
                if (ze(e)) try {
                    this.getOrInitializeService({
                        instanceIdentifier: v
                    })
                } catch {}
                for (const [t, r] of this.instancesDeferred.entries()) {
                    const i = this.normalizeInstanceIdentifier(t);
                    try {
                        const n = this.getOrInitializeService({
                            instanceIdentifier: i
                        });
                        r.resolve(n)
                    } catch {}
                }
            }
        }
        clearInstance(e = v) {
            this.instancesDeferred.delete(e), this.instancesOptions.delete(e), this.instances.delete(e)
        }
        async delete() {
            const e = Array.from(this.instances.values());
            await Promise.all([...e.filter(t => "INTERNAL" in t).map(t => t.INTERNAL.delete()), ...e.filter(t => "_delete" in t).map(t => t._delete())])
        }
        isComponentSet() {
            return this.component != null
        }
        isInitialized(e = v) {
            return this.instances.has(e)
        }
        getOptions(e = v) {
            return this.instancesOptions.get(e) || {}
        }
        initialize(e = {}) {
            const {
                options: t = {}
            } = e, r = this.normalizeInstanceIdentifier(e.instanceIdentifier);
            if (this.isInitialized(r)) throw Error(`${this.name}(${r}) has already been initialized`);
            if (!this.isComponentSet()) throw Error(`Component ${this.name} has not been registered yet`);
            const i = this.getOrInitializeService({
                instanceIdentifier: r,
                options: t
            });
            for (const [n, s] of this.instancesDeferred.entries()) r === this.normalizeInstanceIdentifier(n) && s.resolve(i);
            return i
        }
        onInit(e, t) {
            var r;
            const i = this.normalizeInstanceIdentifier(t),
                n = (r = this.onInitCallbacks.get(i)) !== null && r !== void 0 ? r : new Set;
            n.add(e), this.onInitCallbacks.set(i, n);
            const s = this.instances.get(i);
            return s && e(s, i), () => {
                n.delete(e)
            }
        }
        invokeOnInitCallbacks(e, t) {
            const r = this.onInitCallbacks.get(t);
            if (r)
                for (const i of r) try {
                    i(e, t)
                } catch {}
        }
        getOrInitializeService({
            instanceIdentifier: e,
            options: t = {}
        }) {
            let r = this.instances.get(e);
            if (!r && this.component && (r = this.component.instanceFactory(this.container, {
                    instanceIdentifier: je(e),
                    options: t
                }), this.instances.set(e, r), this.instancesOptions.set(e, t), this.invokeOnInitCallbacks(r, e), this.component.onInstanceCreated)) try {
                this.component.onInstanceCreated(this.container, e, r)
            } catch {}
            return r || null
        }
        normalizeInstanceIdentifier(e = v) {
            return this.component ? this.component.multipleInstances ? e : v : e
        }
        shouldAutoInitialize() {
            return !!this.component && this.component.instantiationMode !== "EXPLICIT"
        }
    };

function je(e) {
    return e === v ? void 0 : e
}

function ze(e) {
    return e.instantiationMode === "EAGER"
}
var Ue = class {
        constructor(e) {
            this.name = e, this.providers = new Map
        }
        addComponent(e) {
            const t = this.getProvider(e.name);
            if (t.isComponentSet()) throw new Error(`Component ${e.name} has already been registered with ${this.name}`);
            t.setComponent(e)
        }
        addOrOverwriteComponent(e) {
            this.getProvider(e.name).isComponentSet() && this.providers.delete(e.name), this.addComponent(e)
        }
        getProvider(e) {
            if (this.providers.has(e)) return this.providers.get(e);
            const t = new Ve(e, this);
            return this.providers.set(e, t), t
        }
        getProviders() {
            return Array.from(this.providers.values())
        }
    },
    We = [],
    d;
(function(e) {
    e[e.DEBUG = 0] = "DEBUG", e[e.VERBOSE = 1] = "VERBOSE", e[e.INFO = 2] = "INFO", e[e.WARN = 3] = "WARN", e[e.ERROR = 4] = "ERROR", e[e.SILENT = 5] = "SILENT"
})(d || (d = {}));
var Ge = {
        debug: d.DEBUG,
        verbose: d.VERBOSE,
        info: d.INFO,
        warn: d.WARN,
        error: d.ERROR,
        silent: d.SILENT
    },
    Je = d.INFO,
    Ke = {
        [d.DEBUG]: "log",
        [d.VERBOSE]: "log",
        [d.INFO]: "info",
        [d.WARN]: "warn",
        [d.ERROR]: "error"
    },
    Ze = (e, t, ...r) => {
        if (t < e.logLevel) return;
        const i = new Date().toISOString(),
            n = Ke[t];
        if (n) console[n](`[${i}]  ${e.name}:`, ...r);
        else throw new Error(`Attempted to log a message with an invalid logType (value: ${t})`)
    },
    Ye = class {
        constructor(e) {
            this.name = e, this._logLevel = Je, this._logHandler = Ze, this._userLogHandler = null, We.push(this)
        }
        get logLevel() {
            return this._logLevel
        }
        set logLevel(e) {
            if (!(e in d)) throw new TypeError(`Invalid value "${e}" assigned to \`logLevel\``);
            this._logLevel = e
        }
        setLogLevel(e) {
            this._logLevel = typeof e == "string" ? Ge[e] : e
        }
        get logHandler() {
            return this._logHandler
        }
        set logHandler(e) {
            if (typeof e != "function") throw new TypeError("Value assigned to `logHandler` must be a function");
            this._logHandler = e
        }
        get userLogHandler() {
            return this._userLogHandler
        }
        set userLogHandler(e) {
            this._userLogHandler = e
        }
        debug(...e) {
            this._userLogHandler && this._userLogHandler(this, d.DEBUG, ...e), this._logHandler(this, d.DEBUG, ...e)
        }
        log(...e) {
            this._userLogHandler && this._userLogHandler(this, d.VERBOSE, ...e), this._logHandler(this, d.VERBOSE, ...e)
        }
        info(...e) {
            this._userLogHandler && this._userLogHandler(this, d.INFO, ...e), this._logHandler(this, d.INFO, ...e)
        }
        warn(...e) {
            this._userLogHandler && this._userLogHandler(this, d.WARN, ...e), this._logHandler(this, d.WARN, ...e)
        }
        error(...e) {
            this._userLogHandler && this._userLogHandler(this, d.ERROR, ...e), this._logHandler(this, d.ERROR, ...e)
        }
    },
    qe = (e, t) => t.some(r => e instanceof r),
    Y, q;

function Xe() {
    return Y || (Y = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])
}

function Qe() {
    return q || (q = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])
}
var ue = new WeakMap,
    $ = new WeakMap,
    fe = new WeakMap,
    O = new WeakMap,
    z = new WeakMap;

function et(e) {
    const t = new Promise((r, i) => {
        const n = () => {
                e.removeEventListener("success", s), e.removeEventListener("error", a)
            },
            s = () => {
                r(p(e.result)), n()
            },
            a = () => {
                i(e.error), n()
            };
        e.addEventListener("success", s), e.addEventListener("error", a)
    });
    return t.then(r => {
        r instanceof IDBCursor && ue.set(r, e)
    }).catch(() => {}), z.set(t, e), t
}

function tt(e) {
    if ($.has(e)) return;
    const t = new Promise((r, i) => {
        const n = () => {
                e.removeEventListener("complete", s), e.removeEventListener("error", a), e.removeEventListener("abort", a)
            },
            s = () => {
                r(), n()
            },
            a = () => {
                i(e.error || new DOMException("AbortError", "AbortError")), n()
            };
        e.addEventListener("complete", s), e.addEventListener("error", a), e.addEventListener("abort", a)
    });
    $.set(e, t)
}
var x = {
    get(e, t, r) {
        if (e instanceof IDBTransaction) {
            if (t === "done") return $.get(e);
            if (t === "objectStoreNames") return e.objectStoreNames || fe.get(e);
            if (t === "store") return r.objectStoreNames[1] ? void 0 : r.objectStore(r.objectStoreNames[0])
        }
        return p(e[t])
    },
    set(e, t, r) {
        return e[t] = r, !0
    },
    has(e, t) {
        return e instanceof IDBTransaction && (t === "done" || t === "store") ? !0 : t in e
    }
};

function rt(e) {
    x = e(x)
}

function nt(e) {
    return e === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype) ? function(t, ...r) {
        const i = e.call(B(this), t, ...r);
        return fe.set(i, t.sort ? t.sort() : [t]), p(i)
    } : Qe().includes(e) ? function(...t) {
        return e.apply(B(this), t), p(ue.get(this))
    } : function(...t) {
        return p(e.apply(B(this), t))
    }
}

function it(e) {
    return typeof e == "function" ? nt(e) : (e instanceof IDBTransaction && tt(e), qe(e, Xe()) ? new Proxy(e, x) : e)
}

function p(e) {
    if (e instanceof IDBRequest) return et(e);
    if (O.has(e)) return O.get(e);
    const t = it(e);
    return t !== e && (O.set(e, t), z.set(t, e)), t
}
var B = e => z.get(e);

function st(e, t, {
    blocked: r,
    upgrade: i,
    blocking: n,
    terminated: s
} = {}) {
    const a = indexedDB.open(e, t),
        l = p(a);
    return i && a.addEventListener("upgradeneeded", c => {
        i(p(a.result), c.oldVersion, c.newVersion, p(a.transaction), c)
    }), r && a.addEventListener("blocked", c => r(c.oldVersion, c.newVersion, c)), l.then(c => {
        s && c.addEventListener("close", () => s()), n && c.addEventListener("versionchange", u => n(u.oldVersion, u.newVersion, u))
    }).catch(() => {}), l
}

function Ir(e, {
    blocked: t
} = {}) {
    const r = indexedDB.deleteDatabase(e);
    return t && r.addEventListener("blocked", i => t(i.oldVersion, i)), p(r).then(() => {})
}
var at = ["get", "getKey", "getAll", "getAllKeys", "count"],
    ot = ["put", "add", "delete", "clear"],
    T = new Map;

function X(e, t) {
    if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string")) return;
    if (T.get(t)) return T.get(t);
    const r = t.replace(/FromIndex$/, ""),
        i = t !== r,
        n = ot.includes(r);
    if (!(r in (i ? IDBIndex : IDBObjectStore).prototype) || !(n || at.includes(r))) return;
    const s = async function(a, ...l) {
        const c = this.transaction(a, n ? "readwrite" : "readonly");
        let u = c.store;
        return i && (u = u.index(l.shift())), (await Promise.all([u[r](...l), n && c.done]))[0]
    };
    return T.set(t, s), s
}
rt(e => ({ ...e,
    get: (t, r, i) => X(t, r) || e.get(t, r, i),
    has: (t, r) => !!X(t, r) || e.has(t, r)
}));
var ct = class {
    constructor(e) {
        this.container = e
    }
    getPlatformInfoString() {
        return this.container.getProviders().map(e => {
            if (lt(e)) {
                const t = e.getImmediate();
                return `${t.library}/${t.version}`
            } else return null
        }).filter(e => e).join(" ")
    }
};

function lt(e) {
    const t = e.getComponent();
    return t ? .type === "VERSION"
}
var k = "@firebase/app",
    Q = "0.13.2",
    m = new Ye("@firebase/app"),
    ht = "@firebase/app-compat",
    dt = "@firebase/analytics-compat",
    ut = "@firebase/analytics",
    ft = "@firebase/app-check-compat",
    pt = "@firebase/app-check",
    mt = "@firebase/auth",
    bt = "@firebase/auth-compat",
    gt = "@firebase/database",
    vt = "@firebase/data-connect",
    _t = "@firebase/database-compat",
    yt = "@firebase/functions",
    Et = "@firebase/functions-compat",
    wt = "@firebase/installations",
    Ct = "@firebase/installations-compat",
    It = "@firebase/messaging",
    Dt = "@firebase/messaging-compat",
    St = "@firebase/performance",
    At = "@firebase/performance-compat",
    Ot = "@firebase/remote-config",
    Bt = "@firebase/remote-config-compat",
    Tt = "@firebase/storage",
    Nt = "@firebase/storage-compat",
    Mt = "@firebase/firestore",
    Rt = "@firebase/ai",
    Pt = "@firebase/firestore-compat",
    $t = "firebase",
    xt = "11.10.0",
    pe = "[DEFAULT]",
    kt = {
        [k]: "fire-core",
        [ht]: "fire-core-compat",
        [ut]: "fire-analytics",
        [dt]: "fire-analytics-compat",
        [pt]: "fire-app-check",
        [ft]: "fire-app-check-compat",
        [mt]: "fire-auth",
        [bt]: "fire-auth-compat",
        [gt]: "fire-rtdb",
        [vt]: "fire-data-connect",
        [_t]: "fire-rtdb-compat",
        [yt]: "fire-fn",
        [Et]: "fire-fn-compat",
        [wt]: "fire-iid",
        [Ct]: "fire-iid-compat",
        [It]: "fire-fcm",
        [Dt]: "fire-fcm-compat",
        [St]: "fire-perf",
        [At]: "fire-perf-compat",
        [Ot]: "fire-rc",
        [Bt]: "fire-rc-compat",
        [Tt]: "fire-gcs",
        [Nt]: "fire-gcs-compat",
        [Mt]: "fire-fst",
        [Pt]: "fire-fst-compat",
        [Rt]: "fire-vertex",
        "fire-js": "fire-js",
        [$t]: "fire-js-all"
    },
    _ = new Map,
    L = new Map,
    H = new Map;

function ee(e, t) {
    try {
        e.container.addComponent(t)
    } catch (r) {
        m.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`, r)
    }
}

function F(e) {
    const t = e.name;
    if (H.has(t)) return m.debug(`There were multiple attempts to register component ${t}.`), !1;
    H.set(t, e);
    for (const r of _.values()) ee(r, e);
    for (const r of L.values()) ee(r, e);
    return !0
}

function Dr(e, t) {
    const r = e.container.getProvider("heartbeat").getImmediate({
        optional: !0
    });
    return r && r.triggerHeartbeat(), e.container.getProvider(t)
}

function Sr(e) {
    return e == null ? !1 : e.settings !== void 0
}
var b = new he("app", "Firebase", {
        "no-app": "No Firebase App '{$appName}' has been created - call initializeApp() first",
        "bad-app-name": "Illegal App name: '{$appName}'",
        "duplicate-app": "Firebase App named '{$appName}' already exists with different options or config",
        "app-deleted": "Firebase App named '{$appName}' already deleted",
        "server-app-deleted": "Firebase Server App has been deleted",
        "no-options": "Need to provide options, when not being deployed to hosting via source.",
        "invalid-app-argument": "firebase.{$appName}() takes either no argument or a Firebase App instance.",
        "invalid-log-argument": "First argument to `onLog` must be null or a function.",
        "idb-open": "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
        "idb-get": "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
        "idb-set": "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
        "idb-delete": "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",
        "finalization-registry-not-supported": "FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",
        "invalid-server-app-environment": "FirebaseServerApp is not for use in browser environments."
    }),
    Lt = class {
        constructor(e, t, r) {
            this._isDeleted = !1, this._options = Object.assign({}, e), this._config = Object.assign({}, t), this._name = t.name, this._automaticDataCollectionEnabled = t.automaticDataCollectionEnabled, this._container = r, this.container.addComponent(new D("app", () => this, "PUBLIC"))
        }
        get automaticDataCollectionEnabled() {
            return this.checkDestroyed(), this._automaticDataCollectionEnabled
        }
        set automaticDataCollectionEnabled(e) {
            this.checkDestroyed(), this._automaticDataCollectionEnabled = e
        }
        get name() {
            return this.checkDestroyed(), this._name
        }
        get options() {
            return this.checkDestroyed(), this._options
        }
        get config() {
            return this.checkDestroyed(), this._config
        }
        get container() {
            return this._container
        }
        get isDeleted() {
            return this._isDeleted
        }
        set isDeleted(e) {
            this._isDeleted = e
        }
        checkDestroyed() {
            if (this.isDeleted) throw b.create("app-deleted", {
                appName: this._name
            })
        }
    },
    Ar = xt;

function Ht(e, t = {}) {
    let r = e;
    typeof t != "object" && (t = {
        name: t
    });
    const i = Object.assign({
            name: pe,
            automaticDataCollectionEnabled: !0
        }, t),
        n = i.name;
    if (typeof n != "string" || !n) throw b.create("bad-app-name", {
        appName: String(n)
    });
    if (r || (r = oe()), !r) throw b.create("no-options");
    const s = _.get(n);
    if (s) {
        if (P(r, s.options) && P(i, s.config)) return s;
        throw b.create("duplicate-app", {
            appName: n
        })
    }
    const a = new Ue(n);
    for (const c of H.values()) a.addComponent(c);
    const l = new Lt(r, i, a);
    return _.set(n, l), l
}

function Or(e = pe) {
    const t = _.get(e);
    if (!t && e === "[DEFAULT]" && oe()) return Ht();
    if (!t) throw b.create("no-app", {
        appName: e
    });
    return t
}

function Br() {
    return Array.from(_.values())
}
async function Tr(e) {
    let t = !1;
    const r = e.name;
    _.has(r) ? (t = !0, _.delete(r)) : L.has(r) && e.decRefCount() <= 0 && (L.delete(r), t = !0), t && (await Promise.all(e.container.getProviders().map(i => i.delete())), e.isDeleted = !0)
}

function C(e, t, r) {
    var i;
    let n = (i = kt[e]) !== null && i !== void 0 ? i : e;
    r && (n += `-${r}`);
    const s = n.match(/\s|\//),
        a = t.match(/\s|\//);
    if (s || a) {
        const l = [`Unable to register library "${n}" with version "${t}":`];
        s && l.push(`library name "${n}" contains illegal characters (whitespace or "/")`), s && a && l.push("and"), a && l.push(`version name "${t}" contains illegal characters (whitespace or "/")`), m.warn(l.join(" "));
        return
    }
    F(new D(`${n}-version`, () => ({
        library: n,
        version: t
    }), "VERSION"))
}
var Ft = "firebase-heartbeat-database",
    Vt = 1,
    E = "firebase-heartbeat-store",
    N = null;

function me() {
    return N || (N = st(Ft, Vt, {
        upgrade: (e, t) => {
            switch (t) {
                case 0:
                    try {
                        e.createObjectStore(E)
                    } catch (r) {
                        console.warn(r)
                    }
            }
        }
    }).catch(e => {
        throw b.create("idb-open", {
            originalErrorMessage: e.message
        })
    })), N
}
async function jt(e) {
    try {
        const t = (await me()).transaction(E),
            r = await t.objectStore(E).get(be(e));
        return await t.done, r
    } catch (t) {
        if (t instanceof j) m.warn(t.message);
        else {
            const r = b.create("idb-get", {
                originalErrorMessage: t ? .message
            });
            m.warn(r.message)
        }
    }
}
async function te(e, t) {
    try {
        const r = (await me()).transaction(E, "readwrite");
        await r.objectStore(E).put(t, be(e)), await r.done
    } catch (r) {
        if (r instanceof j) m.warn(r.message);
        else {
            const i = b.create("idb-set", {
                originalErrorMessage: r ? .message
            });
            m.warn(i.message)
        }
    }
}

function be(e) {
    return `${e.name}!${e.options.appId}`
}
var zt = 1024,
    Ut = 30,
    Wt = class {
        constructor(e) {
            this.container = e, this._heartbeatsCache = null;
            const t = this.container.getProvider("app").getImmediate();
            this._storage = new Jt(t), this._heartbeatsCachePromise = this._storage.read().then(r => (this._heartbeatsCache = r, r))
        }
        async triggerHeartbeat() {
            var e, t;
            try {
                const r = this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),
                    i = re();
                if (((e = this._heartbeatsCache) === null || e === void 0 ? void 0 : e.heartbeats) == null && (this._heartbeatsCache = await this._heartbeatsCachePromise, ((t = this._heartbeatsCache) === null || t === void 0 ? void 0 : t.heartbeats) == null) || this._heartbeatsCache.lastSentHeartbeatDate === i || this._heartbeatsCache.heartbeats.some(n => n.date === i)) return;
                if (this._heartbeatsCache.heartbeats.push({
                        date: i,
                        agent: r
                    }), this._heartbeatsCache.heartbeats.length > Ut) {
                    const n = Kt(this._heartbeatsCache.heartbeats);
                    this._heartbeatsCache.heartbeats.splice(n, 1)
                }
                return this._storage.overwrite(this._heartbeatsCache)
            } catch (r) {
                m.warn(r)
            }
        }
        async getHeartbeatsHeader() {
            var e;
            try {
                if (this._heartbeatsCache === null && await this._heartbeatsCachePromise, ((e = this._heartbeatsCache) === null || e === void 0 ? void 0 : e.heartbeats) == null || this._heartbeatsCache.heartbeats.length === 0) return "";
                const t = re(),
                    {
                        heartbeatsToSend: r,
                        unsentEntries: i
                    } = Gt(this._heartbeatsCache.heartbeats),
                    n = I(JSON.stringify({
                        version: 2,
                        heartbeats: r
                    }));
                return this._heartbeatsCache.lastSentHeartbeatDate = t, i.length > 0 ? (this._heartbeatsCache.heartbeats = i, await this._storage.overwrite(this._heartbeatsCache)) : (this._heartbeatsCache.heartbeats = [], this._storage.overwrite(this._heartbeatsCache)), n
            } catch (t) {
                return m.warn(t), ""
            }
        }
    };

function re() {
    return new Date().toISOString().substring(0, 10)
}

function Gt(e, t = zt) {
    const r = [];
    let i = e.slice();
    for (const n of e) {
        const s = r.find(a => a.agent === n.agent);
        if (s) {
            if (s.dates.push(n.date), ne(r) > t) {
                s.dates.pop();
                break
            }
        } else if (r.push({
                agent: n.agent,
                dates: [n.date]
            }), ne(r) > t) {
            r.pop();
            break
        }
        i = i.slice(1)
    }
    return {
        heartbeatsToSend: r,
        unsentEntries: i
    }
}
var Jt = class {
    constructor(e) {
        this.app = e, this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck()
    }
    async runIndexedDBEnvironmentCheck() {
        return Pe() ? $e().then(() => !0).catch(() => !1) : !1
    }
    async read() {
        if (await this._canUseIndexedDBPromise) {
            const e = await jt(this.app);
            return e ? .heartbeats ? e : {
                heartbeats: []
            }
        } else return {
            heartbeats: []
        }
    }
    async overwrite(e) {
        var t;
        if (await this._canUseIndexedDBPromise) {
            const r = await this.read();
            return te(this.app, {
                lastSentHeartbeatDate: (t = e.lastSentHeartbeatDate) !== null && t !== void 0 ? t : r.lastSentHeartbeatDate,
                heartbeats: e.heartbeats
            })
        } else return
    }
    async add(e) {
        var t;
        if (await this._canUseIndexedDBPromise) {
            const r = await this.read();
            return te(this.app, {
                lastSentHeartbeatDate: (t = e.lastSentHeartbeatDate) !== null && t !== void 0 ? t : r.lastSentHeartbeatDate,
                heartbeats: [...r.heartbeats, ...e.heartbeats]
            })
        } else return
    }
};

function ne(e) {
    return I(JSON.stringify({
        version: 2,
        heartbeats: e
    })).length
}

function Kt(e) {
    if (e.length === 0) return -1;
    let t = 0,
        r = e[0].date;
    for (let i = 1; i < e.length; i++) e[i].date < r && (r = e[i].date, t = i);
    return t
}

function Zt(e) {
    F(new D("platform-logger", t => new ct(t), "PRIVATE")), F(new D("heartbeat", t => new Wt(t), "PRIVATE")), C(k, Q, e), C(k, Q, "esm2017"), C("fire-js", "")
}
Zt("");
C("firebase", "11.10.0", "app");
export {
    ur as $, P as A, Ne as B, se as C, er as D, dr as E, Xt as F, or as G, fr as H, Cr as I, K as J, sr as K, ce as L, gr as M, Be as N, _r as O, qt as P, br as Q, hr as R, ye as S, Ce as T, ar as U, nr as V, rr as W, Qt as X, pr as Y, mr as Z, Te as _, Tr as a, vr as b, Ht as c, st as d, wr as et, d as f, Ve as g, Ue as h, F as i, yr as j, Yt as k, C as l, D as m, Dr as n, cr as nt, Or as o, Ye as p, lr as q, Sr as r, tr as rt, Br as s, Ar as t, Er as tt, Ir as u, he as v, R as w, _e as x, j as y, ir as z
};