import {
    C as i,
    S as m,
    T as s,
    w as r
} from "./vendor-datefns-CALvQ3Vn.js";
try {
    (function() {
        var a = typeof window < "u" ? window : typeof global < "u" ? global : typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : {},
            e = new a.Error().stack;
        e && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[e] = "2297e45b-fe25-4bad-bb3e-acdf4cfb0a31", a._sentryDebugIdIdentifier = "sentry-dbid-2297e45b-fe25-4bad-bb3e-acdf4cfb0a31")
    })()
} catch {}
var u = {
        lessThanXSeconds: {
            one: "kurang dari 1 detik",
            other: "kurang dari {{count}} detik"
        },
        xSeconds: {
            one: "1 detik",
            other: "{{count}} detik"
        },
        halfAMinute: "setengah menit",
        lessThanXMinutes: {
            one: "kurang dari 1 menit",
            other: "kurang dari {{count}} menit"
        },
        xMinutes: {
            one: "1 menit",
            other: "{{count}} menit"
        },
        aboutXHours: {
            one: "sekitar 1 jam",
            other: "sekitar {{count}} jam"
        },
        xHours: {
            one: "1 jam",
            other: "{{count}} jam"
        },
        xDays: {
            one: "1 hari",
            other: "{{count}} hari"
        },
        aboutXWeeks: {
            one: "sekitar 1 minggu",
            other: "sekitar {{count}} minggu"
        },
        xWeeks: {
            one: "1 minggu",
            other: "{{count}} minggu"
        },
        aboutXMonths: {
            one: "sekitar 1 bulan",
            other: "sekitar {{count}} bulan"
        },
        xMonths: {
            one: "1 bulan",
            other: "{{count}} bulan"
        },
        aboutXYears: {
            one: "sekitar 1 tahun",
            other: "sekitar {{count}} tahun"
        },
        xYears: {
            one: "1 tahun",
            other: "{{count}} tahun"
        },
        overXYears: {
            one: "lebih dari 1 tahun",
            other: "lebih dari {{count}} tahun"
        },
        almostXYears: {
            one: "hampir 1 tahun",
            other: "hampir {{count}} tahun"
        }
    },
    d = (a, e, n) => {
        let t;
        const o = u[a];
        return typeof o == "string" ? t = o : e === 1 ? t = o.one : t = o.other.replace("{{count}}", e.toString()), n ? .addSuffix ? n.comparison && n.comparison > 0 ? "dalam waktu " + t : t + " yang lalu" : t
    },
    l = {
        full: "EEEE, d MMMM yyyy",
        long: "d MMMM yyyy",
        medium: "d MMM yyyy",
        short: "d/M/yyyy"
    },
    h = {
        full: "HH.mm.ss",
        long: "HH.mm.ss",
        medium: "HH.mm",
        short: "HH.mm"
    },
    g = {
        full: "{{date}} 'pukul' {{time}}",
        long: "{{date}} 'pukul' {{time}}",
        medium: "{{date}}, {{time}}",
        short: "{{date}}, {{time}}"
    },
    b = {
        date: s({
            formats: l,
            defaultWidth: "full"
        }),
        time: s({
            formats: h,
            defaultWidth: "full"
        }),
        dateTime: s({
            formats: g,
            defaultWidth: "full"
        })
    },
    f = {
        lastWeek: "eeee 'lalu pukul' p",
        yesterday: "'Kemarin pukul' p",
        today: "'Hari ini pukul' p",
        tomorrow: "'Besok pukul' p",
        nextWeek: "eeee 'pukul' p",
        other: "P"
    },
    p = (a, e, n, t) => f[a],
    v = {
        narrow: ["SM", "M"],
        abbreviated: ["SM", "M"],
        wide: ["Sebelum Masehi", "Masehi"]
    },
    c = {
        narrow: ["1", "2", "3", "4"],
        abbreviated: ["K1", "K2", "K3", "K4"],
        wide: ["Kuartal ke-1", "Kuartal ke-2", "Kuartal ke-3", "Kuartal ke-4"]
    },
    k = {
        narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
        abbreviated: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agt", "Sep", "Okt", "Nov", "Des"],
        wide: ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    },
    y = {
        narrow: ["M", "S", "S", "R", "K", "J", "S"],
        short: ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"],
        abbreviated: ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"],
        wide: ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    },
    M = {
        narrow: {
            am: "AM",
            pm: "PM",
            midnight: "tengah malam",
            noon: "tengah hari",
            morning: "pagi",
            afternoon: "siang",
            evening: "sore",
            night: "malam"
        },
        abbreviated: {
            am: "AM",
            pm: "PM",
            midnight: "tengah malam",
            noon: "tengah hari",
            morning: "pagi",
            afternoon: "siang",
            evening: "sore",
            night: "malam"
        },
        wide: {
            am: "AM",
            pm: "PM",
            midnight: "tengah malam",
            noon: "tengah hari",
            morning: "pagi",
            afternoon: "siang",
            evening: "sore",
            night: "malam"
        }
    },
    w = {
        narrow: {
            am: "AM",
            pm: "PM",
            midnight: "tengah malam",
            noon: "tengah hari",
            morning: "pagi",
            afternoon: "siang",
            evening: "sore",
            night: "malam"
        },
        abbreviated: {
            am: "AM",
            pm: "PM",
            midnight: "tengah malam",
            noon: "tengah hari",
            morning: "pagi",
            afternoon: "siang",
            evening: "sore",
            night: "malam"
        },
        wide: {
            am: "AM",
            pm: "PM",
            midnight: "tengah malam",
            noon: "tengah hari",
            morning: "pagi",
            afternoon: "siang",
            evening: "sore",
            night: "malam"
        }
    },
    P = (a, e) => "ke-" + Number(a),
    S = {
        ordinalNumber: P,
        era: r({
            values: v,
            defaultWidth: "wide"
        }),
        quarter: r({
            values: c,
            defaultWidth: "wide",
            argumentCallback: a => a - 1
        }),
        month: r({
            values: k,
            defaultWidth: "wide"
        }),
        day: r({
            values: y,
            defaultWidth: "wide"
        }),
        dayPeriod: r({
            values: M,
            defaultWidth: "wide",
            formattingValues: w,
            defaultFormattingWidth: "wide"
        })
    },
    W = /^ke-(\d+)?/i,
    j = /\d+/i,
    D = {
        narrow: /^(sm|m)/i,
        abbreviated: /^(s\.?\s?m\.?|s\.?\s?e\.?\s?u\.?|m\.?|e\.?\s?u\.?)/i,
        wide: /^(sebelum masehi|sebelum era umum|masehi|era umum)/i
    },
    K = {
        any: [/^s/i, /^(m|e)/i]
    },
    A = {
        narrow: /^[1234]/i,
        abbreviated: /^K-?\s[1234]/i,
        wide: /^Kuartal ke-?\s?[1234]/i
    },
    J = {
        any: [/1/i, /2/i, /3/i, /4/i]
    },
    F = {
        narrow: /^[jfmasond]/i,
        abbreviated: /^(jan|feb|mar|apr|mei|jun|jul|agt|sep|okt|nov|des)/i,
        wide: /^(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember)/i
    },
    H = {
        narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
        any: [/^ja/i, /^f/i, /^ma/i, /^ap/i, /^me/i, /^jun/i, /^jul/i, /^ag/i, /^s/i, /^o/i, /^n/i, /^d/i]
    },
    x = {
        narrow: /^[srkjm]/i,
        short: /^(min|sen|sel|rab|kam|jum|sab)/i,
        abbreviated: /^(min|sen|sel|rab|kam|jum|sab)/i,
        wide: /^(minggu|senin|selasa|rabu|kamis|jumat|sabtu)/i
    },
    N = {
        narrow: [/^m/i, /^s/i, /^s/i, /^r/i, /^k/i, /^j/i, /^s/i],
        any: [/^m/i, /^sen/i, /^sel/i, /^r/i, /^k/i, /^j/i, /^sa/i]
    },
    V = {
        narrow: /^(a|p|tengah m|tengah h|(di(\swaktu)?) (pagi|siang|sore|malam))/i,
        any: /^([ap]\.?\s?m\.?|tengah malam|tengah hari|(di(\swaktu)?) (pagi|siang|sore|malam))/i
    },
    X = {
        any: {
            am: /^a/i,
            pm: /^pm/i,
            midnight: /^tengah m/i,
            noon: /^tengah h/i,
            morning: /pagi/i,
            afternoon: /siang/i,
            evening: /sore/i,
            night: /malam/i
        }
    },
    _ = {
        ordinalNumber: m({
            matchPattern: W,
            parsePattern: j,
            valueCallback: a => parseInt(a, 10)
        }),
        era: i({
            matchPatterns: D,
            defaultMatchWidth: "wide",
            parsePatterns: K,
            defaultParseWidth: "any"
        }),
        quarter: i({
            matchPatterns: A,
            defaultMatchWidth: "wide",
            parsePatterns: J,
            defaultParseWidth: "any",
            valueCallback: a => a + 1
        }),
        month: i({
            matchPatterns: F,
            defaultMatchWidth: "wide",
            parsePatterns: H,
            defaultParseWidth: "any"
        }),
        day: i({
            matchPatterns: x,
            defaultMatchWidth: "wide",
            parsePatterns: N,
            defaultParseWidth: "any"
        }),
        dayPeriod: i({
            matchPatterns: V,
            defaultMatchWidth: "any",
            parsePatterns: X,
            defaultParseWidth: "any"
        })
    },
    T = {
        code: "id",
        formatDistance: d,
        formatLong: b,
        formatRelative: p,
        localize: S,
        match: _,
        options: {
            weekStartsOn: 1,
            firstWeekContainsDate: 1
        }
    };
export {
    T as
    default, T as id
};