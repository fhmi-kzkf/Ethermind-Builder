import {
    A as He,
    B as Ye,
    F as jt,
    H as Qn,
    I as p,
    K as Zn,
    L as T,
    M as z,
    N as er,
    O as tr,
    Q as B,
    U as nr,
    V as rr,
    W as ir,
    X as sr,
    Z as W,
    f as Kt,
    i as pt,
    l as mt,
    m as _t,
    n as zt,
    o as ar,
    p as or,
    r as I,
    rt as cr,
    t as te,
    v as Je,
    w as lr,
    y as Xe,
    z as ur
} from "./vendor-firebase-core-bjLY_DoP.js";
import {
    r as Qe
} from "./vendor-tslib-CeDFfI6J.js";
try {
    (function() {
        var t = typeof window < "u" ? window : typeof global < "u" ? global : typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : {},
            e = new t.Error().stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "03679bec-f1aa-40da-997e-82697af98d4d", t._sentryDebugIdIdentifier = "sentry-dbid-03679bec-f1aa-40da-997e-82697af98d4d")
    })()
} catch {}

function Bt() {
    return {
        "dependent-sdk-initialized-before-auth": "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK."
    }
}
var dr = Bt,
    $t = new Je("auth", "Firebase", Bt()),
    aa = {
        ADMIN_ONLY_OPERATION: "auth/admin-restricted-operation",
        ARGUMENT_ERROR: "auth/argument-error",
        APP_NOT_AUTHORIZED: "auth/app-not-authorized",
        APP_NOT_INSTALLED: "auth/app-not-installed",
        CAPTCHA_CHECK_FAILED: "auth/captcha-check-failed",
        CODE_EXPIRED: "auth/code-expired",
        CORDOVA_NOT_READY: "auth/cordova-not-ready",
        CORS_UNSUPPORTED: "auth/cors-unsupported",
        CREDENTIAL_ALREADY_IN_USE: "auth/credential-already-in-use",
        CREDENTIAL_MISMATCH: "auth/custom-token-mismatch",
        CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "auth/requires-recent-login",
        DEPENDENT_SDK_INIT_BEFORE_AUTH: "auth/dependent-sdk-initialized-before-auth",
        DYNAMIC_LINK_NOT_ACTIVATED: "auth/dynamic-link-not-activated",
        EMAIL_CHANGE_NEEDS_VERIFICATION: "auth/email-change-needs-verification",
        EMAIL_EXISTS: "auth/email-already-in-use",
        EMULATOR_CONFIG_FAILED: "auth/emulator-config-failed",
        EXPIRED_OOB_CODE: "auth/expired-action-code",
        EXPIRED_POPUP_REQUEST: "auth/cancelled-popup-request",
        INTERNAL_ERROR: "auth/internal-error",
        INVALID_API_KEY: "auth/invalid-api-key",
        INVALID_APP_CREDENTIAL: "auth/invalid-app-credential",
        INVALID_APP_ID: "auth/invalid-app-id",
        INVALID_AUTH: "auth/invalid-user-token",
        INVALID_AUTH_EVENT: "auth/invalid-auth-event",
        INVALID_CERT_HASH: "auth/invalid-cert-hash",
        INVALID_CODE: "auth/invalid-verification-code",
        INVALID_CONTINUE_URI: "auth/invalid-continue-uri",
        INVALID_CORDOVA_CONFIGURATION: "auth/invalid-cordova-configuration",
        INVALID_CUSTOM_TOKEN: "auth/invalid-custom-token",
        INVALID_DYNAMIC_LINK_DOMAIN: "auth/invalid-dynamic-link-domain",
        INVALID_EMAIL: "auth/invalid-email",
        INVALID_EMULATOR_SCHEME: "auth/invalid-emulator-scheme",
        INVALID_IDP_RESPONSE: "auth/invalid-credential",
        INVALID_LOGIN_CREDENTIALS: "auth/invalid-credential",
        INVALID_MESSAGE_PAYLOAD: "auth/invalid-message-payload",
        INVALID_MFA_SESSION: "auth/invalid-multi-factor-session",
        INVALID_OAUTH_CLIENT_ID: "auth/invalid-oauth-client-id",
        INVALID_OAUTH_PROVIDER: "auth/invalid-oauth-provider",
        INVALID_OOB_CODE: "auth/invalid-action-code",
        INVALID_ORIGIN: "auth/unauthorized-domain",
        INVALID_PASSWORD: "auth/wrong-password",
        INVALID_PERSISTENCE: "auth/invalid-persistence-type",
        INVALID_PHONE_NUMBER: "auth/invalid-phone-number",
        INVALID_PROVIDER_ID: "auth/invalid-provider-id",
        INVALID_RECIPIENT_EMAIL: "auth/invalid-recipient-email",
        INVALID_SENDER: "auth/invalid-sender",
        INVALID_SESSION_INFO: "auth/invalid-verification-id",
        INVALID_TENANT_ID: "auth/invalid-tenant-id",
        MFA_INFO_NOT_FOUND: "auth/multi-factor-info-not-found",
        MFA_REQUIRED: "auth/multi-factor-auth-required",
        MISSING_ANDROID_PACKAGE_NAME: "auth/missing-android-pkg-name",
        MISSING_APP_CREDENTIAL: "auth/missing-app-credential",
        MISSING_AUTH_DOMAIN: "auth/auth-domain-config-required",
        MISSING_CODE: "auth/missing-verification-code",
        MISSING_CONTINUE_URI: "auth/missing-continue-uri",
        MISSING_IFRAME_START: "auth/missing-iframe-start",
        MISSING_IOS_BUNDLE_ID: "auth/missing-ios-bundle-id",
        MISSING_OR_INVALID_NONCE: "auth/missing-or-invalid-nonce",
        MISSING_MFA_INFO: "auth/missing-multi-factor-info",
        MISSING_MFA_SESSION: "auth/missing-multi-factor-session",
        MISSING_PHONE_NUMBER: "auth/missing-phone-number",
        MISSING_SESSION_INFO: "auth/missing-verification-id",
        MODULE_DESTROYED: "auth/app-deleted",
        NEED_CONFIRMATION: "auth/account-exists-with-different-credential",
        NETWORK_REQUEST_FAILED: "auth/network-request-failed",
        NULL_USER: "auth/null-user",
        NO_AUTH_EVENT: "auth/no-auth-event",
        NO_SUCH_PROVIDER: "auth/no-such-provider",
        OPERATION_NOT_ALLOWED: "auth/operation-not-allowed",
        OPERATION_NOT_SUPPORTED: "auth/operation-not-supported-in-this-environment",
        POPUP_BLOCKED: "auth/popup-blocked",
        POPUP_CLOSED_BY_USER: "auth/popup-closed-by-user",
        PROVIDER_ALREADY_LINKED: "auth/provider-already-linked",
        QUOTA_EXCEEDED: "auth/quota-exceeded",
        REDIRECT_CANCELLED_BY_USER: "auth/redirect-cancelled-by-user",
        REDIRECT_OPERATION_PENDING: "auth/redirect-operation-pending",
        REJECTED_CREDENTIAL: "auth/rejected-credential",
        SECOND_FACTOR_ALREADY_ENROLLED: "auth/second-factor-already-in-use",
        SECOND_FACTOR_LIMIT_EXCEEDED: "auth/maximum-second-factor-count-exceeded",
        TENANT_ID_MISMATCH: "auth/tenant-id-mismatch",
        TIMEOUT: "auth/timeout",
        TOKEN_EXPIRED: "auth/user-token-expired",
        TOO_MANY_ATTEMPTS_TRY_LATER: "auth/too-many-requests",
        UNAUTHORIZED_DOMAIN: "auth/unauthorized-continue-uri",
        UNSUPPORTED_FIRST_FACTOR: "auth/unsupported-first-factor",
        UNSUPPORTED_PERSISTENCE: "auth/unsupported-persistence-type",
        UNSUPPORTED_TENANT_OPERATION: "auth/unsupported-tenant-operation",
        UNVERIFIED_EMAIL: "auth/unverified-email",
        USER_CANCELLED: "auth/user-cancelled",
        USER_DELETED: "auth/user-not-found",
        USER_DISABLED: "auth/user-disabled",
        USER_MISMATCH: "auth/user-mismatch",
        USER_SIGNED_OUT: "auth/user-signed-out",
        WEAK_PASSWORD: "auth/weak-password",
        WEB_STORAGE_UNSUPPORTED: "auth/web-storage-unsupported",
        ALREADY_INITIALIZED: "auth/already-initialized",
        RECAPTCHA_NOT_ENABLED: "auth/recaptcha-not-enabled",
        MISSING_RECAPTCHA_TOKEN: "auth/missing-recaptcha-token",
        INVALID_RECAPTCHA_TOKEN: "auth/invalid-recaptcha-token",
        INVALID_RECAPTCHA_ACTION: "auth/invalid-recaptcha-action",
        MISSING_CLIENT_TYPE: "auth/missing-client-type",
        MISSING_RECAPTCHA_VERSION: "auth/missing-recaptcha-version",
        INVALID_RECAPTCHA_VERSION: "auth/invalid-recaptcha-version",
        INVALID_REQ_TYPE: "auth/invalid-req-type",
        INVALID_HOSTING_LINK_DOMAIN: "auth/invalid-hosting-link-domain"
    },
    Ie = new or("@firebase/auth");

function hr(t, ...e) {
    Ie.logLevel <= Kt.WARN && Ie.warn(`Auth (${te}): ${t}`, ...e)
}

function ue(t, ...e) {
    Ie.logLevel <= Kt.ERROR && Ie.error(`Auth (${te}): ${t}`, ...e)
}

function E(t, ...e) {
    throw et(t, ...e)
}

function v(t, ...e) {
    return et(t, ...e)
}

function Ze(t, e, n) {
    const r = Object.assign(Object.assign({}, dr()), {
        [e]: n
    });
    return new Je("auth", "Firebase", r).create(e, {
        appName: t.name
    })
}

function w(t) {
    return Ze(t, "operation-not-supported-in-this-environment", "Operations that alter the current user are not supported in conjunction with FirebaseServerApp")
}

function G(t, e, n) {
    const r = n;
    if (!(e instanceof r)) throw r.name !== e.constructor.name && E(t, "argument-error"), Ze(t, "argument-error", `Type of ${e.constructor.name} does not match expected instance.Did you pass a reference from a different Auth SDK?`)
}

function et(t, ...e) {
    if (typeof t != "string") {
        const n = e[0],
            r = [...e.slice(1)];
        return r[0] && (r[0].appName = t.name), t._errorFactory.create(n, ...r)
    }
    return $t.create(t, ...e)
}

function l(t, e, ...n) {
    if (!t) throw et(e, ...n)
}

function y(t) {
    const e = "INTERNAL ASSERTION FAILED: " + t;
    throw ue(e), new Error(e)
}

function P(t, e) {
    t || y(e)
}

function xe() {
    var t;
    return typeof self < "u" && ((t = self.location) === null || t === void 0 ? void 0 : t.href) || ""
}

function qt() {
    return gt() === "http:" || gt() === "https:"
}

function gt() {
    var t;
    return typeof self < "u" && ((t = self.location) === null || t === void 0 ? void 0 : t.protocol) || null
}

function fr() {
    return typeof navigator < "u" && navigator && "onLine" in navigator && typeof navigator.onLine == "boolean" && (qt() || ur() || "connection" in navigator) ? navigator.onLine : !0
}

function pr() {
    if (typeof navigator > "u") return null;
    const t = navigator;
    return t.languages && t.languages[0] || t.language || null
}
var ne = class {
    constructor(t, e) {
        this.shortDelay = t, this.longDelay = e, P(e > t, "Short delay should be less than long delay!"), this.isMobile = ir() || Zn()
    }
    get() {
        return fr() ? this.isMobile ? this.longDelay : this.shortDelay : Math.min(5e3, this.shortDelay)
    }
};

function tt(t, e) {
    P(t.emulator, "Emulator should always be set here");
    const {
        url: n
    } = t.emulator;
    return e ? `${n}${e.startsWith("/")?e.slice(1):e}` : n
}
var Yt = class {
        static initialize(t, e, n) {
            this.fetchImpl = t, e && (this.headersImpl = e), n && (this.responseImpl = n)
        }
        static fetch() {
            if (this.fetchImpl) return this.fetchImpl;
            if (typeof self < "u" && "fetch" in self) return self.fetch;
            if (typeof globalThis < "u" && globalThis.fetch) return globalThis.fetch;
            if (typeof fetch < "u") return fetch;
            y("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")
        }
        static headers() {
            if (this.headersImpl) return this.headersImpl;
            if (typeof self < "u" && "Headers" in self) return self.Headers;
            if (typeof globalThis < "u" && globalThis.Headers) return globalThis.Headers;
            if (typeof Headers < "u") return Headers;
            y("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")
        }
        static response() {
            if (this.responseImpl) return this.responseImpl;
            if (typeof self < "u" && "Response" in self) return self.Response;
            if (typeof globalThis < "u" && globalThis.Response) return globalThis.Response;
            if (typeof Response < "u") return Response;
            y("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill")
        }
    },
    mr = {
        CREDENTIAL_MISMATCH: "custom-token-mismatch",
        MISSING_CUSTOM_TOKEN: "internal-error",
        INVALID_IDENTIFIER: "invalid-email",
        MISSING_CONTINUE_URI: "internal-error",
        INVALID_PASSWORD: "wrong-password",
        MISSING_PASSWORD: "missing-password",
        INVALID_LOGIN_CREDENTIALS: "invalid-credential",
        EMAIL_EXISTS: "email-already-in-use",
        PASSWORD_LOGIN_DISABLED: "operation-not-allowed",
        INVALID_IDP_RESPONSE: "invalid-credential",
        INVALID_PENDING_TOKEN: "invalid-credential",
        FEDERATED_USER_ID_ALREADY_LINKED: "credential-already-in-use",
        MISSING_REQ_TYPE: "internal-error",
        EMAIL_NOT_FOUND: "user-not-found",
        RESET_PASSWORD_EXCEED_LIMIT: "too-many-requests",
        EXPIRED_OOB_CODE: "expired-action-code",
        INVALID_OOB_CODE: "invalid-action-code",
        MISSING_OOB_CODE: "internal-error",
        CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "requires-recent-login",
        INVALID_ID_TOKEN: "invalid-user-token",
        TOKEN_EXPIRED: "user-token-expired",
        USER_NOT_FOUND: "user-token-expired",
        TOO_MANY_ATTEMPTS_TRY_LATER: "too-many-requests",
        PASSWORD_DOES_NOT_MEET_REQUIREMENTS: "password-does-not-meet-requirements",
        INVALID_CODE: "invalid-verification-code",
        INVALID_SESSION_INFO: "invalid-verification-id",
        INVALID_TEMPORARY_PROOF: "invalid-credential",
        MISSING_SESSION_INFO: "missing-verification-id",
        SESSION_EXPIRED: "code-expired",
        MISSING_ANDROID_PACKAGE_NAME: "missing-android-pkg-name",
        UNAUTHORIZED_DOMAIN: "unauthorized-continue-uri",
        INVALID_OAUTH_CLIENT_ID: "invalid-oauth-client-id",
        ADMIN_ONLY_OPERATION: "admin-restricted-operation",
        INVALID_MFA_PENDING_CREDENTIAL: "invalid-multi-factor-session",
        MFA_ENROLLMENT_NOT_FOUND: "multi-factor-info-not-found",
        MISSING_MFA_ENROLLMENT_ID: "missing-multi-factor-info",
        MISSING_MFA_PENDING_CREDENTIAL: "missing-multi-factor-session",
        SECOND_FACTOR_EXISTS: "second-factor-already-in-use",
        SECOND_FACTOR_LIMIT_EXCEEDED: "maximum-second-factor-count-exceeded",
        BLOCKING_FUNCTION_ERROR_RESPONSE: "internal-error",
        RECAPTCHA_NOT_ENABLED: "recaptcha-not-enabled",
        MISSING_RECAPTCHA_TOKEN: "missing-recaptcha-token",
        INVALID_RECAPTCHA_TOKEN: "invalid-recaptcha-token",
        INVALID_RECAPTCHA_ACTION: "invalid-recaptcha-action",
        MISSING_CLIENT_TYPE: "missing-client-type",
        MISSING_RECAPTCHA_VERSION: "missing-recaptcha-version",
        INVALID_RECAPTCHA_VERSION: "invalid-recaptcha-version",
        INVALID_REQ_TYPE: "invalid-req-type"
    },
    _r = ["/v1/accounts:signInWithCustomToken", "/v1/accounts:signInWithEmailLink", "/v1/accounts:signInWithIdp", "/v1/accounts:signInWithPassword", "/v1/accounts:signInWithPhoneNumber", "/v1/token"],
    gr = new ne(3e4, 6e4);

function h(t, e) {
    return t.tenantId && !e.tenantId ? Object.assign(Object.assign({}, e), {
        tenantId: t.tenantId
    }) : e
}
async function m(t, e, n, r, i = {}) {
    return Jt(t, i, async () => {
        let s = {},
            a = {};
        r && (e === "GET" ? a = r : s = {
            body: JSON.stringify(r)
        });
        const o = W(Object.assign({
                key: t.config.apiKey
            }, a)).slice(1),
            c = await t._getAdditionalHeaders();
        c["Content-Type"] = "application/json", t.languageCode && (c["X-Firebase-Locale"] = t.languageCode);
        const u = Object.assign({
            method: e,
            headers: c
        }, s);
        return rr() || (u.referrerPolicy = "no-referrer"), t.emulatorConfig && Ye(t.emulatorConfig.host) && (u.credentials = "include"), Yt.fetch()(await Xt(t, t.config.apiHost, n, o), u)
    })
}
async function Jt(t, e, n) {
    t._canInitEmulator = !1;
    const r = Object.assign(Object.assign({}, mr), e);
    try {
        const i = new vr(t),
            s = await Promise.race([n(), i.promise]);
        i.clearNetworkTimeout();
        const a = await s.json();
        if ("needConfirmation" in a) throw $(t, "account-exists-with-different-credential", a);
        if (s.ok && !("errorMessage" in a)) return a; {
            const [o, c] = (s.ok ? a.errorMessage : a.error.message).split(" : ");
            if (o === "FEDERATED_USER_ID_ALREADY_LINKED") throw $(t, "credential-already-in-use", a);
            if (o === "EMAIL_EXISTS") throw $(t, "email-already-in-use", a);
            if (o === "USER_DISABLED") throw $(t, "user-disabled", a);
            const u = r[o] || o.toLowerCase().replace(/[_\s]+/g, "-");
            if (c) throw Ze(t, u, c);
            E(t, u)
        }
    } catch (i) {
        if (i instanceof Xe) throw i;
        E(t, "network-request-failed", {
            message: String(i)
        })
    }
}
async function A(t, e, n, r, i = {}) {
    const s = await m(t, e, n, r, i);
    return "mfaPendingCredential" in s && E(t, "multi-factor-auth-required", {
        _serverResponse: s
    }), s
}
async function Xt(t, e, n, r) {
    const i = `${e}${n}?${r}`,
        s = t,
        a = s.config.emulator ? tt(t.config, i) : `${t.config.apiScheme}://${i}`;
    return _r.includes(n) && (await s._persistenceManagerAvailable, s._getPersistenceType() === "COOKIE") ? s._getPersistence()._getFinalTarget(a).toString() : a
}

function Ir(t) {
    switch (t) {
        case "ENFORCE":
            return "ENFORCE";
        case "AUDIT":
            return "AUDIT";
        case "OFF":
            return "OFF";
        default:
            return "ENFORCEMENT_STATE_UNSPECIFIED"
    }
}
var vr = class {
    clearNetworkTimeout() {
        clearTimeout(this.timer)
    }
    constructor(t) {
        this.auth = t, this.timer = null, this.promise = new Promise((e, n) => {
            this.timer = setTimeout(() => n(v(this.auth, "network-request-failed")), gr.get())
        })
    }
};

function $(t, e, n) {
    const r = {
        appName: t.name
    };
    n.email && (r.email = n.email), n.phoneNumber && (r.phoneNumber = n.phoneNumber);
    const i = v(t, e, r);
    return i.customData._tokenResponse = n, i
}

function It(t) {
    return t !== void 0 && t.getResponse !== void 0
}

function vt(t) {
    return t !== void 0 && t.enterprise !== void 0
}
var Qt = class {
    constructor(t) {
        if (this.siteKey = "", this.recaptchaEnforcementState = [], t.recaptchaKey === void 0) throw new Error("recaptchaKey undefined");
        this.siteKey = t.recaptchaKey.split("/")[3], this.recaptchaEnforcementState = t.recaptchaEnforcementState
    }
    getProviderEnforcementState(t) {
        if (!this.recaptchaEnforcementState || this.recaptchaEnforcementState.length === 0) return null;
        for (const e of this.recaptchaEnforcementState)
            if (e.provider && e.provider === t) return Ir(e.enforcementState);
        return null
    }
    isProviderEnabled(t) {
        return this.getProviderEnforcementState(t) === "ENFORCE" || this.getProviderEnforcementState(t) === "AUDIT"
    }
    isAnyProviderEnabled() {
        return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER") || this.isProviderEnabled("PHONE_PROVIDER")
    }
};
async function Er(t) {
    return (await m(t, "GET", "/v1/recaptchaParams")).recaptchaSiteKey || ""
}
async function Zt(t, e) {
    return m(t, "GET", "/v2/recaptchaConfig", h(t, e))
}
async function Tr(t, e) {
    return m(t, "POST", "/v1/accounts:delete", e)
}
async function ve(t, e) {
    return m(t, "POST", "/v1/accounts:lookup", e)
}

function X(t) {
    if (t) try {
        const e = new Date(Number(t));
        if (!isNaN(e.getTime())) return e.toUTCString()
    } catch {}
}
async function wr(t, e = !1) {
    const n = p(t),
        r = await n.getIdToken(e),
        i = nt(r);
    l(i && i.exp && i.auth_time && i.iat, n.auth, "internal-error");
    const s = typeof i.firebase == "object" ? i.firebase : void 0,
        a = s ? .sign_in_provider;
    return {
        claims: i,
        token: r,
        authTime: X(Ce(i.auth_time)),
        issuedAtTime: X(Ce(i.iat)),
        expirationTime: X(Ce(i.exp)),
        signInProvider: a || null,
        signInSecondFactor: s ? .sign_in_second_factor || null
    }
}

function Ce(t) {
    return Number(t) * 1e3
}

function nt(t) {
    const [e, n, r] = t.split(".");
    if (e === void 0 || n === void 0 || r === void 0) return ue("JWT malformed, contained fewer than 3 sections"), null;
    try {
        const i = lr(n);
        return i ? JSON.parse(i) : (ue("Failed to decode base64 JWT payload"), null)
    } catch (i) {
        return ue("Caught error parsing JWT payload as JSON", i ? .toString()), null
    }
}

function Et(t) {
    const e = nt(t);
    return l(e, "internal-error"), l(typeof e.exp < "u", "internal-error"), l(typeof e.iat < "u", "internal-error"), Number(e.exp) - Number(e.iat)
}
async function N(t, e, n = !1) {
    if (n) return e;
    try {
        return await e
    } catch (r) {
        throw r instanceof Xe && yr(r) && t.auth.currentUser === t && await t.auth.signOut(), r
    }
}

function yr({
    code: t
}) {
    return t === "auth/user-disabled" || t === "auth/user-token-expired"
}
var Rr = class {
        constructor(t) {
            this.user = t, this.isRunning = !1, this.timerId = null, this.errorBackoff = 3e4
        }
        _start() {
            this.isRunning || (this.isRunning = !0, this.schedule())
        }
        _stop() {
            this.isRunning && (this.isRunning = !1, this.timerId !== null && clearTimeout(this.timerId))
        }
        getInterval(t) {
            var e;
            if (t) {
                const n = this.errorBackoff;
                return this.errorBackoff = Math.min(this.errorBackoff * 2, 96e4), n
            } else {
                this.errorBackoff = 3e4;
                const n = ((e = this.user.stsTokenManager.expirationTime) !== null && e !== void 0 ? e : 0) - Date.now() - 3e5;
                return Math.max(0, n)
            }
        }
        schedule(t = !1) {
            if (!this.isRunning) return;
            const e = this.getInterval(t);
            this.timerId = setTimeout(async () => {
                await this.iteration()
            }, e)
        }
        async iteration() {
            try {
                await this.user.getIdToken(!0)
            } catch (t) {
                t ? .code === "auth/network-request-failed" && this.schedule(!0);
                return
            }
            this.schedule()
        }
    },
    We = class {
        constructor(t, e) {
            this.createdAt = t, this.lastLoginAt = e, this._initializeTime()
        }
        _initializeTime() {
            this.lastSignInTime = X(this.lastLoginAt), this.creationTime = X(this.createdAt)
        }
        _copy(t) {
            this.createdAt = t.createdAt, this.lastLoginAt = t.lastLoginAt, this._initializeTime()
        }
        toJSON() {
            return {
                createdAt: this.createdAt,
                lastLoginAt: this.lastLoginAt
            }
        }
    };
async function ee(t) {
    var e;
    const n = t.auth,
        r = await N(t, ve(n, {
            idToken: await t.getIdToken()
        }));
    l(r ? .users.length, n, "internal-error");
    const i = r.users[0];
    t._notifyReloadListener(i);
    const s = !((e = i.providerUserInfo) === null || e === void 0) && e.length ? en(i.providerUserInfo) : [],
        a = Ar(t.providerData, s),
        o = t.isAnonymous,
        c = !(t.email && i.passwordHash) && !a ? .length,
        u = o ? c : !1,
        d = {
            uid: i.localId,
            displayName: i.displayName || null,
            photoURL: i.photoUrl || null,
            email: i.email || null,
            emailVerified: i.emailVerified || !1,
            phoneNumber: i.phoneNumber || null,
            tenantId: i.tenantId || null,
            providerData: a,
            metadata: new We(i.createdAt, i.lastLoginAt),
            isAnonymous: u
        };
    Object.assign(t, d)
}
async function Pr(t) {
    const e = p(t);
    await ee(e), await e.auth._persistUserIfCurrent(e), e.auth._notifyListenersIfCurrent(e)
}

function Ar(t, e) {
    return [...t.filter(n => !e.some(r => r.providerId === n.providerId)), ...e]
}

function en(t) {
    return t.map(e => {
        var {
            providerId: n
        } = e, r = Qe(e, ["providerId"]);
        return {
            providerId: n,
            uid: r.rawId || "",
            displayName: r.displayName || null,
            email: r.email || null,
            phoneNumber: r.phoneNumber || null,
            photoURL: r.photoUrl || null
        }
    })
}
async function Sr(t, e) {
    const n = await Jt(t, {}, async () => {
        const r = W({
                grant_type: "refresh_token",
                refresh_token: e
            }).slice(1),
            {
                tokenApiHost: i,
                apiKey: s
            } = t.config,
            a = await Xt(t, i, "/v1/token", `key=${s}`),
            o = await t._getAdditionalHeaders();
        o["Content-Type"] = "application/x-www-form-urlencoded";
        const c = {
            method: "POST",
            headers: o,
            body: r
        };
        return t.emulatorConfig && Ye(t.emulatorConfig.host) && (c.credentials = "include"), Yt.fetch()(a, c)
    });
    return {
        accessToken: n.access_token,
        expiresIn: n.expires_in,
        refreshToken: n.refresh_token
    }
}
async function kr(t, e) {
    return m(t, "POST", "/v2/accounts:revokeToken", h(t, e))
}
var be = class Ge {
    constructor() {
        this.refreshToken = null, this.accessToken = null, this.expirationTime = null
    }
    get isExpired() {
        return !this.expirationTime || Date.now() > this.expirationTime - 3e4
    }
    updateFromServerResponse(e) {
        l(e.idToken, "internal-error"), l(typeof e.idToken < "u", "internal-error"), l(typeof e.refreshToken < "u", "internal-error");
        const n = "expiresIn" in e && typeof e.expiresIn < "u" ? Number(e.expiresIn) : Et(e.idToken);
        this.updateTokensAndExpiration(e.idToken, e.refreshToken, n)
    }
    updateFromIdToken(e) {
        l(e.length !== 0, "internal-error");
        const n = Et(e);
        this.updateTokensAndExpiration(e, null, n)
    }
    async getToken(e, n = !1) {
        return !n && this.accessToken && !this.isExpired ? this.accessToken : (l(this.refreshToken, e, "user-token-expired"), this.refreshToken ? (await this.refresh(e, this.refreshToken), this.accessToken) : null)
    }
    clearRefreshToken() {
        this.refreshToken = null
    }
    async refresh(e, n) {
        const {
            accessToken: r,
            refreshToken: i,
            expiresIn: s
        } = await Sr(e, n);
        this.updateTokensAndExpiration(r, i, Number(s))
    }
    updateTokensAndExpiration(e, n, r) {
        this.refreshToken = n || null, this.accessToken = e || null, this.expirationTime = Date.now() + r * 1e3
    }
    static fromJSON(e, n) {
        const {
            refreshToken: r,
            accessToken: i,
            expirationTime: s
        } = n, a = new Ge;
        return r && (l(typeof r == "string", "internal-error", {
            appName: e
        }), a.refreshToken = r), i && (l(typeof i == "string", "internal-error", {
            appName: e
        }), a.accessToken = i), s && (l(typeof s == "number", "internal-error", {
            appName: e
        }), a.expirationTime = s), a
    }
    toJSON() {
        return {
            refreshToken: this.refreshToken,
            accessToken: this.accessToken,
            expirationTime: this.expirationTime
        }
    }
    _assign(e) {
        this.accessToken = e.accessToken, this.refreshToken = e.refreshToken, this.expirationTime = e.expirationTime
    }
    _clone() {
        return Object.assign(new Ge, this.toJSON())
    }
    _performRefresh() {
        return y("not implemented")
    }
};

function k(t, e) {
    l(typeof t == "string" || typeof t > "u", "internal-error", {
        appName: e
    })
}
var V = class q {
        constructor(e) {
            var {
                uid: n,
                auth: r,
                stsTokenManager: i
            } = e, s = Qe(e, ["uid", "auth", "stsTokenManager"]);
            this.providerId = "firebase", this.proactiveRefresh = new Rr(this), this.reloadUserInfo = null, this.reloadListener = null, this.uid = n, this.auth = r, this.stsTokenManager = i, this.accessToken = i.accessToken, this.displayName = s.displayName || null, this.email = s.email || null, this.emailVerified = s.emailVerified || !1, this.phoneNumber = s.phoneNumber || null, this.photoURL = s.photoURL || null, this.isAnonymous = s.isAnonymous || !1, this.tenantId = s.tenantId || null, this.providerData = s.providerData ? [...s.providerData] : [], this.metadata = new We(s.createdAt || void 0, s.lastLoginAt || void 0)
        }
        async getIdToken(e) {
            const n = await N(this, this.stsTokenManager.getToken(this.auth, e));
            return l(n, this.auth, "internal-error"), this.accessToken !== n && (this.accessToken = n, await this.auth._persistUserIfCurrent(this), this.auth._notifyListenersIfCurrent(this)), n
        }
        getIdTokenResult(e) {
            return wr(this, e)
        }
        reload() {
            return Pr(this)
        }
        _assign(e) {
            this !== e && (l(this.uid === e.uid, this.auth, "internal-error"), this.displayName = e.displayName, this.photoURL = e.photoURL, this.email = e.email, this.emailVerified = e.emailVerified, this.phoneNumber = e.phoneNumber, this.isAnonymous = e.isAnonymous, this.tenantId = e.tenantId, this.providerData = e.providerData.map(n => Object.assign({}, n)), this.metadata._copy(e.metadata), this.stsTokenManager._assign(e.stsTokenManager))
        }
        _clone(e) {
            const n = new q(Object.assign(Object.assign({}, this), {
                auth: e,
                stsTokenManager: this.stsTokenManager._clone()
            }));
            return n.metadata._copy(this.metadata), n
        }
        _onReload(e) {
            l(!this.reloadListener, this.auth, "internal-error"), this.reloadListener = e, this.reloadUserInfo && (this._notifyReloadListener(this.reloadUserInfo), this.reloadUserInfo = null)
        }
        _notifyReloadListener(e) {
            this.reloadListener ? this.reloadListener(e) : this.reloadUserInfo = e
        }
        _startProactiveRefresh() {
            this.proactiveRefresh._start()
        }
        _stopProactiveRefresh() {
            this.proactiveRefresh._stop()
        }
        async _updateTokensIfNecessary(e, n = !1) {
            let r = !1;
            e.idToken && e.idToken !== this.stsTokenManager.accessToken && (this.stsTokenManager.updateFromServerResponse(e), r = !0), n && await ee(this), await this.auth._persistUserIfCurrent(this), r && this.auth._notifyListenersIfCurrent(this)
        }
        async delete() {
            if (I(this.auth.app)) return Promise.reject(w(this.auth));
            const e = await this.getIdToken();
            return await N(this, Tr(this.auth, {
                idToken: e
            })), this.stsTokenManager.clearRefreshToken(), this.auth.signOut()
        }
        toJSON() {
            return Object.assign(Object.assign({
                uid: this.uid,
                email: this.email || void 0,
                emailVerified: this.emailVerified,
                displayName: this.displayName || void 0,
                isAnonymous: this.isAnonymous,
                photoURL: this.photoURL || void 0,
                phoneNumber: this.phoneNumber || void 0,
                tenantId: this.tenantId || void 0,
                providerData: this.providerData.map(e => Object.assign({}, e)),
                stsTokenManager: this.stsTokenManager.toJSON(),
                _redirectEventId: this._redirectEventId
            }, this.metadata.toJSON()), {
                apiKey: this.auth.config.apiKey,
                appName: this.auth.name
            })
        }
        get refreshToken() {
            return this.stsTokenManager.refreshToken || ""
        }
        static _fromJSON(e, n) {
            var r, i, s, a, o, c, u, d;
            const f = (r = n.displayName) !== null && r !== void 0 ? r : void 0,
                S = (i = n.email) !== null && i !== void 0 ? i : void 0,
                ae = (s = n.phoneNumber) !== null && s !== void 0 ? s : void 0,
                oe = (a = n.photoURL) !== null && a !== void 0 ? a : void 0,
                ct = (o = n.tenantId) !== null && o !== void 0 ? o : void 0,
                Se = (c = n._redirectEventId) !== null && c !== void 0 ? c : void 0,
                lt = (u = n.createdAt) !== null && u !== void 0 ? u : void 0,
                ut = (d = n.lastLoginAt) !== null && d !== void 0 ? d : void 0,
                {
                    uid: ke,
                    emailVerified: dt,
                    isAnonymous: ht,
                    providerData: Ne,
                    stsTokenManager: ft
                } = n;
            l(ke && ft, e, "internal-error");
            const Jn = be.fromJSON(this.name, ft);
            l(typeof ke == "string", e, "internal-error"), k(f, e.name), k(S, e.name), l(typeof dt == "boolean", e, "internal-error"), l(typeof ht == "boolean", e, "internal-error"), k(ae, e.name), k(oe, e.name), k(ct, e.name), k(Se, e.name), k(lt, e.name), k(ut, e.name);
            const Oe = new q({
                uid: ke,
                auth: e,
                email: S,
                emailVerified: dt,
                displayName: f,
                isAnonymous: ht,
                photoURL: oe,
                phoneNumber: ae,
                tenantId: ct,
                stsTokenManager: Jn,
                createdAt: lt,
                lastLoginAt: ut
            });
            return Ne && Array.isArray(Ne) && (Oe.providerData = Ne.map(Xn => Object.assign({}, Xn))), Se && (Oe._redirectEventId = Se), Oe
        }
        static async _fromIdTokenResponse(e, n, r = !1) {
            const i = new be;
            i.updateFromServerResponse(n);
            const s = new q({
                uid: n.localId,
                auth: e,
                stsTokenManager: i,
                isAnonymous: r
            });
            return await ee(s), s
        }
        static async _fromGetAccountInfoResponse(e, n, r) {
            const i = n.users[0];
            l(i.localId !== void 0, "internal-error");
            const s = i.providerUserInfo !== void 0 ? en(i.providerUserInfo) : [],
                a = !(i.email && i.passwordHash) && !s ? .length,
                o = new be;
            o.updateFromIdToken(r);
            const c = new q({
                    uid: i.localId,
                    auth: e,
                    stsTokenManager: o,
                    isAnonymous: a
                }),
                u = {
                    uid: i.localId,
                    displayName: i.displayName || null,
                    photoURL: i.photoUrl || null,
                    email: i.email || null,
                    emailVerified: i.emailVerified || !1,
                    phoneNumber: i.phoneNumber || null,
                    tenantId: i.tenantId || null,
                    providerData: s,
                    metadata: new We(i.createdAt, i.lastLoginAt),
                    isAnonymous: !(i.email && i.passwordHash) && !s ? .length
                };
            return Object.assign(c, u), c
        }
    },
    Tt = new Map;

function R(t) {
    P(t instanceof Function, "Expected a class definition");
    let e = Tt.get(t);
    return e ? (P(e instanceof t, "Instance stored in cache mismatched with class"), e) : (e = new t, Tt.set(t, e), e)
}
var tn = class {
    constructor() {
        this.type = "NONE", this.storage = {}
    }
    async _isAvailable() {
        return !0
    }
    async _set(t, e) {
        this.storage[t] = e
    }
    async _get(t) {
        const e = this.storage[t];
        return e === void 0 ? null : e
    }
    async _remove(t) {
        delete this.storage[t]
    }
    _addListener(t, e) {}
    _removeListener(t, e) {}
};
tn.type = "NONE";
var wt = tn;

function de(t, e, n) {
    return `firebase:${t}:${e}:${n}`
}
var yt = class he {
    constructor(e, n, r) {
        this.persistence = e, this.auth = n, this.userKey = r;
        const {
            config: i,
            name: s
        } = this.auth;
        this.fullUserKey = de(this.userKey, i.apiKey, s), this.fullPersistenceKey = de("persistence", i.apiKey, s), this.boundEventHandler = n._onStorageEvent.bind(n), this.persistence._addListener(this.fullUserKey, this.boundEventHandler)
    }
    setCurrentUser(e) {
        return this.persistence._set(this.fullUserKey, e.toJSON())
    }
    async getCurrentUser() {
        const e = await this.persistence._get(this.fullUserKey);
        if (!e) return null;
        if (typeof e == "string") {
            const n = await ve(this.auth, {
                idToken: e
            }).catch(() => {});
            return n ? V._fromGetAccountInfoResponse(this.auth, n, e) : null
        }
        return V._fromJSON(this.auth, e)
    }
    removeCurrentUser() {
        return this.persistence._remove(this.fullUserKey)
    }
    savePersistenceForRedirect() {
        return this.persistence._set(this.fullPersistenceKey, this.persistence.type)
    }
    async setPersistence(e) {
        if (this.persistence === e) return;
        const n = await this.getCurrentUser();
        if (await this.removeCurrentUser(), this.persistence = e, n) return this.setCurrentUser(n)
    }
    delete() {
        this.persistence._removeListener(this.fullUserKey, this.boundEventHandler)
    }
    static async create(e, n, r = "authUser") {
        if (!n.length) return new he(R(wt), e, r);
        const i = (await Promise.all(n.map(async u => {
            if (await u._isAvailable()) return u
        }))).filter(u => u);
        let s = i[0] || R(wt);
        const a = de(r, e.config.apiKey, e.name);
        let o = null;
        for (const u of n) try {
            const d = await u._get(a);
            if (d) {
                let f;
                if (typeof d == "string") {
                    const S = await ve(e, {
                        idToken: d
                    }).catch(() => {});
                    if (!S) break;
                    f = await V._fromGetAccountInfoResponse(e, S, d)
                } else f = V._fromJSON(e, d);
                u !== s && (o = f), s = u;
                break
            }
        } catch {}
        const c = i.filter(u => u._shouldAllowMigration);
        return !s._shouldAllowMigration || !c.length ? new he(s, e, r) : (s = c[0], o && await s._set(a, o.toJSON()), await Promise.all(n.map(async u => {
            if (u !== s) try {
                await u._remove(a)
            } catch {}
        })), new he(s, e, r))
    }
};

function Rt(t) {
    const e = t.toLowerCase();
    if (e.includes("opera/") || e.includes("opr/") || e.includes("opios/")) return "Opera";
    if (an(e)) return "IEMobile";
    if (e.includes("msie") || e.includes("trident/")) return "IE";
    if (e.includes("edge/")) return "Edge";
    if (nn(e)) return "Firefox";
    if (e.includes("silk/")) return "Silk";
    if (cn(e)) return "Blackberry";
    if (ln(e)) return "Webos";
    if (rn(e)) return "Safari";
    if ((e.includes("chrome/") || sn(e)) && !e.includes("edge/")) return "Chrome";
    if (on(e)) return "Android"; {
        const n = t.match(/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/);
        if (n ? .length === 2) return n[1]
    }
    return "Other"
}

function nn(t = T()) {
    return /firefox\//i.test(t)
}

function rn(t = T()) {
    const e = t.toLowerCase();
    return e.includes("safari/") && !e.includes("chrome/") && !e.includes("crios/") && !e.includes("android")
}

function sn(t = T()) {
    return /crios\//i.test(t)
}

function an(t = T()) {
    return /iemobile/i.test(t)
}

function on(t = T()) {
    return /android/i.test(t)
}

function cn(t = T()) {
    return /blackberry/i.test(t)
}

function ln(t = T()) {
    return /webos/i.test(t)
}

function rt(t = T()) {
    return /iphone|ipad|ipod/i.test(t) || /macintosh/i.test(t) && /mobile/i.test(t)
}

function Nr(t = T()) {
    var e;
    return rt(t) && !!(!((e = window.navigator) === null || e === void 0) && e.standalone)
}

function Or() {
    return nr() && document.documentMode === 10
}

function un(t = T()) {
    return rt(t) || on(t) || ln(t) || cn(t) || /windows phone/i.test(t) || an(t)
}

function dn(t, e = []) {
    let n;
    switch (t) {
        case "Browser":
            n = Rt(T());
            break;
        case "Worker":
            n = `${Rt(T())}-${t}`;
            break;
        default:
            n = t
    }
    const r = e.length ? e.join(",") : "FirebaseCore-web";
    return `${n}/JsCore/${te}/${r}`
}
var Cr = class {
    constructor(t) {
        this.auth = t, this.queue = []
    }
    pushCallback(t, e) {
        const n = i => new Promise((s, a) => {
            try {
                s(t(i))
            } catch (o) {
                a(o)
            }
        });
        n.onAbort = e, this.queue.push(n);
        const r = this.queue.length - 1;
        return () => {
            this.queue[r] = () => Promise.resolve()
        }
    }
    async runMiddleware(t) {
        if (this.auth.currentUser === t) return;
        const e = [];
        try {
            for (const n of this.queue) await n(t), n.onAbort && e.push(n.onAbort)
        } catch (n) {
            e.reverse();
            for (const r of e) try {
                r()
            } catch {}
            throw this.auth._errorFactory.create("login-blocked", {
                originalMessage: n ? .message
            })
        }
    }
};
async function br(t, e = {}) {
    return m(t, "GET", "/v2/passwordPolicy", h(t, e))
}
var Dr = 6,
    Lr = class {
        constructor(t) {
            var e, n, r, i;
            const s = t.customStrengthOptions;
            this.customStrengthOptions = {}, this.customStrengthOptions.minPasswordLength = (e = s.minPasswordLength) !== null && e !== void 0 ? e : Dr, s.maxPasswordLength && (this.customStrengthOptions.maxPasswordLength = s.maxPasswordLength), s.containsLowercaseCharacter !== void 0 && (this.customStrengthOptions.containsLowercaseLetter = s.containsLowercaseCharacter), s.containsUppercaseCharacter !== void 0 && (this.customStrengthOptions.containsUppercaseLetter = s.containsUppercaseCharacter), s.containsNumericCharacter !== void 0 && (this.customStrengthOptions.containsNumericCharacter = s.containsNumericCharacter), s.containsNonAlphanumericCharacter !== void 0 && (this.customStrengthOptions.containsNonAlphanumericCharacter = s.containsNonAlphanumericCharacter), this.enforcementState = t.enforcementState, this.enforcementState === "ENFORCEMENT_STATE_UNSPECIFIED" && (this.enforcementState = "OFF"), this.allowedNonAlphanumericCharacters = (r = (n = t.allowedNonAlphanumericCharacters) === null || n === void 0 ? void 0 : n.join("")) !== null && r !== void 0 ? r : "", this.forceUpgradeOnSignin = (i = t.forceUpgradeOnSignin) !== null && i !== void 0 ? i : !1, this.schemaVersion = t.schemaVersion
        }
        validatePassword(t) {
            var e, n, r, i, s, a;
            const o = {
                isValid: !0,
                passwordPolicy: this
            };
            return this.validatePasswordLengthOptions(t, o), this.validatePasswordCharacterOptions(t, o), o.isValid && (o.isValid = (e = o.meetsMinPasswordLength) !== null && e !== void 0 ? e : !0), o.isValid && (o.isValid = (n = o.meetsMaxPasswordLength) !== null && n !== void 0 ? n : !0), o.isValid && (o.isValid = (r = o.containsLowercaseLetter) !== null && r !== void 0 ? r : !0), o.isValid && (o.isValid = (i = o.containsUppercaseLetter) !== null && i !== void 0 ? i : !0), o.isValid && (o.isValid = (s = o.containsNumericCharacter) !== null && s !== void 0 ? s : !0), o.isValid && (o.isValid = (a = o.containsNonAlphanumericCharacter) !== null && a !== void 0 ? a : !0), o
        }
        validatePasswordLengthOptions(t, e) {
            const n = this.customStrengthOptions.minPasswordLength,
                r = this.customStrengthOptions.maxPasswordLength;
            n && (e.meetsMinPasswordLength = t.length >= n), r && (e.meetsMaxPasswordLength = t.length <= r)
        }
        validatePasswordCharacterOptions(t, e) {
            this.updatePasswordCharacterOptionsStatuses(e, !1, !1, !1, !1);
            let n;
            for (let r = 0; r < t.length; r++) n = t.charAt(r), this.updatePasswordCharacterOptionsStatuses(e, n >= "a" && n <= "z", n >= "A" && n <= "Z", n >= "0" && n <= "9", this.allowedNonAlphanumericCharacters.includes(n))
        }
        updatePasswordCharacterOptionsStatuses(t, e, n, r, i) {
            this.customStrengthOptions.containsLowercaseLetter && (t.containsLowercaseLetter || (t.containsLowercaseLetter = e)), this.customStrengthOptions.containsUppercaseLetter && (t.containsUppercaseLetter || (t.containsUppercaseLetter = n)), this.customStrengthOptions.containsNumericCharacter && (t.containsNumericCharacter || (t.containsNumericCharacter = r)), this.customStrengthOptions.containsNonAlphanumericCharacter && (t.containsNonAlphanumericCharacter || (t.containsNonAlphanumericCharacter = i))
        }
    },
    Mr = class {
        constructor(t, e, n, r) {
            this.app = t, this.heartbeatServiceProvider = e, this.appCheckServiceProvider = n, this.config = r, this.currentUser = null, this.emulatorConfig = null, this.operations = Promise.resolve(), this.authStateSubscription = new Pt(this), this.idTokenSubscription = new Pt(this), this.beforeStateQueue = new Cr(this), this.redirectUser = null, this.isProactiveRefreshEnabled = !1, this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION = 1, this._canInitEmulator = !0, this._isInitialized = !1, this._deleted = !1, this._initializationPromise = null, this._popupRedirectResolver = null, this._errorFactory = $t, this._agentRecaptchaConfig = null, this._tenantRecaptchaConfigs = {}, this._projectPasswordPolicy = null, this._tenantPasswordPolicies = {}, this._resolvePersistenceManagerAvailable = void 0, this.lastNotifiedUid = void 0, this.languageCode = null, this.tenantId = null, this.settings = {
                appVerificationDisabledForTesting: !1
            }, this.frameworks = [], this.name = t.name, this.clientVersion = r.sdkClientVersion, this._persistenceManagerAvailable = new Promise(i => this._resolvePersistenceManagerAvailable = i)
        }
        _initializeWithPersistence(t, e) {
            return e && (this._popupRedirectResolver = R(e)), this._initializationPromise = this.queue(async () => {
                var n, r, i;
                if (!this._deleted && (this.persistenceManager = await yt.create(this, t), (n = this._resolvePersistenceManagerAvailable) === null || n === void 0 || n.call(this), !this._deleted)) {
                    if (!((r = this._popupRedirectResolver) === null || r === void 0) && r._shouldInitProactively) try {
                        await this._popupRedirectResolver._initialize(this)
                    } catch {}
                    await this.initializeCurrentUser(e), this.lastNotifiedUid = ((i = this.currentUser) === null || i === void 0 ? void 0 : i.uid) || null, !this._deleted && (this._isInitialized = !0)
                }
            }), this._initializationPromise
        }
        async _onStorageEvent() {
            if (this._deleted) return;
            const t = await this.assertedPersistence.getCurrentUser();
            if (!(!this.currentUser && !t)) {
                if (this.currentUser && t && this.currentUser.uid === t.uid) {
                    this._currentUser._assign(t), await this.currentUser.getIdToken();
                    return
                }
                await this._updateCurrentUser(t, !0)
            }
        }
        async initializeCurrentUserFromIdToken(t) {
            try {
                const e = await ve(this, {
                        idToken: t
                    }),
                    n = await V._fromGetAccountInfoResponse(this, e, t);
                await this.directlySetCurrentUser(n)
            } catch (e) {
                console.warn("FirebaseServerApp could not login user with provided authIdToken: ", e), await this.directlySetCurrentUser(null)
            }
        }
        async initializeCurrentUser(t) {
            var e;
            if (I(this.app)) {
                const s = this.app.settings.authIdToken;
                return s ? new Promise(a => {
                    setTimeout(() => this.initializeCurrentUserFromIdToken(s).then(a, a))
                }) : this.directlySetCurrentUser(null)
            }
            const n = await this.assertedPersistence.getCurrentUser();
            let r = n,
                i = !1;
            if (t && this.config.authDomain) {
                await this.getOrInitRedirectPersistenceManager();
                const s = (e = this.redirectUser) === null || e === void 0 ? void 0 : e._redirectEventId,
                    a = r ? ._redirectEventId,
                    o = await this.tryRedirectSignIn(t);
                (!s || s === a) && o ? .user && (r = o.user, i = !0)
            }
            if (!r) return this.directlySetCurrentUser(null);
            if (!r._redirectEventId) {
                if (i) try {
                    await this.beforeStateQueue.runMiddleware(r)
                } catch (s) {
                    r = n, this._popupRedirectResolver._overrideRedirectResult(this, () => Promise.reject(s))
                }
                return r ? this.reloadAndSetCurrentUserOrClear(r) : this.directlySetCurrentUser(null)
            }
            return l(this._popupRedirectResolver, this, "argument-error"), await this.getOrInitRedirectPersistenceManager(), this.redirectUser && this.redirectUser._redirectEventId === r._redirectEventId ? this.directlySetCurrentUser(r) : this.reloadAndSetCurrentUserOrClear(r)
        }
        async tryRedirectSignIn(t) {
            let e = null;
            try {
                e = await this._popupRedirectResolver._completeRedirectFn(this, t, !0)
            } catch {
                await this._setRedirectUser(null)
            }
            return e
        }
        async reloadAndSetCurrentUserOrClear(t) {
            try {
                await ee(t)
            } catch (e) {
                if (e ? .code !== "auth/network-request-failed") return this.directlySetCurrentUser(null)
            }
            return this.directlySetCurrentUser(t)
        }
        useDeviceLanguage() {
            this.languageCode = pr()
        }
        async _delete() {
            this._deleted = !0
        }
        async updateCurrentUser(t) {
            if (I(this.app)) return Promise.reject(w(this));
            const e = t ? p(t) : null;
            return e && l(e.auth.config.apiKey === this.config.apiKey, this, "invalid-user-token"), this._updateCurrentUser(e && e._clone(this))
        }
        async _updateCurrentUser(t, e = !1) {
            if (!this._deleted) return t && l(this.tenantId === t.tenantId, this, "tenant-id-mismatch"), e || await this.beforeStateQueue.runMiddleware(t), this.queue(async () => {
                await this.directlySetCurrentUser(t), this.notifyAuthListeners()
            })
        }
        async signOut() {
            return I(this.app) ? Promise.reject(w(this)) : (await this.beforeStateQueue.runMiddleware(null), (this.redirectPersistenceManager || this._popupRedirectResolver) && await this._setRedirectUser(null), this._updateCurrentUser(null, !0))
        }
        setPersistence(t) {
            return I(this.app) ? Promise.reject(w(this)) : this.queue(async () => {
                await this.assertedPersistence.setPersistence(R(t))
            })
        }
        _getRecaptchaConfig() {
            return this.tenantId == null ? this._agentRecaptchaConfig : this._tenantRecaptchaConfigs[this.tenantId]
        }
        async validatePassword(t) {
            this._getPasswordPolicyInternal() || await this._updatePasswordPolicy();
            const e = this._getPasswordPolicyInternal();
            return e.schemaVersion !== this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION ? Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version", {})) : e.validatePassword(t)
        }
        _getPasswordPolicyInternal() {
            return this.tenantId === null ? this._projectPasswordPolicy : this._tenantPasswordPolicies[this.tenantId]
        }
        async _updatePasswordPolicy() {
            const t = await br(this),
                e = new Lr(t);
            this.tenantId === null ? this._projectPasswordPolicy = e : this._tenantPasswordPolicies[this.tenantId] = e
        }
        _getPersistenceType() {
            return this.assertedPersistence.persistence.type
        }
        _getPersistence() {
            return this.assertedPersistence.persistence
        }
        _updateErrorMap(t) {
            this._errorFactory = new Je("auth", "Firebase", t())
        }
        onAuthStateChanged(t, e, n) {
            return this.registerStateListener(this.authStateSubscription, t, e, n)
        }
        beforeAuthStateChanged(t, e) {
            return this.beforeStateQueue.pushCallback(t, e)
        }
        onIdTokenChanged(t, e, n) {
            return this.registerStateListener(this.idTokenSubscription, t, e, n)
        }
        authStateReady() {
            return new Promise((t, e) => {
                if (this.currentUser) t();
                else {
                    const n = this.onAuthStateChanged(() => {
                        n(), t()
                    }, e)
                }
            })
        }
        async revokeAccessToken(t) {
            if (this.currentUser) {
                const e = {
                    providerId: "apple.com",
                    tokenType: "ACCESS_TOKEN",
                    token: t,
                    idToken: await this.currentUser.getIdToken()
                };
                this.tenantId != null && (e.tenantId = this.tenantId), await kr(this, e)
            }
        }
        toJSON() {
            var t;
            return {
                apiKey: this.config.apiKey,
                authDomain: this.config.authDomain,
                appName: this.name,
                currentUser: (t = this._currentUser) === null || t === void 0 ? void 0 : t.toJSON()
            }
        }
        async _setRedirectUser(t, e) {
            const n = await this.getOrInitRedirectPersistenceManager(e);
            return t === null ? n.removeCurrentUser() : n.setCurrentUser(t)
        }
        async getOrInitRedirectPersistenceManager(t) {
            if (!this.redirectPersistenceManager) {
                const e = t && R(t) || this._popupRedirectResolver;
                l(e, this, "argument-error"), this.redirectPersistenceManager = await yt.create(this, [R(e._redirectPersistence)], "redirectUser"), this.redirectUser = await this.redirectPersistenceManager.getCurrentUser()
            }
            return this.redirectPersistenceManager
        }
        async _redirectUserForId(t) {
            var e, n;
            return this._isInitialized && await this.queue(async () => {}), ((e = this._currentUser) === null || e === void 0 ? void 0 : e._redirectEventId) === t ? this._currentUser : ((n = this.redirectUser) === null || n === void 0 ? void 0 : n._redirectEventId) === t ? this.redirectUser : null
        }
        async _persistUserIfCurrent(t) {
            if (t === this.currentUser) return this.queue(async () => this.directlySetCurrentUser(t))
        }
        _notifyListenersIfCurrent(t) {
            t === this.currentUser && this.notifyAuthListeners()
        }
        _key() {
            return `${this.config.authDomain}:${this.config.apiKey}:${this.name}`
        }
        _startProactiveRefresh() {
            this.isProactiveRefreshEnabled = !0, this.currentUser && this._currentUser._startProactiveRefresh()
        }
        _stopProactiveRefresh() {
            this.isProactiveRefreshEnabled = !1, this.currentUser && this._currentUser._stopProactiveRefresh()
        }
        get _currentUser() {
            return this.currentUser
        }
        notifyAuthListeners() {
            var t, e;
            if (!this._isInitialized) return;
            this.idTokenSubscription.next(this.currentUser);
            const n = (e = (t = this.currentUser) === null || t === void 0 ? void 0 : t.uid) !== null && e !== void 0 ? e : null;
            this.lastNotifiedUid !== n && (this.lastNotifiedUid = n, this.authStateSubscription.next(this.currentUser))
        }
        registerStateListener(t, e, n, r) {
            if (this._deleted) return () => {};
            const i = typeof e == "function" ? e : e.next.bind(e);
            let s = !1;
            const a = this._isInitialized ? Promise.resolve() : this._initializationPromise;
            if (l(a, this, "internal-error"), a.then(() => {
                    s || i(this.currentUser)
                }), typeof e == "function") {
                const o = t.addObserver(e, n, r);
                return () => {
                    s = !0, o()
                }
            } else {
                const o = t.addObserver(e);
                return () => {
                    s = !0, o()
                }
            }
        }
        async directlySetCurrentUser(t) {
            this.currentUser && this.currentUser !== t && this._currentUser._stopProactiveRefresh(), t && this.isProactiveRefreshEnabled && t._startProactiveRefresh(), this.currentUser = t, t ? await this.assertedPersistence.setCurrentUser(t) : await this.assertedPersistence.removeCurrentUser()
        }
        queue(t) {
            return this.operations = this.operations.then(t, t), this.operations
        }
        get assertedPersistence() {
            return l(this.persistenceManager, this, "internal-error"), this.persistenceManager
        }
        _logFramework(t) {
            !t || this.frameworks.includes(t) || (this.frameworks.push(t), this.frameworks.sort(), this.clientVersion = dn(this.config.clientPlatform, this._getFrameworks()))
        }
        _getFrameworks() {
            return this.frameworks
        }
        async _getAdditionalHeaders() {
            var t;
            const e = {
                "X-Client-Version": this.clientVersion
            };
            this.app.options.appId && (e["X-Firebase-gmpid"] = this.app.options.appId);
            const n = await ((t = this.heartbeatServiceProvider.getImmediate({
                optional: !0
            })) === null || t === void 0 ? void 0 : t.getHeartbeatsHeader());
            n && (e["X-Firebase-Client"] = n);
            const r = await this._getAppCheckToken();
            return r && (e["X-Firebase-AppCheck"] = r), e
        }
        async _getAppCheckToken() {
            var t;
            if (I(this.app) && this.app.settings.appCheckToken) return this.app.settings.appCheckToken;
            const e = await ((t = this.appCheckServiceProvider.getImmediate({
                optional: !0
            })) === null || t === void 0 ? void 0 : t.getToken());
            return e ? .error && hr(`Error while retrieving App Check token: ${e.error}`), e ? .token
        }
    };

function g(t) {
    return p(t)
}
var Pt = class {
        constructor(t) {
            this.auth = t, this.observer = null, this.addObserver = tr(e => this.observer = e)
        }
        get next() {
            return l(this.observer, this.auth, "internal-error"), this.observer.next.bind(this.observer)
        }
    },
    re = {
        async loadJS() {
            throw new Error("Unable to load external scripts")
        },
        recaptchaV2Script: "",
        recaptchaEnterpriseScript: "",
        gapiScript: ""
    };

function Ur(t) {
    re = t
}

function it(t) {
    return re.loadJS(t)
}

function Fr() {
    return re.recaptchaV2Script
}

function Vr() {
    return re.recaptchaEnterpriseScript
}

function Hr() {
    return re.gapiScript
}

function hn(t) {
    return `__${t}${Math.floor(Math.random()*1e6)}`
}
var xr = 500,
    Wr = 6e4,
    ce = 1e12,
    Gr = class {
        constructor(t) {
            this.auth = t, this.counter = ce, this._widgets = new Map
        }
        render(t, e) {
            const n = this.counter;
            return this._widgets.set(n, new zr(t, this.auth.name, e || {})), this.counter++, n
        }
        reset(t) {
            var e;
            const n = t || ce;
            (e = this._widgets.get(n)) === null || e === void 0 || e.delete(), this._widgets.delete(n)
        }
        getResponse(t) {
            var e;
            const n = t || ce;
            return ((e = this._widgets.get(n)) === null || e === void 0 ? void 0 : e.getResponse()) || ""
        }
        async execute(t) {
            var e;
            const n = t || ce;
            return (e = this._widgets.get(n)) === null || e === void 0 || e.execute(), ""
        }
    },
    jr = class {
        constructor() {
            this.enterprise = new Kr
        }
        ready(t) {
            t()
        }
        execute(t, e) {
            return Promise.resolve("token")
        }
        render(t, e) {
            return ""
        }
    },
    Kr = class {
        ready(t) {
            t()
        }
        execute(t, e) {
            return Promise.resolve("token")
        }
        render(t, e) {
            return ""
        }
    },
    zr = class {
        constructor(t, e, n) {
            this.params = n, this.timerId = null, this.deleted = !1, this.responseToken = null, this.clickHandler = () => {
                this.execute()
            };
            const r = typeof t == "string" ? document.getElementById(t) : t;
            l(r, "argument-error", {
                appName: e
            }), this.container = r, this.isVisible = this.params.size !== "invisible", this.isVisible ? this.execute() : this.container.addEventListener("click", this.clickHandler)
        }
        getResponse() {
            return this.checkIfDeleted(), this.responseToken
        }
        delete() {
            this.checkIfDeleted(), this.deleted = !0, this.timerId && (clearTimeout(this.timerId), this.timerId = null), this.container.removeEventListener("click", this.clickHandler)
        }
        execute() {
            this.checkIfDeleted(), !this.timerId && (this.timerId = window.setTimeout(() => {
                this.responseToken = Br(50);
                const {
                    callback: t,
                    "expired-callback": e
                } = this.params;
                if (t) try {
                    t(this.responseToken)
                } catch {}
                this.timerId = window.setTimeout(() => {
                    if (this.timerId = null, this.responseToken = null, e) try {
                        e()
                    } catch {}
                    this.isVisible && this.execute()
                }, Wr)
            }, xr))
        }
        checkIfDeleted() {
            if (this.deleted) throw new Error("reCAPTCHA mock was already deleted!")
        }
    };

function Br(t) {
    const e = [],
        n = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (let r = 0; r < t; r++) e.push(n.charAt(Math.floor(Math.random() * 62)));
    return e.join("")
}
var $r = "recaptcha-enterprise",
    Q = "NO_RECAPTCHA",
    fn = class {
        constructor(t) {
            this.type = $r, this.auth = g(t)
        }
        async verify(t = "verify", e = !1) {
            async function n(i) {
                if (!e) {
                    if (i.tenantId == null && i._agentRecaptchaConfig != null) return i._agentRecaptchaConfig.siteKey;
                    if (i.tenantId != null && i._tenantRecaptchaConfigs[i.tenantId] !== void 0) return i._tenantRecaptchaConfigs[i.tenantId].siteKey
                }
                return new Promise(async (s, a) => {
                    Zt(i, {
                        clientType: "CLIENT_TYPE_WEB",
                        version: "RECAPTCHA_ENTERPRISE"
                    }).then(o => {
                        if (o.recaptchaKey === void 0) a(new Error("recaptcha Enterprise site key undefined"));
                        else {
                            const c = new Qt(o);
                            return i.tenantId == null ? i._agentRecaptchaConfig = c : i._tenantRecaptchaConfigs[i.tenantId] = c, s(c.siteKey)
                        }
                    }).catch(o => {
                        a(o)
                    })
                })
            }

            function r(i, s, a) {
                const o = window.grecaptcha;
                vt(o) ? o.enterprise.ready(() => {
                    o.enterprise.execute(i, {
                        action: t
                    }).then(c => {
                        s(c)
                    }).catch(() => {
                        s(Q)
                    })
                }) : a(Error("No reCAPTCHA enterprise script loaded."))
            }
            return this.auth.settings.appVerificationDisabledForTesting ? new jr().execute("siteKey", {
                action: "verify"
            }) : new Promise((i, s) => {
                n(this.auth).then(a => {
                    if (!e && vt(window.grecaptcha)) r(a, i, s);
                    else {
                        if (typeof window > "u") {
                            s(new Error("RecaptchaVerifier is only supported in browser"));
                            return
                        }
                        let o = Vr();
                        o.length !== 0 && (o += a), it(o).then(() => {
                            r(a, i, s)
                        }).catch(c => {
                            s(c)
                        })
                    }
                }).catch(a => {
                    s(a)
                })
            })
        }
    };
async function K(t, e, n, r = !1, i = !1) {
    const s = new fn(t);
    let a;
    if (i) a = Q;
    else try {
        a = await s.verify(n)
    } catch {
        a = await s.verify(n, !0)
    }
    const o = Object.assign({}, e);
    if (n === "mfaSmsEnrollment" || n === "mfaSmsSignIn") {
        if ("phoneEnrollmentInfo" in o) {
            const c = o.phoneEnrollmentInfo.phoneNumber,
                u = o.phoneEnrollmentInfo.recaptchaToken;
            Object.assign(o, {
                phoneEnrollmentInfo: {
                    phoneNumber: c,
                    recaptchaToken: u,
                    captchaResponse: a,
                    clientType: "CLIENT_TYPE_WEB",
                    recaptchaVersion: "RECAPTCHA_ENTERPRISE"
                }
            })
        } else if ("phoneSignInInfo" in o) {
            const c = o.phoneSignInInfo.recaptchaToken;
            Object.assign(o, {
                phoneSignInInfo: {
                    recaptchaToken: c,
                    captchaResponse: a,
                    clientType: "CLIENT_TYPE_WEB",
                    recaptchaVersion: "RECAPTCHA_ENTERPRISE"
                }
            })
        }
        return o
    }
    return r ? Object.assign(o, {
        captchaResp: a
    }) : Object.assign(o, {
        captchaResponse: a
    }), Object.assign(o, {
        clientType: "CLIENT_TYPE_WEB"
    }), Object.assign(o, {
        recaptchaVersion: "RECAPTCHA_ENTERPRISE"
    }), o
}
async function C(t, e, n, r, i) {
    var s, a;
    return i === "EMAIL_PASSWORD_PROVIDER" ? !((s = t._getRecaptchaConfig()) === null || s === void 0) && s.isProviderEnabled("EMAIL_PASSWORD_PROVIDER") ? r(t, await K(t, e, n, n === "getOobCode")) : r(t, e).catch(async o => o.code === "auth/missing-recaptcha-token" ? (console.log(`${n} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`), r(t, await K(t, e, n, n === "getOobCode"))) : Promise.reject(o)) : i === "PHONE_PROVIDER" ? !((a = t._getRecaptchaConfig()) === null || a === void 0) && a.isProviderEnabled("PHONE_PROVIDER") ? r(t, await K(t, e, n)).catch(async o => {
        var c;
        return ((c = t._getRecaptchaConfig()) === null || c === void 0 ? void 0 : c.getProviderEnforcementState("PHONE_PROVIDER")) === "AUDIT" && (o.code === "auth/missing-recaptcha-token" || o.code === "auth/invalid-app-credential") ? (console.log(`Failed to verify with reCAPTCHA Enterprise. Automatically triggering the reCAPTCHA v2 flow to complete the ${n} flow.`), r(t, await K(t, e, n, !1, !0))) : Promise.reject(o)
    }) : r(t, await K(t, e, n, !1, !0)) : Promise.reject(i + " provider is not supported.")
}
async function qr(t) {
    const e = g(t),
        n = await Zt(e, {
            clientType: "CLIENT_TYPE_WEB",
            version: "RECAPTCHA_ENTERPRISE"
        }),
        r = new Qt(n);
    e.tenantId == null ? e._agentRecaptchaConfig = r : e._tenantRecaptchaConfigs[e.tenantId] = r, r.isAnyProviderEnabled() && new fn(e).verify()
}

function Yr(t, e) {
    const n = zt(t, "auth");
    if (n.isInitialized()) {
        const r = n.getImmediate(),
            i = n.getOptions();
        if (He(i, e ? ? {})) return r;
        E(r, "already-initialized")
    }
    return n.initialize({
        options: e
    })
}

function Jr(t, e) {
    const n = e ? .persistence || [],
        r = (Array.isArray(n) ? n : [n]).map(R);
    e ? .errorMap && t._updateErrorMap(e.errorMap), t._initializeWithPersistence(r, e ? .popupRedirectResolver)
}

function Xr(t, e, n) {
    const r = g(t);
    l(/^https?:\/\//.test(e), r, "invalid-emulator-scheme");
    const i = !!n ? .disableWarnings,
        s = pn(e),
        {
            host: a,
            port: o
        } = Qr(e),
        c = o === null ? "" : `:${o}`,
        u = {
            url: `${s}//${a}${c}/`
        },
        d = Object.freeze({
            host: a,
            port: o,
            protocol: s.replace(":", ""),
            options: Object.freeze({
                disableWarnings: i
            })
        });
    if (!r._canInitEmulator) {
        l(r.config.emulator && r.emulatorConfig, r, "emulator-config-failed"), l(He(u, r.config.emulator) && He(d, r.emulatorConfig), r, "emulator-config-failed");
        return
    }
    r.config.emulator = u, r.emulatorConfig = d, r.settings.appVerificationDisabledForTesting = !0, Ye(a) ? (sr(`${s}//${a}${c}`), cr("Auth", !0)) : i || Zr()
}

function pn(t) {
    const e = t.indexOf(":");
    return e < 0 ? "" : t.substr(0, e + 1)
}

function Qr(t) {
    const e = pn(t),
        n = /(\/\/)?([^?#/]+)/.exec(t.substr(e.length));
    if (!n) return {
        host: "",
        port: null
    };
    const r = n[2].split("@").pop() || "",
        i = /^(\[[^\]]+\])(:|$)/.exec(r);
    if (i) {
        const s = i[1];
        return {
            host: s,
            port: At(r.substr(s.length + 1))
        }
    } else {
        const [s, a] = r.split(":");
        return {
            host: s,
            port: At(a)
        }
    }
}

function At(t) {
    if (!t) return null;
    const e = Number(t);
    return isNaN(e) ? null : e
}

function Zr() {
    function t() {
        const e = document.createElement("p"),
            n = e.style;
        e.innerText = "Running in emulator mode. Do not use with production credentials.", n.position = "fixed", n.width = "100%", n.backgroundColor = "#ffffff", n.border = ".1em solid #000000", n.color = "#b50000", n.bottom = "0px", n.left = "0px", n.margin = "0px", n.zIndex = "10000", n.textAlign = "center", e.classList.add("firebase-emulator-warning"), document.body.appendChild(e)
    }
    typeof console < "u" && typeof console.info == "function" && console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."), typeof window < "u" && typeof document < "u" && (document.readyState === "loading" ? window.addEventListener("DOMContentLoaded", t) : t())
}
var we = class {
    constructor(t, e) {
        this.providerId = t, this.signInMethod = e
    }
    toJSON() {
        return y("not implemented")
    }
    _getIdTokenResponse(t) {
        return y("not implemented")
    }
    _linkToIdToken(t, e) {
        return y("not implemented")
    }
    _getReauthenticationResolver(t) {
        return y("not implemented")
    }
};
async function ei(t, e) {
    return m(t, "POST", "/v1/accounts:resetPassword", h(t, e))
}
async function ti(t, e) {
    return m(t, "POST", "/v1/accounts:signUp", e)
}
async function ni(t, e) {
    return A(t, "POST", "/v1/accounts:signInWithPassword", h(t, e))
}
async function mn(t, e) {
    return m(t, "POST", "/v1/accounts:sendOobCode", h(t, e))
}
async function ri(t, e) {
    return mn(t, e)
}
async function ii(t, e) {
    return mn(t, e)
}
async function si(t, e) {
    return A(t, "POST", "/v1/accounts:signInWithEmailLink", h(t, e))
}
async function ai(t, e) {
    return A(t, "POST", "/v1/accounts:signInWithEmailLink", h(t, e))
}
var St = class je extends we {
    constructor(e, n, r, i = null) {
        super("password", r), this._email = e, this._password = n, this._tenantId = i
    }
    static _fromEmailAndPassword(e, n) {
        return new je(e, n, "password")
    }
    static _fromEmailAndCode(e, n, r = null) {
        return new je(e, n, "emailLink", r)
    }
    toJSON() {
        return {
            email: this._email,
            password: this._password,
            signInMethod: this.signInMethod,
            tenantId: this._tenantId
        }
    }
    static fromJSON(e) {
        const n = typeof e == "string" ? JSON.parse(e) : e;
        if (n ? .email && n ? .password) {
            if (n.signInMethod === "password") return this._fromEmailAndPassword(n.email, n.password);
            if (n.signInMethod === "emailLink") return this._fromEmailAndCode(n.email, n.password, n.tenantId)
        }
        return null
    }
    async _getIdTokenResponse(e) {
        switch (this.signInMethod) {
            case "password":
                return C(e, {
                    returnSecureToken: !0,
                    email: this._email,
                    password: this._password,
                    clientType: "CLIENT_TYPE_WEB"
                }, "signInWithPassword", ni, "EMAIL_PASSWORD_PROVIDER");
            case "emailLink":
                return si(e, {
                    email: this._email,
                    oobCode: this._password
                });
            default:
                E(e, "internal-error")
        }
    }
    async _linkToIdToken(e, n) {
        switch (this.signInMethod) {
            case "password":
                return C(e, {
                    idToken: n,
                    returnSecureToken: !0,
                    email: this._email,
                    password: this._password,
                    clientType: "CLIENT_TYPE_WEB"
                }, "signUpPassword", ti, "EMAIL_PASSWORD_PROVIDER");
            case "emailLink":
                return ai(e, {
                    idToken: n,
                    email: this._email,
                    oobCode: this._password
                });
            default:
                E(e, "internal-error")
        }
    }
    _getReauthenticationResolver(e) {
        return this._getIdTokenResponse(e)
    }
};
async function H(t, e) {
    return A(t, "POST", "/v1/accounts:signInWithIdp", h(t, e))
}
var oi = "http://localhost",
    x = class Ke extends we {
        constructor() {
            super(...arguments), this.pendingToken = null
        }
        static _fromParams(e) {
            const n = new Ke(e.providerId, e.signInMethod);
            return e.idToken || e.accessToken ? (e.idToken && (n.idToken = e.idToken), e.accessToken && (n.accessToken = e.accessToken), e.nonce && !e.pendingToken && (n.nonce = e.nonce), e.pendingToken && (n.pendingToken = e.pendingToken)) : e.oauthToken && e.oauthTokenSecret ? (n.accessToken = e.oauthToken, n.secret = e.oauthTokenSecret) : E("argument-error"), n
        }
        toJSON() {
            return {
                idToken: this.idToken,
                accessToken: this.accessToken,
                secret: this.secret,
                nonce: this.nonce,
                pendingToken: this.pendingToken,
                providerId: this.providerId,
                signInMethod: this.signInMethod
            }
        }
        static fromJSON(e) {
            const n = typeof e == "string" ? JSON.parse(e) : e,
                {
                    providerId: r,
                    signInMethod: i
                } = n,
                s = Qe(n, ["providerId", "signInMethod"]);
            if (!r || !i) return null;
            const a = new Ke(r, i);
            return a.idToken = s.idToken || void 0, a.accessToken = s.accessToken || void 0, a.secret = s.secret, a.nonce = s.nonce, a.pendingToken = s.pendingToken || null, a
        }
        _getIdTokenResponse(e) {
            return H(e, this.buildRequest())
        }
        _linkToIdToken(e, n) {
            const r = this.buildRequest();
            return r.idToken = n, H(e, r)
        }
        _getReauthenticationResolver(e) {
            const n = this.buildRequest();
            return n.autoCreate = !1, H(e, n)
        }
        buildRequest() {
            const e = {
                requestUri: oi,
                returnSecureToken: !0
            };
            if (this.pendingToken) e.pendingToken = this.pendingToken;
            else {
                const n = {};
                this.idToken && (n.id_token = this.idToken), this.accessToken && (n.access_token = this.accessToken), this.secret && (n.oauth_token_secret = this.secret), n.providerId = this.providerId, this.nonce && !this.pendingToken && (n.nonce = this.nonce), e.postBody = W(n)
            }
            return e
        }
    };
async function kt(t, e) {
    return m(t, "POST", "/v1/accounts:sendVerificationCode", h(t, e))
}
async function ci(t, e) {
    return A(t, "POST", "/v1/accounts:signInWithPhoneNumber", h(t, e))
}
async function li(t, e) {
    const n = await A(t, "POST", "/v1/accounts:signInWithPhoneNumber", h(t, e));
    if (n.temporaryProof) throw $(t, "account-exists-with-different-credential", n);
    return n
}
var ui = {
    USER_NOT_FOUND: "user-not-found"
};
async function di(t, e) {
    return A(t, "POST", "/v1/accounts:signInWithPhoneNumber", h(t, Object.assign(Object.assign({}, e), {
        operation: "REAUTH"
    })), ui)
}
var Nt = class fe extends we {
    constructor(e) {
        super("phone", "phone"), this.params = e
    }
    static _fromVerification(e, n) {
        return new fe({
            verificationId: e,
            verificationCode: n
        })
    }
    static _fromTokenResponse(e, n) {
        return new fe({
            phoneNumber: e,
            temporaryProof: n
        })
    }
    _getIdTokenResponse(e) {
        return ci(e, this._makeVerificationRequest())
    }
    _linkToIdToken(e, n) {
        return li(e, Object.assign({
            idToken: n
        }, this._makeVerificationRequest()))
    }
    _getReauthenticationResolver(e) {
        return di(e, this._makeVerificationRequest())
    }
    _makeVerificationRequest() {
        const {
            temporaryProof: e,
            phoneNumber: n,
            verificationId: r,
            verificationCode: i
        } = this.params;
        return e && n ? {
            temporaryProof: e,
            phoneNumber: n
        } : {
            sessionInfo: r,
            code: i
        }
    }
    toJSON() {
        const e = {
            providerId: this.providerId
        };
        return this.params.phoneNumber && (e.phoneNumber = this.params.phoneNumber), this.params.temporaryProof && (e.temporaryProof = this.params.temporaryProof), this.params.verificationCode && (e.verificationCode = this.params.verificationCode), this.params.verificationId && (e.verificationId = this.params.verificationId), e
    }
    static fromJSON(e) {
        typeof e == "string" && (e = JSON.parse(e));
        const {
            verificationId: n,
            verificationCode: r,
            phoneNumber: i,
            temporaryProof: s
        } = e;
        return !r && !n && !i && !s ? null : new fe({
            verificationId: n,
            verificationCode: r,
            phoneNumber: i,
            temporaryProof: s
        })
    }
};

function hi(t) {
    switch (t) {
        case "recoverEmail":
            return "RECOVER_EMAIL";
        case "resetPassword":
            return "PASSWORD_RESET";
        case "signIn":
            return "EMAIL_SIGNIN";
        case "verifyEmail":
            return "VERIFY_EMAIL";
        case "verifyAndChangeEmail":
            return "VERIFY_AND_CHANGE_EMAIL";
        case "revertSecondFactorAddition":
            return "REVERT_SECOND_FACTOR_ADDITION";
        default:
            return null
    }
}

function fi(t) {
    const e = B(z(t)).link,
        n = e ? B(z(e)).deep_link_id : null,
        r = B(z(t)).deep_link_id;
    return (r ? B(z(r)).link : null) || r || n || e || t
}
var pi = class _n {
        constructor(e) {
            var n, r, i, s, a, o;
            const c = B(z(e)),
                u = (n = c.apiKey) !== null && n !== void 0 ? n : null,
                d = (r = c.oobCode) !== null && r !== void 0 ? r : null,
                f = hi((i = c.mode) !== null && i !== void 0 ? i : null);
            l(u && d && f, "argument-error"), this.apiKey = u, this.operation = f, this.code = d, this.continueUrl = (s = c.continueUrl) !== null && s !== void 0 ? s : null, this.languageCode = (a = c.lang) !== null && a !== void 0 ? a : null, this.tenantId = (o = c.tenantId) !== null && o !== void 0 ? o : null
        }
        static parseLink(e) {
            const n = fi(e);
            try {
                return new _n(n)
            } catch {
                return null
            }
        }
    },
    ye = class gn {
        constructor() {
            this.providerId = gn.PROVIDER_ID
        }
        static credential(e, n) {
            return St._fromEmailAndPassword(e, n)
        }
        static credentialWithLink(e, n) {
            const r = pi.parseLink(n);
            return l(r, "argument-error"), St._fromEmailAndCode(e, r.code, r.tenantId)
        }
    };
ye.PROVIDER_ID = "password";
ye.EMAIL_PASSWORD_SIGN_IN_METHOD = "password";
ye.EMAIL_LINK_SIGN_IN_METHOD = "emailLink";
var O = class {
        constructor(t) {
            this.providerId = t, this.defaultLanguageCode = null, this.customParameters = {}
        }
        setDefaultLanguage(t) {
            this.defaultLanguageCode = t
        }
        setCustomParameters(t) {
            return this.customParameters = t, this
        }
        getCustomParameters() {
            return this.customParameters
        }
    },
    j = class extends O {
        constructor() {
            super(...arguments), this.scopes = []
        }
        addScope(t) {
            return this.scopes.includes(t) || this.scopes.push(t), this
        }
        getScopes() {
            return [...this.scopes]
        }
    },
    oa = class pe extends j {
        static credentialFromJSON(e) {
            const n = typeof e == "string" ? JSON.parse(e) : e;
            return l("providerId" in n && "signInMethod" in n, "argument-error"), x._fromParams(n)
        }
        credential(e) {
            return this._credential(Object.assign(Object.assign({}, e), {
                nonce: e.rawNonce
            }))
        }
        _credential(e) {
            return l(e.idToken || e.accessToken, "argument-error"), x._fromParams(Object.assign(Object.assign({}, e), {
                providerId: this.providerId,
                signInMethod: this.providerId
            }))
        }
        static credentialFromResult(e) {
            return pe.oauthCredentialFromTaggedObject(e)
        }
        static credentialFromError(e) {
            return pe.oauthCredentialFromTaggedObject(e.customData || {})
        }
        static oauthCredentialFromTaggedObject({
            _tokenResponse: e
        }) {
            if (!e) return null;
            const {
                oauthIdToken: n,
                oauthAccessToken: r,
                oauthTokenSecret: i,
                pendingToken: s,
                nonce: a,
                providerId: o
            } = e;
            if (!r && !i && !n && !s || !o) return null;
            try {
                return new pe(o)._credential({
                    idToken: n,
                    accessToken: r,
                    nonce: a,
                    pendingToken: s
                })
            } catch {
                return null
            }
        }
    },
    In = class L extends j {
        constructor() {
            super("facebook.com")
        }
        static credential(e) {
            return x._fromParams({
                providerId: L.PROVIDER_ID,
                signInMethod: L.FACEBOOK_SIGN_IN_METHOD,
                accessToken: e
            })
        }
        static credentialFromResult(e) {
            return L.credentialFromTaggedObject(e)
        }
        static credentialFromError(e) {
            return L.credentialFromTaggedObject(e.customData || {})
        }
        static credentialFromTaggedObject({
            _tokenResponse: e
        }) {
            if (!e || !("oauthAccessToken" in e) || !e.oauthAccessToken) return null;
            try {
                return L.credential(e.oauthAccessToken)
            } catch {
                return null
            }
        }
    };
In.FACEBOOK_SIGN_IN_METHOD = "facebook.com";
In.PROVIDER_ID = "facebook.com";
var vn = class M extends j {
    constructor() {
        super("google.com"), this.addScope("profile")
    }
    static credential(e, n) {
        return x._fromParams({
            providerId: M.PROVIDER_ID,
            signInMethod: M.GOOGLE_SIGN_IN_METHOD,
            idToken: e,
            accessToken: n
        })
    }
    static credentialFromResult(e) {
        return M.credentialFromTaggedObject(e)
    }
    static credentialFromError(e) {
        return M.credentialFromTaggedObject(e.customData || {})
    }
    static credentialFromTaggedObject({
        _tokenResponse: e
    }) {
        if (!e) return null;
        const {
            oauthIdToken: n,
            oauthAccessToken: r
        } = e;
        if (!n && !r) return null;
        try {
            return M.credential(n, r)
        } catch {
            return null
        }
    }
};
vn.GOOGLE_SIGN_IN_METHOD = "google.com";
vn.PROVIDER_ID = "google.com";
var En = class U extends j {
    constructor() {
        super("github.com")
    }
    static credential(e) {
        return x._fromParams({
            providerId: U.PROVIDER_ID,
            signInMethod: U.GITHUB_SIGN_IN_METHOD,
            accessToken: e
        })
    }
    static credentialFromResult(e) {
        return U.credentialFromTaggedObject(e)
    }
    static credentialFromError(e) {
        return U.credentialFromTaggedObject(e.customData || {})
    }
    static credentialFromTaggedObject({
        _tokenResponse: e
    }) {
        if (!e || !("oauthAccessToken" in e) || !e.oauthAccessToken) return null;
        try {
            return U.credential(e.oauthAccessToken)
        } catch {
            return null
        }
    }
};
En.GITHUB_SIGN_IN_METHOD = "github.com";
En.PROVIDER_ID = "github.com";
var Tn = class F extends j {
    constructor() {
        super("twitter.com")
    }
    static credential(e, n) {
        return x._fromParams({
            providerId: F.PROVIDER_ID,
            signInMethod: F.TWITTER_SIGN_IN_METHOD,
            oauthToken: e,
            oauthTokenSecret: n
        })
    }
    static credentialFromResult(e) {
        return F.credentialFromTaggedObject(e)
    }
    static credentialFromError(e) {
        return F.credentialFromTaggedObject(e.customData || {})
    }
    static credentialFromTaggedObject({
        _tokenResponse: e
    }) {
        if (!e) return null;
        const {
            oauthAccessToken: n,
            oauthTokenSecret: r
        } = e;
        if (!n || !r) return null;
        try {
            return F.credential(n, r)
        } catch {
            return null
        }
    }
};
Tn.TWITTER_SIGN_IN_METHOD = "twitter.com";
Tn.PROVIDER_ID = "twitter.com";
async function mi(t, e) {
    return A(t, "POST", "/v1/accounts:signUp", h(t, e))
}
var b = class ze {
    constructor(e) {
        this.user = e.user, this.providerId = e.providerId, this._tokenResponse = e._tokenResponse, this.operationType = e.operationType
    }
    static async _fromIdTokenResponse(e, n, r, i = !1) {
        const s = await V._fromIdTokenResponse(e, r, i),
            a = Ot(r);
        return new ze({
            user: s,
            providerId: a,
            _tokenResponse: r,
            operationType: n
        })
    }
    static async _forOperation(e, n, r) {
        await e._updateTokensIfNecessary(r, !0);
        const i = Ot(r);
        return new ze({
            user: e,
            providerId: i,
            _tokenResponse: r,
            operationType: n
        })
    }
};

function Ot(t) {
    return t.providerId ? t.providerId : "phoneNumber" in t ? "phone" : null
}
var _i = class Be extends Xe {
    constructor(e, n, r, i) {
        var s;
        super(n.code, n.message), this.operationType = r, this.user = i, Object.setPrototypeOf(this, Be.prototype), this.customData = {
            appName: e.name,
            tenantId: (s = e.tenantId) !== null && s !== void 0 ? s : void 0,
            _serverResponse: n.customData._serverResponse,
            operationType: r
        }
    }
    static _fromErrorAndOperation(e, n, r, i) {
        return new Be(e, n, r, i)
    }
};

function wn(t, e, n, r) {
    return (e === "reauthenticate" ? n._getReauthenticationResolver(t) : n._getIdTokenResponse(t)).catch(i => {
        throw i.code === "auth/multi-factor-auth-required" ? _i._fromErrorAndOperation(t, i, e, r) : i
    })
}

function gi(t) {
    return new Set(t.map(({
        providerId: e
    }) => e).filter(e => !!e))
}
async function Ii(t, e, n = !1) {
    const r = await N(t, e._linkToIdToken(t.auth, await t.getIdToken()), n);
    return b._forOperation(t, "link", r)
}
async function vi(t, e, n) {
    await ee(e);
    const r = gi(e.providerData),
        i = t === !1 ? "provider-already-linked" : "no-such-provider";
    l(r.has(n) === t, e.auth, i)
}
async function Ei(t, e, n = !1) {
    const {
        auth: r
    } = t;
    if (I(r.app)) return Promise.reject(w(r));
    const i = "reauthenticate";
    try {
        const s = await N(t, wn(r, i, e, t), n);
        l(s.idToken, r, "internal-error");
        const a = nt(s.idToken);
        l(a, r, "internal-error");
        const {
            sub: o
        } = a;
        return l(t.uid === o, r, "user-mismatch"), b._forOperation(t, i, s)
    } catch (s) {
        throw s ? .code === "auth/user-not-found" && E(r, "user-mismatch"), s
    }
}
async function yn(t, e, n = !1) {
    if (I(t.app)) return Promise.reject(w(t));
    const r = "signIn",
        i = await wn(t, r, e),
        s = await b._fromIdTokenResponse(t, r, i);
    return n || await t._updateCurrentUser(s.user), s
}
async function Ti(t, e) {
    return yn(g(t), e)
}
async function wi(t, e) {
    return A(t, "POST", "/v1/accounts:signInWithCustomToken", h(t, e))
}
async function ca(t, e) {
    if (I(t.app)) return Promise.reject(w(t));
    const n = g(t),
        r = await wi(n, {
            token: e,
            returnSecureToken: !0
        }),
        i = await b._fromIdTokenResponse(n, "signIn", r);
    return await n._updateCurrentUser(i.user), i
}
var ie = class {
        constructor(t, e) {
            this.factorId = t, this.uid = e.mfaEnrollmentId, this.enrollmentTime = new Date(e.enrolledAt).toUTCString(), this.displayName = e.displayName
        }
        static _fromServerResponse(t, e) {
            return "phoneInfo" in e ? yi._fromServerResponse(t, e) : "totpInfo" in e ? Ri._fromServerResponse(t, e) : E(t, "internal-error")
        }
    },
    yi = class Rn extends ie {
        constructor(e) {
            super("phone", e), this.phoneNumber = e.phoneInfo
        }
        static _fromServerResponse(e, n) {
            return new Rn(n)
        }
    },
    Ri = class Pn extends ie {
        constructor(e) {
            super("totp", e)
        }
        static _fromServerResponse(e, n) {
            return new Pn(n)
        }
    };

function An(t, e, n) {
    var r;
    l(((r = n.url) === null || r === void 0 ? void 0 : r.length) > 0, t, "invalid-continue-uri"), l(typeof n.dynamicLinkDomain > "u" || n.dynamicLinkDomain.length > 0, t, "invalid-dynamic-link-domain"), l(typeof n.linkDomain > "u" || n.linkDomain.length > 0, t, "invalid-hosting-link-domain"), e.continueUrl = n.url, e.dynamicLinkDomain = n.dynamicLinkDomain, e.linkDomain = n.linkDomain, e.canHandleCodeInApp = n.handleCodeInApp, n.iOS && (l(n.iOS.bundleId.length > 0, t, "missing-ios-bundle-id"), e.iOSBundleId = n.iOS.bundleId), n.android && (l(n.android.packageName.length > 0, t, "missing-android-pkg-name"), e.androidInstallApp = n.android.installApp, e.androidMinimumVersionCode = n.android.minimumVersion, e.androidPackageName = n.android.packageName)
}
async function Sn(t) {
    const e = g(t);
    e._getPasswordPolicyInternal() && await e._updatePasswordPolicy()
}
async function la(t, e, n) {
    const r = g(t),
        i = {
            requestType: "PASSWORD_RESET",
            email: e,
            clientType: "CLIENT_TYPE_WEB"
        };
    n && An(r, i, n), await C(r, i, "getOobCode", ii, "EMAIL_PASSWORD_PROVIDER")
}
async function ua(t, e) {
    const n = p(t),
        r = await ei(n, {
            oobCode: e
        }),
        i = r.requestType;
    switch (l(i, n, "internal-error"), i) {
        case "EMAIL_SIGNIN":
            break;
        case "VERIFY_AND_CHANGE_EMAIL":
            l(r.newEmail, n, "internal-error");
            break;
        case "REVERT_SECOND_FACTOR_ADDITION":
            l(r.mfaInfo, n, "internal-error");
        default:
            l(r.email, n, "internal-error")
    }
    let s = null;
    return r.mfaInfo && (s = ie._fromServerResponse(g(n), r.mfaInfo)), {
        data: {
            email: (r.requestType === "VERIFY_AND_CHANGE_EMAIL" ? r.newEmail : r.email) || null,
            previousEmail: (r.requestType === "VERIFY_AND_CHANGE_EMAIL" ? r.email : r.newEmail) || null,
            multiFactorInfo: s
        },
        operation: i
    }
}
async function da(t, e, n) {
    if (I(t.app)) return Promise.reject(w(t));
    const r = g(t),
        i = await C(r, {
            returnSecureToken: !0,
            email: e,
            password: n,
            clientType: "CLIENT_TYPE_WEB"
        }, "signUpPassword", mi, "EMAIL_PASSWORD_PROVIDER").catch(a => {
            throw a.code === "auth/password-does-not-meet-requirements" && Sn(t), a
        }),
        s = await b._fromIdTokenResponse(r, "signIn", i);
    return await r._updateCurrentUser(s.user), s
}

function ha(t, e, n) {
    return I(t.app) ? Promise.reject(w(t)) : Ti(p(t), ye.credential(e, n)).catch(async r => {
        throw r.code === "auth/password-does-not-meet-requirements" && Sn(t), r
    })
}
async function fa(t, e) {
    const n = p(t),
        r = {
            requestType: "VERIFY_EMAIL",
            idToken: await t.getIdToken()
        };
    e && An(n.auth, r, e);
    const {
        email: i
    } = await ri(n.auth, r);
    i !== t.email && await t.reload()
}
async function Pi(t, e) {
    return m(t, "POST", "/v1/accounts:update", e)
}
async function pa(t, {
    displayName: e,
    photoURL: n
}) {
    if (e === void 0 && n === void 0) return;
    const r = p(t),
        i = {
            idToken: await r.getIdToken(),
            displayName: e,
            photoUrl: n,
            returnSecureToken: !0
        },
        s = await N(r, Pi(r.auth, i));
    r.displayName = s.displayName || null, r.photoURL = s.photoUrl || null;
    const a = r.providerData.find(({
        providerId: o
    }) => o === "password");
    a && (a.displayName = r.displayName, a.photoURL = r.photoURL), await r._updateTokensIfNecessary(s)
}

function ma(t, e) {
    return p(t).setPersistence(e)
}

function Ai(t, e, n, r) {
    return p(t).onIdTokenChanged(e, n, r)
}

function Si(t, e, n) {
    return p(t).beforeAuthStateChanged(e, n)
}

function _a(t, e, n, r) {
    return p(t).onAuthStateChanged(e, n, r)
}

function ga(t, e) {
    return p(t).updateCurrentUser(e)
}

function Ia(t) {
    return p(t).signOut()
}
var kn = class Y {
        constructor(e, n, r) {
            this.type = e, this.credential = n, this.user = r
        }
        static _fromIdtoken(e, n) {
            return new Y("enroll", e, n)
        }
        static _fromMfaPendingCredential(e) {
            return new Y("signin", e)
        }
        toJSON() {
            return {
                multiFactorSession: {
                    [this.type === "enroll" ? "idToken" : "pendingCredential"]: this.credential
                }
            }
        }
        static fromJSON(e) {
            var n, r;
            if (e ? .multiFactorSession) {
                if (!((n = e.multiFactorSession) === null || n === void 0) && n.pendingCredential) return Y._fromMfaPendingCredential(e.multiFactorSession.pendingCredential);
                if (!((r = e.multiFactorSession) === null || r === void 0) && r.idToken) return Y._fromIdtoken(e.multiFactorSession.idToken)
            }
            return null
        }
    },
    ki = class Nn {
        constructor(e, n, r) {
            this.session = e, this.hints = n, this.signInResolver = r
        }
        static _fromError(e, n) {
            const r = g(e),
                i = n.customData._serverResponse,
                s = (i.mfaInfo || []).map(o => ie._fromServerResponse(r, o));
            l(i.mfaPendingCredential, r, "internal-error");
            const a = kn._fromMfaPendingCredential(i.mfaPendingCredential);
            return new Nn(a, s, async o => {
                const c = await o._process(r, a);
                delete i.mfaInfo, delete i.mfaPendingCredential;
                const u = Object.assign(Object.assign({}, i), {
                    idToken: c.idToken,
                    refreshToken: c.refreshToken
                });
                switch (n.operationType) {
                    case "signIn":
                        const d = await b._fromIdTokenResponse(r, n.operationType, u);
                        return await r._updateCurrentUser(d.user), d;
                    case "reauthenticate":
                        return l(n.user, r, "internal-error"), b._forOperation(n.user, n.operationType, u);
                    default:
                        E(r, "internal-error")
                }
            })
        }
        async resolveSignIn(e) {
            const n = e;
            return this.signInResolver(n)
        }
    };

function va(t, e) {
    var n;
    const r = p(t),
        i = e;
    return l(e.customData.operationType, r, "argument-error"), l((n = i.customData._serverResponse) === null || n === void 0 ? void 0 : n.mfaPendingCredential, r, "argument-error"), ki._fromError(r, i)
}

function Ct(t, e) {
    return m(t, "POST", "/v2/accounts/mfaEnrollment:start", h(t, e))
}

function Ni(t, e) {
    return m(t, "POST", "/v2/accounts/mfaEnrollment:finalize", h(t, e))
}

function Oi(t, e) {
    return m(t, "POST", "/v2/accounts/mfaEnrollment:start", h(t, e))
}

function Ci(t, e) {
    return m(t, "POST", "/v2/accounts/mfaEnrollment:finalize", h(t, e))
}

function bi(t, e) {
    return m(t, "POST", "/v2/accounts/mfaEnrollment:withdraw", h(t, e))
}
var Di = class On {
        constructor(e) {
            this.user = e, this.enrolledFactors = [], e._onReload(n => {
                n.mfaInfo && (this.enrolledFactors = n.mfaInfo.map(r => ie._fromServerResponse(e.auth, r)))
            })
        }
        static _fromUser(e) {
            return new On(e)
        }
        async getSession() {
            return kn._fromIdtoken(await this.user.getIdToken(), this.user)
        }
        async enroll(e, n) {
            const r = e,
                i = await this.getSession(),
                s = await N(this.user, r._process(this.user.auth, i, n));
            return await this.user._updateTokensIfNecessary(s), this.user.reload()
        }
        async unenroll(e) {
            const n = typeof e == "string" ? e : e.uid,
                r = await this.user.getIdToken();
            try {
                const i = await N(this.user, bi(this.user.auth, {
                    idToken: r,
                    mfaEnrollmentId: n
                }));
                this.enrolledFactors = this.enrolledFactors.filter(({
                    uid: s
                }) => s !== n), await this.user._updateTokensIfNecessary(i), await this.user.reload()
            } catch (i) {
                throw i
            }
        }
    },
    De = new WeakMap;

function Ea(t) {
    const e = p(t);
    return De.has(e) || De.set(e, Di._fromUser(e)), De.get(e)
}
var Ee = "__sak",
    Cn = class {
        constructor(t, e) {
            this.storageRetriever = t, this.type = e
        }
        _isAvailable() {
            try {
                return this.storage ? (this.storage.setItem(Ee, "1"), this.storage.removeItem(Ee), Promise.resolve(!0)) : Promise.resolve(!1)
            } catch {
                return Promise.resolve(!1)
            }
        }
        _set(t, e) {
            return this.storage.setItem(t, JSON.stringify(e)), Promise.resolve()
        }
        _get(t) {
            const e = this.storage.getItem(t);
            return Promise.resolve(e ? JSON.parse(e) : null)
        }
        _remove(t) {
            return this.storage.removeItem(t), Promise.resolve()
        }
        get storage() {
            return this.storageRetriever()
        }
    },
    Li = 1e3,
    Mi = 10,
    bn = class extends Cn {
        constructor() {
            super(() => window.localStorage, "LOCAL"), this.boundEventHandler = (t, e) => this.onStorageEvent(t, e), this.listeners = {}, this.localCache = {}, this.pollTimer = null, this.fallbackToPolling = un(), this._shouldAllowMigration = !0
        }
        forAllChangedKeys(t) {
            for (const e of Object.keys(this.listeners)) {
                const n = this.storage.getItem(e),
                    r = this.localCache[e];
                n !== r && t(e, r, n)
            }
        }
        onStorageEvent(t, e = !1) {
            if (!t.key) {
                this.forAllChangedKeys((s, a, o) => {
                    this.notifyListeners(s, o)
                });
                return
            }
            const n = t.key;
            e ? this.detachListener() : this.stopPolling();
            const r = () => {
                    const s = this.storage.getItem(n);
                    !e && this.localCache[n] === s || this.notifyListeners(n, s)
                },
                i = this.storage.getItem(n);
            Or() && i !== t.newValue && t.newValue !== t.oldValue ? setTimeout(r, Mi) : r()
        }
        notifyListeners(t, e) {
            this.localCache[t] = e;
            const n = this.listeners[t];
            if (n)
                for (const r of Array.from(n)) r(e && JSON.parse(e))
        }
        startPolling() {
            this.stopPolling(), this.pollTimer = setInterval(() => {
                this.forAllChangedKeys((t, e, n) => {
                    this.onStorageEvent(new StorageEvent("storage", {
                        key: t,
                        oldValue: e,
                        newValue: n
                    }), !0)
                })
            }, Li)
        }
        stopPolling() {
            this.pollTimer && (clearInterval(this.pollTimer), this.pollTimer = null)
        }
        attachListener() {
            window.addEventListener("storage", this.boundEventHandler)
        }
        detachListener() {
            window.removeEventListener("storage", this.boundEventHandler)
        }
        _addListener(t, e) {
            Object.keys(this.listeners).length === 0 && (this.fallbackToPolling ? this.startPolling() : this.attachListener()), this.listeners[t] || (this.listeners[t] = new Set, this.localCache[t] = this.storage.getItem(t)), this.listeners[t].add(e)
        }
        _removeListener(t, e) {
            this.listeners[t] && (this.listeners[t].delete(e), this.listeners[t].size === 0 && delete this.listeners[t]), Object.keys(this.listeners).length === 0 && (this.detachListener(), this.stopPolling())
        }
        async _set(t, e) {
            await super._set(t, e), this.localCache[t] = JSON.stringify(e)
        }
        async _get(t) {
            const e = await super._get(t);
            return this.localCache[t] = JSON.stringify(e), e
        }
        async _remove(t) {
            await super._remove(t), delete this.localCache[t]
        }
    };
bn.type = "LOCAL";
var Ui = bn,
    Fi = 1e3;

function Le(t) {
    var e, n;
    const r = t.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&"),
        i = RegExp(`${r}=([^;]+)`);
    return (n = (e = document.cookie.match(i)) === null || e === void 0 ? void 0 : e[1]) !== null && n !== void 0 ? n : null
}

function Me(t) {
    return `${window.location.protocol==="http:"?"__dev_":"__HOST-"}FIREBASE_${t.split(":")[3]}`
}
var Vi = class {
    constructor() {
        this.type = "COOKIE", this.listenerUnsubscribes = new Map
    }
    _getFinalTarget(t) {
        const e = new URL(`${window.location.origin}/__cookies__`);
        return e.searchParams.set("finalTarget", t), e
    }
    async _isAvailable() {
        var t;
        return typeof isSecureContext == "boolean" && !isSecureContext || typeof navigator > "u" || typeof document > "u" ? !1 : (t = navigator.cookieEnabled) !== null && t !== void 0 ? t : !0
    }
    async _set(t, e) {}
    async _get(t) {
        if (!this._isAvailable()) return null;
        const e = Me(t);
        if (window.cookieStore) {
            const n = await window.cookieStore.get(e);
            return n ? .value
        }
        return Le(e)
    }
    async _remove(t) {
        if (!this._isAvailable() || !await this._get(t)) return;
        const e = Me(t);
        document.cookie = `${e}=;Max-Age=34560000;Partitioned;Secure;SameSite=Strict;Path=/;Priority=High`, await fetch("/__cookies__", {
            method: "DELETE"
        }).catch(() => {})
    }
    _addListener(t, e) {
        if (!this._isAvailable()) return;
        const n = Me(t);
        if (window.cookieStore) {
            const a = (c => {
                    const u = c.changed.find(d => d.name === n);
                    u && e(u.value), c.deleted.find(d => d.name === n) && e(null)
                }),
                o = () => window.cookieStore.removeEventListener("change", a);
            return this.listenerUnsubscribes.set(e, o), window.cookieStore.addEventListener("change", a)
        }
        let r = Le(n);
        const i = setInterval(() => {
                const a = Le(n);
                a !== r && (e(a), r = a)
            }, Fi),
            s = () => clearInterval(i);
        this.listenerUnsubscribes.set(e, s)
    }
    _removeListener(t, e) {
        const n = this.listenerUnsubscribes.get(e);
        n && (n(), this.listenerUnsubscribes.delete(e))
    }
};
Vi.type = "COOKIE";
var Dn = class extends Cn {
    constructor() {
        super(() => window.sessionStorage, "SESSION")
    }
    _addListener(t, e) {}
    _removeListener(t, e) {}
};
Dn.type = "SESSION";
var Ln = Dn;

function Hi(t) {
    return Promise.all(t.map(async e => {
        try {
            return {
                fulfilled: !0,
                value: await e
            }
        } catch (n) {
            return {
                fulfilled: !1,
                reason: n
            }
        }
    }))
}
var Mn = class Un {
    constructor(e) {
        this.eventTarget = e, this.handlersMap = {}, this.boundEventHandler = this.handleEvent.bind(this)
    }
    static _getInstance(e) {
        const n = this.receivers.find(i => i.isListeningto(e));
        if (n) return n;
        const r = new Un(e);
        return this.receivers.push(r), r
    }
    isListeningto(e) {
        return this.eventTarget === e
    }
    async handleEvent(e) {
        const n = e,
            {
                eventId: r,
                eventType: i,
                data: s
            } = n.data,
            a = this.handlersMap[i];
        if (!a ? .size) return;
        n.ports[0].postMessage({
            status: "ack",
            eventId: r,
            eventType: i
        });
        const o = await Hi(Array.from(a).map(async c => c(n.origin, s)));
        n.ports[0].postMessage({
            status: "done",
            eventId: r,
            eventType: i,
            response: o
        })
    }
    _subscribe(e, n) {
        Object.keys(this.handlersMap).length === 0 && this.eventTarget.addEventListener("message", this.boundEventHandler), this.handlersMap[e] || (this.handlersMap[e] = new Set), this.handlersMap[e].add(n)
    }
    _unsubscribe(e, n) {
        this.handlersMap[e] && n && this.handlersMap[e].delete(n), (!n || this.handlersMap[e].size === 0) && delete this.handlersMap[e], Object.keys(this.handlersMap).length === 0 && this.eventTarget.removeEventListener("message", this.boundEventHandler)
    }
};
Mn.receivers = [];

function Re(t = "", e = 10) {
    let n = "";
    for (let r = 0; r < e; r++) n += Math.floor(Math.random() * 10);
    return t + n
}
var xi = class {
    constructor(t) {
        this.target = t, this.handlers = new Set
    }
    removeMessageHandler(t) {
        t.messageChannel && (t.messageChannel.port1.removeEventListener("message", t.onMessage), t.messageChannel.port1.close()), this.handlers.delete(t)
    }
    async _send(t, e, n = 50) {
        const r = typeof MessageChannel < "u" ? new MessageChannel : null;
        if (!r) throw new Error("connection_unavailable");
        let i, s;
        return new Promise((a, o) => {
            const c = Re("", 20);
            r.port1.start();
            const u = setTimeout(() => {
                o(new Error("unsupported_event"))
            }, n);
            s = {
                messageChannel: r,
                onMessage(d) {
                    const f = d;
                    if (f.data.eventId === c) switch (f.data.status) {
                        case "ack":
                            clearTimeout(u), i = setTimeout(() => {
                                o(new Error("timeout"))
                            }, 3e3);
                            break;
                        case "done":
                            clearTimeout(i), a(f.data.response);
                            break;
                        default:
                            clearTimeout(u), clearTimeout(i), o(new Error("invalid_response"))
                    }
                }
            }, this.handlers.add(s), r.port1.addEventListener("message", s.onMessage), this.target.postMessage({
                eventType: t,
                eventId: c,
                data: e
            }, [r.port2])
        }).finally(() => {
            s && this.removeMessageHandler(s)
        })
    }
};

function _() {
    return window
}

function Wi(t) {
    _().location.href = t
}

function st() {
    return typeof _().WorkerGlobalScope < "u" && typeof _().importScripts == "function"
}
async function Gi() {
    if (!navigator ? .serviceWorker) return null;
    try {
        return (await navigator.serviceWorker.ready).active
    } catch {
        return null
    }
}

function ji() {
    var t;
    return ((t = navigator ? .serviceWorker) === null || t === void 0 ? void 0 : t.controller) || null
}

function Ki() {
    return st() ? self : null
}
var Fn = "firebaseLocalStorageDb",
    zi = 1,
    Te = "firebaseLocalStorage",
    Vn = "fbase_key",
    se = class {
        constructor(t) {
            this.request = t
        }
        toPromise() {
            return new Promise((t, e) => {
                this.request.addEventListener("success", () => {
                    t(this.request.result)
                }), this.request.addEventListener("error", () => {
                    e(this.request.error)
                })
            })
        }
    };

function Pe(t, e) {
    return t.transaction([Te], e ? "readwrite" : "readonly").objectStore(Te)
}

function Bi() {
    const t = indexedDB.deleteDatabase(Fn);
    return new se(t).toPromise()
}

function $e() {
    const t = indexedDB.open(Fn, zi);
    return new Promise((e, n) => {
        t.addEventListener("error", () => {
            n(t.error)
        }), t.addEventListener("upgradeneeded", () => {
            const r = t.result;
            try {
                r.createObjectStore(Te, {
                    keyPath: Vn
                })
            } catch (i) {
                n(i)
            }
        }), t.addEventListener("success", async () => {
            const r = t.result;
            r.objectStoreNames.contains(Te) ? e(r) : (r.close(), await Bi(), e(await $e()))
        })
    })
}
async function bt(t, e, n) {
    const r = Pe(t, !0).put({
        [Vn]: e,
        value: n
    });
    return new se(r).toPromise()
}
async function $i(t, e) {
    const n = Pe(t, !1).get(e),
        r = await new se(n).toPromise();
    return r === void 0 ? null : r.value
}

function Dt(t, e) {
    const n = Pe(t, !0).delete(e);
    return new se(n).toPromise()
}
var qi = 800,
    Yi = 3,
    Hn = class {
        constructor() {
            this.type = "LOCAL", this._shouldAllowMigration = !0, this.listeners = {}, this.localCache = {}, this.pollTimer = null, this.pendingWrites = 0, this.receiver = null, this.sender = null, this.serviceWorkerReceiverAvailable = !1, this.activeServiceWorker = null, this._workerInitializationPromise = this.initializeServiceWorkerMessaging().then(() => {}, () => {})
        }
        async _openDb() {
            return this.db ? this.db : (this.db = await $e(), this.db)
        }
        async _withRetries(t) {
            let e = 0;
            for (;;) try {
                return await t(await this._openDb())
            } catch (n) {
                if (e++ > Yi) throw n;
                this.db && (this.db.close(), this.db = void 0)
            }
        }
        async initializeServiceWorkerMessaging() {
            return st() ? this.initializeReceiver() : this.initializeSender()
        }
        async initializeReceiver() {
            this.receiver = Mn._getInstance(Ki()), this.receiver._subscribe("keyChanged", async (t, e) => ({
                keyProcessed: (await this._poll()).includes(e.key)
            })), this.receiver._subscribe("ping", async (t, e) => ["keyChanged"])
        }
        async initializeSender() {
            var t, e;
            if (this.activeServiceWorker = await Gi(), !this.activeServiceWorker) return;
            this.sender = new xi(this.activeServiceWorker);
            const n = await this.sender._send("ping", {}, 800);
            n && !((t = n[0]) === null || t === void 0) && t.fulfilled && !((e = n[0]) === null || e === void 0) && e.value.includes("keyChanged") && (this.serviceWorkerReceiverAvailable = !0)
        }
        async notifyServiceWorker(t) {
            if (!(!this.sender || !this.activeServiceWorker || ji() !== this.activeServiceWorker)) try {
                await this.sender._send("keyChanged", {
                    key: t
                }, this.serviceWorkerReceiverAvailable ? 800 : 50)
            } catch {}
        }
        async _isAvailable() {
            try {
                if (!indexedDB) return !1;
                const t = await $e();
                return await bt(t, Ee, "1"), await Dt(t, Ee), !0
            } catch {}
            return !1
        }
        async _withPendingWrite(t) {
            this.pendingWrites++;
            try {
                await t()
            } finally {
                this.pendingWrites--
            }
        }
        async _set(t, e) {
            return this._withPendingWrite(async () => (await this._withRetries(n => bt(n, t, e)), this.localCache[t] = e, this.notifyServiceWorker(t)))
        }
        async _get(t) {
            const e = await this._withRetries(n => $i(n, t));
            return this.localCache[t] = e, e
        }
        async _remove(t) {
            return this._withPendingWrite(async () => (await this._withRetries(e => Dt(e, t)), delete this.localCache[t], this.notifyServiceWorker(t)))
        }
        async _poll() {
            const t = await this._withRetries(r => {
                const i = Pe(r, !1).getAll();
                return new se(i).toPromise()
            });
            if (!t) return [];
            if (this.pendingWrites !== 0) return [];
            const e = [],
                n = new Set;
            if (t.length !== 0)
                for (const {
                        fbase_key: r,
                        value: i
                    } of t) n.add(r), JSON.stringify(this.localCache[r]) !== JSON.stringify(i) && (this.notifyListeners(r, i), e.push(r));
            for (const r of Object.keys(this.localCache)) this.localCache[r] && !n.has(r) && (this.notifyListeners(r, null), e.push(r));
            return e
        }
        notifyListeners(t, e) {
            this.localCache[t] = e;
            const n = this.listeners[t];
            if (n)
                for (const r of Array.from(n)) r(e)
        }
        startPolling() {
            this.stopPolling(), this.pollTimer = setInterval(async () => this._poll(), qi)
        }
        stopPolling() {
            this.pollTimer && (clearInterval(this.pollTimer), this.pollTimer = null)
        }
        _addListener(t, e) {
            Object.keys(this.listeners).length === 0 && this.startPolling(), this.listeners[t] || (this.listeners[t] = new Set, this._get(t)), this.listeners[t].add(e)
        }
        _removeListener(t, e) {
            this.listeners[t] && (this.listeners[t].delete(e), this.listeners[t].size === 0 && delete this.listeners[t]), Object.keys(this.listeners).length === 0 && this.stopPolling()
        }
    };
Hn.type = "LOCAL";
var Ji = Hn;

function Lt(t, e) {
    return m(t, "POST", "/v2/accounts/mfaSignIn:start", h(t, e))
}

function Xi(t, e) {
    return m(t, "POST", "/v2/accounts/mfaSignIn:finalize", h(t, e))
}

function Qi(t, e) {
    return m(t, "POST", "/v2/accounts/mfaSignIn:finalize", h(t, e))
}
var Ue = hn("rcb"),
    Zi = new ne(3e4, 6e4),
    es = class {
        constructor() {
            var t;
            this.hostLanguage = "", this.counter = 0, this.librarySeparatelyLoaded = !!(!((t = _().grecaptcha) === null || t === void 0) && t.render)
        }
        load(t, e = "") {
            return l(ts(e), t, "argument-error"), this.shouldResolveImmediately(e) && It(_().grecaptcha) ? Promise.resolve(_().grecaptcha) : new Promise((n, r) => {
                const i = _().setTimeout(() => {
                    r(v(t, "network-request-failed"))
                }, Zi.get());
                _()[Ue] = () => {
                    _().clearTimeout(i), delete _()[Ue];
                    const s = _().grecaptcha;
                    if (!s || !It(s)) {
                        r(v(t, "internal-error"));
                        return
                    }
                    const a = s.render;
                    s.render = (o, c) => {
                        const u = a(o, c);
                        return this.counter++, u
                    }, this.hostLanguage = e, n(s)
                }, it(`${Fr()}?${W({onload:Ue,render:"explicit",hl:e})}`).catch(() => {
                    clearTimeout(i), r(v(t, "internal-error"))
                })
            })
        }
        clearedOneInstance() {
            this.counter--
        }
        shouldResolveImmediately(t) {
            var e;
            return !!(!((e = _().grecaptcha) === null || e === void 0) && e.render) && (t === this.hostLanguage || this.counter > 0 || this.librarySeparatelyLoaded)
        }
    };

function ts(t) {
    return t.length <= 6 && /^\s*[a-zA-Z0-9\-]*\s*$/.test(t)
}
var ns = class {
        async load(t) {
            return new Gr(t)
        }
        clearedOneInstance() {}
    },
    Z = "recaptcha",
    rs = {
        theme: "light",
        type: "image"
    },
    Ta = class {
        constructor(t, e, n = Object.assign({}, rs)) {
            this.parameters = n, this.type = Z, this.destroyed = !1, this.widgetId = null, this.tokenChangeListeners = new Set, this.renderPromise = null, this.recaptcha = null, this.auth = g(t), this.isInvisible = this.parameters.size === "invisible", l(typeof document < "u", this.auth, "operation-not-supported-in-this-environment");
            const r = typeof e == "string" ? document.getElementById(e) : e;
            l(r, this.auth, "argument-error"), this.container = r, this.parameters.callback = this.makeTokenCallback(this.parameters.callback), this._recaptchaLoader = this.auth.settings.appVerificationDisabledForTesting ? new ns : new es, this.validateStartingState()
        }
        async verify() {
            this.assertNotDestroyed();
            const t = await this.render(),
                e = this.getAssertedRecaptcha(),
                n = e.getResponse(t);
            return n || new Promise(r => {
                const i = s => {
                    s && (this.tokenChangeListeners.delete(i), r(s))
                };
                this.tokenChangeListeners.add(i), this.isInvisible && e.execute(t)
            })
        }
        render() {
            try {
                this.assertNotDestroyed()
            } catch (t) {
                return Promise.reject(t)
            }
            return this.renderPromise ? this.renderPromise : (this.renderPromise = this.makeRenderPromise().catch(t => {
                throw this.renderPromise = null, t
            }), this.renderPromise)
        }
        _reset() {
            this.assertNotDestroyed(), this.widgetId !== null && this.getAssertedRecaptcha().reset(this.widgetId)
        }
        clear() {
            this.assertNotDestroyed(), this.destroyed = !0, this._recaptchaLoader.clearedOneInstance(), this.isInvisible || this.container.childNodes.forEach(t => {
                this.container.removeChild(t)
            })
        }
        validateStartingState() {
            l(!this.parameters.sitekey, this.auth, "argument-error"), l(this.isInvisible || !this.container.hasChildNodes(), this.auth, "argument-error"), l(typeof document < "u", this.auth, "operation-not-supported-in-this-environment")
        }
        makeTokenCallback(t) {
            return e => {
                if (this.tokenChangeListeners.forEach(n => n(e)), typeof t == "function") t(e);
                else if (typeof t == "string") {
                    const n = _()[t];
                    typeof n == "function" && n(e)
                }
            }
        }
        assertNotDestroyed() {
            l(!this.destroyed, this.auth, "internal-error")
        }
        async makeRenderPromise() {
            if (await this.init(), !this.widgetId) {
                let t = this.container;
                if (!this.isInvisible) {
                    const e = document.createElement("div");
                    t.appendChild(e), t = e
                }
                this.widgetId = this.getAssertedRecaptcha().render(t, this.parameters)
            }
            return this.widgetId
        }
        async init() {
            l(qt() && !st(), this.auth, "internal-error"), await is(), this.recaptcha = await this._recaptchaLoader.load(this.auth, this.auth.languageCode || void 0);
            const t = await Er(this.auth);
            l(t, this.auth, "internal-error"), this.parameters.sitekey = t
        }
        getAssertedRecaptcha() {
            return l(this.recaptcha, this.auth, "internal-error"), this.recaptcha
        }
    };

function is() {
    let t = null;
    return new Promise(e => {
        if (document.readyState === "complete") {
            e();
            return
        }
        t = () => e(), window.addEventListener("load", t)
    }).catch(e => {
        throw t && window.removeEventListener("load", t), e
    })
}
async function ss(t, e, n) {
    var r;
    if (!t._getRecaptchaConfig()) try {
        await qr(t)
    } catch {
        console.log("Failed to initialize reCAPTCHA Enterprise config. Triggering the reCAPTCHA v2 verification.")
    }
    try {
        let i;
        if (typeof e == "string" ? i = {
                phoneNumber: e
            } : i = e, "session" in i) {
            const s = i.session;
            if ("phoneNumber" in i) {
                l(s.type === "enroll", t, "internal-error");
                const a = {
                    idToken: s.credential,
                    phoneEnrollmentInfo: {
                        phoneNumber: i.phoneNumber,
                        clientType: "CLIENT_TYPE_WEB"
                    }
                };
                return (await C(t, a, "mfaSmsEnrollment", async (c, u) => u.phoneEnrollmentInfo.captchaResponse === Q ? (l(n ? .type === Z, c, "argument-error"), Ct(c, await Fe(c, u, n))) : Ct(c, u), "PHONE_PROVIDER").catch(c => Promise.reject(c))).phoneSessionInfo.sessionInfo
            } else {
                l(s.type === "signin", t, "internal-error");
                const a = ((r = i.multiFactorHint) === null || r === void 0 ? void 0 : r.uid) || i.multiFactorUid;
                l(a, t, "missing-multi-factor-info");
                const o = {
                    mfaPendingCredential: s.credential,
                    mfaEnrollmentId: a,
                    phoneSignInInfo: {
                        clientType: "CLIENT_TYPE_WEB"
                    }
                };
                return (await C(t, o, "mfaSmsSignIn", async (u, d) => d.phoneSignInInfo.captchaResponse === Q ? (l(n ? .type === Z, u, "argument-error"), Lt(u, await Fe(u, d, n))) : Lt(u, d), "PHONE_PROVIDER").catch(u => Promise.reject(u))).phoneResponseInfo.sessionInfo
            }
        } else {
            const s = {
                phoneNumber: i.phoneNumber,
                clientType: "CLIENT_TYPE_WEB"
            };
            return (await C(t, s, "sendVerificationCode", async (o, c) => c.captchaResponse === Q ? (l(n ? .type === Z, o, "argument-error"), kt(o, await Fe(o, c, n))) : kt(o, c), "PHONE_PROVIDER").catch(o => Promise.reject(o))).sessionInfo
        }
    } finally {
        n ? ._reset()
    }
}
async function Fe(t, e, n) {
    l(n.type === Z, t, "argument-error");
    const r = await n.verify();
    l(typeof r == "string", t, "argument-error");
    const i = Object.assign({}, e);
    if ("phoneEnrollmentInfo" in i) {
        const s = i.phoneEnrollmentInfo.phoneNumber,
            a = i.phoneEnrollmentInfo.captchaResponse,
            o = i.phoneEnrollmentInfo.clientType,
            c = i.phoneEnrollmentInfo.recaptchaVersion;
        return Object.assign(i, {
            phoneEnrollmentInfo: {
                phoneNumber: s,
                recaptchaToken: r,
                captchaResponse: a,
                clientType: o,
                recaptchaVersion: c
            }
        }), i
    } else if ("phoneSignInInfo" in i) {
        const s = i.phoneSignInInfo.captchaResponse,
            a = i.phoneSignInInfo.clientType,
            o = i.phoneSignInInfo.recaptchaVersion;
        return Object.assign(i, {
            phoneSignInInfo: {
                recaptchaToken: r,
                captchaResponse: s,
                clientType: a,
                recaptchaVersion: o
            }
        }), i
    } else return Object.assign(i, {
        recaptchaToken: r
    }), i
}
var xn = class me {
    constructor(e) {
        this.providerId = me.PROVIDER_ID, this.auth = g(e)
    }
    verifyPhoneNumber(e, n) {
        return ss(this.auth, e, p(n))
    }
    static credential(e, n) {
        return Nt._fromVerification(e, n)
    }
    static credentialFromResult(e) {
        const n = e;
        return me.credentialFromTaggedObject(n)
    }
    static credentialFromError(e) {
        return me.credentialFromTaggedObject(e.customData || {})
    }
    static credentialFromTaggedObject({
        _tokenResponse: e
    }) {
        if (!e) return null;
        const {
            phoneNumber: n,
            temporaryProof: r
        } = e;
        return n && r ? Nt._fromTokenResponse(n, r) : null
    }
};
xn.PROVIDER_ID = "phone";
xn.PHONE_SIGN_IN_METHOD = "phone";

function D(t, e) {
    return e ? R(e) : (l(t._popupRedirectResolver, t, "argument-error"), t._popupRedirectResolver)
}
var at = class extends we {
    constructor(t) {
        super("custom", "custom"), this.params = t
    }
    _getIdTokenResponse(t) {
        return H(t, this._buildIdpRequest())
    }
    _linkToIdToken(t, e) {
        return H(t, this._buildIdpRequest(e))
    }
    _getReauthenticationResolver(t) {
        return H(t, this._buildIdpRequest())
    }
    _buildIdpRequest(t) {
        const e = {
            requestUri: this.params.requestUri,
            sessionId: this.params.sessionId,
            postBody: this.params.postBody,
            tenantId: this.params.tenantId,
            pendingToken: this.params.pendingToken,
            returnSecureToken: !0,
            returnIdpCredential: !0
        };
        return t && (e.idToken = t), e
    }
};

function as(t) {
    return yn(t.auth, new at(t), t.bypassAuthState)
}

function os(t) {
    const {
        auth: e,
        user: n
    } = t;
    return l(n, e, "internal-error"), Ei(n, new at(t), t.bypassAuthState)
}
async function cs(t) {
    const {
        auth: e,
        user: n
    } = t;
    return l(n, e, "internal-error"), Ii(n, new at(t), t.bypassAuthState)
}
var Wn = class {
        constructor(t, e, n, r, i = !1) {
            this.auth = t, this.resolver = n, this.user = r, this.bypassAuthState = i, this.pendingPromise = null, this.eventManager = null, this.filter = Array.isArray(e) ? e : [e]
        }
        execute() {
            return new Promise(async (t, e) => {
                this.pendingPromise = {
                    resolve: t,
                    reject: e
                };
                try {
                    this.eventManager = await this.resolver._initialize(this.auth), await this.onExecution(), this.eventManager.registerConsumer(this)
                } catch (n) {
                    this.reject(n)
                }
            })
        }
        async onAuthEvent(t) {
            const {
                urlResponse: e,
                sessionId: n,
                postBody: r,
                tenantId: i,
                error: s,
                type: a
            } = t;
            if (s) {
                this.reject(s);
                return
            }
            const o = {
                auth: this.auth,
                requestUri: e,
                sessionId: n,
                tenantId: i || void 0,
                postBody: r || void 0,
                user: this.user,
                bypassAuthState: this.bypassAuthState
            };
            try {
                this.resolve(await this.getIdpTask(a)(o))
            } catch (c) {
                this.reject(c)
            }
        }
        onError(t) {
            this.reject(t)
        }
        getIdpTask(t) {
            switch (t) {
                case "signInViaPopup":
                case "signInViaRedirect":
                    return as;
                case "linkViaPopup":
                case "linkViaRedirect":
                    return cs;
                case "reauthViaPopup":
                case "reauthViaRedirect":
                    return os;
                default:
                    E(this.auth, "internal-error")
            }
        }
        resolve(t) {
            P(this.pendingPromise, "Pending promise was never set"), this.pendingPromise.resolve(t), this.unregisterAndCleanUp()
        }
        reject(t) {
            P(this.pendingPromise, "Pending promise was never set"), this.pendingPromise.reject(t), this.unregisterAndCleanUp()
        }
        unregisterAndCleanUp() {
            this.eventManager && this.eventManager.unregisterConsumer(this), this.pendingPromise = null, this.cleanUp()
        }
    },
    ls = new ne(2e3, 1e4);
async function wa(t, e, n) {
    if (I(t.app)) return Promise.reject(v(t, "operation-not-supported-in-this-environment"));
    const r = g(t);
    G(t, e, O);
    const i = D(r, n);
    return new Ae(r, "signInViaPopup", e, i).executeNotNull()
}
async function ya(t, e, n) {
    const r = p(t);
    if (I(r.auth.app)) return Promise.reject(v(r.auth, "operation-not-supported-in-this-environment"));
    G(r.auth, e, O);
    const i = D(r.auth, n);
    return new Ae(r.auth, "reauthViaPopup", e, i, r).executeNotNull()
}
async function Ra(t, e, n) {
    const r = p(t);
    G(r.auth, e, O);
    const i = D(r.auth, n);
    return new Ae(r.auth, "linkViaPopup", e, i, r).executeNotNull()
}
var Ae = class J extends Wn {
    constructor(e, n, r, i, s) {
        super(e, n, i, s), this.provider = r, this.authWindow = null, this.pollId = null, J.currentPopupAction && J.currentPopupAction.cancel(), J.currentPopupAction = this
    }
    async executeNotNull() {
        const e = await this.execute();
        return l(e, this.auth, "internal-error"), e
    }
    async onExecution() {
        P(this.filter.length === 1, "Popup operations only handle one event");
        const e = Re();
        this.authWindow = await this.resolver._openPopup(this.auth, this.provider, this.filter[0], e), this.authWindow.associatedEvent = e, this.resolver._originValidation(this.auth).catch(n => {
            this.reject(n)
        }), this.resolver._isIframeWebStorageSupported(this.auth, n => {
            n || this.reject(v(this.auth, "web-storage-unsupported"))
        }), this.pollUserCancellation()
    }
    get eventId() {
        var e;
        return ((e = this.authWindow) === null || e === void 0 ? void 0 : e.associatedEvent) || null
    }
    cancel() {
        this.reject(v(this.auth, "cancelled-popup-request"))
    }
    cleanUp() {
        this.authWindow && this.authWindow.close(), this.pollId && window.clearTimeout(this.pollId), this.authWindow = null, this.pollId = null, J.currentPopupAction = null
    }
    pollUserCancellation() {
        const e = () => {
            var n, r;
            if (!((r = (n = this.authWindow) === null || n === void 0 ? void 0 : n.window) === null || r === void 0) && r.closed) {
                this.pollId = window.setTimeout(() => {
                    this.pollId = null, this.reject(v(this.auth, "popup-closed-by-user"))
                }, 8e3);
                return
            }
            this.pollId = window.setTimeout(e, ls.get())
        };
        e()
    }
};
Ae.currentPopupAction = null;
var us = "pendingRedirect",
    _e = new Map,
    ds = class extends Wn {
        constructor(t, e, n = !1) {
            super(t, ["signInViaRedirect", "linkViaRedirect", "reauthViaRedirect", "unknown"], e, void 0, n), this.eventId = null
        }
        async execute() {
            let t = _e.get(this.auth._key());
            if (!t) {
                try {
                    const e = await hs(this.resolver, this.auth) ? await super.execute() : null;
                    t = () => Promise.resolve(e)
                } catch (e) {
                    t = () => Promise.reject(e)
                }
                _e.set(this.auth._key(), t)
            }
            return this.bypassAuthState || _e.set(this.auth._key(), () => Promise.resolve(null)), t()
        }
        async onAuthEvent(t) {
            if (t.type === "signInViaRedirect") return super.onAuthEvent(t);
            if (t.type === "unknown") {
                this.resolve(null);
                return
            }
            if (t.eventId) {
                const e = await this.auth._redirectUserForId(t.eventId);
                if (e) return this.user = e, super.onAuthEvent(t);
                this.resolve(null)
            }
        }
        async onExecution() {}
        cleanUp() {}
    };
async function hs(t, e) {
    const n = jn(e),
        r = Gn(t);
    if (!await r._isAvailable()) return !1;
    const i = await r._get(n) === "true";
    return await r._remove(n), i
}
async function ot(t, e) {
    return Gn(t)._set(jn(e), "true")
}

function fs(t, e) {
    _e.set(t._key(), e)
}

function Gn(t) {
    return R(t._redirectPersistence)
}

function jn(t) {
    return de(us, t.config.apiKey, t.name)
}

function Pa(t, e, n) {
    return ps(t, e, n)
}
async function ps(t, e, n) {
    if (I(t.app)) return Promise.reject(w(t));
    const r = g(t);
    G(t, e, O), await r._initializationPromise;
    const i = D(r, n);
    return await ot(i, r), i._openRedirect(r, e, "signInViaRedirect")
}

function Aa(t, e, n) {
    return ms(t, e, n)
}
async function ms(t, e, n) {
    const r = p(t);
    if (G(r.auth, e, O), I(r.auth.app)) return Promise.reject(w(r.auth));
    await r.auth._initializationPromise;
    const i = D(r.auth, n);
    await ot(i, r.auth);
    const s = await zn(r);
    return i._openRedirect(r.auth, e, "reauthViaRedirect", s)
}

function Sa(t, e, n) {
    return _s(t, e, n)
}
async function _s(t, e, n) {
    const r = p(t);
    G(r.auth, e, O), await r.auth._initializationPromise;
    const i = D(r.auth, n);
    await vi(!1, r, e.providerId), await ot(i, r.auth);
    const s = await zn(r);
    return i._openRedirect(r.auth, e, "linkViaRedirect", s)
}
async function ka(t, e) {
    return await g(t)._initializationPromise, Kn(t, e, !1)
}
async function Kn(t, e, n = !1) {
    if (I(t.app)) return Promise.reject(w(t));
    const r = g(t),
        i = D(r, e),
        s = await new ds(r, i, n).execute();
    return s && !n && (delete s.user._redirectEventId, await r._persistUserIfCurrent(s.user), await r._setRedirectUser(null, e)), s
}
async function zn(t) {
    const e = Re(`${t.uid}:::`);
    return t._redirectEventId = e, await t.auth._setRedirectUser(t), await t.auth._persistUserIfCurrent(t), e
}
var gs = 6e5,
    Is = class {
        constructor(t) {
            this.auth = t, this.cachedEventUids = new Set, this.consumers = new Set, this.queuedRedirectEvent = null, this.hasHandledPotentialRedirect = !1, this.lastProcessedEventTime = Date.now()
        }
        registerConsumer(t) {
            this.consumers.add(t), this.queuedRedirectEvent && this.isEventForConsumer(this.queuedRedirectEvent, t) && (this.sendToConsumer(this.queuedRedirectEvent, t), this.saveEventToCache(this.queuedRedirectEvent), this.queuedRedirectEvent = null)
        }
        unregisterConsumer(t) {
            this.consumers.delete(t)
        }
        onEvent(t) {
            if (this.hasEventBeenHandled(t)) return !1;
            let e = !1;
            return this.consumers.forEach(n => {
                this.isEventForConsumer(t, n) && (e = !0, this.sendToConsumer(t, n), this.saveEventToCache(t))
            }), this.hasHandledPotentialRedirect || !vs(t) || (this.hasHandledPotentialRedirect = !0, e || (this.queuedRedirectEvent = t, e = !0)), e
        }
        sendToConsumer(t, e) {
            var n;
            if (t.error && !Bn(t)) {
                const r = ((n = t.error.code) === null || n === void 0 ? void 0 : n.split("auth/")[1]) || "internal-error";
                e.onError(v(this.auth, r))
            } else e.onAuthEvent(t)
        }
        isEventForConsumer(t, e) {
            const n = e.eventId === null || !!t.eventId && t.eventId === e.eventId;
            return e.filter.includes(t.type) && n
        }
        hasEventBeenHandled(t) {
            return Date.now() - this.lastProcessedEventTime >= gs && this.cachedEventUids.clear(), this.cachedEventUids.has(Mt(t))
        }
        saveEventToCache(t) {
            this.cachedEventUids.add(Mt(t)), this.lastProcessedEventTime = Date.now()
        }
    };

function Mt(t) {
    return [t.type, t.eventId, t.sessionId, t.tenantId].filter(e => e).join("-")
}

function Bn({
    type: t,
    error: e
}) {
    return t === "unknown" && e ? .code === "auth/no-auth-event"
}

function vs(t) {
    switch (t.type) {
        case "signInViaRedirect":
        case "linkViaRedirect":
        case "reauthViaRedirect":
            return !0;
        case "unknown":
            return Bn(t);
        default:
            return !1
    }
}
async function Es(t, e = {}) {
    return m(t, "GET", "/v1/projects", e)
}
var Ts = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,
    ws = /^https?/;
async function ys(t) {
    if (t.config.emulator) return;
    const {
        authorizedDomains: e
    } = await Es(t);
    for (const n of e) try {
        if (Rs(n)) return
    } catch {}
    E(t, "unauthorized-domain")
}

function Rs(t) {
    const e = xe(),
        {
            protocol: n,
            hostname: r
        } = new URL(e);
    if (t.startsWith("chrome-extension://")) {
        const s = new URL(t);
        return s.hostname === "" && r === "" ? n === "chrome-extension:" && t.replace("chrome-extension://", "") === e.replace("chrome-extension://", "") : n === "chrome-extension:" && s.hostname === r
    }
    if (!ws.test(n)) return !1;
    if (Ts.test(t)) return r === t;
    const i = t.replace(/\./g, "\\.");
    return new RegExp("^(.+\\." + i + "|" + i + ")$", "i").test(r)
}
var Ps = new ne(3e4, 6e4);

function Ut() {
    const t = _().___jsl;
    if (t ? .H) {
        for (const e of Object.keys(t.H))
            if (t.H[e].r = t.H[e].r || [], t.H[e].L = t.H[e].L || [], t.H[e].r = [...t.H[e].L], t.CP)
                for (let n = 0; n < t.CP.length; n++) t.CP[n] = null
    }
}

function As(t) {
    return new Promise((e, n) => {
        var r, i, s;

        function a() {
            Ut(), gapi.load("gapi.iframes", {
                callback: () => {
                    e(gapi.iframes.getContext())
                },
                ontimeout: () => {
                    Ut(), n(v(t, "network-request-failed"))
                },
                timeout: Ps.get()
            })
        }
        if (!((i = (r = _().gapi) === null || r === void 0 ? void 0 : r.iframes) === null || i === void 0) && i.Iframe) e(gapi.iframes.getContext());
        else if (!((s = _().gapi) === null || s === void 0) && s.load) a();
        else {
            const o = hn("iframefcb");
            return _()[o] = () => {
                gapi.load ? a() : n(v(t, "network-request-failed"))
            }, it(`${Hr()}?onload=${o}`).catch(c => n(c))
        }
    }).catch(e => {
        throw ge = null, e
    })
}
var ge = null;

function Ss(t) {
    return ge = ge || As(t), ge
}
var ks = new ne(5e3, 15e3),
    Ns = "__/auth/iframe",
    Os = "emulator/auth/iframe",
    Cs = {
        style: {
            position: "absolute",
            top: "-100px",
            width: "1px",
            height: "1px"
        },
        "aria-hidden": "true",
        tabindex: "-1"
    },
    bs = new Map([
        ["identitytoolkit.googleapis.com", "p"],
        ["staging-identitytoolkit.sandbox.googleapis.com", "s"],
        ["test-identitytoolkit.sandbox.googleapis.com", "t"]
    ]);

function Ds(t) {
    const e = t.config;
    l(e.authDomain, t, "auth-domain-config-required");
    const n = e.emulator ? tt(e, Os) : `https://${t.config.authDomain}/${Ns}`,
        r = {
            apiKey: e.apiKey,
            appName: t.name,
            v: te
        },
        i = bs.get(t.config.apiHost);
    i && (r.eid = i);
    const s = t._getFrameworks();
    return s.length && (r.fw = s.join(",")), `${n}?${W(r).slice(1)}`
}
async function Ls(t) {
    const e = await Ss(t),
        n = _().gapi;
    return l(n, t, "internal-error"), e.open({
        where: document.body,
        url: Ds(t),
        messageHandlersFilter: n.iframes.CROSS_ORIGIN_IFRAMES_FILTER,
        attributes: Cs,
        dontclear: !0
    }, r => new Promise(async (i, s) => {
        await r.restyle({
            setHideOnLeave: !1
        });
        const a = v(t, "network-request-failed"),
            o = _().setTimeout(() => {
                s(a)
            }, ks.get());

        function c() {
            _().clearTimeout(o), i(r)
        }
        r.ping(c).then(c, () => {
            s(a)
        })
    }))
}
var Ms = {
        location: "yes",
        resizable: "yes",
        statusbar: "yes",
        toolbar: "no"
    },
    Us = 500,
    Fs = 600,
    Vs = "_blank",
    Hs = "http://localhost",
    Ft = class {
        constructor(t) {
            this.window = t, this.associatedEvent = null
        }
        close() {
            if (this.window) try {
                this.window.close()
            } catch {}
        }
    };

function xs(t, e, n, r = Us, i = Fs) {
    const s = Math.max((window.screen.availHeight - i) / 2, 0).toString(),
        a = Math.max((window.screen.availWidth - r) / 2, 0).toString();
    let o = "";
    const c = Object.assign(Object.assign({}, Ms), {
            width: r.toString(),
            height: i.toString(),
            top: s,
            left: a
        }),
        u = T().toLowerCase();
    n && (o = sn(u) ? Vs : n), nn(u) && (e = e || Hs, c.scrollbars = "yes");
    const d = Object.entries(c).reduce((S, [ae, oe]) => `${S}${ae}=${oe},`, "");
    if (Nr(u) && o !== "_self") return Ws(e || "", o), new Ft(null);
    const f = window.open(e || "", o, d);
    l(f, t, "popup-blocked");
    try {
        f.focus()
    } catch {}
    return new Ft(f)
}

function Ws(t, e) {
    const n = document.createElement("a");
    n.href = t, n.target = e;
    const r = document.createEvent("MouseEvent");
    r.initMouseEvent("click", !0, !0, window, 1, 0, 0, 0, 0, !1, !1, !1, !1, 1, null), n.dispatchEvent(r)
}
var Gs = "__/auth/handler",
    js = "emulator/auth/handler",
    Ks = encodeURIComponent("fac");
async function Vt(t, e, n, r, i, s) {
    l(t.config.authDomain, t, "auth-domain-config-required"), l(t.config.apiKey, t, "invalid-api-key");
    const a = {
        apiKey: t.config.apiKey,
        appName: t.name,
        authType: n,
        redirectUrl: r,
        v: te,
        eventId: i
    };
    if (e instanceof O) {
        e.setDefaultLanguage(t.languageCode), a.providerId = e.providerId || "", Qn(e.getCustomParameters()) || (a.customParameters = JSON.stringify(e.getCustomParameters()));
        for (const [d, f] of Object.entries(s || {})) a[d] = f
    }
    if (e instanceof j) {
        const d = e.getScopes().filter(f => f !== "");
        d.length > 0 && (a.scopes = d.join(","))
    }
    t.tenantId && (a.tid = t.tenantId);
    const o = a;
    for (const d of Object.keys(o)) o[d] === void 0 && delete o[d];
    const c = await t._getAppCheckToken(),
        u = c ? `#${Ks}=${encodeURIComponent(c)}` : "";
    return `${zs(t)}?${W(o).slice(1)}${u}`
}

function zs({
    config: t
}) {
    return t.emulator ? tt(t, js) : `https://${t.authDomain}/${Gs}`
}
var Ve = "webStorageSupport",
    Bs = class {
        constructor() {
            this.eventManagers = {}, this.iframes = {}, this.originValidationPromises = {}, this._redirectPersistence = Ln, this._completeRedirectFn = Kn, this._overrideRedirectResult = fs
        }
        async _openPopup(t, e, n, r) {
            var i;
            return P((i = this.eventManagers[t._key()]) === null || i === void 0 ? void 0 : i.manager, "_initialize() not called before _openPopup()"), xs(t, await Vt(t, e, n, xe(), r), Re())
        }
        async _openRedirect(t, e, n, r) {
            return await this._originValidation(t), Wi(await Vt(t, e, n, xe(), r)), new Promise(() => {})
        }
        _initialize(t) {
            const e = t._key();
            if (this.eventManagers[e]) {
                const {
                    manager: r,
                    promise: i
                } = this.eventManagers[e];
                return r ? Promise.resolve(r) : (P(i, "If manager is not set, promise should be"), i)
            }
            const n = this.initAndGetManager(t);
            return this.eventManagers[e] = {
                promise: n
            }, n.catch(() => {
                delete this.eventManagers[e]
            }), n
        }
        async initAndGetManager(t) {
            const e = await Ls(t),
                n = new Is(t);
            return e.register("authEvent", r => (l(r ? .authEvent, t, "invalid-auth-event"), {
                status: n.onEvent(r.authEvent) ? "ACK" : "ERROR"
            }), gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER), this.eventManagers[t._key()] = {
                manager: n
            }, this.iframes[t._key()] = e, n
        }
        _isIframeWebStorageSupported(t, e) {
            this.iframes[t._key()].send(Ve, {
                type: Ve
            }, n => {
                var r;
                const i = (r = n ? .[0]) === null || r === void 0 ? void 0 : r[Ve];
                i !== void 0 && e(!!i), E(t, "internal-error")
            }, gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER)
        }
        _originValidation(t) {
            const e = t._key();
            return this.originValidationPromises[e] || (this.originValidationPromises[e] = ys(t)), this.originValidationPromises[e]
        }
        get _shouldInitProactively() {
            return un() || rn() || rt()
        }
    },
    $s = Bs,
    $n = class {
        constructor(t) {
            this.factorId = t
        }
        _process(t, e, n) {
            switch (e.type) {
                case "enroll":
                    return this._finalizeEnroll(t, e.credential, n);
                case "signin":
                    return this._finalizeSignIn(t, e.credential);
                default:
                    return y("unexpected MultiFactorSessionType")
            }
        }
    },
    qs = class qn extends $n {
        constructor(e) {
            super("phone"), this.credential = e
        }
        static _fromCredential(e) {
            return new qn(e)
        }
        _finalizeEnroll(e, n, r) {
            return Ni(e, {
                idToken: n,
                displayName: r,
                phoneVerificationInfo: this.credential._makeVerificationRequest()
            })
        }
        _finalizeSignIn(e, n) {
            return Xi(e, {
                mfaPendingCredential: n,
                phoneVerificationInfo: this.credential._makeVerificationRequest()
            })
        }
    },
    Ys = class {
        constructor() {}
        static assertion(t) {
            return qs._fromCredential(t)
        }
    };
Ys.FACTOR_ID = "phone";
var Js = class {
    static assertionForEnrollment(t, e) {
        return Ht._fromSecret(t, e)
    }
    static assertionForSignIn(t, e) {
        return Ht._fromEnrollmentId(t, e)
    }
    static async generateSecret(t) {
        var e;
        const n = t;
        l(typeof((e = n.user) === null || e === void 0 ? void 0 : e.auth) < "u", "internal-error");
        const r = await Oi(n.user.auth, {
            idToken: n.credential,
            totpEnrollmentInfo: {}
        });
        return Xs._fromStartTotpMfaEnrollmentResponse(r, n.user.auth)
    }
};
Js.FACTOR_ID = "totp";
var Ht = class qe extends $n {
        constructor(e, n, r) {
            super("totp"), this.otp = e, this.enrollmentId = n, this.secret = r
        }
        static _fromSecret(e, n) {
            return new qe(n, void 0, e)
        }
        static _fromEnrollmentId(e, n) {
            return new qe(n, e)
        }
        async _finalizeEnroll(e, n, r) {
            return l(typeof this.secret < "u", e, "argument-error"), Ci(e, {
                idToken: n,
                displayName: r,
                totpVerificationInfo: this.secret._makeTotpVerificationInfo(this.otp)
            })
        }
        async _finalizeSignIn(e, n) {
            l(this.enrollmentId !== void 0 && this.otp !== void 0, e, "argument-error");
            const r = {
                verificationCode: this.otp
            };
            return Qi(e, {
                mfaPendingCredential: n,
                mfaEnrollmentId: this.enrollmentId,
                totpVerificationInfo: r
            })
        }
    },
    Xs = class Yn {
        constructor(e, n, r, i, s, a, o) {
            this.sessionInfo = a, this.auth = o, this.secretKey = e, this.hashingAlgorithm = n, this.codeLength = r, this.codeIntervalSeconds = i, this.enrollmentCompletionDeadline = s
        }
        static _fromStartTotpMfaEnrollmentResponse(e, n) {
            return new Yn(e.totpSessionInfo.sharedSecretKey, e.totpSessionInfo.hashingAlgorithm, e.totpSessionInfo.verificationCodeLength, e.totpSessionInfo.periodSec, new Date(e.totpSessionInfo.finalizeEnrollmentTime).toUTCString(), e.totpSessionInfo.sessionInfo, n)
        }
        _makeTotpVerificationInfo(e) {
            return {
                sessionInfo: this.sessionInfo,
                verificationCode: e
            }
        }
        generateQrCodeUrl(e, n) {
            var r;
            let i = !1;
            return (le(e) || le(n)) && (i = !0), i && (le(e) && (e = ((r = this.auth.currentUser) === null || r === void 0 ? void 0 : r.email) || "unknownuser"), le(n) && (n = this.auth.name)), `otpauth://totp/${n}:${e}?secret=${this.secretKey}&issuer=${n}&algorithm=${this.hashingAlgorithm}&digits=${this.codeLength}`
        }
    };

function le(t) {
    return typeof t > "u" || t ? .length === 0
}
var xt = "@firebase/auth",
    Wt = "1.10.8",
    Qs = class {
        constructor(t) {
            this.auth = t, this.internalListeners = new Map
        }
        getUid() {
            var t;
            return this.assertAuthConfigured(), ((t = this.auth.currentUser) === null || t === void 0 ? void 0 : t.uid) || null
        }
        async getToken(t) {
            return this.assertAuthConfigured(), await this.auth._initializationPromise, this.auth.currentUser ? {
                accessToken: await this.auth.currentUser.getIdToken(t)
            } : null
        }
        addAuthTokenListener(t) {
            if (this.assertAuthConfigured(), this.internalListeners.has(t)) return;
            const e = this.auth.onIdTokenChanged(n => {
                t(n ? .stsTokenManager.accessToken || null)
            });
            this.internalListeners.set(t, e), this.updateProactiveRefresh()
        }
        removeAuthTokenListener(t) {
            this.assertAuthConfigured();
            const e = this.internalListeners.get(t);
            e && (this.internalListeners.delete(t), e(), this.updateProactiveRefresh())
        }
        assertAuthConfigured() {
            l(this.auth._initializationPromise, "dependent-sdk-initialized-before-auth")
        }
        updateProactiveRefresh() {
            this.internalListeners.size > 0 ? this.auth._startProactiveRefresh() : this.auth._stopProactiveRefresh()
        }
    };

function Zs(t) {
    switch (t) {
        case "Node":
            return "node";
        case "ReactNative":
            return "rn";
        case "Worker":
            return "webworker";
        case "Cordova":
            return "cordova";
        case "WebExtension":
            return "web-extension";
        default:
            return
    }
}

function ea(t) {
    pt(new _t("auth", (e, {
        options: n
    }) => {
        const r = e.getProvider("app").getImmediate(),
            i = e.getProvider("heartbeat"),
            s = e.getProvider("app-check-internal"),
            {
                apiKey: a,
                authDomain: o
            } = r.options;
        l(a && !a.includes(":"), "invalid-api-key", {
            appName: r.name
        });
        const c = {
                apiKey: a,
                authDomain: o,
                clientPlatform: t,
                apiHost: "identitytoolkit.googleapis.com",
                tokenApiHost: "securetoken.googleapis.com",
                apiScheme: "https",
                sdkClientVersion: dn(t)
            },
            u = new Mr(r, i, s, c);
        return Jr(u, n), u
    }, "PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e, n, r) => {
        e.getProvider("auth-internal").initialize()
    })), pt(new _t("auth-internal", e => (n => new Qs(n))(g(e.getProvider("auth").getImmediate())), "PRIVATE").setInstantiationMode("EXPLICIT")), mt(xt, Wt, Zs(t)), mt(xt, Wt, "esm2017")
}
var ta = jt("authIdTokenMaxAge") || 300,
    Gt = null,
    na = t => async e => {
        const n = e && await e.getIdTokenResult(),
            r = n && (new Date().getTime() - Date.parse(n.issuedAtTime)) / 1e3;
        if (r && r > ta) return;
        const i = n ? .token;
        Gt !== i && (Gt = i, await fetch(t, {
            method: i ? "POST" : "DELETE",
            headers: i ? {
                Authorization: `Bearer ${i}`
            } : {}
        }))
    };

function Na(t = ar()) {
    const e = zt(t, "auth");
    if (e.isInitialized()) return e.getImmediate();
    const n = Yr(t, {
            popupRedirectResolver: $s,
            persistence: [Ji, Ui, Ln]
        }),
        r = jt("authTokenSyncURL");
    if (r && typeof isSecureContext == "boolean" && isSecureContext) {
        const s = new URL(r, location.origin);
        if (location.origin === s.origin) {
            const a = na(s.toString());
            Si(n, a, () => a(n.currentUser)), Ai(n, o => a(o))
        }
    }
    const i = er("auth");
    return i && Xr(n, `http://${i}`), n
}

function ra() {
    var t, e;
    return (e = (t = document.getElementsByTagName("head")) === null || t === void 0 ? void 0 : t[0]) !== null && e !== void 0 ? e : document
}
Ur({
    loadJS(t) {
        return new Promise((e, n) => {
            const r = document.createElement("script");
            r.setAttribute("src", t), r.onload = e, r.onerror = i => {
                const s = v("internal-error");
                s.customData = i, n(s)
            }, r.type = "text/javascript", r.charset = "UTF-8", ra().appendChild(r)
        })
    },
    gapiScript: "https://apis.google.com/js/api.js",
    recaptchaV2Script: "https://www.google.com/recaptcha/api.js",
    recaptchaEnterpriseScript: "https://www.google.com/recaptcha/enterprise.js?render="
});
ea("Browser");
export {
    Ji as A, Pr as B, Xr as C, va as D, wr as E, _a as F, ca as G, la as H, Ai as I, Pa as J, ha as K, dr as L, Ra as M, Sa as N, ka as O, Ea as P, ya as R, ua as S, Na as T, ma as U, fa as V, Ti as W, ga as X, Ia as Y, pa as Z, Tn as _, ye as a, $s as b, vn as c, Nt as d, xn as f, Xs as g, Js as h, St as i, Yr as j, wt as k, x as l, Ta as m, pi as n, In as o, Ys as p, wa as q, we as r, En as s, aa as t, oa as u, Si as v, da as w, Ln as x, Ui as y, Aa as z
};