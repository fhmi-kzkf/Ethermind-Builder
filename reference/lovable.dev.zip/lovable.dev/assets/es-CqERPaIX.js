import {
    o as ba,
    t as X
} from "./rolldown-runtime-CSz5w8F5.js";
import {
    i as ci
} from "./vendor-react-Fx2PtaaM.js";
import {
    n as D
} from "./vendor-tslib-CeDFfI6J.js";
try {
    (function() {
        var a = typeof window < "u" ? window : typeof global < "u" ? global : typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : {},
            i = new a.Error().stack;
        i && (a._sentryDebugIds = a._sentryDebugIds || {}, a._sentryDebugIds[i] = "d0ee67bb-15bb-416d-a5d6-434954bd20d8", a._sentryDebugIdIdentifier = "sentry-dbid-d0ee67bb-15bb-416d-a5d6-434954bd20d8")
    })()
} catch {}
var ri = X(((a, i) => {
        var t = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
        i.exports = t
    })),
    si = X(((a, i) => {
        var t = ri();

        function n() {}

        function o() {}
        o.resetWarningCache = n, i.exports = function() {
            function p(u, z, E, O, $, q) {
                if (q !== t) {
                    var A = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                    throw A.name = "Invariant Violation", A
                }
            }
            p.isRequired = p;

            function c() {
                return p
            }
            var r = {
                array: p,
                bigint: p,
                bool: p,
                func: p,
                number: p,
                object: p,
                string: p,
                symbol: p,
                any: p,
                arrayOf: c,
                element: p,
                elementType: p,
                instanceOf: c,
                node: p,
                objectOf: c,
                oneOf: c,
                oneOfType: c,
                shape: c,
                exact: c,
                checkPropTypes: o,
                resetWarningCache: n
            };
            return r.PropTypes = r, r
        }
    })),
    di = X(((a, i) => {
        i.exports = si()()
    })),
    mi = new Map([
        ["1km", "application/vnd.1000minds.decision-model+xml"],
        ["3dml", "text/vnd.in3d.3dml"],
        ["3ds", "image/x-3ds"],
        ["3g2", "video/3gpp2"],
        ["3gp", "video/3gp"],
        ["3gpp", "video/3gpp"],
        ["3mf", "model/3mf"],
        ["7z", "application/x-7z-compressed"],
        ["7zip", "application/x-7z-compressed"],
        ["123", "application/vnd.lotus-1-2-3"],
        ["aab", "application/x-authorware-bin"],
        ["aac", "audio/x-acc"],
        ["aam", "application/x-authorware-map"],
        ["aas", "application/x-authorware-seg"],
        ["abw", "application/x-abiword"],
        ["ac", "application/vnd.nokia.n-gage.ac+xml"],
        ["ac3", "audio/ac3"],
        ["acc", "application/vnd.americandynamics.acc"],
        ["ace", "application/x-ace-compressed"],
        ["acu", "application/vnd.acucobol"],
        ["acutc", "application/vnd.acucorp"],
        ["adp", "audio/adpcm"],
        ["aep", "application/vnd.audiograph"],
        ["afm", "application/x-font-type1"],
        ["afp", "application/vnd.ibm.modcap"],
        ["ahead", "application/vnd.ahead.space"],
        ["ai", "application/pdf"],
        ["aif", "audio/x-aiff"],
        ["aifc", "audio/x-aiff"],
        ["aiff", "audio/x-aiff"],
        ["air", "application/vnd.adobe.air-application-installer-package+zip"],
        ["ait", "application/vnd.dvb.ait"],
        ["ami", "application/vnd.amiga.ami"],
        ["amr", "audio/amr"],
        ["apk", "application/vnd.android.package-archive"],
        ["apng", "image/apng"],
        ["appcache", "text/cache-manifest"],
        ["application", "application/x-ms-application"],
        ["apr", "application/vnd.lotus-approach"],
        ["arc", "application/x-freearc"],
        ["arj", "application/x-arj"],
        ["asc", "application/pgp-signature"],
        ["asf", "video/x-ms-asf"],
        ["asm", "text/x-asm"],
        ["aso", "application/vnd.accpac.simply.aso"],
        ["asx", "video/x-ms-asf"],
        ["atc", "application/vnd.acucorp"],
        ["atom", "application/atom+xml"],
        ["atomcat", "application/atomcat+xml"],
        ["atomdeleted", "application/atomdeleted+xml"],
        ["atomsvc", "application/atomsvc+xml"],
        ["atx", "application/vnd.antix.game-component"],
        ["au", "audio/x-au"],
        ["avi", "video/x-msvideo"],
        ["avif", "image/avif"],
        ["aw", "application/applixware"],
        ["azf", "application/vnd.airzip.filesecure.azf"],
        ["azs", "application/vnd.airzip.filesecure.azs"],
        ["azv", "image/vnd.airzip.accelerator.azv"],
        ["azw", "application/vnd.amazon.ebook"],
        ["b16", "image/vnd.pco.b16"],
        ["bat", "application/x-msdownload"],
        ["bcpio", "application/x-bcpio"],
        ["bdf", "application/x-font-bdf"],
        ["bdm", "application/vnd.syncml.dm+wbxml"],
        ["bdoc", "application/x-bdoc"],
        ["bed", "application/vnd.realvnc.bed"],
        ["bh2", "application/vnd.fujitsu.oasysprs"],
        ["bin", "application/octet-stream"],
        ["blb", "application/x-blorb"],
        ["blorb", "application/x-blorb"],
        ["bmi", "application/vnd.bmi"],
        ["bmml", "application/vnd.balsamiq.bmml+xml"],
        ["bmp", "image/bmp"],
        ["book", "application/vnd.framemaker"],
        ["box", "application/vnd.previewsystems.box"],
        ["boz", "application/x-bzip2"],
        ["bpk", "application/octet-stream"],
        ["bpmn", "application/octet-stream"],
        ["bsp", "model/vnd.valve.source.compiled-map"],
        ["btif", "image/prs.btif"],
        ["buffer", "application/octet-stream"],
        ["bz", "application/x-bzip"],
        ["bz2", "application/x-bzip2"],
        ["c", "text/x-c"],
        ["c4d", "application/vnd.clonk.c4group"],
        ["c4f", "application/vnd.clonk.c4group"],
        ["c4g", "application/vnd.clonk.c4group"],
        ["c4p", "application/vnd.clonk.c4group"],
        ["c4u", "application/vnd.clonk.c4group"],
        ["c11amc", "application/vnd.cluetrust.cartomobile-config"],
        ["c11amz", "application/vnd.cluetrust.cartomobile-config-pkg"],
        ["cab", "application/vnd.ms-cab-compressed"],
        ["caf", "audio/x-caf"],
        ["cap", "application/vnd.tcpdump.pcap"],
        ["car", "application/vnd.curl.car"],
        ["cat", "application/vnd.ms-pki.seccat"],
        ["cb7", "application/x-cbr"],
        ["cba", "application/x-cbr"],
        ["cbr", "application/x-cbr"],
        ["cbt", "application/x-cbr"],
        ["cbz", "application/x-cbr"],
        ["cc", "text/x-c"],
        ["cco", "application/x-cocoa"],
        ["cct", "application/x-director"],
        ["ccxml", "application/ccxml+xml"],
        ["cdbcmsg", "application/vnd.contact.cmsg"],
        ["cda", "application/x-cdf"],
        ["cdf", "application/x-netcdf"],
        ["cdfx", "application/cdfx+xml"],
        ["cdkey", "application/vnd.mediastation.cdkey"],
        ["cdmia", "application/cdmi-capability"],
        ["cdmic", "application/cdmi-container"],
        ["cdmid", "application/cdmi-domain"],
        ["cdmio", "application/cdmi-object"],
        ["cdmiq", "application/cdmi-queue"],
        ["cdr", "application/cdr"],
        ["cdx", "chemical/x-cdx"],
        ["cdxml", "application/vnd.chemdraw+xml"],
        ["cdy", "application/vnd.cinderella"],
        ["cer", "application/pkix-cert"],
        ["cfs", "application/x-cfs-compressed"],
        ["cgm", "image/cgm"],
        ["chat", "application/x-chat"],
        ["chm", "application/vnd.ms-htmlhelp"],
        ["chrt", "application/vnd.kde.kchart"],
        ["cif", "chemical/x-cif"],
        ["cii", "application/vnd.anser-web-certificate-issue-initiation"],
        ["cil", "application/vnd.ms-artgalry"],
        ["cjs", "application/node"],
        ["cla", "application/vnd.claymore"],
        ["class", "application/octet-stream"],
        ["clkk", "application/vnd.crick.clicker.keyboard"],
        ["clkp", "application/vnd.crick.clicker.palette"],
        ["clkt", "application/vnd.crick.clicker.template"],
        ["clkw", "application/vnd.crick.clicker.wordbank"],
        ["clkx", "application/vnd.crick.clicker"],
        ["clp", "application/x-msclip"],
        ["cmc", "application/vnd.cosmocaller"],
        ["cmdf", "chemical/x-cmdf"],
        ["cml", "chemical/x-cml"],
        ["cmp", "application/vnd.yellowriver-custom-menu"],
        ["cmx", "image/x-cmx"],
        ["cod", "application/vnd.rim.cod"],
        ["coffee", "text/coffeescript"],
        ["com", "application/x-msdownload"],
        ["conf", "text/plain"],
        ["cpio", "application/x-cpio"],
        ["cpp", "text/x-c"],
        ["cpt", "application/mac-compactpro"],
        ["crd", "application/x-mscardfile"],
        ["crl", "application/pkix-crl"],
        ["crt", "application/x-x509-ca-cert"],
        ["crx", "application/x-chrome-extension"],
        ["cryptonote", "application/vnd.rig.cryptonote"],
        ["csh", "application/x-csh"],
        ["csl", "application/vnd.citationstyles.style+xml"],
        ["csml", "chemical/x-csml"],
        ["csp", "application/vnd.commonspace"],
        ["csr", "application/octet-stream"],
        ["css", "text/css"],
        ["cst", "application/x-director"],
        ["csv", "text/csv"],
        ["cu", "application/cu-seeme"],
        ["curl", "text/vnd.curl"],
        ["cww", "application/prs.cww"],
        ["cxt", "application/x-director"],
        ["cxx", "text/x-c"],
        ["dae", "model/vnd.collada+xml"],
        ["daf", "application/vnd.mobius.daf"],
        ["dart", "application/vnd.dart"],
        ["dataless", "application/vnd.fdsn.seed"],
        ["davmount", "application/davmount+xml"],
        ["dbf", "application/vnd.dbf"],
        ["dbk", "application/docbook+xml"],
        ["dcr", "application/x-director"],
        ["dcurl", "text/vnd.curl.dcurl"],
        ["dd2", "application/vnd.oma.dd2+xml"],
        ["ddd", "application/vnd.fujixerox.ddd"],
        ["ddf", "application/vnd.syncml.dmddf+xml"],
        ["dds", "image/vnd.ms-dds"],
        ["deb", "application/x-debian-package"],
        ["def", "text/plain"],
        ["deploy", "application/octet-stream"],
        ["der", "application/x-x509-ca-cert"],
        ["dfac", "application/vnd.dreamfactory"],
        ["dgc", "application/x-dgc-compressed"],
        ["dic", "text/x-c"],
        ["dir", "application/x-director"],
        ["dis", "application/vnd.mobius.dis"],
        ["disposition-notification", "message/disposition-notification"],
        ["dist", "application/octet-stream"],
        ["distz", "application/octet-stream"],
        ["djv", "image/vnd.djvu"],
        ["djvu", "image/vnd.djvu"],
        ["dll", "application/octet-stream"],
        ["dmg", "application/x-apple-diskimage"],
        ["dmn", "application/octet-stream"],
        ["dmp", "application/vnd.tcpdump.pcap"],
        ["dms", "application/octet-stream"],
        ["dna", "application/vnd.dna"],
        ["doc", "application/msword"],
        ["docm", "application/vnd.ms-word.template.macroEnabled.12"],
        ["docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
        ["dot", "application/msword"],
        ["dotm", "application/vnd.ms-word.template.macroEnabled.12"],
        ["dotx", "application/vnd.openxmlformats-officedocument.wordprocessingml.template"],
        ["dp", "application/vnd.osgi.dp"],
        ["dpg", "application/vnd.dpgraph"],
        ["dra", "audio/vnd.dra"],
        ["drle", "image/dicom-rle"],
        ["dsc", "text/prs.lines.tag"],
        ["dssc", "application/dssc+der"],
        ["dtb", "application/x-dtbook+xml"],
        ["dtd", "application/xml-dtd"],
        ["dts", "audio/vnd.dts"],
        ["dtshd", "audio/vnd.dts.hd"],
        ["dump", "application/octet-stream"],
        ["dvb", "video/vnd.dvb.file"],
        ["dvi", "application/x-dvi"],
        ["dwd", "application/atsc-dwd+xml"],
        ["dwf", "model/vnd.dwf"],
        ["dwg", "image/vnd.dwg"],
        ["dxf", "image/vnd.dxf"],
        ["dxp", "application/vnd.spotfire.dxp"],
        ["dxr", "application/x-director"],
        ["ear", "application/java-archive"],
        ["ecelp4800", "audio/vnd.nuera.ecelp4800"],
        ["ecelp7470", "audio/vnd.nuera.ecelp7470"],
        ["ecelp9600", "audio/vnd.nuera.ecelp9600"],
        ["ecma", "application/ecmascript"],
        ["edm", "application/vnd.novadigm.edm"],
        ["edx", "application/vnd.novadigm.edx"],
        ["efif", "application/vnd.picsel"],
        ["ei6", "application/vnd.pg.osasli"],
        ["elc", "application/octet-stream"],
        ["emf", "image/emf"],
        ["eml", "message/rfc822"],
        ["emma", "application/emma+xml"],
        ["emotionml", "application/emotionml+xml"],
        ["emz", "application/x-msmetafile"],
        ["eol", "audio/vnd.digital-winds"],
        ["eot", "application/vnd.ms-fontobject"],
        ["eps", "application/postscript"],
        ["epub", "application/epub+zip"],
        ["es", "application/ecmascript"],
        ["es3", "application/vnd.eszigno3+xml"],
        ["esa", "application/vnd.osgi.subsystem"],
        ["esf", "application/vnd.epson.esf"],
        ["et3", "application/vnd.eszigno3+xml"],
        ["etx", "text/x-setext"],
        ["eva", "application/x-eva"],
        ["evy", "application/x-envoy"],
        ["exe", "application/octet-stream"],
        ["exi", "application/exi"],
        ["exp", "application/express"],
        ["exr", "image/aces"],
        ["ext", "application/vnd.novadigm.ext"],
        ["ez", "application/andrew-inset"],
        ["ez2", "application/vnd.ezpix-album"],
        ["ez3", "application/vnd.ezpix-package"],
        ["f", "text/x-fortran"],
        ["f4v", "video/mp4"],
        ["f77", "text/x-fortran"],
        ["f90", "text/x-fortran"],
        ["fbs", "image/vnd.fastbidsheet"],
        ["fcdt", "application/vnd.adobe.formscentral.fcdt"],
        ["fcs", "application/vnd.isac.fcs"],
        ["fdf", "application/vnd.fdf"],
        ["fdt", "application/fdt+xml"],
        ["fe_launch", "application/vnd.denovo.fcselayout-link"],
        ["fg5", "application/vnd.fujitsu.oasysgp"],
        ["fgd", "application/x-director"],
        ["fh", "image/x-freehand"],
        ["fh4", "image/x-freehand"],
        ["fh5", "image/x-freehand"],
        ["fh7", "image/x-freehand"],
        ["fhc", "image/x-freehand"],
        ["fig", "application/x-xfig"],
        ["fits", "image/fits"],
        ["flac", "audio/x-flac"],
        ["fli", "video/x-fli"],
        ["flo", "application/vnd.micrografx.flo"],
        ["flv", "video/x-flv"],
        ["flw", "application/vnd.kde.kivio"],
        ["flx", "text/vnd.fmi.flexstor"],
        ["fly", "text/vnd.fly"],
        ["fm", "application/vnd.framemaker"],
        ["fnc", "application/vnd.frogans.fnc"],
        ["fo", "application/vnd.software602.filler.form+xml"],
        ["for", "text/x-fortran"],
        ["fpx", "image/vnd.fpx"],
        ["frame", "application/vnd.framemaker"],
        ["fsc", "application/vnd.fsc.weblaunch"],
        ["fst", "image/vnd.fst"],
        ["ftc", "application/vnd.fluxtime.clip"],
        ["fti", "application/vnd.anser-web-funds-transfer-initiation"],
        ["fvt", "video/vnd.fvt"],
        ["fxp", "application/vnd.adobe.fxp"],
        ["fxpl", "application/vnd.adobe.fxp"],
        ["fzs", "application/vnd.fuzzysheet"],
        ["g2w", "application/vnd.geoplan"],
        ["g3", "image/g3fax"],
        ["g3w", "application/vnd.geospace"],
        ["gac", "application/vnd.groove-account"],
        ["gam", "application/x-tads"],
        ["gbr", "application/rpki-ghostbusters"],
        ["gca", "application/x-gca-compressed"],
        ["gdl", "model/vnd.gdl"],
        ["gdoc", "application/vnd.google-apps.document"],
        ["geo", "application/vnd.dynageo"],
        ["geojson", "application/geo+json"],
        ["gex", "application/vnd.geometry-explorer"],
        ["ggb", "application/vnd.geogebra.file"],
        ["ggt", "application/vnd.geogebra.tool"],
        ["ghf", "application/vnd.groove-help"],
        ["gif", "image/gif"],
        ["gim", "application/vnd.groove-identity-message"],
        ["glb", "model/gltf-binary"],
        ["gltf", "model/gltf+json"],
        ["gml", "application/gml+xml"],
        ["gmx", "application/vnd.gmx"],
        ["gnumeric", "application/x-gnumeric"],
        ["gpg", "application/gpg-keys"],
        ["gph", "application/vnd.flographit"],
        ["gpx", "application/gpx+xml"],
        ["gqf", "application/vnd.grafeq"],
        ["gqs", "application/vnd.grafeq"],
        ["gram", "application/srgs"],
        ["gramps", "application/x-gramps-xml"],
        ["gre", "application/vnd.geometry-explorer"],
        ["grv", "application/vnd.groove-injector"],
        ["grxml", "application/srgs+xml"],
        ["gsf", "application/x-font-ghostscript"],
        ["gsheet", "application/vnd.google-apps.spreadsheet"],
        ["gslides", "application/vnd.google-apps.presentation"],
        ["gtar", "application/x-gtar"],
        ["gtm", "application/vnd.groove-tool-message"],
        ["gtw", "model/vnd.gtw"],
        ["gv", "text/vnd.graphviz"],
        ["gxf", "application/gxf"],
        ["gxt", "application/vnd.geonext"],
        ["gz", "application/gzip"],
        ["gzip", "application/gzip"],
        ["h", "text/x-c"],
        ["h261", "video/h261"],
        ["h263", "video/h263"],
        ["h264", "video/h264"],
        ["hal", "application/vnd.hal+xml"],
        ["hbci", "application/vnd.hbci"],
        ["hbs", "text/x-handlebars-template"],
        ["hdd", "application/x-virtualbox-hdd"],
        ["hdf", "application/x-hdf"],
        ["heic", "image/heic"],
        ["heics", "image/heic-sequence"],
        ["heif", "image/heif"],
        ["heifs", "image/heif-sequence"],
        ["hej2", "image/hej2k"],
        ["held", "application/atsc-held+xml"],
        ["hh", "text/x-c"],
        ["hjson", "application/hjson"],
        ["hlp", "application/winhlp"],
        ["hpgl", "application/vnd.hp-hpgl"],
        ["hpid", "application/vnd.hp-hpid"],
        ["hps", "application/vnd.hp-hps"],
        ["hqx", "application/mac-binhex40"],
        ["hsj2", "image/hsj2"],
        ["htc", "text/x-component"],
        ["htke", "application/vnd.kenameaapp"],
        ["htm", "text/html"],
        ["html", "text/html"],
        ["hvd", "application/vnd.yamaha.hv-dic"],
        ["hvp", "application/vnd.yamaha.hv-voice"],
        ["hvs", "application/vnd.yamaha.hv-script"],
        ["i2g", "application/vnd.intergeo"],
        ["icc", "application/vnd.iccprofile"],
        ["ice", "x-conference/x-cooltalk"],
        ["icm", "application/vnd.iccprofile"],
        ["ico", "image/x-icon"],
        ["ics", "text/calendar"],
        ["ief", "image/ief"],
        ["ifb", "text/calendar"],
        ["ifm", "application/vnd.shana.informed.formdata"],
        ["iges", "model/iges"],
        ["igl", "application/vnd.igloader"],
        ["igm", "application/vnd.insors.igm"],
        ["igs", "model/iges"],
        ["igx", "application/vnd.micrografx.igx"],
        ["iif", "application/vnd.shana.informed.interchange"],
        ["img", "application/octet-stream"],
        ["imp", "application/vnd.accpac.simply.imp"],
        ["ims", "application/vnd.ms-ims"],
        ["in", "text/plain"],
        ["ini", "text/plain"],
        ["ink", "application/inkml+xml"],
        ["inkml", "application/inkml+xml"],
        ["install", "application/x-install-instructions"],
        ["iota", "application/vnd.astraea-software.iota"],
        ["ipfix", "application/ipfix"],
        ["ipk", "application/vnd.shana.informed.package"],
        ["irm", "application/vnd.ibm.rights-management"],
        ["irp", "application/vnd.irepository.package+xml"],
        ["iso", "application/x-iso9660-image"],
        ["itp", "application/vnd.shana.informed.formtemplate"],
        ["its", "application/its+xml"],
        ["ivp", "application/vnd.immervision-ivp"],
        ["ivu", "application/vnd.immervision-ivu"],
        ["jad", "text/vnd.sun.j2me.app-descriptor"],
        ["jade", "text/jade"],
        ["jam", "application/vnd.jam"],
        ["jar", "application/java-archive"],
        ["jardiff", "application/x-java-archive-diff"],
        ["java", "text/x-java-source"],
        ["jhc", "image/jphc"],
        ["jisp", "application/vnd.jisp"],
        ["jls", "image/jls"],
        ["jlt", "application/vnd.hp-jlyt"],
        ["jng", "image/x-jng"],
        ["jnlp", "application/x-java-jnlp-file"],
        ["joda", "application/vnd.joost.joda-archive"],
        ["jp2", "image/jp2"],
        ["jpe", "image/jpeg"],
        ["jpeg", "image/jpeg"],
        ["jpf", "image/jpx"],
        ["jpg", "image/jpeg"],
        ["jpg2", "image/jp2"],
        ["jpgm", "video/jpm"],
        ["jpgv", "video/jpeg"],
        ["jph", "image/jph"],
        ["jpm", "video/jpm"],
        ["jpx", "image/jpx"],
        ["js", "application/javascript"],
        ["json", "application/json"],
        ["json5", "application/json5"],
        ["jsonld", "application/ld+json"],
        ["jsonl", "application/jsonl"],
        ["jsonml", "application/jsonml+json"],
        ["jsx", "text/jsx"],
        ["jxr", "image/jxr"],
        ["jxra", "image/jxra"],
        ["jxrs", "image/jxrs"],
        ["jxs", "image/jxs"],
        ["jxsc", "image/jxsc"],
        ["jxsi", "image/jxsi"],
        ["jxss", "image/jxss"],
        ["kar", "audio/midi"],
        ["karbon", "application/vnd.kde.karbon"],
        ["kdb", "application/octet-stream"],
        ["kdbx", "application/x-keepass2"],
        ["key", "application/x-iwork-keynote-sffkey"],
        ["kfo", "application/vnd.kde.kformula"],
        ["kia", "application/vnd.kidspiration"],
        ["kml", "application/vnd.google-earth.kml+xml"],
        ["kmz", "application/vnd.google-earth.kmz"],
        ["kne", "application/vnd.kinar"],
        ["knp", "application/vnd.kinar"],
        ["kon", "application/vnd.kde.kontour"],
        ["kpr", "application/vnd.kde.kpresenter"],
        ["kpt", "application/vnd.kde.kpresenter"],
        ["kpxx", "application/vnd.ds-keypoint"],
        ["ksp", "application/vnd.kde.kspread"],
        ["ktr", "application/vnd.kahootz"],
        ["ktx", "image/ktx"],
        ["ktx2", "image/ktx2"],
        ["ktz", "application/vnd.kahootz"],
        ["kwd", "application/vnd.kde.kword"],
        ["kwt", "application/vnd.kde.kword"],
        ["lasxml", "application/vnd.las.las+xml"],
        ["latex", "application/x-latex"],
        ["lbd", "application/vnd.llamagraphics.life-balance.desktop"],
        ["lbe", "application/vnd.llamagraphics.life-balance.exchange+xml"],
        ["les", "application/vnd.hhe.lesson-player"],
        ["less", "text/less"],
        ["lgr", "application/lgr+xml"],
        ["lha", "application/octet-stream"],
        ["link66", "application/vnd.route66.link66+xml"],
        ["list", "text/plain"],
        ["list3820", "application/vnd.ibm.modcap"],
        ["listafp", "application/vnd.ibm.modcap"],
        ["litcoffee", "text/coffeescript"],
        ["lnk", "application/x-ms-shortcut"],
        ["log", "text/plain"],
        ["lostxml", "application/lost+xml"],
        ["lrf", "application/octet-stream"],
        ["lrm", "application/vnd.ms-lrm"],
        ["ltf", "application/vnd.frogans.ltf"],
        ["lua", "text/x-lua"],
        ["luac", "application/x-lua-bytecode"],
        ["lvp", "audio/vnd.lucent.voice"],
        ["lwp", "application/vnd.lotus-wordpro"],
        ["lzh", "application/octet-stream"],
        ["m1v", "video/mpeg"],
        ["m2a", "audio/mpeg"],
        ["m2v", "video/mpeg"],
        ["m3a", "audio/mpeg"],
        ["m3u", "text/plain"],
        ["m3u8", "application/vnd.apple.mpegurl"],
        ["m4a", "audio/x-m4a"],
        ["m4p", "application/mp4"],
        ["m4s", "video/iso.segment"],
        ["m4u", "application/vnd.mpegurl"],
        ["m4v", "video/x-m4v"],
        ["m13", "application/x-msmediaview"],
        ["m14", "application/x-msmediaview"],
        ["m21", "application/mp21"],
        ["ma", "application/mathematica"],
        ["mads", "application/mads+xml"],
        ["maei", "application/mmt-aei+xml"],
        ["mag", "application/vnd.ecowin.chart"],
        ["maker", "application/vnd.framemaker"],
        ["man", "text/troff"],
        ["manifest", "text/cache-manifest"],
        ["map", "application/json"],
        ["mar", "application/octet-stream"],
        ["markdown", "text/markdown"],
        ["mathml", "application/mathml+xml"],
        ["mb", "application/mathematica"],
        ["mbk", "application/vnd.mobius.mbk"],
        ["mbox", "application/mbox"],
        ["mc1", "application/vnd.medcalcdata"],
        ["mcd", "application/vnd.mcd"],
        ["mcurl", "text/vnd.curl.mcurl"],
        ["md", "text/markdown"],
        ["mdb", "application/x-msaccess"],
        ["mdi", "image/vnd.ms-modi"],
        ["mdx", "text/mdx"],
        ["me", "text/troff"],
        ["mesh", "model/mesh"],
        ["meta4", "application/metalink4+xml"],
        ["metalink", "application/metalink+xml"],
        ["mets", "application/mets+xml"],
        ["mfm", "application/vnd.mfmp"],
        ["mft", "application/rpki-manifest"],
        ["mgp", "application/vnd.osgeo.mapguide.package"],
        ["mgz", "application/vnd.proteus.magazine"],
        ["mid", "audio/midi"],
        ["midi", "audio/midi"],
        ["mie", "application/x-mie"],
        ["mif", "application/vnd.mif"],
        ["mime", "message/rfc822"],
        ["mj2", "video/mj2"],
        ["mjp2", "video/mj2"],
        ["mjs", "application/javascript"],
        ["mk3d", "video/x-matroska"],
        ["mka", "audio/x-matroska"],
        ["mkd", "text/x-markdown"],
        ["mks", "video/x-matroska"],
        ["mkv", "video/x-matroska"],
        ["mlp", "application/vnd.dolby.mlp"],
        ["mmd", "application/vnd.chipnuts.karaoke-mmd"],
        ["mmf", "application/vnd.smaf"],
        ["mml", "text/mathml"],
        ["mmr", "image/vnd.fujixerox.edmics-mmr"],
        ["mng", "video/x-mng"],
        ["mny", "application/x-msmoney"],
        ["mobi", "application/x-mobipocket-ebook"],
        ["mods", "application/mods+xml"],
        ["mov", "video/quicktime"],
        ["movie", "video/x-sgi-movie"],
        ["mp2", "audio/mpeg"],
        ["mp2a", "audio/mpeg"],
        ["mp3", "audio/mpeg"],
        ["mp4", "video/mp4"],
        ["mp4a", "audio/mp4"],
        ["mp4s", "application/mp4"],
        ["mp4v", "video/mp4"],
        ["mp21", "application/mp21"],
        ["mpc", "application/vnd.mophun.certificate"],
        ["mpd", "application/dash+xml"],
        ["mpe", "video/mpeg"],
        ["mpeg", "video/mpeg"],
        ["mpg", "video/mpeg"],
        ["mpg4", "video/mp4"],
        ["mpga", "audio/mpeg"],
        ["mpkg", "application/vnd.apple.installer+xml"],
        ["mpm", "application/vnd.blueice.multipass"],
        ["mpn", "application/vnd.mophun.application"],
        ["mpp", "application/vnd.ms-project"],
        ["mpt", "application/vnd.ms-project"],
        ["mpy", "application/vnd.ibm.minipay"],
        ["mqy", "application/vnd.mobius.mqy"],
        ["mrc", "application/marc"],
        ["mrcx", "application/marcxml+xml"],
        ["ms", "text/troff"],
        ["mscml", "application/mediaservercontrol+xml"],
        ["mseed", "application/vnd.fdsn.mseed"],
        ["mseq", "application/vnd.mseq"],
        ["msf", "application/vnd.epson.msf"],
        ["msg", "application/vnd.ms-outlook"],
        ["msh", "model/mesh"],
        ["msi", "application/x-msdownload"],
        ["msl", "application/vnd.mobius.msl"],
        ["msm", "application/octet-stream"],
        ["msp", "application/octet-stream"],
        ["msty", "application/vnd.muvee.style"],
        ["mtl", "model/mtl"],
        ["mts", "model/vnd.mts"],
        ["mus", "application/vnd.musician"],
        ["musd", "application/mmt-usd+xml"],
        ["musicxml", "application/vnd.recordare.musicxml+xml"],
        ["mvb", "application/x-msmediaview"],
        ["mvt", "application/vnd.mapbox-vector-tile"],
        ["mwf", "application/vnd.mfer"],
        ["mxf", "application/mxf"],
        ["mxl", "application/vnd.recordare.musicxml"],
        ["mxmf", "audio/mobile-xmf"],
        ["mxml", "application/xv+xml"],
        ["mxs", "application/vnd.triscape.mxs"],
        ["mxu", "video/vnd.mpegurl"],
        ["n-gage", "application/vnd.nokia.n-gage.symbian.install"],
        ["n3", "text/n3"],
        ["nb", "application/mathematica"],
        ["nbp", "application/vnd.wolfram.player"],
        ["nc", "application/x-netcdf"],
        ["ncx", "application/x-dtbncx+xml"],
        ["nfo", "text/x-nfo"],
        ["ngdat", "application/vnd.nokia.n-gage.data"],
        ["nitf", "application/vnd.nitf"],
        ["nlu", "application/vnd.neurolanguage.nlu"],
        ["nml", "application/vnd.enliven"],
        ["nnd", "application/vnd.noblenet-directory"],
        ["nns", "application/vnd.noblenet-sealer"],
        ["nnw", "application/vnd.noblenet-web"],
        ["npx", "image/vnd.net-fpx"],
        ["nq", "application/n-quads"],
        ["nsc", "application/x-conference"],
        ["nsf", "application/vnd.lotus-notes"],
        ["nt", "application/n-triples"],
        ["ntf", "application/vnd.nitf"],
        ["numbers", "application/x-iwork-numbers-sffnumbers"],
        ["nzb", "application/x-nzb"],
        ["oa2", "application/vnd.fujitsu.oasys2"],
        ["oa3", "application/vnd.fujitsu.oasys3"],
        ["oas", "application/vnd.fujitsu.oasys"],
        ["obd", "application/x-msbinder"],
        ["obgx", "application/vnd.openblox.game+xml"],
        ["obj", "model/obj"],
        ["oda", "application/oda"],
        ["odb", "application/vnd.oasis.opendocument.database"],
        ["odc", "application/vnd.oasis.opendocument.chart"],
        ["odf", "application/vnd.oasis.opendocument.formula"],
        ["odft", "application/vnd.oasis.opendocument.formula-template"],
        ["odg", "application/vnd.oasis.opendocument.graphics"],
        ["odi", "application/vnd.oasis.opendocument.image"],
        ["odm", "application/vnd.oasis.opendocument.text-master"],
        ["odp", "application/vnd.oasis.opendocument.presentation"],
        ["ods", "application/vnd.oasis.opendocument.spreadsheet"],
        ["odt", "application/vnd.oasis.opendocument.text"],
        ["oga", "audio/ogg"],
        ["ogex", "model/vnd.opengex"],
        ["ogg", "audio/ogg"],
        ["ogv", "video/ogg"],
        ["ogx", "application/ogg"],
        ["omdoc", "application/omdoc+xml"],
        ["onepkg", "application/onenote"],
        ["onetmp", "application/onenote"],
        ["onetoc", "application/onenote"],
        ["onetoc2", "application/onenote"],
        ["opf", "application/oebps-package+xml"],
        ["opml", "text/x-opml"],
        ["oprc", "application/vnd.palm"],
        ["opus", "audio/ogg"],
        ["org", "text/x-org"],
        ["osf", "application/vnd.yamaha.openscoreformat"],
        ["osfpvg", "application/vnd.yamaha.openscoreformat.osfpvg+xml"],
        ["osm", "application/vnd.openstreetmap.data+xml"],
        ["otc", "application/vnd.oasis.opendocument.chart-template"],
        ["otf", "font/otf"],
        ["otg", "application/vnd.oasis.opendocument.graphics-template"],
        ["oth", "application/vnd.oasis.opendocument.text-web"],
        ["oti", "application/vnd.oasis.opendocument.image-template"],
        ["otp", "application/vnd.oasis.opendocument.presentation-template"],
        ["ots", "application/vnd.oasis.opendocument.spreadsheet-template"],
        ["ott", "application/vnd.oasis.opendocument.text-template"],
        ["ova", "application/x-virtualbox-ova"],
        ["ovf", "application/x-virtualbox-ovf"],
        ["owl", "application/rdf+xml"],
        ["oxps", "application/oxps"],
        ["oxt", "application/vnd.openofficeorg.extension"],
        ["p", "text/x-pascal"],
        ["p7a", "application/x-pkcs7-signature"],
        ["p7b", "application/x-pkcs7-certificates"],
        ["p7c", "application/pkcs7-mime"],
        ["p7m", "application/pkcs7-mime"],
        ["p7r", "application/x-pkcs7-certreqresp"],
        ["p7s", "application/pkcs7-signature"],
        ["p8", "application/pkcs8"],
        ["p10", "application/x-pkcs10"],
        ["p12", "application/x-pkcs12"],
        ["pac", "application/x-ns-proxy-autoconfig"],
        ["pages", "application/x-iwork-pages-sffpages"],
        ["pas", "text/x-pascal"],
        ["paw", "application/vnd.pawaafile"],
        ["pbd", "application/vnd.powerbuilder6"],
        ["pbm", "image/x-portable-bitmap"],
        ["pcap", "application/vnd.tcpdump.pcap"],
        ["pcf", "application/x-font-pcf"],
        ["pcl", "application/vnd.hp-pcl"],
        ["pclxl", "application/vnd.hp-pclxl"],
        ["pct", "image/x-pict"],
        ["pcurl", "application/vnd.curl.pcurl"],
        ["pcx", "image/x-pcx"],
        ["pdb", "application/x-pilot"],
        ["pde", "text/x-processing"],
        ["pdf", "application/pdf"],
        ["pem", "application/x-x509-user-cert"],
        ["pfa", "application/x-font-type1"],
        ["pfb", "application/x-font-type1"],
        ["pfm", "application/x-font-type1"],
        ["pfr", "application/font-tdpfr"],
        ["pfx", "application/x-pkcs12"],
        ["pgm", "image/x-portable-graymap"],
        ["pgn", "application/x-chess-pgn"],
        ["pgp", "application/pgp"],
        ["php", "application/x-httpd-php"],
        ["php3", "application/x-httpd-php"],
        ["php4", "application/x-httpd-php"],
        ["phps", "application/x-httpd-php-source"],
        ["phtml", "application/x-httpd-php"],
        ["pic", "image/x-pict"],
        ["pkg", "application/octet-stream"],
        ["pki", "application/pkixcmp"],
        ["pkipath", "application/pkix-pkipath"],
        ["pkpass", "application/vnd.apple.pkpass"],
        ["pl", "application/x-perl"],
        ["plb", "application/vnd.3gpp.pic-bw-large"],
        ["plc", "application/vnd.mobius.plc"],
        ["plf", "application/vnd.pocketlearn"],
        ["pls", "application/pls+xml"],
        ["pm", "application/x-perl"],
        ["pml", "application/vnd.ctc-posml"],
        ["png", "image/png"],
        ["pnm", "image/x-portable-anymap"],
        ["portpkg", "application/vnd.macports.portpkg"],
        ["pot", "application/vnd.ms-powerpoint"],
        ["potm", "application/vnd.ms-powerpoint.presentation.macroEnabled.12"],
        ["potx", "application/vnd.openxmlformats-officedocument.presentationml.template"],
        ["ppa", "application/vnd.ms-powerpoint"],
        ["ppam", "application/vnd.ms-powerpoint.addin.macroEnabled.12"],
        ["ppd", "application/vnd.cups-ppd"],
        ["ppm", "image/x-portable-pixmap"],
        ["pps", "application/vnd.ms-powerpoint"],
        ["ppsm", "application/vnd.ms-powerpoint.slideshow.macroEnabled.12"],
        ["ppsx", "application/vnd.openxmlformats-officedocument.presentationml.slideshow"],
        ["ppt", "application/powerpoint"],
        ["pptm", "application/vnd.ms-powerpoint.presentation.macroEnabled.12"],
        ["pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"],
        ["pqa", "application/vnd.palm"],
        ["prc", "application/x-pilot"],
        ["pre", "application/vnd.lotus-freelance"],
        ["prf", "application/pics-rules"],
        ["provx", "application/provenance+xml"],
        ["ps", "application/postscript"],
        ["psb", "application/vnd.3gpp.pic-bw-small"],
        ["psd", "application/x-photoshop"],
        ["psf", "application/x-font-linux-psf"],
        ["pskcxml", "application/pskc+xml"],
        ["pti", "image/prs.pti"],
        ["ptid", "application/vnd.pvi.ptid1"],
        ["pub", "application/x-mspublisher"],
        ["pvb", "application/vnd.3gpp.pic-bw-var"],
        ["pwn", "application/vnd.3m.post-it-notes"],
        ["pya", "audio/vnd.ms-playready.media.pya"],
        ["pyv", "video/vnd.ms-playready.media.pyv"],
        ["qam", "application/vnd.epson.quickanime"],
        ["qbo", "application/vnd.intu.qbo"],
        ["qfx", "application/vnd.intu.qfx"],
        ["qps", "application/vnd.publishare-delta-tree"],
        ["qt", "video/quicktime"],
        ["qwd", "application/vnd.quark.quarkxpress"],
        ["qwt", "application/vnd.quark.quarkxpress"],
        ["qxb", "application/vnd.quark.quarkxpress"],
        ["qxd", "application/vnd.quark.quarkxpress"],
        ["qxl", "application/vnd.quark.quarkxpress"],
        ["qxt", "application/vnd.quark.quarkxpress"],
        ["ra", "audio/x-realaudio"],
        ["ram", "audio/x-pn-realaudio"],
        ["raml", "application/raml+yaml"],
        ["rapd", "application/route-apd+xml"],
        ["rar", "application/x-rar"],
        ["ras", "image/x-cmu-raster"],
        ["rcprofile", "application/vnd.ipunplugged.rcprofile"],
        ["rdf", "application/rdf+xml"],
        ["rdz", "application/vnd.data-vision.rdz"],
        ["relo", "application/p2p-overlay+xml"],
        ["rep", "application/vnd.businessobjects"],
        ["res", "application/x-dtbresource+xml"],
        ["rgb", "image/x-rgb"],
        ["rif", "application/reginfo+xml"],
        ["rip", "audio/vnd.rip"],
        ["ris", "application/x-research-info-systems"],
        ["rl", "application/resource-lists+xml"],
        ["rlc", "image/vnd.fujixerox.edmics-rlc"],
        ["rld", "application/resource-lists-diff+xml"],
        ["rm", "audio/x-pn-realaudio"],
        ["rmi", "audio/midi"],
        ["rmp", "audio/x-pn-realaudio-plugin"],
        ["rms", "application/vnd.jcp.javame.midlet-rms"],
        ["rmvb", "application/vnd.rn-realmedia-vbr"],
        ["rnc", "application/relax-ng-compact-syntax"],
        ["rng", "application/xml"],
        ["roa", "application/rpki-roa"],
        ["roff", "text/troff"],
        ["rp9", "application/vnd.cloanto.rp9"],
        ["rpm", "audio/x-pn-realaudio-plugin"],
        ["rpss", "application/vnd.nokia.radio-presets"],
        ["rpst", "application/vnd.nokia.radio-preset"],
        ["rq", "application/sparql-query"],
        ["rs", "application/rls-services+xml"],
        ["rsa", "application/x-pkcs7"],
        ["rsat", "application/atsc-rsat+xml"],
        ["rsd", "application/rsd+xml"],
        ["rsheet", "application/urc-ressheet+xml"],
        ["rss", "application/rss+xml"],
        ["rtf", "text/rtf"],
        ["rtx", "text/richtext"],
        ["run", "application/x-makeself"],
        ["rusd", "application/route-usd+xml"],
        ["rv", "video/vnd.rn-realvideo"],
        ["s", "text/x-asm"],
        ["s3m", "audio/s3m"],
        ["saf", "application/vnd.yamaha.smaf-audio"],
        ["sass", "text/x-sass"],
        ["sbml", "application/sbml+xml"],
        ["sc", "application/vnd.ibm.secure-container"],
        ["scd", "application/x-msschedule"],
        ["scm", "application/vnd.lotus-screencam"],
        ["scq", "application/scvp-cv-request"],
        ["scs", "application/scvp-cv-response"],
        ["scss", "text/x-scss"],
        ["scurl", "text/vnd.curl.scurl"],
        ["sda", "application/vnd.stardivision.draw"],
        ["sdc", "application/vnd.stardivision.calc"],
        ["sdd", "application/vnd.stardivision.impress"],
        ["sdkd", "application/vnd.solent.sdkm+xml"],
        ["sdkm", "application/vnd.solent.sdkm+xml"],
        ["sdp", "application/sdp"],
        ["sdw", "application/vnd.stardivision.writer"],
        ["sea", "application/octet-stream"],
        ["see", "application/vnd.seemail"],
        ["seed", "application/vnd.fdsn.seed"],
        ["sema", "application/vnd.sema"],
        ["semd", "application/vnd.semd"],
        ["semf", "application/vnd.semf"],
        ["senmlx", "application/senml+xml"],
        ["sensmlx", "application/sensml+xml"],
        ["ser", "application/java-serialized-object"],
        ["setpay", "application/set-payment-initiation"],
        ["setreg", "application/set-registration-initiation"],
        ["sfd-hdstx", "application/vnd.hydrostatix.sof-data"],
        ["sfs", "application/vnd.spotfire.sfs"],
        ["sfv", "text/x-sfv"],
        ["sgi", "image/sgi"],
        ["sgl", "application/vnd.stardivision.writer-global"],
        ["sgm", "text/sgml"],
        ["sgml", "text/sgml"],
        ["sh", "application/x-sh"],
        ["shar", "application/x-shar"],
        ["shex", "text/shex"],
        ["shf", "application/shf+xml"],
        ["shtml", "text/html"],
        ["sid", "image/x-mrsid-image"],
        ["sieve", "application/sieve"],
        ["sig", "application/pgp-signature"],
        ["sil", "audio/silk"],
        ["silo", "model/mesh"],
        ["sis", "application/vnd.symbian.install"],
        ["sisx", "application/vnd.symbian.install"],
        ["sit", "application/x-stuffit"],
        ["sitx", "application/x-stuffitx"],
        ["siv", "application/sieve"],
        ["skd", "application/vnd.koan"],
        ["skm", "application/vnd.koan"],
        ["skp", "application/vnd.koan"],
        ["skt", "application/vnd.koan"],
        ["sldm", "application/vnd.ms-powerpoint.slide.macroenabled.12"],
        ["sldx", "application/vnd.openxmlformats-officedocument.presentationml.slide"],
        ["slim", "text/slim"],
        ["slm", "text/slim"],
        ["sls", "application/route-s-tsid+xml"],
        ["slt", "application/vnd.epson.salt"],
        ["sm", "application/vnd.stepmania.stepchart"],
        ["smf", "application/vnd.stardivision.math"],
        ["smi", "application/smil"],
        ["smil", "application/smil"],
        ["smv", "video/x-smv"],
        ["smzip", "application/vnd.stepmania.package"],
        ["snd", "audio/basic"],
        ["snf", "application/x-font-snf"],
        ["so", "application/octet-stream"],
        ["spc", "application/x-pkcs7-certificates"],
        ["spdx", "text/spdx"],
        ["spf", "application/vnd.yamaha.smaf-phrase"],
        ["spl", "application/x-futuresplash"],
        ["spot", "text/vnd.in3d.spot"],
        ["spp", "application/scvp-vp-response"],
        ["spq", "application/scvp-vp-request"],
        ["spx", "audio/ogg"],
        ["sql", "application/x-sql"],
        ["src", "application/x-wais-source"],
        ["srt", "application/x-subrip"],
        ["sru", "application/sru+xml"],
        ["srx", "application/sparql-results+xml"],
        ["ssdl", "application/ssdl+xml"],
        ["sse", "application/vnd.kodak-descriptor"],
        ["ssf", "application/vnd.epson.ssf"],
        ["ssml", "application/ssml+xml"],
        ["sst", "application/octet-stream"],
        ["st", "application/vnd.sailingtracker.track"],
        ["stc", "application/vnd.sun.xml.calc.template"],
        ["std", "application/vnd.sun.xml.draw.template"],
        ["stf", "application/vnd.wt.stf"],
        ["sti", "application/vnd.sun.xml.impress.template"],
        ["stk", "application/hyperstudio"],
        ["stl", "model/stl"],
        ["stpx", "model/step+xml"],
        ["stpxz", "model/step-xml+zip"],
        ["stpz", "model/step+zip"],
        ["str", "application/vnd.pg.format"],
        ["stw", "application/vnd.sun.xml.writer.template"],
        ["styl", "text/stylus"],
        ["stylus", "text/stylus"],
        ["sub", "text/vnd.dvb.subtitle"],
        ["sus", "application/vnd.sus-calendar"],
        ["susp", "application/vnd.sus-calendar"],
        ["sv4cpio", "application/x-sv4cpio"],
        ["sv4crc", "application/x-sv4crc"],
        ["svc", "application/vnd.dvb.service"],
        ["svd", "application/vnd.svd"],
        ["svg", "image/svg+xml"],
        ["svgz", "image/svg+xml"],
        ["swa", "application/x-director"],
        ["swf", "application/x-shockwave-flash"],
        ["swi", "application/vnd.aristanetworks.swi"],
        ["swidtag", "application/swid+xml"],
        ["sxc", "application/vnd.sun.xml.calc"],
        ["sxd", "application/vnd.sun.xml.draw"],
        ["sxg", "application/vnd.sun.xml.writer.global"],
        ["sxi", "application/vnd.sun.xml.impress"],
        ["sxm", "application/vnd.sun.xml.math"],
        ["sxw", "application/vnd.sun.xml.writer"],
        ["t", "text/troff"],
        ["t3", "application/x-t3vm-image"],
        ["t38", "image/t38"],
        ["taglet", "application/vnd.mynfc"],
        ["tao", "application/vnd.tao.intent-module-archive"],
        ["tap", "image/vnd.tencent.tap"],
        ["tar", "application/x-tar"],
        ["tcap", "application/vnd.3gpp2.tcap"],
        ["tcl", "application/x-tcl"],
        ["td", "application/urc-targetdesc+xml"],
        ["teacher", "application/vnd.smart.teacher"],
        ["tei", "application/tei+xml"],
        ["teicorpus", "application/tei+xml"],
        ["tex", "application/x-tex"],
        ["texi", "application/x-texinfo"],
        ["texinfo", "application/x-texinfo"],
        ["text", "text/plain"],
        ["tfi", "application/thraud+xml"],
        ["tfm", "application/x-tex-tfm"],
        ["tfx", "image/tiff-fx"],
        ["tga", "image/x-tga"],
        ["tgz", "application/x-tar"],
        ["thmx", "application/vnd.ms-officetheme"],
        ["tif", "image/tiff"],
        ["tiff", "image/tiff"],
        ["tk", "application/x-tcl"],
        ["tmo", "application/vnd.tmobile-livetv"],
        ["toml", "application/toml"],
        ["torrent", "application/x-bittorrent"],
        ["tpl", "application/vnd.groove-tool-template"],
        ["tpt", "application/vnd.trid.tpt"],
        ["tr", "text/troff"],
        ["tra", "application/vnd.trueapp"],
        ["trig", "application/trig"],
        ["trm", "application/x-msterminal"],
        ["ts", "video/mp2t"],
        ["tsd", "application/timestamped-data"],
        ["tsv", "text/tab-separated-values"],
        ["ttc", "font/collection"],
        ["ttf", "font/ttf"],
        ["ttl", "text/turtle"],
        ["ttml", "application/ttml+xml"],
        ["twd", "application/vnd.simtech-mindmapper"],
        ["twds", "application/vnd.simtech-mindmapper"],
        ["txd", "application/vnd.genomatix.tuxedo"],
        ["txf", "application/vnd.mobius.txf"],
        ["txt", "text/plain"],
        ["u8dsn", "message/global-delivery-status"],
        ["u8hdr", "message/global-headers"],
        ["u8mdn", "message/global-disposition-notification"],
        ["u8msg", "message/global"],
        ["u32", "application/x-authorware-bin"],
        ["ubj", "application/ubjson"],
        ["udeb", "application/x-debian-package"],
        ["ufd", "application/vnd.ufdl"],
        ["ufdl", "application/vnd.ufdl"],
        ["ulx", "application/x-glulx"],
        ["umj", "application/vnd.umajin"],
        ["unityweb", "application/vnd.unity"],
        ["uoml", "application/vnd.uoml+xml"],
        ["uri", "text/uri-list"],
        ["uris", "text/uri-list"],
        ["urls", "text/uri-list"],
        ["usdz", "model/vnd.usdz+zip"],
        ["ustar", "application/x-ustar"],
        ["utz", "application/vnd.uiq.theme"],
        ["uu", "text/x-uuencode"],
        ["uva", "audio/vnd.dece.audio"],
        ["uvd", "application/vnd.dece.data"],
        ["uvf", "application/vnd.dece.data"],
        ["uvg", "image/vnd.dece.graphic"],
        ["uvh", "video/vnd.dece.hd"],
        ["uvi", "image/vnd.dece.graphic"],
        ["uvm", "video/vnd.dece.mobile"],
        ["uvp", "video/vnd.dece.pd"],
        ["uvs", "video/vnd.dece.sd"],
        ["uvt", "application/vnd.dece.ttml+xml"],
        ["uvu", "video/vnd.uvvu.mp4"],
        ["uvv", "video/vnd.dece.video"],
        ["uvva", "audio/vnd.dece.audio"],
        ["uvvd", "application/vnd.dece.data"],
        ["uvvf", "application/vnd.dece.data"],
        ["uvvg", "image/vnd.dece.graphic"],
        ["uvvh", "video/vnd.dece.hd"],
        ["uvvi", "image/vnd.dece.graphic"],
        ["uvvm", "video/vnd.dece.mobile"],
        ["uvvp", "video/vnd.dece.pd"],
        ["uvvs", "video/vnd.dece.sd"],
        ["uvvt", "application/vnd.dece.ttml+xml"],
        ["uvvu", "video/vnd.uvvu.mp4"],
        ["uvvv", "video/vnd.dece.video"],
        ["uvvx", "application/vnd.dece.unspecified"],
        ["uvvz", "application/vnd.dece.zip"],
        ["uvx", "application/vnd.dece.unspecified"],
        ["uvz", "application/vnd.dece.zip"],
        ["vbox", "application/x-virtualbox-vbox"],
        ["vbox-extpack", "application/x-virtualbox-vbox-extpack"],
        ["vcard", "text/vcard"],
        ["vcd", "application/x-cdlink"],
        ["vcf", "text/x-vcard"],
        ["vcg", "application/vnd.groove-vcard"],
        ["vcs", "text/x-vcalendar"],
        ["vcx", "application/vnd.vcx"],
        ["vdi", "application/x-virtualbox-vdi"],
        ["vds", "model/vnd.sap.vds"],
        ["vhd", "application/x-virtualbox-vhd"],
        ["vis", "application/vnd.visionary"],
        ["viv", "video/vnd.vivo"],
        ["vlc", "application/videolan"],
        ["vmdk", "application/x-virtualbox-vmdk"],
        ["vob", "video/x-ms-vob"],
        ["vor", "application/vnd.stardivision.writer"],
        ["vox", "application/x-authorware-bin"],
        ["vrml", "model/vrml"],
        ["vsd", "application/vnd.visio"],
        ["vsf", "application/vnd.vsf"],
        ["vss", "application/vnd.visio"],
        ["vst", "application/vnd.visio"],
        ["vsw", "application/vnd.visio"],
        ["vtf", "image/vnd.valve.source.texture"],
        ["vtt", "text/vtt"],
        ["vtu", "model/vnd.vtu"],
        ["vxml", "application/voicexml+xml"],
        ["w3d", "application/x-director"],
        ["wad", "application/x-doom"],
        ["wadl", "application/vnd.sun.wadl+xml"],
        ["war", "application/java-archive"],
        ["wasm", "application/wasm"],
        ["wav", "audio/x-wav"],
        ["wax", "audio/x-ms-wax"],
        ["wbmp", "image/vnd.wap.wbmp"],
        ["wbs", "application/vnd.criticaltools.wbs+xml"],
        ["wbxml", "application/wbxml"],
        ["wcm", "application/vnd.ms-works"],
        ["wdb", "application/vnd.ms-works"],
        ["wdp", "image/vnd.ms-photo"],
        ["weba", "audio/webm"],
        ["webapp", "application/x-web-app-manifest+json"],
        ["webm", "video/webm"],
        ["webmanifest", "application/manifest+json"],
        ["webp", "image/webp"],
        ["wg", "application/vnd.pmi.widget"],
        ["wgt", "application/widget"],
        ["wks", "application/vnd.ms-works"],
        ["wm", "video/x-ms-wm"],
        ["wma", "audio/x-ms-wma"],
        ["wmd", "application/x-ms-wmd"],
        ["wmf", "image/wmf"],
        ["wml", "text/vnd.wap.wml"],
        ["wmlc", "application/wmlc"],
        ["wmls", "text/vnd.wap.wmlscript"],
        ["wmlsc", "application/vnd.wap.wmlscriptc"],
        ["wmv", "video/x-ms-wmv"],
        ["wmx", "video/x-ms-wmx"],
        ["wmz", "application/x-msmetafile"],
        ["woff", "font/woff"],
        ["woff2", "font/woff2"],
        ["word", "application/msword"],
        ["wpd", "application/vnd.wordperfect"],
        ["wpl", "application/vnd.ms-wpl"],
        ["wps", "application/vnd.ms-works"],
        ["wqd", "application/vnd.wqd"],
        ["wri", "application/x-mswrite"],
        ["wrl", "model/vrml"],
        ["wsc", "message/vnd.wfa.wsc"],
        ["wsdl", "application/wsdl+xml"],
        ["wspolicy", "application/wspolicy+xml"],
        ["wtb", "application/vnd.webturbo"],
        ["wvx", "video/x-ms-wvx"],
        ["x3d", "model/x3d+xml"],
        ["x3db", "model/x3d+fastinfoset"],
        ["x3dbz", "model/x3d+binary"],
        ["x3dv", "model/x3d-vrml"],
        ["x3dvz", "model/x3d+vrml"],
        ["x3dz", "model/x3d+xml"],
        ["x32", "application/x-authorware-bin"],
        ["x_b", "model/vnd.parasolid.transmit.binary"],
        ["x_t", "model/vnd.parasolid.transmit.text"],
        ["xaml", "application/xaml+xml"],
        ["xap", "application/x-silverlight-app"],
        ["xar", "application/vnd.xara"],
        ["xav", "application/xcap-att+xml"],
        ["xbap", "application/x-ms-xbap"],
        ["xbd", "application/vnd.fujixerox.docuworks.binder"],
        ["xbm", "image/x-xbitmap"],
        ["xca", "application/xcap-caps+xml"],
        ["xcs", "application/calendar+xml"],
        ["xdf", "application/xcap-diff+xml"],
        ["xdm", "application/vnd.syncml.dm+xml"],
        ["xdp", "application/vnd.adobe.xdp+xml"],
        ["xdssc", "application/dssc+xml"],
        ["xdw", "application/vnd.fujixerox.docuworks"],
        ["xel", "application/xcap-el+xml"],
        ["xenc", "application/xenc+xml"],
        ["xer", "application/patch-ops-error+xml"],
        ["xfdf", "application/vnd.adobe.xfdf"],
        ["xfdl", "application/vnd.xfdl"],
        ["xht", "application/xhtml+xml"],
        ["xhtml", "application/xhtml+xml"],
        ["xhvml", "application/xv+xml"],
        ["xif", "image/vnd.xiff"],
        ["xl", "application/excel"],
        ["xla", "application/vnd.ms-excel"],
        ["xlam", "application/vnd.ms-excel.addin.macroEnabled.12"],
        ["xlc", "application/vnd.ms-excel"],
        ["xlf", "application/xliff+xml"],
        ["xlm", "application/vnd.ms-excel"],
        ["xls", "application/vnd.ms-excel"],
        ["xlsb", "application/vnd.ms-excel.sheet.binary.macroEnabled.12"],
        ["xlsm", "application/vnd.ms-excel.sheet.macroEnabled.12"],
        ["xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
        ["xlt", "application/vnd.ms-excel"],
        ["xltm", "application/vnd.ms-excel.template.macroEnabled.12"],
        ["xltx", "application/vnd.openxmlformats-officedocument.spreadsheetml.template"],
        ["xlw", "application/vnd.ms-excel"],
        ["xm", "audio/xm"],
        ["xml", "application/xml"],
        ["xns", "application/xcap-ns+xml"],
        ["xo", "application/vnd.olpc-sugar"],
        ["xop", "application/xop+xml"],
        ["xpi", "application/x-xpinstall"],
        ["xpl", "application/xproc+xml"],
        ["xpm", "image/x-xpixmap"],
        ["xpr", "application/vnd.is-xpr"],
        ["xps", "application/vnd.ms-xpsdocument"],
        ["xpw", "application/vnd.intercon.formnet"],
        ["xpx", "application/vnd.intercon.formnet"],
        ["xsd", "application/xml"],
        ["xsl", "application/xml"],
        ["xslt", "application/xslt+xml"],
        ["xsm", "application/vnd.syncml+xml"],
        ["xspf", "application/xspf+xml"],
        ["xul", "application/vnd.mozilla.xul+xml"],
        ["xvm", "application/xv+xml"],
        ["xvml", "application/xv+xml"],
        ["xwd", "image/x-xwindowdump"],
        ["xyz", "chemical/x-xyz"],
        ["xz", "application/x-xz"],
        ["yaml", "text/yaml"],
        ["yang", "application/yang"],
        ["yin", "application/yin+xml"],
        ["yml", "text/yaml"],
        ["ymp", "text/x-suse-ymp"],
        ["z", "application/x-compress"],
        ["z1", "application/x-zmachine"],
        ["z2", "application/x-zmachine"],
        ["z3", "application/x-zmachine"],
        ["z4", "application/x-zmachine"],
        ["z5", "application/x-zmachine"],
        ["z6", "application/x-zmachine"],
        ["z7", "application/x-zmachine"],
        ["z8", "application/x-zmachine"],
        ["zaz", "application/vnd.zzazz.deck+xml"],
        ["zip", "application/zip"],
        ["zir", "application/vnd.zul"],
        ["zirz", "application/vnd.zul"],
        ["zmm", "application/vnd.handheld-entertainment+xml"],
        ["zsh", "text/x-scriptzsh"]
    ]);

function C(a, i, t) {
    const n = ui(a),
        {
            webkitRelativePath: o
        } = a,
        p = typeof i == "string" ? i : typeof o == "string" && o.length > 0 ? o : `./${a.name}`;
    return typeof n.path != "string" && Ia(n, "path", p), t !== void 0 && Object.defineProperty(n, "handle", {
        value: t,
        writable: !1,
        configurable: !1,
        enumerable: !0
    }), Ia(n, "relativePath", p), n
}

function ui(a) {
    const {
        name: i
    } = a;
    if (i && i.lastIndexOf(".") !== -1 && !a.type) {
        const t = i.split(".").pop().toLowerCase(),
            n = mi.get(t);
        n && Object.defineProperty(a, "type", {
            value: n,
            writable: !1,
            configurable: !1,
            enumerable: !0
        })
    }
    return a
}

function Ia(a, i, t) {
    Object.defineProperty(a, i, {
        value: t,
        writable: !1,
        configurable: !1,
        enumerable: !0
    })
}
var vi = [".DS_Store", "Thumbs.db"];

function fi(a) {
    return D(this, void 0, void 0, function*() {
        return J(a) && xi(a.dataTransfer) ? yi(a.dataTransfer, a.type) : gi(a) ? bi(a) : Array.isArray(a) && a.every(i => "getFile" in i && typeof i.getFile == "function") ? hi(a) : []
    })
}

function xi(a) {
    return J(a)
}

function gi(a) {
    return J(a) && J(a.target)
}

function J(a) {
    return typeof a == "object" && a !== null
}

function bi(a) {
    return ua(a.target.files).map(i => C(i))
}

function hi(a) {
    return D(this, void 0, void 0, function*() {
        return (yield Promise.all(a.map(i => i.getFile()))).map(i => C(i))
    })
}

function yi(a, i) {
    return D(this, void 0, void 0, function*() {
        if (a.items) {
            const t = ua(a.items).filter(n => n.kind === "file");
            return i !== "drop" ? t : Ra(Ya(yield Promise.all(t.map(wi))))
        }
        return Ra(ua(a.files).map(t => C(t)))
    })
}

function Ra(a) {
    return a.filter(i => vi.indexOf(i.name) === -1)
}

function ua(a) {
    if (a === null) return [];
    const i = [];
    for (let t = 0; t < a.length; t++) {
        const n = a[t];
        i.push(n)
    }
    return i
}

function wi(a) {
    if (typeof a.webkitGetAsEntry != "function") return La(a);
    const i = a.webkitGetAsEntry();
    return i && i.isDirectory ? Ga(i) : La(a, i)
}

function Ya(a) {
    return a.reduce((i, t) => [...i, ...Array.isArray(t) ? Ya(t) : [t]], [])
}

function La(a, i) {
    return D(this, void 0, void 0, function*() {
        var t;
        if (globalThis.isSecureContext && typeof a.getAsFileSystemHandle == "function") {
            const o = yield a.getAsFileSystemHandle();
            if (o === null) throw new Error(`${a} is not a File`);
            if (o !== void 0) {
                const p = yield o.getFile();
                return p.handle = o, C(p)
            }
        }
        const n = a.getAsFile();
        if (!n) throw new Error(`${a} is not a File`);
        return C(n, (t = i ? .fullPath) !== null && t !== void 0 ? t : void 0)
    })
}

function ki(a) {
    return D(this, void 0, void 0, function*() {
        return a.isDirectory ? Ga(a) : ji(a)
    })
}

function Ga(a) {
    const i = a.createReader();
    return new Promise((t, n) => {
        const o = [];

        function p() {
            i.readEntries(c => D(this, void 0, void 0, function*() {
                if (c.length) {
                    const r = Promise.all(c.map(ki));
                    o.push(r), p()
                } else try {
                    t(yield Promise.all(o))
                } catch (r) {
                    n(r)
                }
            }), c => {
                n(c)
            })
        }
        p()
    })
}

function ji(a) {
    return D(this, void 0, void 0, function*() {
        return new Promise((i, t) => {
            a.file(n => {
                i(C(n, a.fullPath))
            }, n => {
                t(n)
            })
        })
    })
}
var Di = X((a => {
        a.__esModule = !0, a.default = function(i, t) {
            if (i && t) {
                var n = Array.isArray(t) ? t : t.split(",");
                if (n.length === 0) return !0;
                var o = i.name || "",
                    p = (i.type || "").toLowerCase(),
                    c = p.replace(/\/.*$/, "");
                return n.some(function(r) {
                    var u = r.trim().toLowerCase();
                    return u.charAt(0) === "." ? o.toLowerCase().endsWith(u) : u.endsWith("/*") ? c === u.replace(/\/.*$/, "") : p === u
                })
            }
            return !0
        }
    })),
    s = ba(ci()),
    d = ba(di()),
    da = ba(Di());

function Ma(a) {
    return Oi(a) || Ei(a) || Va(a) || zi()
}

function zi() {
    throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function Ei(a) {
    if (typeof Symbol < "u" && a[Symbol.iterator] != null || a["@@iterator"] != null) return Array.from(a)
}

function Oi(a) {
    if (Array.isArray(a)) return va(a)
}

function $a(a, i) {
    var t = Object.keys(a);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(a);
        i && (n = n.filter(function(o) {
            return Object.getOwnPropertyDescriptor(a, o).enumerable
        })), t.push.apply(t, n)
    }
    return t
}

function Ka(a) {
    for (var i = 1; i < arguments.length; i++) {
        var t = arguments[i] != null ? arguments[i] : {};
        i % 2 ? $a(Object(t), !0).forEach(function(n) {
            Ja(a, n, t[n])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(a, Object.getOwnPropertyDescriptors(t)) : $a(Object(t)).forEach(function(n) {
            Object.defineProperty(a, n, Object.getOwnPropertyDescriptor(t, n))
        })
    }
    return a
}

function Ja(a, i, t) {
    return i in a ? Object.defineProperty(a, i, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[i] = t, a
}

function M(a, i) {
    return Fi(a) || _i(a, i) || Va(a, i) || Ai()
}

function Ai() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function Va(a, i) {
    if (a) {
        if (typeof a == "string") return va(a, i);
        var t = Object.prototype.toString.call(a).slice(8, -1);
        if (t === "Object" && a.constructor && (t = a.constructor.name), t === "Map" || t === "Set") return Array.from(a);
        if (t === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)) return va(a, i)
    }
}

function va(a, i) {
    (i == null || i > a.length) && (i = a.length);
    for (var t = 0, n = new Array(i); t < i; t++) n[t] = a[t];
    return n
}

function _i(a, i) {
    var t = a == null ? null : typeof Symbol < "u" && a[Symbol.iterator] || a["@@iterator"];
    if (t != null) {
        var n = [],
            o = !0,
            p = !1,
            c, r;
        try {
            for (t = t.call(a); !(o = (c = t.next()).done) && (n.push(c.value), !(i && n.length === i)); o = !0);
        } catch (u) {
            p = !0, r = u
        } finally {
            try {
                !o && t.return != null && t.return()
            } finally {
                if (p) throw r
            }
        }
        return n
    }
}

function Fi(a) {
    if (Array.isArray(a)) return a
}
var Pi = typeof da.default == "function" ? da.default : da.default.default,
    Ti = "file-invalid-type",
    Ci = "file-too-large",
    qi = "file-too-small",
    Si = "too-many-files",
    Ii = function() {
        var i = (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "").split(","),
            t = i.length > 1 ? "one of ".concat(i.join(", ")) : i[0];
        return {
            code: Ti,
            message: "File type must be ".concat(t)
        }
    },
    Wa = function(i) {
        return {
            code: Ci,
            message: "File is larger than ".concat(i, " ").concat(i === 1 ? "byte" : "bytes")
        }
    },
    Ha = function(i) {
        return {
            code: qi,
            message: "File is smaller than ".concat(i, " ").concat(i === 1 ? "byte" : "bytes")
        }
    },
    Ri = {
        code: Si,
        message: "Too many files"
    };

function Qa(a, i) {
    var t = a.type === "application/x-moz-file" || Pi(a, i);
    return [t, t ? null : Ii(i)]
}

function Xa(a, i, t) {
    if (j(a.size))
        if (j(i) && j(t)) {
            if (a.size > t) return [!1, Wa(t)];
            if (a.size < i) return [!1, Ha(i)]
        } else {
            if (j(i) && a.size < i) return [!1, Ha(i)];
            if (j(t) && a.size > t) return [!1, Wa(t)]
        }
    return [!0, null]
}

function j(a) {
    return a != null
}

function Li(a) {
    var i = a.files,
        t = a.accept,
        n = a.minSize,
        o = a.maxSize,
        p = a.multiple,
        c = a.maxFiles,
        r = a.validator;
    return !p && i.length > 1 || p && c >= 1 && i.length > c ? !1 : i.every(function(u) {
        var z = M(Qa(u, t), 1)[0],
            E = M(Xa(u, n, o), 1)[0],
            O = r ? r(u) : null;
        return z && E && !O
    })
}

function V(a) {
    return typeof a.isPropagationStopped == "function" ? a.isPropagationStopped() : typeof a.cancelBubble < "u" ? a.cancelBubble : !1
}

function G(a) {
    return a.dataTransfer ? Array.prototype.some.call(a.dataTransfer.types, function(i) {
        return i === "Files" || i === "application/x-moz-file"
    }) : !!a.target && !!a.target.files
}

function Ba(a) {
    a.preventDefault()
}

function Mi(a) {
    return a.indexOf("MSIE") !== -1 || a.indexOf("Trident/") !== -1
}

function $i(a) {
    return a.indexOf("Edge/") !== -1
}

function Ki() {
    var a = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : window.navigator.userAgent;
    return Mi(a) || $i(a)
}

function y() {
    for (var a = arguments.length, i = new Array(a), t = 0; t < a; t++) i[t] = arguments[t];
    return function(n) {
        for (var o = arguments.length, p = new Array(o > 1 ? o - 1 : 0), c = 1; c < o; c++) p[c - 1] = arguments[c];
        return i.some(function(r) {
            return !V(n) && r && r.apply(void 0, [n].concat(p)), V(n)
        })
    }
}

function Wi() {
    return "showOpenFilePicker" in window
}

function Hi(a) {
    return j(a) ? [{
        description: "Files",
        accept: Object.entries(a).filter(function(i) {
            var t = M(i, 2),
                n = t[0],
                o = t[1],
                p = !0;
            return Za(n) || (console.warn('Skipped "'.concat(n, '" because it is not a valid MIME type. Check https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types for a list of valid MIME types.')), p = !1), (!Array.isArray(o) || !o.every(ai)) && (console.warn('Skipped "'.concat(n, '" because an invalid file extension was provided.')), p = !1), p
        }).reduce(function(i, t) {
            var n = M(t, 2),
                o = n[0],
                p = n[1];
            return Ka(Ka({}, i), {}, Ja({}, o, p))
        }, {})
    }] : a
}

function Bi(a) {
    if (j(a)) return Object.entries(a).reduce(function(i, t) {
        var n = M(t, 2),
            o = n[0],
            p = n[1];
        return [].concat(Ma(i), [o], Ma(p))
    }, []).filter(function(i) {
        return Za(i) || ai(i)
    }).join(",")
}

function Ni(a) {
    return a instanceof DOMException && (a.name === "AbortError" || a.code === a.ABORT_ERR)
}

function Ui(a) {
    return a instanceof DOMException && (a.name === "SecurityError" || a.code === a.SECURITY_ERR)
}

function Za(a) {
    return a === "audio/*" || a === "video/*" || a === "image/*" || a === "text/*" || a === "application/*" || /\w+\/[-+.\w]+/g.test(a)
}

function ai(a) {
    return /^.*\.[\w]+$/.test(a)
}
var Yi = ["children"],
    Gi = ["open"],
    Ji = ["refKey", "role", "onKeyDown", "onFocus", "onBlur", "onClick", "onDragEnter", "onDragOver", "onDragLeave", "onDrop"],
    Vi = ["refKey", "onChange", "onClick"];

function Qi(a) {
    return at(a) || Zi(a) || ii(a) || Xi()
}

function Xi() {
    throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function Zi(a) {
    if (typeof Symbol < "u" && a[Symbol.iterator] != null || a["@@iterator"] != null) return Array.from(a)
}

function at(a) {
    if (Array.isArray(a)) return fa(a)
}

function ma(a, i) {
    return nt(a) || tt(a, i) || ii(a, i) || it()
}

function it() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}

function ii(a, i) {
    if (a) {
        if (typeof a == "string") return fa(a, i);
        var t = Object.prototype.toString.call(a).slice(8, -1);
        if (t === "Object" && a.constructor && (t = a.constructor.name), t === "Map" || t === "Set") return Array.from(a);
        if (t === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)) return fa(a, i)
    }
}

function fa(a, i) {
    (i == null || i > a.length) && (i = a.length);
    for (var t = 0, n = new Array(i); t < i; t++) n[t] = a[t];
    return n
}

function tt(a, i) {
    var t = a == null ? null : typeof Symbol < "u" && a[Symbol.iterator] || a["@@iterator"];
    if (t != null) {
        var n = [],
            o = !0,
            p = !1,
            c, r;
        try {
            for (t = t.call(a); !(o = (c = t.next()).done) && (n.push(c.value), !(i && n.length === i)); o = !0);
        } catch (u) {
            p = !0, r = u
        } finally {
            try {
                !o && t.return != null && t.return()
            } finally {
                if (p) throw r
            }
        }
        return n
    }
}

function nt(a) {
    if (Array.isArray(a)) return a
}

function Na(a, i) {
    var t = Object.keys(a);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(a);
        i && (n = n.filter(function(o) {
            return Object.getOwnPropertyDescriptor(a, o).enumerable
        })), t.push.apply(t, n)
    }
    return t
}

function m(a) {
    for (var i = 1; i < arguments.length; i++) {
        var t = arguments[i] != null ? arguments[i] : {};
        i % 2 ? Na(Object(t), !0).forEach(function(n) {
            xa(a, n, t[n])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(a, Object.getOwnPropertyDescriptors(t)) : Na(Object(t)).forEach(function(n) {
            Object.defineProperty(a, n, Object.getOwnPropertyDescriptor(t, n))
        })
    }
    return a
}

function xa(a, i, t) {
    return i in a ? Object.defineProperty(a, i, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[i] = t, a
}

function Q(a, i) {
    if (a == null) return {};
    var t = et(a, i),
        n, o;
    if (Object.getOwnPropertySymbols) {
        var p = Object.getOwnPropertySymbols(a);
        for (o = 0; o < p.length; o++) n = p[o], !(i.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(a, n) && (t[n] = a[n])
    }
    return t
}

function et(a, i) {
    if (a == null) return {};
    var t = {},
        n = Object.keys(a),
        o, p;
    for (p = 0; p < n.length; p++) o = n[p], !(i.indexOf(o) >= 0) && (t[o] = a[o]);
    return t
}
var ha = (0, s.forwardRef)(function(a, i) {
    var t = a.children,
        n = pt(Q(a, Yi)),
        o = n.open,
        p = Q(n, Gi);
    return (0, s.useImperativeHandle)(i, function() {
        return {
            open: o
        }
    }, [o]), s.createElement(s.Fragment, null, t(m(m({}, p), {}, {
        open: o
    })))
});
ha.displayName = "Dropzone";
var ti = {
    disabled: !1,
    getFilesFromEvent: fi,
    maxSize: 1 / 0,
    minSize: 0,
    multiple: !0,
    maxFiles: 0,
    preventDropOnDocument: !0,
    noClick: !1,
    noKeyboard: !1,
    noDrag: !1,
    noDragEventsBubbling: !1,
    validator: null,
    useFsAccessApi: !1,
    autoFocus: !1
};
ha.defaultProps = ti;
ha.propTypes = {
    children: d.default.func,
    accept: d.default.objectOf(d.default.arrayOf(d.default.string)),
    multiple: d.default.bool,
    preventDropOnDocument: d.default.bool,
    noClick: d.default.bool,
    noKeyboard: d.default.bool,
    noDrag: d.default.bool,
    noDragEventsBubbling: d.default.bool,
    minSize: d.default.number,
    maxSize: d.default.number,
    maxFiles: d.default.number,
    disabled: d.default.bool,
    getFilesFromEvent: d.default.func,
    onFileDialogCancel: d.default.func,
    onFileDialogOpen: d.default.func,
    useFsAccessApi: d.default.bool,
    autoFocus: d.default.bool,
    onDragEnter: d.default.func,
    onDragLeave: d.default.func,
    onDragOver: d.default.func,
    onDrop: d.default.func,
    onDropAccepted: d.default.func,
    onDropRejected: d.default.func,
    onError: d.default.func,
    validator: d.default.func
};
var ga = {
    isFocused: !1,
    isFileDialogActive: !1,
    isDragActive: !1,
    isDragAccept: !1,
    isDragReject: !1,
    acceptedFiles: [],
    fileRejections: []
};

function pt() {
    var a = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
        i = m(m({}, ti), a),
        t = i.accept,
        n = i.disabled,
        o = i.getFilesFromEvent,
        p = i.maxSize,
        c = i.minSize,
        r = i.multiple,
        u = i.maxFiles,
        z = i.onDragEnter,
        E = i.onDragLeave,
        O = i.onDragOver,
        $ = i.onDrop,
        q = i.onDropAccepted,
        A = i.onDropRejected,
        Z = i.onFileDialogCancel,
        aa = i.onFileDialogOpen,
        ya = i.useFsAccessApi,
        wa = i.autoFocus,
        ia = i.preventDropOnDocument,
        ka = i.noClick,
        ta = i.noKeyboard,
        ja = i.noDrag,
        w = i.noDragEventsBubbling,
        na = i.onError,
        S = i.validator,
        I = (0, s.useMemo)(function() {
            return Bi(t)
        }, [t]),
        Da = (0, s.useMemo)(function() {
            return Hi(t)
        }, [t]),
        ea = (0, s.useMemo)(function() {
            return typeof aa == "function" ? aa : Ua
        }, [aa]),
        K = (0, s.useMemo)(function() {
            return typeof Z == "function" ? Z : Ua
        }, [Z]),
        x = (0, s.useRef)(null),
        b = (0, s.useRef)(null),
        za = ma((0, s.useReducer)(ot, ga), 2),
        pa = za[0],
        g = za[1],
        ni = pa.isFocused,
        Ea = pa.isFileDialogActive,
        W = (0, s.useRef)(typeof window < "u" && window.isSecureContext && ya && Wi()),
        Oa = function() {
            !W.current && Ea && setTimeout(function() {
                b.current && (b.current.files.length || (g({
                    type: "closeDialog"
                }), K()))
            }, 300)
        };
    (0, s.useEffect)(function() {
        return window.addEventListener("focus", Oa, !1),
            function() {
                window.removeEventListener("focus", Oa, !1)
            }
    }, [b, Ea, K, W]);
    var _ = (0, s.useRef)([]),
        Aa = function(l) {
            x.current && x.current.contains(l.target) || (l.preventDefault(), _.current = [])
        };
    (0, s.useEffect)(function() {
        return ia && (document.addEventListener("dragover", Ba, !1), document.addEventListener("drop", Aa, !1)),
            function() {
                ia && (document.removeEventListener("dragover", Ba), document.removeEventListener("drop", Aa))
            }
    }, [x, ia]), (0, s.useEffect)(function() {
        return !n && wa && x.current && x.current.focus(),
            function() {}
    }, [x, wa, n]);
    var k = (0, s.useCallback)(function(e) {
            na ? na(e) : console.error(e)
        }, [na]),
        _a = (0, s.useCallback)(function(e) {
            e.preventDefault(), e.persist(), U(e), _.current = [].concat(Qi(_.current), [e.target]), G(e) && Promise.resolve(o(e)).then(function(l) {
                if (!(V(e) && !w)) {
                    var v = l.length,
                        f = v > 0 && Li({
                            files: l,
                            accept: I,
                            minSize: c,
                            maxSize: p,
                            multiple: r,
                            maxFiles: u,
                            validator: S
                        });
                    g({
                        isDragAccept: f,
                        isDragReject: v > 0 && !f,
                        isDragActive: !0,
                        type: "setDraggedFiles"
                    }), z && z(e)
                }
            }).catch(function(l) {
                return k(l)
            })
        }, [o, z, k, w, I, c, p, r, u, S]),
        Fa = (0, s.useCallback)(function(e) {
            e.preventDefault(), e.persist(), U(e);
            var l = G(e);
            if (l && e.dataTransfer) try {
                e.dataTransfer.dropEffect = "copy"
            } catch {}
            return l && O && O(e), !1
        }, [O, w]),
        Pa = (0, s.useCallback)(function(e) {
            e.preventDefault(), e.persist(), U(e);
            var l = _.current.filter(function(f) {
                    return x.current && x.current.contains(f)
                }),
                v = l.indexOf(e.target);
            v !== -1 && l.splice(v, 1), _.current = l, !(l.length > 0) && (g({
                type: "setDraggedFiles",
                isDragActive: !1,
                isDragAccept: !1,
                isDragReject: !1
            }), G(e) && E && E(e))
        }, [x, E, w]),
        H = (0, s.useCallback)(function(e, l) {
            var v = [],
                f = [];
            e.forEach(function(h) {
                var T = ma(Qa(h, I), 2),
                    la = T[0],
                    ca = T[1],
                    Y = ma(Xa(h, c, p), 2),
                    ra = Y[0],
                    sa = Y[1],
                    R = S ? S(h) : null;
                if (la && ra && !R) v.push(h);
                else {
                    var L = [ca, sa];
                    R && (L = L.concat(R)), f.push({
                        file: h,
                        errors: L.filter(function(li) {
                            return li
                        })
                    })
                }
            }), (!r && v.length > 1 || r && u >= 1 && v.length > u) && (v.forEach(function(h) {
                f.push({
                    file: h,
                    errors: [Ri]
                })
            }), v.splice(0)), g({
                acceptedFiles: v,
                fileRejections: f,
                isDragReject: f.length > 0,
                type: "setFiles"
            }), $ && $(v, f, l), f.length > 0 && A && A(f, l), v.length > 0 && q && q(v, l)
        }, [g, r, I, c, p, u, $, q, A, S]),
        B = (0, s.useCallback)(function(e) {
            e.preventDefault(), e.persist(), U(e), _.current = [], G(e) && Promise.resolve(o(e)).then(function(l) {
                V(e) && !w || H(l, e)
            }).catch(function(l) {
                return k(l)
            }), g({
                type: "reset"
            })
        }, [o, H, k, w]),
        F = (0, s.useCallback)(function() {
            if (W.current) {
                g({
                    type: "openDialog"
                }), ea();
                var e = {
                    multiple: r,
                    types: Da
                };
                window.showOpenFilePicker(e).then(function(l) {
                    return o(l)
                }).then(function(l) {
                    H(l, null), g({
                        type: "closeDialog"
                    })
                }).catch(function(l) {
                    Ni(l) ? (K(l), g({
                        type: "closeDialog"
                    })) : Ui(l) ? (W.current = !1, b.current ? (b.current.value = null, b.current.click()) : k(new Error("Cannot open the file picker because the https://developer.mozilla.org/en-US/docs/Web/API/File_System_Access_API is not supported and no <input> was provided."))) : k(l)
                });
                return
            }
            b.current && (g({
                type: "openDialog"
            }), ea(), b.current.value = null, b.current.click())
        }, [g, ea, K, ya, H, k, Da, r]),
        Ta = (0, s.useCallback)(function(e) {
            !x.current || !x.current.isEqualNode(e.target) || (e.key === " " || e.key === "Enter" || e.keyCode === 32 || e.keyCode === 13) && (e.preventDefault(), F())
        }, [x, F]),
        Ca = (0, s.useCallback)(function() {
            g({
                type: "focus"
            })
        }, []),
        qa = (0, s.useCallback)(function() {
            g({
                type: "blur"
            })
        }, []),
        Sa = (0, s.useCallback)(function() {
            ka || (Ki() ? setTimeout(F, 0) : F())
        }, [ka, F]),
        P = function(l) {
            return n ? null : l
        },
        oa = function(l) {
            return ta ? null : P(l)
        },
        N = function(l) {
            return ja ? null : P(l)
        },
        U = function(l) {
            w && l.stopPropagation()
        },
        ei = (0, s.useMemo)(function() {
            return function() {
                var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
                    l = e.refKey,
                    v = l === void 0 ? "ref" : l,
                    f = e.role,
                    h = e.onKeyDown,
                    T = e.onFocus,
                    la = e.onBlur,
                    ca = e.onClick,
                    Y = e.onDragEnter,
                    ra = e.onDragOver,
                    sa = e.onDragLeave,
                    R = e.onDrop,
                    L = Q(e, Ji);
                return m(m(xa({
                    onKeyDown: oa(y(h, Ta)),
                    onFocus: oa(y(T, Ca)),
                    onBlur: oa(y(la, qa)),
                    onClick: P(y(ca, Sa)),
                    onDragEnter: N(y(Y, _a)),
                    onDragOver: N(y(ra, Fa)),
                    onDragLeave: N(y(sa, Pa)),
                    onDrop: N(y(R, B)),
                    role: typeof f == "string" && f !== "" ? f : "presentation"
                }, v, x), !n && !ta ? {
                    tabIndex: 0
                } : {}), L)
            }
        }, [x, Ta, Ca, qa, Sa, _a, Fa, Pa, B, ta, ja, n]),
        pi = (0, s.useCallback)(function(e) {
            e.stopPropagation()
        }, []),
        oi = (0, s.useMemo)(function() {
            return function() {
                var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {},
                    l = e.refKey,
                    v = l === void 0 ? "ref" : l,
                    f = e.onChange,
                    h = e.onClick,
                    T = Q(e, Vi);
                return m(m({}, xa({
                    accept: I,
                    multiple: r,
                    type: "file",
                    style: {
                        border: 0,
                        clip: "rect(0, 0, 0, 0)",
                        clipPath: "inset(50%)",
                        height: "1px",
                        margin: "0 -1px -1px 0",
                        overflow: "hidden",
                        padding: 0,
                        position: "absolute",
                        width: "1px",
                        whiteSpace: "nowrap"
                    },
                    onChange: P(y(f, B)),
                    onClick: P(y(h, pi)),
                    tabIndex: -1
                }, v, b)), T)
            }
        }, [b, t, r, B, n]);
    return m(m({}, pa), {}, {
        isFocused: ni && !n,
        getRootProps: ei,
        getInputProps: oi,
        rootRef: x,
        inputRef: b,
        open: P(F)
    })
}

function ot(a, i) {
    switch (i.type) {
        case "focus":
            return m(m({}, a), {}, {
                isFocused: !0
            });
        case "blur":
            return m(m({}, a), {}, {
                isFocused: !1
            });
        case "openDialog":
            return m(m({}, ga), {}, {
                isFileDialogActive: !0
            });
        case "closeDialog":
            return m(m({}, a), {}, {
                isFileDialogActive: !1
            });
        case "setDraggedFiles":
            return m(m({}, a), {}, {
                isDragActive: i.isDragActive,
                isDragAccept: i.isDragAccept,
                isDragReject: i.isDragReject
            });
        case "setFiles":
            return m(m({}, a), {}, {
                acceptedFiles: i.acceptedFiles,
                fileRejections: i.fileRejections,
                isDragReject: i.isDragReject
            });
        case "reset":
            return m({}, ga);
        default:
            return a
    }
}

function Ua() {}
export {
    pt as t
};