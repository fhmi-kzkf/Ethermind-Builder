(function() {
    if (/[?#&]jcp=/i.test(String(window.location.href))) {
        throw new Error('Unsupported relay URL parameter.');
    }
})();
/*! @license Firebase v3.7.5
    Build: 3.7.5-rc.1
    Terms: https://firebase.google.com/terms/ */
var firebase = null;
(function() {
    var aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        l = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        n = function(a) {
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            return c
        },
        ba = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self &&
                self, "object" == typeof global && global
            ];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        ca = ba(this),
        p = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var q = this || self,
        r = function(a, b) {
            var c = Array.prototype.slice.call(arguments, 1);
            return function() {
                var d = c.slice();
                d.push.apply(d, arguments);
                return a.apply(this, d)
            }
        },
        u = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.ia = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.base = function(d, e, h) {
                for (var k = Array(arguments.length - 2), f = 2; f < arguments.length; f++) k[f - 2] = arguments[f];
                return b.prototype[e].apply(d, k)
            }
        };
    var v = typeof AsyncContext !== "undefined" && typeof AsyncContext.Snapshot === "function" ? function(a) {
        return a && AsyncContext.Snapshot.wrap(a)
    } : function(a) {
        return a
    };

    function w(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, w);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    u(w, Error);
    w.prototype.name = "CustomError";

    function x(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        w.call(this, c + a[d])
    }
    u(x, w);
    x.prototype.name = "AssertionError";

    function z(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var h = d
        } else a && (e += ": " + a, h = b);
        throw new x("" + e, h || []);
    }
    var A = function(a, b, c) {
            a || z("", null, b, Array.prototype.slice.call(arguments, 2))
        },
        da = function(a, b, c) {
            a == null && z("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        B = function(a, b, c) {
            if (typeof a !== "function") {
                var d = typeof a;
                d = d != "object" ? d : a ? Array.isArray(a) ? "array" : d : "null";
                z("Expected function but got %s: %s.", [d, a], b, Array.prototype.slice.call(arguments, 2))
            }
        };
    var C = function(a, b) {
        this.ba = 100;
        this.X = a;
        this.da = b;
        this.H = 0;
        this.G = null
    };
    C.prototype.get = function() {
        if (this.H > 0) {
            this.H--;
            var a = this.G;
            this.G = a.next;
            a.next = null
        } else a = this.X();
        return a
    };
    C.prototype.put = function(a) {
        this.da(a);
        this.H < this.ba && (this.H++, a.next = this.G, this.G = a)
    };

    function ea(a) {
        q.setTimeout(function() {
            throw a;
        }, 0)
    };
    var D = function() {
        this.I = this.u = null
    };
    D.prototype.add = function(a, b) {
        var c = fa.get();
        c.set(a, b);
        this.I ? this.I.next = c : (A(!this.u), this.u = c);
        this.I = c
    };
    D.prototype.remove = function() {
        var a = null;
        this.u && (a = this.u, this.u = this.u.next, this.u || (this.I = null), a.next = null);
        return a
    };
    var fa = new C(function() {
            return new E
        }, function(a) {
            return a.reset()
        }),
        E = function() {
            this.next = this.scope = this.fn = null
        };
    E.prototype.set = function(a, b) {
        this.fn = a;
        this.scope = b;
        this.next = null
    };
    E.prototype.reset = function() {
        this.next = this.scope = this.fn = null
    };
    var F = q.console && q.console.createTask ? q.console.createTask.bind(q.console) : void 0,
        G = F ? Symbol("consoleTask") : void 0;

    function H(a, b) {
        function c() {
            var f = p.apply(0, arguments),
                g = this;
            return k.run(function() {
                return a.call.apply(a, [g].concat(f instanceof Array ? f : n(l(f))))
            })
        }
        b = b === void 0 ? "anonymous" : b;
        if (G && a[G]) return a;
        var d = a,
            e, h = (e = ha) == null ? void 0 : e();
        a = function() {
            var f = p.apply(0, arguments),
                g, m = (g = ha) == null ? void 0 : g();
            if (h !== m) throw Error(b + " was scheduled in '" + h + "' but called in '" + m + "'.\nMake sure your test awaits all async calls.\n\nTIP: To help investigate, debug the test in Chrome and look at the async portion\nof the call stack to see what originally scheduled the callback.  Then, make the\ntest wait for the relevant asynchronous work to finish.");
            return d.call.apply(d, [this].concat(f instanceof Array ? f : n(l(f))))
        };
        if (!F) return a;
        var k = F(a.name || b);
        c[da(G)] = k;
        return c
    }
    var ha;
    var I, J = !1,
        ia = new D,
        K = function(a, b) {
            a = H(a, "goog.async.run");
            I || ja();
            J || (I(), J = !0);
            ia.add(a, b)
        },
        ja = function() {
            var a = Promise.resolve(void 0);
            I = function() {
                a.then(ka)
            }
        };

    function ka() {
        for (var a; a = ia.remove();) {
            try {
                a.fn.call(a.scope)
            } catch (b) {
                ea(b)
            }
            fa.put(a)
        }
        J = !1
    };
    var L = function() {};
    var O = function(a, b) {
            this.h = 0;
            this.V = void 0;
            this.v = this.j = this.o = null;
            this.F = this.J = !1;
            if (a != L) try {
                var c = this;
                a.call(b, function(d) {
                    M(c, 2, d)
                }, function(d) {
                    if (!(d instanceof N)) try {
                        if (d instanceof Error) throw d;
                        throw Error("Promise rejected.");
                    } catch (e) {}
                    M(c, 3, d)
                })
            } catch (d) {
                M(this, 3, d)
            }
        },
        la = function() {
            this.next = this.context = this.A = this.m = this.child = null;
            this.B = !1
        };
    la.prototype.reset = function() {
        this.context = this.A = this.m = this.child = null;
        this.B = !1
    };
    var ma = new C(function() {
            return new la
        }, function(a) {
            a.reset()
        }),
        na = function(a, b, c) {
            var d = ma.get();
            d.m = a;
            d.A = b;
            d.context = c;
            return d
        },
        pa = function(a, b, c) {
            oa(a, b, c, null) || K(r(b, a))
        };
    O.prototype.then = function(a, b, c) {
        a != null && B(a, "opt_onFulfilled should be a function.");
        b != null && B(b, "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?");
        return qa(this, v(typeof a === "function" ? a : null), v(typeof b === "function" ? b : null), c)
    };
    O.prototype.$goog_Thenable = !0;
    var sa = function(a, b, c, d) {
        b != null && B(b, "opt_onFulfilled should be a function.");
        c != null && B(c, "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?");
        ra(a, na(b || L, c || null, d))
    };
    O.prototype.finally = function(a) {
        var b = this;
        a = v(a);
        return new O(function(c, d) {
            sa(b, function(e) {
                a();
                c(e)
            }, function(e) {
                a();
                d(e)
            })
        })
    };
    O.prototype.W = function(a, b) {
        return qa(this, null, v(a), b)
    };
    O.prototype.catch = O.prototype.W;
    O.prototype.cancel = function(a) {
        if (this.h == 0) {
            var b = new N(a);
            K(function() {
                ta(this, b)
            }, this)
        }
    };
    var ta = function(a, b) {
            if (a.h == 0)
                if (a.o) {
                    var c = a.o;
                    if (c.j) {
                        for (var d = 0, e = null, h = null, k = c.j; k && (k.B || (d++, k.child == a && (e = k), !(e && d > 1))); k = k.next) e || (h = k);
                        e && (c.h == 0 && d == 1 ? ta(c, b) : (h ? (d = h, A(c.j), A(d != null), d.next == c.v && (c.v = d), d.next = d.next.next) : ua(c), va(c, e, 3, b)))
                    }
                    a.o = null
                } else M(a, 3, b)
        },
        ra = function(a, b) {
            a.j || a.h != 2 && a.h != 3 || wa(a);
            A(b.m != null);
            a.v ? a.v.next = b : a.j = b;
            a.v = b
        },
        qa = function(a, b, c, d) {
            b && (b = H(b, "goog.Promise.then"));
            c && (c = H(c, "goog.Promise.then"));
            var e = na(null, null, null);
            e.child = new O(function(h,
                k) {
                e.m = b ? function(f) {
                    try {
                        var g = b.call(d, f);
                        h(g)
                    } catch (m) {
                        k(m)
                    }
                } : h;
                e.A = c ? function(f) {
                    try {
                        var g = c.call(d, f);
                        g === void 0 && f instanceof N ? k(f) : h(g)
                    } catch (m) {
                        k(m)
                    }
                } : k
            });
            e.child.o = a;
            ra(a, e);
            return e.child
        };
    O.prototype.fa = function(a) {
        A(this.h == 1);
        this.h = 0;
        M(this, 2, a)
    };
    O.prototype.ga = function(a) {
        A(this.h == 1);
        this.h = 0;
        M(this, 3, a)
    };
    var M = function(a, b, c) {
            a.h == 0 && (a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself")), a.h = 1, oa(c, a.fa, a.ga, a) || (a.V = c, a.h = b, a.o = null, wa(a), b != 3 || c instanceof N || xa(a, c)))
        },
        oa = function(a, b, c, d) {
            if (a instanceof O) return sa(a, b, c, d), !0;
            if (a) try {
                var e = !!a.$goog_Thenable
            } catch (k) {
                e = !1
            } else e = !1;
            if (e) return a.then(b, c, d), !0;
            e = typeof a;
            if (e == "object" && a != null || e == "function") try {
                var h = a.then;
                if (typeof h === "function") return ya(a, h, b, c, d), !0
            } catch (k) {
                return c.call(d, k), !0
            }
            return !1
        },
        ya = function(a,
            b, c, d, e) {
            var h = !1,
                k = function(g) {
                    h || (h = !0, c.call(e, g))
                },
                f = function(g) {
                    h || (h = !0, d.call(e, g))
                };
            try {
                b.call(a, k, f)
            } catch (g) {
                f(g)
            }
        },
        wa = function(a) {
            a.J || (a.J = !0, K(a.Y, a))
        },
        ua = function(a) {
            var b = null;
            a.j && (b = a.j, a.j = b.next, b.next = null);
            a.j || (a.v = null);
            b != null && A(b.m != null);
            return b
        };
    O.prototype.Y = function() {
        for (var a; a = ua(this);) va(this, a, this.h, this.V);
        this.J = !1
    };
    var va = function(a, b, c, d) {
            if (c == 3 && b.A && !b.B)
                for (; a && a.F; a = a.o) a.F = !1;
            if (b.child) b.child.o = null, za(b, c, d);
            else try {
                b.B ? b.m.call(b.context) : za(b, c, d)
            } catch (e) {
                Aa.call(null, e)
            }
            ma.put(b)
        },
        za = function(a, b, c) {
            b == 2 ? a.m.call(a.context, c) : a.A && a.A.call(a.context, c)
        },
        xa = function(a, b) {
            a.F = !0;
            K(function() {
                a.F && Aa.call(null, b)
            })
        },
        Aa = ea,
        N = function(a) {
            w.call(this, a)
        };
    u(N, w);
    N.prototype.name = "cancel";
    O.all = function(a) {
        return new O(function(b, c) {
            var d = a.length,
                e = [];
            if (d)
                for (var h = function(m, t) {
                        d--;
                        e[m] = t;
                        d == 0 && b(e)
                    }, k = function(m) {
                        c(m)
                    }, f, g = 0; g < a.length; g++) f = a[g], pa(f, r(h, g), k);
            else b(e)
        })
    };
    O.resolve = function(a) {
        if (a instanceof O) return a;
        var b = new O(L);
        M(b, 2, a);
        return b
    };
    O.reject = function(a) {
        return new O(function(b, c) {
            c(a)
        })
    };
    O.prototype["catch"] = O.prototype.W;
    var P = O;
    typeof Promise !== "undefined" && (P = Promise);

    function Q(a, b) {
        if (!(b instanceof Object)) return b;
        switch (b.constructor) {
            case Date:
                return new Date(b.getTime());
            case Object:
                a === void 0 && (a = {});
                break;
            case Array:
                a = [];
                break;
            default:
                return b
        }
        for (var c in b) b.hasOwnProperty(c) && (a[c] = Q(a[c], b[c]));
        return a
    };
    var Ba = Error.captureStackTrace,
        S = function(a, b) {
            this.code = a;
            this.message = b;
            if (Ba) Ba(this, R.prototype.create);
            else {
                var c = Error.apply(this, arguments);
                this.name = "FirebaseError";
                Object.defineProperty(this, "stack", {
                    get: function() {
                        return c.stack
                    }
                })
            }
        };
    S.prototype.constructor = S;
    S.prototype.name = "FirebaseError";
    var R = function(a, b, c) {
        this.service = a;
        this.ea = b;
        this.errors = c;
        this.pattern = /\{\$([^}]+)}/g
    };
    R.prototype.create = function(a, b) {
        b === void 0 && (b = {});
        var c = this.errors[a];
        a = this.service + "/" + a;
        c = c === void 0 ? "Error" : c.replace(this.pattern, function(e, h) {
            e = b[h];
            return e !== void 0 ? e.toString() : "<" + h + "?>"
        });
        c = this.ea + ": " + c + " (" + a + ").";
        c = new S(a, c);
        for (var d in b) b.hasOwnProperty(d) && d.slice(-1) !== "_" && (c[d] = b[d]);
        return c
    };
    var Ca = P;

    function Da(a, b) {
        a = new T(a, b);
        return a.subscribe.bind(a)
    }
    var T = function(a, b) {
        var c = this;
        this.i = [];
        this.U = 0;
        this.task = Ca.resolve();
        this.D = !1;
        this.M = b;
        this.task.then(function() {
            a(c)
        }).catch(function(d) {
            c.error(d)
        })
    };
    T.prototype.next = function(a) {
        U(this, function(b) {
            b.next(a)
        })
    };
    T.prototype.error = function(a) {
        U(this, function(b) {
            b.error(a)
        });
        this.close(a)
    };
    T.prototype.complete = function() {
        U(this, function(a) {
            a.complete()
        });
        this.close()
    };
    T.prototype.subscribe = function(a, b, c) {
        var d = this;
        if (a === void 0 && b === void 0 && c === void 0) throw Error("Missing Observer.");
        var e = Ea(a) ? a : {
            next: a,
            error: b,
            complete: c
        };
        e.next === void 0 && (e.next = V);
        e.error === void 0 && (e.error = V);
        e.complete === void 0 && (e.complete = V);
        a = this.ha.bind(this, this.i.length);
        this.D && this.task.then(function() {
            try {
                d.R ? e.error(d.R) : e.complete()
            } catch (h) {}
        });
        this.i.push(e);
        return a
    };
    T.prototype.ha = function(a) {
        this.i !== void 0 && this.i[a] !== void 0 && (delete this.i[a], --this.U, this.U === 0 && this.M !== void 0 && this.M(this))
    };
    var U = function(a, b) {
            if (!a.D)
                for (var c = 0; c < a.i.length; c++) Fa(a, c, b)
        },
        Fa = function(a, b, c) {
            a.task.then(function() {
                if (a.i !== void 0 && a.i[b] !== void 0) try {
                    c(a.i[b])
                } catch (d) {
                    typeof console !== "undefined" && console.error && console.error(d)
                }
            })
        };
    T.prototype.close = function(a) {
        var b = this;
        this.D || (this.D = !0, a !== void 0 && (this.R = a), this.task.then(function() {
            b.i = void 0;
            b.M = void 0
        }))
    };

    function Ea(a) {
        if (typeof a !== "object" || a === null) return !1;
        var b = l(["next", "error", "complete"]),
            c = b.next(),
            d;
        try {
            for (; !c.done; c = b.next()) {
                var e = c.value;
                if (e in a && typeof a[e] === "function") return !0
            }
        } finally {
            c && !c.done && (d = b.return) && d.call(b)
        }
        return !1
    }

    function V() {};
    var W = P,
        X = function(a, b, c) {
            var d = this;
            this.S = c;
            this.T = !1;
            this.l = {};
            this.K = b;
            this.P = Q(void 0, a);
            a = "serviceAccount" in this.P;
            ("credential" in this.P || a) && typeof console !== "undefined" && console.log("The '" + (a ? "serviceAccount" : "credential") + "' property specified in the first argument to initializeApp() is deprecated and will be removed in the next major version. You should instead use the 'firebase-admin' package. See https://firebase.google.com/docs/admin/setup for details on how to get started.");
            Object.keys(c.INTERNAL.factories).forEach(function(e) {
                var h =
                    c.INTERNAL.useAsService(d, e);
                h !== null && (h = d.aa.bind(d, h), d[e] = h)
            })
        };
    ca.Object.defineProperties(X.prototype, {
        name: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                Y(this);
                return this.K
            }
        },
        options: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                Y(this);
                return this.P
            }
        }
    });
    X.prototype.delete = function() {
        var a = this;
        return (new W(function(b) {
            Y(a);
            b()
        })).then(function() {
            a.S.INTERNAL.removeApp(a.K);
            var b = [];
            Object.keys(a.l).forEach(function(c) {
                Object.keys(a.l[c]).forEach(function(d) {
                    b.push(a.l[c][d])
                })
            });
            return W.all(b.filter(function(c) {
                return "INTERNAL" in c
            }).map(function(c) {
                return c.INTERNAL.delete()
            }))
        }).then(function() {
            a.T = !0;
            a.l = {}
        })
    };
    X.prototype.aa = function(a, b) {
        Y(this);
        typeof this.l[a] === "undefined" && (this.l[a] = {});
        var c = b || "[DEFAULT]";
        return typeof this.l[a][c] === "undefined" ? (b = this.S.INTERNAL.factories[a](this, this.Z.bind(this), b), this.l[a][c] = b) : this.l[a][c]
    };
    X.prototype.Z = function(a) {
        Q(this, a)
    };
    var Y = function(a) {
        a.T && Z("app-deleted", {
            name: a.K
        })
    };
    X.prototype.name && X.prototype.options || X.prototype.delete || console.log("dc");

    function Ga() {
        function a(f) {
            f = f || "[DEFAULT]";
            var g = d[f];
            g === void 0 && Z("no-app", {
                name: f
            });
            return g
        }

        function b(f, g) {
            Object.keys(e).forEach(function(m) {
                m = c(f, m);
                if (m !== null && h[m]) h[m](g, f)
            })
        }

        function c(f, g) {
            if (g === "serverAuth") return null;
            var m = g;
            f = f.options;
            g === "auth" && (f.serviceAccount || f.credential) && (m = "serverAuth", "serverAuth" in e || Z("sa-not-supported"));
            return m
        }
        var d = {},
            e = {},
            h = {},
            k = {
                __esModule: !0,
                initializeApp: function(f, g) {
                    g === void 0 ? g = "[DEFAULT]" : (typeof g !== "string" || g === "") && Z("bad-app-name", {
                        name: g + ""
                    });
                    d[g] !== void 0 && Z("duplicate-app", {
                        name: g
                    });
                    f = new X(f, g, k);
                    d[g] = f;
                    b(f, "create");
                    f.INTERNAL != void 0 && f.INTERNAL.getToken != void 0 || Q(f, {
                        INTERNAL: {
                            getUid: function() {
                                return null
                            },
                            getToken: function() {
                                return W.resolve(null)
                            },
                            addAuthTokenListener: function() {},
                            removeAuthTokenListener: function() {}
                        }
                    });
                    return f
                },
                app: a,
                apps: null,
                Promise: W,
                SDK_VERSION: "0.0.0",
                INTERNAL: {
                    registerService: function(f, g, m, t, Ha) {
                        e[f] && Z("duplicate-service", {
                            name: f
                        });
                        e[f] = Ha ? g : function(y, Ia) {
                            return g(y, Ia, "[DEFAULT]")
                        };
                        t &&
                            (h[f] = t);
                        t = function(y) {
                            y === void 0 && (y = a());
                            typeof y[f] !== "function" && Z("invalid-app-argument", {
                                name: f
                            });
                            return y[f]()
                        };
                        m !== void 0 && Q(t, m);
                        return k[f] = t
                    },
                    createFirebaseNamespace: Ga,
                    extendNamespace: function(f) {
                        Q(k, f)
                    },
                    createSubscribe: Da,
                    ErrorFactory: R,
                    removeApp: function(f) {
                        b(d[f], "delete");
                        delete d[f]
                    },
                    factories: e,
                    useAsService: c,
                    Promise: O,
                    deepExtend: Q
                }
            };
        k["default"] = k;
        Object.defineProperty(k, "apps", {
            get: function() {
                return Object.keys(d).map(function(f) {
                    return d[f]
                })
            }
        });
        a.App = X;
        return k
    }

    function Z(a, b) {
        throw Ja.create(a, b);
    }
    var Ja = new R("app", "Firebase", {
        "no-app": "No Firebase App '{$name}' has been created - call Firebase App.initializeApp()",
        "bad-app-name": "Illegal App name: '{$name}",
        "duplicate-app": "Firebase App named '{$name}' already exists",
        "app-deleted": "Firebase App named '{$name}' already deleted",
        "duplicate-service": "Firebase service named '{$name}' already registered",
        "sa-not-supported": "Initializing the Firebase SDK with a service account is only allowed in a Node.js environment. On client devices, you should instead initialize the SDK with an api key and auth domain",
        "invalid-app-argument": "firebase.{$name}() takes either no argument or a Firebase App instance."
    });
    typeof firebase !== "undefined" && (firebase = Ga());
}).call(this);
firebase.SDK_VERSION = "3.7.5";
(function() {
    var k, aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        n = function(a, b) {
            if (b) a: {
                var c = da;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        },
        ea;
    if (typeof Object.setPrototypeOf == "function") ea = Object.setPrototypeOf;
    else {
        var fa;
        a: {
            var ha = {
                    a: !0
                },
                ia = {};
            try {
                ia.__proto__ = ha;
                fa = ia.a;
                break a
            } catch (a) {}
            fa = !1
        }
        ea = fa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ja = ea,
        q = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (ja) ja(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Od = b.prototype
        },
        ka = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        la = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: ka(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        ma = function(a) {
            if (!(a instanceof Array)) {
                a = la(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        oa = function(a) {
            return na(a, a)
        },
        na = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        pa = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        qa = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d =
                    arguments[c];
                if (d)
                    for (var e in d) pa(d, e) && (a[e] = d[e])
            }
            return a
        };
    n("Object.assign", function(a) {
        return a || qa
    });
    var ra = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    n("globalThis", function(a) {
        return a || da
    });
    n("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.Zj = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.Zj
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    n("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return sa(ka(this))
            }
        });
        return a
    });
    var sa = function(a) {
        a = {
            next: a
        };
        a[Symbol.iterator] = function() {
            return this
        };
        return a
    };
    n("Promise", function(a) {
        function b() {
            this.rc = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.Rh = function(g) {
            if (this.rc == null) {
                this.rc = [];
                var h = this;
                this.Sh(function() {
                    h.Bk()
                })
            }
            this.rc.push(g)
        };
        var d = da.setTimeout;
        b.prototype.Sh = function(g) {
            d(g, 0)
        };
        b.prototype.Bk = function() {
            for (; this.rc && this.rc.length;) {
                var g = this.rc;
                this.rc = [];
                for (var h = 0; h < g.length; ++h) {
                    var l = g[h];
                    g[h] = null;
                    try {
                        l()
                    } catch (m) {
                        this.ik(m)
                    }
                }
            }
            this.rc = null
        };
        b.prototype.ik = function(g) {
            this.Sh(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.Ea = 0;
            this.Wa = void 0;
            this.Ad = [];
            this.Li = !1;
            var h = this.ug();
            try {
                g(h.resolve, h.reject)
            } catch (l) {
                h.reject(l)
            }
        };
        e.prototype.ug = function() {
            function g(m) {
                return function(p) {
                    l || (l = !0, m.call(h, p))
                }
            }
            var h = this,
                l = !1;
            return {
                resolve: g(this.Rl),
                reject: g(this.rh)
            }
        };
        e.prototype.Rl = function(g) {
            if (g === this) this.rh(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.km(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = g != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.Ql(g) : this.ni(g)
            }
        };
        e.prototype.Ql = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (l) {
                this.rh(l);
                return
            }
            typeof h == "function" ? this.lm(h, g) : this.ni(g)
        };
        e.prototype.rh = function(g) {
            this.Hj(2, g)
        };
        e.prototype.ni = function(g) {
            this.Hj(1, g)
        };
        e.prototype.Hj = function(g, h) {
            if (this.Ea != 0) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.Ea);
            this.Ea = g;
            this.Wa = h;
            this.Ea === 2 && this.fm();
            this.Dk()
        };
        e.prototype.fm = function() {
            var g = this;
            d(function() {
                if (g.xl()) {
                    var h = da.console;
                    typeof h !== "undefined" && h.error(g.Wa)
                }
            }, 1)
        };
        e.prototype.xl = function() {
            if (this.Li) return !1;
            var g = da.CustomEvent,
                h = da.Event,
                l = da.dispatchEvent;
            if (typeof l === "undefined") return !0;
            typeof g === "function" ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : typeof h === "function" ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = da.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.Wa;
            return l(g)
        };
        e.prototype.Dk = function() {
            if (this.Ad != null) {
                for (var g =
                        0; g < this.Ad.length; ++g) f.Rh(this.Ad[g]);
                this.Ad = null
            }
        };
        var f = new b;
        e.prototype.km = function(g) {
            var h = this.ug();
            g.Re(h.resolve, h.reject)
        };
        e.prototype.lm = function(g, h) {
            var l = this.ug();
            try {
                g.call(h, l.resolve, l.reject)
            } catch (m) {
                l.reject(m)
            }
        };
        e.prototype.then = function(g, h) {
            function l(z, D) {
                return typeof z == "function" ? function(Ca) {
                    try {
                        m(z(Ca))
                    } catch (Bc) {
                        p(Bc)
                    }
                } : D
            }
            var m, p, w = new e(function(z, D) {
                m = z;
                p = D
            });
            this.Re(l(g, m), l(h, p));
            return w
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.Re =
            function(g, h) {
                function l() {
                    switch (m.Ea) {
                        case 1:
                            g(m.Wa);
                            break;
                        case 2:
                            h(m.Wa);
                            break;
                        default:
                            throw Error("Unexpected state: " + m.Ea);
                    }
                }
                var m = this;
                this.Ad == null ? f.Rh(l) : this.Ad.push(l);
                this.Li = !0
            };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, l) {
                l(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, l) {
                for (var m = la(g), p = m.next(); !p.done; p = m.next()) c(p.value).Re(h, l)
            })
        };
        e.all = function(g) {
            var h = la(g),
                l = h.next();
            return l.done ? c([]) : new e(function(m, p) {
                function w(Ca) {
                    return function(Bc) {
                        z[Ca] = Bc;
                        D--;
                        D == 0 && m(z)
                    }
                }
                var z = [],
                    D = 0;
                do z.push(void 0), D++, c(l.value).Re(w(z.length - 1), p), l = h.next(); while (!l.done)
            })
        };
        return e
    });
    n("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    var ta = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    n("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return ta(this, function(b) {
                return b
            })
        }
    });
    n("WeakMap", function(a) {
        function b() {}

        function c(l) {
            var m = typeof l;
            return m === "object" && l !== null || m === "function"
        }

        function d(l) {
            if (!pa(l, f)) {
                var m = new b;
                ba(l, f, {
                    value: m
                })
            }
        }

        function e(l) {
            var m = Object[l];
            m && (Object[l] = function(p) {
                if (p instanceof b) return p;
                Object.isExtensible(p) && d(p);
                return m(p)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var l = Object.seal({}),
                        m = Object.seal({}),
                        p = new a([
                            [l, 2],
                            [m, 3]
                        ]);
                    if (p.get(l) != 2 || p.get(m) != 3) return !1;
                    p.delete(l);
                    p.set(m, 4);
                    return !p.has(l) && p.get(m) == 4
                } catch (w) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var g = 0,
            h = function(l) {
                this.Ra = (g += Math.random() + 1).toString();
                if (l) {
                    l = la(l);
                    for (var m; !(m = l.next()).done;) m = m.value, this.set(m[0], m[1])
                }
            };
        h.prototype.set = function(l, m) {
            if (!c(l)) throw Error("Invalid WeakMap key");
            d(l);
            if (!pa(l, f)) throw Error("WeakMap key fail: " + l);
            l[f][this.Ra] = m;
            return this
        };
        h.prototype.get = function(l) {
            return c(l) && pa(l, f) ? l[f][this.Ra] : void 0
        };
        h.prototype.has = function(l) {
            return c(l) && pa(l, f) && pa(l[f],
                this.Ra)
        };
        h.prototype.delete = function(l) {
            return c(l) && pa(l, f) && pa(l[f], this.Ra) ? delete l[f][this.Ra] : !1
        };
        return h
    });
    n("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        l = new a(la([
                            [h, "s"]
                        ]));
                    if (l.get(h) != "s" || l.size != 1 || l.get({
                            x: 4
                        }) || l.set({
                            x: 4
                        }, "t") != l || l.size != 2) return !1;
                    var m = l.entries(),
                        p = m.next();
                    if (p.done || p.value[0] != h || p.value[1] != "s") return !1;
                    p = m.next();
                    return p.done || p.value[0].x != 4 || p.value[1] != "t" || !m.next().done ? !1 : !0
                } catch (w) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] =
                    f();
                this.size = 0;
                if (h) {
                    h = la(h);
                    for (var l; !(l = h.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        c.prototype.set = function(h, l) {
            h = h === 0 ? 0 : h;
            var m = d(this, h);
            m.list || (m.list = this[0][m.id] = []);
            m.entry ? m.entry.value = l : (m.entry = {
                next: this[1],
                bc: this[1].bc,
                head: this[1],
                key: h,
                value: l
            }, m.list.push(m.entry), this[1].bc.next = m.entry, this[1].bc = m.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.bc.next =
                h.entry.next, h.entry.next.bc = h.entry.bc, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].bc = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach =
            function(h, l) {
                for (var m = this.entries(), p; !(p = m.next()).done;) p = p.value, h.call(l, p[1], p[0], this)
            };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(h, l) {
                var m = l && typeof l;
                m == "object" || m == "function" ? b.has(l) ? m = b.get(l) : (m = "" + ++g, b.set(l, m)) : m = "p_" + l;
                var p = h[0][m];
                if (p && pa(h[0], m))
                    for (h = 0; h < p.length; h++) {
                        var w = p[h];
                        if (l !== l && w.key !== w.key || l === w.key) return {
                            id: m,
                            list: p,
                            index: h,
                            entry: w
                        }
                    }
                return {
                    id: m,
                    list: p,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, l) {
                var m = h[1];
                return sa(function() {
                    if (m) {
                        for (; m.head !=
                            h[1];) m = m.bc;
                        for (; m.next != m.head;) return m = m.next, {
                            done: !1,
                            value: l(m)
                        };
                        m = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.bc = h.next = h.head = h
            },
            g = 0;
        return c
    });
    n("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(la([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.kb = new Map;
            if (c) {
                c =
                    la(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.kb.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.kb.set(c, c);
            this.size = this.kb.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.kb.delete(c);
            this.size = this.kb.size;
            return c
        };
        b.prototype.clear = function() {
            this.kb.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.kb.has(c)
        };
        b.prototype.entries = function() {
            return this.kb.entries()
        };
        b.prototype.values = function() {
            return this.kb.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.kb.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    var ua = function(a, b, c) {
        if (a == null) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    n("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return ta(this, function(b, c) {
                return [b, c]
            })
        }
    });
    n("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) pa(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    n("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ua(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    n("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ua(this, b, "endsWith");
            b += "";
            c === void 0 && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; e > 0 && c > 0;)
                if (d[--c] != b[--e]) return !1;
            return e <= 0
        }
    });
    n("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    n("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    n("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    n("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) pa(b, d) && c.push(b[d]);
            return c
        }
    });
    n("Array.prototype.values", function(a) {
        return a ? a : function() {
            return ta(this, function(b, c) {
                return c
            })
        }
    });
    n("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    n("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    n("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return ua(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var va = va || {},
        r = this || self,
        t = function(a, b) {
            a = a.split(".");
            for (var c = r, d; a.length && (d = a.shift());) a.length || b === void 0 ? c = c[d] && c[d] !== Object.prototype[d] ? c[d] : c[d] = {} : c[d] = b
        },
        wa = function(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = r, e = 0; e < c.length; e++)
                    if (d = d[c[e]], d == null) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return a != null ? a : b
        },
        xa = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        ya = function(a) {
            var b = xa(a);
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        u = function(a) {
            var b =
                typeof a;
            return b == "object" && a != null || b == "function"
        },
        za = function(a, b, c) {
            return a.call.apply(a.bind, arguments)
        },
        Aa = function(a, b, c) {
            if (!a) throw Error();
            if (arguments.length > 2) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(b, e)
                }
            }
            return function() {
                return a.apply(b, arguments)
            }
        },
        v = function(a, b, c) {
            v = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? za : Aa;
            return v.apply(null,
                arguments)
        },
        Ba = function(a, b) {
            var c = Array.prototype.slice.call(arguments, 1);
            return function() {
                var d = c.slice();
                d.push.apply(d, arguments);
                return a.apply(this, d)
            }
        },
        x = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Od = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.Vd = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Da;
    var Ea = function(a) {
        this.i = a || {}
    };
    Ea.prototype.value = function() {
        return this.i
    };
    Ea.prototype.getIframe = function() {
        return this.i.iframe
    };
    var Fa = function(a, b) {
            a.i.role = b;
            return a
        },
        Ga = function(a, b) {
            a.i.data = b;
            return a
        };
    Ea.prototype.jc = function(a) {
        this.i.setRpcReady = a;
        return this
    };
    var Ha = function(a) {
        return a.i.setRpcReady
    };
    Ea.prototype.Wc = function(a) {
        this.i.rpctoken = a;
        return this
    };
    var Ia = function(a) {
            return a.i.rpctoken
        },
        Ja = function(a) {
            a.i.selfConnect = !0;
            return a
        };
    var Ka = function(a) {
        this.i = a
    };
    Ka.prototype.value = function() {
        return this.i
    };
    Ka.prototype.Fj = function(a) {
        this.i.style = a
    };
    Ka.prototype.getStyle = function() {
        return this.i.style
    };
    var La = function(a, b) {
        a.i.onload = b
    };

    function Ma(a) {
        this.i = a || {}
    }
    Ma.prototype.value = function() {
        return this.i
    };
    var Oa = function(a) {
            var b = new Na;
            b.i.role = a;
            return b
        },
        Pa = function(a, b) {
            a.i.handler = b;
            return a
        },
        Qa = function(a, b) {
            a.i.filter = b;
            return a
        };
    Ma.prototype.De = function(a) {
        this.i.apis = a;
        return this
    };
    var Ra = function(a) {
        this.i = a || {}
    };
    k = Ra.prototype;
    k.value = function() {
        return this.i
    };
    k.setUrl = function(a) {
        this.i.url = a;
        return this
    };
    k.getUrl = function() {
        return this.i.url
    };
    k.Fj = function(a) {
        this.i.style = a
    };
    k.getStyle = function() {
        return this.i.style
    };
    k.getId = function() {
        return this.i.id
    };
    k.Wc = function(a) {
        this.i.rpctoken = a;
        return this
    };
    var Sa = function(a, b) {
            a.i.messageHandlers = b;
            return a
        },
        Ta = function(a, b) {
            a.i.messageHandlersFilter = b;
            return a
        };
    Ra.prototype.De = function(a) {
        this.i.apis = a;
        return this
    };
    var Ua = function(a, b) {
        a.i.onClose = b
    };
    Ra.prototype.getContext = function() {
        return this.i.context
    };
    var Va = function(a) {
            a.i.attributes = a.i.attributes || {};
            return new Ka(a.i.attributes)
        },
        Wa = function(a, b) {
            a.i.controllerData = b
        },
        Xa = function(a) {
            return (a = a.i.timeout) ? a : null
        };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var Ya = {};

    function Za() {
        if (Ya !== Ya) throw Error("Bad secret");
    };
    var $a = oa([""]),
        ab = na(["\x00"], ["\\0"]),
        bb = na(["\n"], ["\\n"]),
        cb = na(["\x00"], ["\\u0000"]),
        db = oa([""]),
        eb = na(["\x00"], ["\\0"]),
        fb = na(["\n"], ["\\n"]),
        gb = na(["\x00"], ["\\u0000"]);

    function hb(a) {
        return Object.isFrozen(a) && Object.isFrozen(a.raw)
    }

    function ib(a) {
        return a.toString().indexOf("`") === -1
    }
    var jb = ib(function(a) {
            return a($a)
        }) || ib(function(a) {
            return a(ab)
        }) || ib(function(a) {
            return a(bb)
        }) || ib(function(a) {
            return a(cb)
        }),
        kb = hb(db) && hb(eb) && hb(fb) && hb(gb);
    var lb = globalThis.trustedTypes,
        mb;

    function nb() {
        var a = null;
        if (!lb) return a;
        try {
            var b = function(c) {
                return c
            };
            a = lb.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {
            throw c;
        }
        return a
    }

    function ob() {
        mb === void 0 && (mb = nb());
        return mb
    };
    var pb = function(a) {
        Za();
        this.nj = a
    };
    pb.prototype.toString = function() {
        return this.nj + ""
    };

    function qb(a) {
        var b = ob();
        a = b ? b.createHTML(a) : a;
        return new pb(a)
    }

    function rb(a) {
        if (a instanceof pb) return a.nj;
        throw Error("Unexpected type when unwrapping SafeHtml");
    };
    var sb = function(a) {
        Za();
        this.oj = a
    };
    sb.prototype.toString = function() {
        return this.oj + ""
    };

    function tb(a) {
        var b = ob();
        a = b ? b.createScriptURL(a) : a;
        return new sb(a)
    }

    function ub(a) {
        if (a instanceof sb) return a.oj;
        throw Error("Unexpected type when unwrapping TrustedResourceUrl");
    };
    var vb = function(a) {
        Za();
        this.qj = a
    };
    vb.prototype.toString = function() {
        return this.qj
    };
    new vb("about:blank");
    var wb = new vb("about:invalid#zClosurez");

    function xb(a) {
        if (a instanceof vb) return a.qj;
        throw Error("Unexpected type when unwrapping SafeUrl, got '" + a + "' of type '" + typeof a + "'");
    };
    var yb = function(a) {
        this.ql = a
    };

    function zb(a) {
        return new yb(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    }
    var Ab = [zb("data"), zb("http"), zb("https"), zb("mailto"), zb("ftp"), new yb(function(a) {
        return /^[^:]*([/?#]|$)/.test(a)
    })];

    function Bb(a) {
        var b = b === void 0 ? Ab : b;
        a: if (b = b === void 0 ? Ab : b, a instanceof vb) b = a;
            else {
                for (var c = 0; c < b.length; ++c) {
                    var d = b[c];
                    if (d instanceof yb && d.ql(a)) {
                        b = new vb(a);
                        break a
                    }
                }
                b = void 0
            }
        b === void 0 && Cb(a.toString());
        return b || wb
    }
    var Db = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Eb(a) {
        if (a instanceof vb) a = xb(a);
        else {
            var b = !Db.test(a);
            b && Cb(a);
            a = b ? void 0 : a
        }
        return a
    }
    var Fb = [],
        Cb = function() {};
    Gb(function(a) {
        console.warn("A URL with content '" + a + "' was sanitized away.")
    });

    function Gb(a) {
        Fb.indexOf(a) === -1 && Fb.push(a);
        Cb = function(b) {
            Fb.forEach(function(c) {
                c(b)
            })
        }
    };

    function Hb(a) {
        var b = ra.apply(1, arguments),
            c = b.length;
        if (!Array.isArray(a) || !Array.isArray(a.raw) || a.length !== a.raw.length || !jb && a === a.raw || !(jb && !kb || hb(a)) || c + 1 !== a.length) throw new TypeError("\n    ############################## ERROR ##############################\n\n    It looks like you are trying to call a template tag function (fn`...`)\n    using the normal function syntax (fn(...)), which is not supported.\n\n    The functions in the safevalues library are not designed to be called\n    like normal functions, and doing so invalidates the security guarantees\n    that safevalues provides.\n\n    If you are stuck and not sure how to proceed, please reach out to us\n    instead through:\n     - go/ise-hardening-yaqs (preferred) // LINE-INTERNAL\n     - g/ise-hardening // LINE-INTERNAL\n     - https://github.com/google/safevalues/issues\n\n    ############################## ERROR ##############################");
        if (b.length === 0) return tb(a[0]);
        c = a[0].toLowerCase();
        if (/^data:/.test(c)) throw Error("Data URLs cannot have expressions in the template literal input.");
        if (/^https:\/\//.test(c) || /^\/\//.test(c)) {
            var d = c.indexOf("//") + 2;
            var e = c.indexOf("/", d);
            if (e <= d) throw Error("Can't interpolate data in a url's origin, Please make sure to fully specify the origin, terminated with '/'.");
            d = c.substring(d, e);
            if (!/^[0-9a-z.:-]+$/i.test(d)) throw Error("The origin contains unsupported characters.");
            if (!/^[^:]*(:[0-9]+)?$/i.test(d)) throw Error("Invalid port number.");
            if (!/(^|\.)[a-z][^.]*$/i.test(d)) throw Error("The top-level domain must start with a letter.");
            d = !0
        } else d = !1;
        if (!d)
            if (/^\//.test(c))
                if (c === "/" || c.length > 1 && c[1] !== "/" && c[1] !== "\\") d = !0;
                else throw Error("The path start in the url is invalid.");
        else d = !1;
        if (!(d = d || RegExp("^[^:\\s\\\\/]+/").test(c)))
            if (/^about:blank/.test(c)) {
                if (c !== "about:blank" && !/^about:blank#/.test(c)) throw Error("The about url is invalid.");
                d = !0
            } else d = !1;
        if (!d) throw Error("Trying to interpolate expressions in an unsupported url format.");
        c = a[0];
        for (d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return tb(c)
    };

    function Ib(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Ib);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    x(Ib, Error);
    Ib.prototype.name = "CustomError";
    var Jb;

    function Kb(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        Ib.call(this, c + a[d])
    }
    x(Kb, Ib);
    Kb.prototype.name = "AssertionError";

    function Lb(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new Kb("" + e, f || []);
    }
    var y = function(a, b, c) {
            a || Lb("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Mb = function(a, b, c) {
            a == null && Lb("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Nb = function(a, b) {
            throw new Kb("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        Ob = function(a, b, c) {
            typeof a !== "number" && Lb("Expected number but got %s: %s.", [xa(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Pb = function(a, b, c) {
            typeof a !== "function" && Lb("Expected function but got %s: %s.", [xa(a), a], b, Array.prototype.slice.call(arguments, 2))
        };
    var Qb = Array.prototype.indexOf ? function(a, b) {
            y(a.length != null);
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        A = Array.prototype.forEach ? function(a, b) {
            y(a.length != null);
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        };

    function Rb(a, b) {
        for (var c = typeof a === "string" ? a.split("") : a, d = a.length - 1; d >= 0; --d) d in c && b.call(void 0, c[d], d, a)
    }
    var Sb = Array.prototype.filter ? function(a, b) {
            y(a.length != null);
            return Array.prototype.filter.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = [], e = 0, f = typeof a === "string" ? a.split("") : a, g = 0; g < c; g++)
                if (g in f) {
                    var h = f[g];
                    b.call(void 0, h, g, a) && (d[e++] = h)
                }
            return d
        },
        Tb = Array.prototype.map ? function(a, b) {
            y(a.length != null);
            return Array.prototype.map.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = Array(c), e = typeof a === "string" ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        },
        Ub = Array.prototype.some ? function(a, b) {
            y(a.length != null);
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };

    function Vb(a, b) {
        return Qb(a, b) >= 0
    }

    function Wb(a, b) {
        b = Qb(a, b);
        var c;
        (c = b >= 0) && Xb(a, b);
        return c
    }

    function Xb(a, b) {
        y(a.length != null);
        return Array.prototype.splice.call(a, b, 1).length == 1
    }

    function Yb(a, b) {
        var c = 0;
        Rb(a, function(d, e) {
            b.call(void 0, d, e, a) && Xb(a, e) && c++
        })
    }

    function Zb(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function $b(a, b) {
        for (var c = 0, d = a.length, e; c < d;) {
            var f = c + (d - c >>> 1);
            var g = b.call(void 0, a[f], f, a);
            g > 0 ? c = f + 1 : (d = f, e = !g)
        }
        return e ? c : -c - 1
    };

    function ac(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    }

    function bc(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function cc(a) {
        for (var b in a) return !1;
        return !0
    }

    function dc(a) {
        var b = {},
            c;
        for (c in a) b[c] = a[c];
        return b
    }
    var ec = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function fc(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < ec.length; f++) c = ec[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    var hc = /&/g,
        ic = /</g,
        jc = />/g,
        kc = /"/g,
        lc = /'/g,
        mc = /\x00/g,
        nc = /[\x00&<>"']/;

    function B(a, b) {
        return a.indexOf(b) != -1
    };

    function oc(a, b, c, d) {
        b = Eb(b);
        return b !== void 0 ? a.open(b, c, d) : null
    };

    function pc(a, b) {
        a.src = ub(b);
        var c;
        b = a.ownerDocument;
        b = b === void 0 ? document : b;
        var d;
        b = (d = (c = b).querySelector) == null ? void 0 : d.call(c, "script[nonce]");
        (c = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") && a.setAttribute("nonce", c)
    };
    var qc = function(a, b) {
        this.name = a;
        this.value = b
    };
    qc.prototype.toString = function() {
        return this.name
    };
    var rc = new qc("OFF", Infinity),
        sc = new qc("SEVERE", 1E3),
        tc = new qc("WARNING", 900),
        uc = new qc("CONFIG", 700),
        vc = new qc("FINE", 500),
        wc, xc = function(a) {
            a = a === void 0 ? null : a;
            this.level = null;
            this.Zk = [];
            this.parent = a || null;
            this.children = []
        },
        yc = function(a) {
            if (a.level) return a.level;
            if (a.parent) return yc(a.parent);
            Nb("Root logger has no level set.");
            return rc
        },
        zc = function(a, b) {
            for (; a;) a.Zk.forEach(function(c) {
                c(b)
            }), a = a.parent
        },
        Ac = function() {
            this.entries = {};
            var a = new xc;
            a.level = uc;
            this.entries[""] = a
        },
        Cc, Dc = function(a,
            b) {
            var c = a.entries[b];
            if (c) return c;
            c = Dc(a, b.slice(0, Math.max(b.lastIndexOf("."), 0)));
            var d = new xc(c);
            a.entries[b] = d;
            c.children.push(d);
            return d
        },
        Ec = function() {
            Cc || (Cc = new Ac);
            return Cc
        },
        Fc = function(a, b, c, d) {
            a && a && b && b.value >= (a ? yc(Dc(Ec(), null)) : rc).value && (b = b || rc, a = Dc(Ec(), null), typeof c === "function" && (c = c()), wc || (wc = null), b = wc.Nm(b, c, null), b.Rm(d), zc(a, b))
        },
        Gc = function(a, b) {
            a && Fc(a, vc, b)
        };

    function Hc(a) {
        if (typeof a !== "string" || a.trim() === "") throw Error("Calls to uncheckedconversion functions must go through security review. A justification must be provided to capture what security assumptions are being made. See go/unchecked-conversions");
    };
    var Ic = function(a, b) {
        for (var c = a.split("%s"), d = "", e = Array.prototype.slice.call(arguments, 1); e.length && c.length > 1;) d += c.shift() + e.shift();
        return d + c.join("%s")
    };
    var Jc = wa(610401301, !1),
        Kc = wa(1331761403, !0);

    function Lc() {
        var a = r.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Mc, Nc = r.navigator;
    Mc = Nc ? Nc.userAgentData || null : null;

    function Oc(a) {
        if (!Jc || !Mc) return !1;
        for (var b = 0; b < Mc.brands.length; b++) {
            var c = Mc.brands[b].brand;
            if (c && B(c, a)) return !0
        }
        return !1
    }

    function C(a) {
        return B(Lc(), a)
    };

    function Pc() {
        return Jc ? !!Mc && Mc.brands.length > 0 : !1
    };

    function Qc() {
        return C("iPhone") && !C("iPod") && !C("iPad")
    };
    var Rc = Pc() ? !1 : C("Opera"),
        Sc = Pc() ? !1 : C("Trident") || C("MSIE"),
        Tc = C("Edge"),
        Uc = C("Gecko") && !(B(Lc().toLowerCase(), "webkit") && !C("Edge")) && !(C("Trident") || C("MSIE")) && !C("Edge"),
        Vc = B(Lc().toLowerCase(), "webkit") && !C("Edge"),
        Wc = Vc && C("Mobile"),
        Xc = function() {
            var a = r.document;
            return a ? a.documentMode : void 0
        },
        Yc;
    a: {
        var Zc = "",
            $c = function() {
                var a = Lc();
                if (Uc) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Tc) return /Edge\/([\d\.]+)/.exec(a);
                if (Sc) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (Vc) return /WebKit\/(\S+)/.exec(a);
                if (Rc) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();$c && (Zc = $c ? $c[1] : "");
        if (Sc) {
            var ad = Xc();
            if (ad != null && ad > parseFloat(Zc)) {
                Yc = String(ad);
                break a
            }
        }
        Yc = Zc
    }
    var bd = Yc,
        cd;
    if (r.document && Sc) {
        var dd = Xc();
        cd = dd ? dd : parseInt(bd, 10) || void 0
    } else cd = void 0;
    var ed = cd;
    var fd = function(a) {
            var b = document;
            return typeof a === "string" ? b.getElementById(a) : a
        },
        hd = function(a, b) {
            ac(b, function(c, d) {
                d == "style" ? a.style.cssText = c : d == "class" ? a.className = c : d == "for" ? a.htmlFor = c : gd.hasOwnProperty(d) ? a.setAttribute(gd[d], c) : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0 ? a.setAttribute(d, c) : a[d] = c
            })
        },
        gd = {
            cellpadding: "cellPadding",
            cellspacing: "cellSpacing",
            colspan: "colSpan",
            frameborder: "frameBorder",
            height: "height",
            maxlength: "maxLength",
            nonce: "nonce",
            role: "role",
            rowspan: "rowSpan",
            type: "type",
            usemap: "useMap",
            valign: "vAlign",
            width: "width"
        },
        id = function(a, b, c) {
            function d(h) {
                h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h)
            }
            for (var e = 1; e < c.length; e++) {
                var f = c[e];
                if (!ya(f) || u(f) && f.nodeType > 0) d(f);
                else {
                    a: {
                        if (f && typeof f.length == "number") {
                            if (u(f)) {
                                var g = typeof f.item == "function" || typeof f.item == "string";
                                break a
                            }
                            if (typeof f === "function") {
                                g = typeof f.item == "function";
                                break a
                            }
                        }
                        g = !1
                    }
                    A(g ? Zb(f) : f, d)
                }
            }
        },
        jd = function(a, b) {
            b = String(b);
            a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
            return a.createElement(b)
        },
        kd = function(a) {
            for (var b; b = a.firstChild;) a.removeChild(b)
        },
        ld = function(a) {
            return a && a.parentNode ? a.parentNode.removeChild(a) : null
        },
        md = function(a) {
            y(a, "Node cannot be null or undefined.");
            return a.nodeType == 9 ? a : a.ownerDocument || a.document
        },
        nd = function(a) {
            this.We = a || r.document || document
        };
    k = nd.prototype;
    k.getElementsByTagName = function(a, b) {
        return (b || this.We).getElementsByTagName(String(a))
    };
    k.createElement = function(a) {
        return jd(this.We, a)
    };
    k.createTextNode = function(a) {
        return this.We.createTextNode(String(a))
    };
    k.getWindow = function() {
        return this.We.defaultView
    };
    k.appendChild = function(a, b) {
        y(a != null && b != null, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    k.append = function(a, b) {
        id(md(a), a, arguments)
    };
    k.canHaveChildren = function(a) {
        if (a.nodeType != 1) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    k.removeNode = ld;
    k.isElement = function(a) {
        return u(a) && a.nodeType == 1
    };
    k.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    /*
     gapi.loader.OBJECT_CREATE_TEST_OVERRIDE &&*/
    var E = window,
        od = document,
        pd = /\[native code\]/,
        qd = function(a, b, c) {
            return a[b] = a[b] || c
        },
        rd = function(a) {
            return !!a && typeof a === "object" && pd.test(a.push)
        },
        sd = function(a) {
            for (var b = 0; b < this.length; b++)
                if (this[b] === a) return b;
            return -1
        },
        ud = function(a, b, c) {
            if (a)
                if (rd(a)) {
                    if (a) {
                        F(rd(a), "arrayForEach was called with a non array value");
                        for (var d = 0; d < a.length; d++) b.call(c, a[d], d)
                    }
                } else
                    for (d in F(typeof a === "object", "objectForEach was called with a non object value"), c = c || a, a) td(a, d) && a[d] !== void 0 && b.call(c,
                        a[d], d)
        },
        vd = /&/g,
        wd = /</g,
        xd = />/g,
        yd = /"/g,
        zd = /'/g,
        Ad = function(a) {
            return String(a).replace(vd, "&amp;").replace(wd, "&lt;").replace(xd, "&gt;").replace(yd, "&quot;").replace(zd, "&#39;")
        },
        Bd = function() {
            var a;
            if ((a = Object.create) && pd.test(a)) a = a(null);
            else {
                a = {};
                for (var b in a) a[b] = void 0
            }
            return a
        },
        td = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        Cd = function(a, b) {
            a = a || {};
            for (var c in a) td(a, c) && (b[c] = a[c])
        },
        F = function(a, b) {
            if (!a) throw Error(b || "");
        },
        Dd = qd(E, "gapi", {});
    var Ed = function(a, b, c) {
            var d = new RegExp("([#].*&|[#])" + b + "=([^&#]*)", "g");
            b = new RegExp("([?#].*&|[?#])" + b + "=([^&#]*)", "g");
            if (a = a && (d.exec(a) || b.exec(a))) try {
                c = decodeURIComponent(a[2])
            } catch (e) {}
            return c
        },
        Fd = new RegExp(/^/.source + /([a-zA-Z][-+.a-zA-Z0-9]*:)?/.source + /(\/\/[^\/?#]*)?/.source + /([^?#]*)?/.source + /(\?([^#]*))?/.source + /(#((#|[^#])*))?/.source + /$/.source),
        Gd = /[\ud800-\udbff][\udc00-\udfff]|[^!-~]/g,
        Hd = new RegExp(/(%([^0-9a-fA-F%]|[0-9a-fA-F]([^0-9a-fA-F%])?)?)*/.source + /%($|[^0-9a-fA-F]|[0-9a-fA-F]($|[^0-9a-fA-F]))/.source,
            "g"),
        Id = /%([a-f]|[0-9a-fA-F][a-f])/g,
        Jd = /^(https?|ftp|file|chrome-extension):$/i,
        Kd = function(a) {
            a = String(a);
            a = a.replace(Gd, function(e) {
                try {
                    return encodeURIComponent(e)
                } catch (f) {
                    return encodeURIComponent(e.replace(/^[^%]+$/g, "\ufffd"))
                }
            }).replace(Hd, function(e) {
                return e.replace(/%/g, "%25")
            }).replace(Id, function(e) {
                return e.toUpperCase()
            });
            a = a.match(Fd) || [];
            var b = Bd(),
                c = function(e) {
                    return e.replace(/\\/g, "%5C").replace(/\^/g, "%5E").replace(/`/g, "%60").replace(/\{/g, "%7B").replace(/\|/g, "%7C").replace(/\}/g,
                        "%7D")
                },
                d = !!(a[1] || "").match(Jd);
            b.Vd = c((a[1] || "") + (a[2] || "") + (a[3] || (a[2] && d ? "/" : "")));
            d = function(e) {
                return c(e.replace(/\?/g, "%3F").replace(/#/g, "%23"))
            };
            b.query = a[5] ? [d(a[5])] : [];
            b.fragment = a[7] ? [d(a[7])] : [];
            return b
        },
        Ld = function(a) {
            return a.Vd + (a.query.length > 0 ? "?" + a.query.join("&") : "") + (a.fragment.length > 0 ? "#" + a.fragment.join("&") : "")
        },
        Md = function(a, b) {
            var c = [];
            if (a)
                for (var d in a)
                    if (td(a, d) && a[d] != null) {
                        var e = b ? b(a[d]) : a[d];
                        c.push(encodeURIComponent(d) + "=" + encodeURIComponent(e))
                    }
            return c
        },
        Nd =
        new RegExp(/\/?\??#?/.source + "(" + /[\/?#]/i.source + "|" + /[\uD800-\uDBFF]/i.source + "|" + /%[c-f][0-9a-f](%[89ab][0-9a-f]){0,2}(%[89ab]?)?/i.source + "|" + /%[0-9a-f]?/i.source + ")$", "i"),
        Od = function(a, b) {
            var c = Kd(b);
            b = c.Vd;
            c.query.length && (b += "?" + c.query.join(""));
            c.fragment.length && (b += "#" + c.fragment.join(""));
            var d = "";
            b.length > 2E3 && (d = b, b = b.substr(0, 2E3), b = b.replace(Nd, ""), d = d.substr(b.length));
            var e = a.createElement("div");
            a = a.createElement("a");
            c = Kd(b);
            b = c.Vd;
            c.query.length && (b += "?" + c.query.join(""));
            c.fragment.length &&
                (b += "#" + c.fragment.join(""));
            b = b === null ? "null" : b === void 0 ? "undefined" : b;
            if (typeof b !== "string") throw Error("Expected a string");
            b = new vb(b);
            b = Eb(b);
            b !== void 0 && (a.href = b);
            e.appendChild(a);
            a = e.innerHTML;
            Hc("Assignment to self.");
            a = qb(a);
            if (e.nodeType === 1 && (b = e.tagName, /^(script|style)$/i.test(b))) throw d = b.toLowerCase() === "script" ? "Use setScriptTextContent with a SafeScript." : "Use setStyleTextContent with a SafeStyleSheet.", Error(d);
            e.innerHTML = rb(a);
            b = String(e.firstChild.href);
            e.parentNode && e.parentNode.removeChild(e);
            c = Kd(b + d);
            d = c.Vd;
            c.query.length && (d += "?" + c.query.join(""));
            c.fragment.length && (d += "#" + c.fragment.join(""));
            return d
        },
        Pd = /^https?:\/\/[^\/%\\?#\s]+\/[^\s]*$/i;
    var Rd = function(a, b, c) {
            Qd(a, b, c, "add", "at")
        },
        Qd = function(a, b, c, d, e) {
            if (a[d + "EventListener"]) a[d + "EventListener"](b, c, !1);
            else if (a[e + "tachEvent"]) a[e + "tachEvent"]("on" + b, c)
        },
        Sd = function(a) {
            for (; a.firstChild;) a.removeChild(a.firstChild)
        };
    var Td = function(a) {
        var b = window.___jsl = window.___jsl || {};
        b.cfg = b.cfg || {};
        b = b.cfg;
        if (!a) return b;
        a = a.split("/");
        for (var c = 0, d = a.length; b && typeof b === "object" && c < d; ++c) b = b[a[c]];
        return c === a.length && b !== void 0 ? b : void 0
    };
    var Ud = /^https?:\/\/(?:\w|[\-\.])+\.google\.(?:\w|[\-:\.])+(?:\/[^\?#]*)?\/u\/(\d)\//,
        Vd = /^https?:\/\/(?:\w|[\-\.])+\.google\.(?:\w|[\-:\.])+(?:\/[^\?#]*)?\/b\/(\d{10,21})\//,
        Wd = function() {
            var a = Td("googleapis.config/sessionIndex");
            "string" === typeof a && a.length > 254 && (a = null);
            a == null && (a = window.__X_GOOG_AUTHUSER);
            "string" === typeof a && a.length > 254 && (a = null);
            if (a == null) {
                var b = window.google;
                b && (a = b.authuser)
            }
            "string" === typeof a && a.length > 254 && (a = null);
            a == null && (b = window.location.href, a = Ed(b, "authuser") ||
                null, a == null && (a = (a = b.match(Ud)) ? a[1] : null));
            if (a == null) return null;
            a = String(a);
            a.length > 254 && (a = null);
            return a
        },
        Xd = function() {
            var a = Td("googleapis.config/sessionDelegate");
            "string" === typeof a && a.length > 21 && (a = null);
            a == null && (a = (a = window.location.href.match(Vd)) ? a[1] : null);
            if (a == null) return null;
            a = String(a);
            a.length > 21 && (a = null);
            return a
        };
    var Yd = {};
    Yd = qd(E, "___jsl", Bd());
    qd(Yd, "I", 0);
    qd(Yd, "hel", 10);
    var Zd, $d, ae = void 0,
        be = function(a) {
            try {
                return r.JSON.parse.call(r.JSON, a)
            } catch (b) {
                return !1
            }
        },
        ce = function(a) {
            return Object.prototype.toString.call(a)
        },
        de = ce(0),
        ee = ce(new Date(0)),
        fe = ce(!0),
        ge = ce(""),
        he = ce({}),
        ie = ce([]),
        ke = function(a, b) {
            if (b)
                for (var c = 0, d = b.length; c < d; ++c)
                    if (a === b[c]) throw new TypeError("Converting circular structure to JSON");
            d = typeof a;
            if (d !== "undefined") {
                c = Array.prototype.slice.call(b || [], 0);
                c[c.length] = a;
                b = [];
                var e = ce(a);
                if (a != null && typeof a.toJSON === "function" && (Object.prototype.hasOwnProperty.call(a,
                        "toJSON") || (e !== ie || a.constructor !== Array && a.constructor !== Object) && (e !== he || a.constructor !== Array && a.constructor !== Object) && e !== ge && e !== de && e !== fe && e !== ee)) return ke(a.toJSON.call(a), c);
                if (a == null) b[b.length] = "null";
                else if (e === de) a = Number(a), isNaN(a) || isNaN(a - a) ? a = "null" : a === -0 && 1 / a < 0 && (a = "-0"), b[b.length] = String(a);
                else if (e === fe) b[b.length] = String(!!Number(a));
                else {
                    if (e === ee) return ke(a.toISOString.call(a), c);
                    if (e === ie && ce(a.length) === de) {
                        b[b.length] = "[";
                        var f = 0;
                        for (d = Number(a.length) >> 0; f < d; ++f) f &&
                            (b[b.length] = ","), b[b.length] = ke(a[f], c) || "null";
                        b[b.length] = "]"
                    } else if (e == ge && ce(a.length) === de) {
                        b[b.length] = '"';
                        f = 0;
                        for (c = Number(a.length) >> 0; f < c; ++f) d = String.prototype.charAt.call(a, f), e = String.prototype.charCodeAt.call(a, f), b[b.length] = d === "\b" ? "\\b" : d === "\f" ? "\\f" : d === "\n" ? "\\n" : d === "\r" ? "\\r" : d === "\t" ? "\\t" : d === "\\" || d === '"' ? "\\" + d : e <= 31 ? "\\u" + (e + 65536).toString(16).substr(1) : e >= 32 && e <= 65535 ? d : "\ufffd";
                        b[b.length] = '"'
                    } else if (d === "object") {
                        b[b.length] = "{";
                        d = 0;
                        for (f in a) Object.prototype.hasOwnProperty.call(a,
                            f) && (e = ke(a[f], c), e !== void 0 && (d++ && (b[b.length] = ","), b[b.length] = ke(f), b[b.length] = ":", b[b.length] = e));
                        b[b.length] = "}"
                    } else return
                }
                return b.join("")
            }
        },
        le = /[\0-\x07\x0b\x0e-\x1f]/,
        me = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*[\0-\x1f]/,
        ne = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\[^\\\/"bfnrtu]/,
        oe = /^([^"]*"([^\\"]|\\.)*")*[^"]*"([^"\\]|\\.)*\\u([0-9a-fA-F]{0,3}[^0-9a-fA-F])/,
        pe = /"([^\0-\x1f\\"]|\\[\\\/"bfnrt]|\\u[0-9a-fA-F]{4})*"/g,
        qe = /-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?/g,
        re = /[ \t\n\r]+/g,
        se = /[^"]:/,
        te = /""/g,
        ue = /true|false|null/g,
        ve = /00/,
        we = /[\{]([^0\}]|0[^:])/,
        xe = /(^|\[)[,:]|[,:](\]|\}|[,:]|$)/,
        ye = /[^\[,:][\[\{]/,
        ze = /^(\{|\}|\[|\]|,|:|0)+/,
        Ae = /\u2028/g,
        Be = /\u2029/g,
        Ce = function(a) {
            a = String(a);
            if (le.test(a) || me.test(a) || ne.test(a) || oe.test(a)) return !1;
            var b = a.replace(pe, '""');
            b = b.replace(qe, "0");
            b = b.replace(re, "");
            if (se.test(b)) return !1;
            b = b.replace(te, "0");
            b = b.replace(ue, "0");
            if (ve.test(b) || we.test(b) || xe.test(b) || ye.test(b) || !b || (b = b.replace(ze, ""))) return !1;
            a = a.replace(Ae, "\\u2028").replace(Be,
                "\\u2029");
            b = void 0;
            try {
                b = ae ? [be(a)] : eval("(function (var_args) {\n  return Array.prototype.slice.call(arguments, 0);\n})(\n" + a + "\n)")
            } catch (c) {
                return !1
            }
            return b && b.length === 1 ? b[0] : !1
        },
        De = function() {
            var a = ((r.document || {}).scripts || []).length;
            if ((Zd === void 0 || ae === void 0 || $d !== a) && $d !== -1) {
                Zd = ae = !1;
                $d = -1;
                try {
                    try {
                        ae = !!r.JSON && r.JSON.stringify.call(r.JSON, {
                            a: [3, !0, new Date(0)],
                            c: function() {}
                        }) === '{"a":[3,true,"1970-01-01T00:00:00.000Z"]}' && be("true") === !0 && be('[{"a":3}]')[0].a === 3
                    } catch (b) {}
                    Zd = ae &&
                        !be("[00]") && !be('"\u0007"') && !be('"\\0"') && !be('"\\v"')
                } finally {
                    $d = a
                }
            }
        },
        Ee = function(a) {
            if ($d === -1) return !1;
            De();
            return (Zd ? be : Ce)(a)
        },
        Fe = function(a) {
            if ($d !== -1) return De(), ae ? r.JSON.stringify.call(r.JSON, a) : ke(a)
        },
        Ge = !Date.prototype.toISOString || typeof Date.prototype.toISOString !== "function" || (new Date(0)).toISOString() !== "1970-01-01T00:00:00.000Z",
        He = function() {
            var a = Date.prototype.getUTCFullYear.call(this);
            return [a < 0 ? "-" + String(1E6 - a).substr(1) : a <= 9999 ? String(1E4 + a).substr(1) : "+" + String(1E6 + a).substr(1),
                "-", String(101 + Date.prototype.getUTCMonth.call(this)).substr(1), "-", String(100 + Date.prototype.getUTCDate.call(this)).substr(1), "T", String(100 + Date.prototype.getUTCHours.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCMinutes.call(this)).substr(1), ":", String(100 + Date.prototype.getUTCSeconds.call(this)).substr(1), ".", String(1E3 + Date.prototype.getUTCMilliseconds.call(this)).substr(1), "Z"
            ].join("")
        };
    Date.prototype.toISOString = Ge ? He : Date.prototype.toISOString;
    var Ie = function() {
        if (!r.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            var c = function() {};
            r.addEventListener("test", c, b);
            r.removeEventListener("test", c, b)
        } catch (d) {}
        return a
    }();

    function Je() {
        this.blockSize = -1
    };
    var Ke = function() {
        this.blockSize = -1;
        this.blockSize = 64;
        this.Aa = [];
        this.lg = [];
        this.ak = [];
        this.Bf = [];
        this.Bf[0] = 128;
        for (var a = 1; a < this.blockSize; ++a) this.Bf[a] = 0;
        this.kc = this.wd = 0;
        this.reset()
    };
    q(Ke, Je);
    Ke.prototype.reset = function() {
        this.Aa[0] = 1732584193;
        this.Aa[1] = 4023233417;
        this.Aa[2] = 2562383102;
        this.Aa[3] = 271733878;
        this.Aa[4] = 3285377520;
        this.kc = this.wd = 0
    };
    var Le = function(a, b, c) {
        c || (c = 0);
        var d = a.ak;
        if (typeof b === "string")
            for (var e = 0; e < 16; e++) d[e] = b.charCodeAt(c) << 24 | b.charCodeAt(c + 1) << 16 | b.charCodeAt(c + 2) << 8 | b.charCodeAt(c + 3), c += 4;
        else
            for (e = 0; e < 16; e++) d[e] = b[c] << 24 | b[c + 1] << 16 | b[c + 2] << 8 | b[c + 3], c += 4;
        for (b = 16; b < 80; b++) c = d[b - 3] ^ d[b - 8] ^ d[b - 14] ^ d[b - 16], d[b] = (c << 1 | c >>> 31) & 4294967295;
        b = a.Aa[0];
        c = a.Aa[1];
        e = a.Aa[2];
        for (var f = a.Aa[3], g = a.Aa[4], h, l, m = 0; m < 80; m++) m < 40 ? m < 20 ? (h = f ^ c & (e ^ f), l = 1518500249) : (h = c ^ e ^ f, l = 1859775393) : m < 60 ? (h = c & e | f & (c | e), l = 2400959708) : (h = c ^
            e ^ f, l = 3395469782), h = (b << 5 | b >>> 27) + h + g + l + d[m] & 4294967295, g = f, f = e, e = (c << 30 | c >>> 2) & 4294967295, c = b, b = h;
        a.Aa[0] = a.Aa[0] + b & 4294967295;
        a.Aa[1] = a.Aa[1] + c & 4294967295;
        a.Aa[2] = a.Aa[2] + e & 4294967295;
        a.Aa[3] = a.Aa[3] + f & 4294967295;
        a.Aa[4] = a.Aa[4] + g & 4294967295
    };
    Ke.prototype.update = function(a, b) {
        if (a != null) {
            b === void 0 && (b = a.length);
            for (var c = b - this.blockSize, d = 0, e = this.lg, f = this.wd; d < b;) {
                if (f == 0)
                    for (; d <= c;) Le(this, a, d), d += this.blockSize;
                if (typeof a === "string")
                    for (; d < b;) {
                        if (e[f] = a.charCodeAt(d), ++f, ++d, f == this.blockSize) {
                            Le(this, e);
                            f = 0;
                            break
                        }
                    } else
                        for (; d < b;)
                            if (e[f] = a[d], ++f, ++d, f == this.blockSize) {
                                Le(this, e);
                                f = 0;
                                break
                            }
            }
            this.wd = f;
            this.kc += b
        }
    };
    Ke.prototype.digest = function() {
        var a = [],
            b = this.kc * 8;
        this.wd < 56 ? this.update(this.Bf, 56 - this.wd) : this.update(this.Bf, this.blockSize - (this.wd - 56));
        for (var c = this.blockSize - 1; c >= 56; c--) this.lg[c] = b & 255, b /= 256;
        Le(this, this.lg);
        for (c = b = 0; c < 5; c++)
            for (var d = 24; d >= 0; d -= 8) a[b] = this.Aa[c] >> d & 255, ++b;
        return a
    };
    var Me = function() {
        this.Eh = new Ke
    };
    k = Me.prototype;
    k.reset = function() {
        this.Eh.reset()
    };
    k.updateByteArray = function(a) {
        this.Eh.update(a)
    };
    k.digestByteArray = function() {
        return this.Eh.digest()
    };
    k.updateString = function(a) {
        a = unescape(encodeURIComponent(a));
        for (var b = [], c = a.length, d = 0; d < c; ++d) b.push(a.charCodeAt(d));
        this.updateByteArray(b)
    };
    k.digestString = function() {
        for (var a = this.digestByteArray(), b = "", c = 0; c < a.length; c++) b += "0123456789ABCDEF".charAt(Math.floor(a[c] / 16)) + "0123456789ABCDEF".charAt(a[c] % 16);
        return b
    };
    var Ne = E.crypto,
        Oe = !1,
        Pe = 0,
        Qe = 0,
        Re = 1,
        Se = 0,
        Te = "",
        Ue = function(a) {
            a = a || E.event;
            var b = a.screenX + a.clientX << 16;
            b += a.screenY + a.clientY;
            b *= (new Date).getTime() % 1E6;
            Re = Re * b % Se;
            Pe > 0 && ++Qe == Pe && Qd(E, "mousemove", Ue, "remove", "de")
        },
        Ve = function(a) {
            var b = new Me;
            b.updateString(a);
            return b.digestString()
        };
    Oe = !!Ne && typeof Ne.getRandomValues == "function";
    Oe || (Se = (screen.width * screen.width + screen.height) * 1E6, Te = Ve(od.cookie + "|" + od.location + "|" + (new Date).getTime() + "|" + Math.random()), Pe = Td("random/maxObserveMousemove") || 0, Pe != 0 && Rd(E, "mousemove", Ue));
    var We = function() {
            var a = Yd.onl;
            if (!a) {
                a = Bd();
                Yd.onl = a;
                var b = Bd();
                a.e = function(c) {
                    var d = b[c];
                    d && (delete b[c], d())
                };
                a.a = function(c, d) {
                    b[c] = d
                };
                a.r = function(c) {
                    delete b[c]
                }
            }
            return a
        },
        Xe = function(a, b) {
            b = b.onload;
            return typeof b === "function" ? (We().a(a, b), b) : null
        },
        Ye = function(a) {
            F(/^\w+$/.test(a), "Unsupported id - " + a);
            return 'onload="window.___jsl.onl.e(&#34;' + a + '&#34;)"'
        },
        Ze = function(a) {
            We().r(a)
        };
    var $e = {
            allowtransparency: "true",
            frameborder: "0",
            hspace: "0",
            marginheight: "0",
            marginwidth: "0",
            scrolling: "no",
            style: "",
            tabindex: "0",
            vspace: "0",
            width: "100%"
        },
        af = {
            allowtransparency: !0,
            onload: !0
        },
        bf = 0,
        cf = function(a, b) {
            var c = 0;
            do var d = b.id || ["I", bf++, "_", (new Date).getTime()].join(""); while (a.getElementById(d) && ++c < 5);
            F(c < 5, "Error creating iframe id");
            return d
        },
        df = function(a, b) {
            return a ? b + "/" + a : ""
        },
        ef = function(a, b, c, d) {
            var e = {},
                f = {};
            a.documentMode && a.documentMode < 9 && (e.hostiemode = a.documentMode);
            Cd(d.queryParams || {}, e);
            Cd(d.fragmentParams || {}, f);
            var g = d.pfname;
            var h = Bd();
            Td("iframes/dropLegacyIdParam") || (h.id = c);
            h._gfid = c;
            h.parent = a.location.protocol + "//" + a.location.host;
            c = Ed(a.location.href, "parent");
            g = g || "";
            !g && c && (g = Ed(a.location.href, "_gfid", "") || Ed(a.location.href, "id", ""), g = df(g, Ed(a.location.href, "pfname", "")));
            g || (c = Ee(Ed(a.location.href, "jcp", ""))) && typeof c == "object" && (g = df(c.id, c.pfname));
            h.pfname = g;
            d.connectWithJsonParam && (g = {}, g.jcp = Fe(h), h = g);
            g = Ed(b, "rpctoken") || e.rpctoken || f.rpctoken;
            if (!g) {
                if (!(g =
                        d.rpctoken)) {
                    g = String;
                    c = Math;
                    var l = c.round;
                    if (Oe) {
                        var m = new E.Uint32Array(1);
                        Ne.getRandomValues(m);
                        m = Number("0." + m[0])
                    } else m = Re, m += parseInt(Te.substr(0, 20), 16), Te = Ve(Te), m /= Se + 1.2089258196146292E24;
                    g = g(l.call(c, m * 1E8))
                }
                h.rpctoken = g
            }
            d.rpctoken = g;
            Cd(h, d.connectWithQueryParams ? e : f);
            h = a.location.href;
            a = Bd();
            (g = Ed(h, "_bsh", Yd.bsh)) && (a._bsh = g);
            (h = Yd.dpo ? Yd.h : Ed(h, "jsh", Yd.h)) && (a.jsh = h);
            d.hintInFragment ? Cd(a, f) : Cd(a, e);
            d = d.paramsSerializer;
            b = Kd(b);
            b.query.push.apply(b.query, Md(e, d));
            b.fragment.push.apply(b.fragment,
                Md(f, d));
            return Ld(b)
        },
        ff = function(a) {
            F(!a || Pd.test(a), "Illegal url for new iframe - " + a)
        },
        gf = function(a, b, c, d, e) {
            ff(c.src);
            var f, g = Xe(d, c),
                h = g ? Ye(d) : "";
            try {
                document.all && (f = a.createElement('<iframe frameborder="' + Ad(String(c.frameborder)) + '" scrolling="' + Ad(String(c.scrolling)) + '" ' + h + ' name="' + Ad(String(c.name)) + '"/>'))
            } catch (m) {} finally {
                f || (f = (a ? new nd(md(a)) : Jb || (Jb = new nd)).createElement("IFRAME"), g && (f.onload = function() {
                    f.onload = null;
                    g.call(this)
                }, Ze(d)))
            }
            f.setAttribute("ng-non-bindable", "");
            for (var l in c) a = c[l], l === "style" && typeof a === "object" ? Cd(a, f.style) : af[l] || f.setAttribute(l, String(a));
            (l = e && e.beforeNode || null) || e && e.dontclear || Sd(b);
            b.insertBefore(f, l);
            f = l ? l.previousSibling : b.lastChild;
            c.allowtransparency && (f.allowTransparency = !0);
            return f
        };
    var hf = /^:[\w]+$/,
        jf = /:([a-zA-Z_]+):/g,
        kf = function(a, b) {
            a = Wd() || "0";
            var c = Xd();
            var d = Wd() || a;
            var e = Xd(),
                f = "";
            d && (f += "u/" + encodeURIComponent(String(d)) + "/");
            e && (f += "b/" + encodeURIComponent(String(e)) + "/");
            d = f || null;
            (f = (e = Td("isLoggedIn") === !1) ? "_/im/" : "") && (d = "");
            var g = Td("iframes/:socialhost:"),
                h = Td("iframes/:im_socialhost:");
            Da = {
                socialhost: g,
                ctx_socialhost: e ? h : g,
                session_index: a,
                session_delegate: c,
                session_prefix: d,
                im_prefix: f
            };
            return Da[b] || ""
        },
        lf = function(a) {
            var b = a;
            hf.test(a) && (b = Td("iframes/" + b.substring(1) +
                "/url"), F(!!b, "Unknown iframe url config for - " + a));
            return Od(od, b.replace(jf, kf))
        },
        mf = function(a, b, c) {
            c = c || {};
            var d = c.attributes || {};
            F(!(c.allowPost || c.forcePost) || !d.onload, "onload is not supported by post iframe (allowPost or forcePost)");
            a = lf(a);
            d = b.ownerDocument || od;
            var e = cf(d, c);
            a = ef(d, a, e, c);
            var f = c,
                g = Bd();
            Cd($e, g);
            Cd(f.attributes, g);
            g.name = g.id = e;
            g.src = a;
            c.eurl = a;
            c = (f = c) || {};
            var h = !!c.allowPost;
            if (c.forcePost || h && a.length > 2E3) {
                c = Kd(a);
                g.src = "";
                f.dropDataPostorigin || (g["data-postorigin"] =
                    a);
                a = gf(d, b, g, e);
                if (navigator.userAgent.indexOf("WebKit") != -1) {
                    var l = a.contentWindow.document;
                    l.open();
                    g = l.createElement("div");
                    h = {};
                    var m = e + "_inner";
                    h.name = m;
                    h.src = "";
                    h.style = "display:none";
                    gf(d, g, h, m, f)
                }
                g = (f = c.query[0]) ? f.split("&") : [];
                f = [];
                for (h = 0; h < g.length; h++) m = g[h].split("=", 2), f.push([decodeURIComponent(m[0]), decodeURIComponent(m[1])]);
                c.query = [];
                g = Ld(c);
                F(Pd.test(g), "Invalid URL: " + g);
                c = d.createElement("form");
                c.method = "POST";
                c.target = e;
                c.style.display = "none";
                e = Eb(g);
                e !== void 0 && (c.action =
                    e);
                for (e = 0; e < f.length; e++) g = d.createElement("input"), g.type = "hidden", g.name = f[e][0], g.value = f[e][1], c.appendChild(g);
                b.appendChild(c);
                c.submit();
                c.parentNode.removeChild(c);
                l && l.close();
                b = a
            } else b = gf(d, b, g, e, f);
            return b
        };
    window.osapi = window.osapi || {};
    window.___jsl = window.___jsl || {};
    (window.___jsl.cd = window.___jsl.cd || []).push({
        gwidget: {
            parsetags: "explicit"
        },
        appsapi: {
            plus_one_service: "/plus/v1"
        },
        csi: {
            rate: .01
        },
        poshare: {
            hangoutContactPickerServer: "https://plus.google.com"
        },
        gappsutil: {
            required_scopes: ["https://www.googleapis.com/auth/plus.me", "https://www.googleapis.com/auth/plus.people.recommended"],
            display_on_page_ready: !1
        },
        appsutil: {
            required_scopes: ["https://www.googleapis.com/auth/plus.me", "https://www.googleapis.com/auth/plus.people.recommended"],
            display_on_page_ready: !1
        },
        "oauth-flow": {
            authUrl: "https://accounts.google.com/o/oauth2/auth",
            proxyUrl: "https://accounts.google.com/o/oauth2/postmessageRelay",
            redirectUri: "postmessage"
        },
        iframes: {
            sharebox: {
                params: {
                    json: "&"
                },
                url: ":socialhost:/:session_prefix:_/sharebox/dialog"
            },
            plus: {
                url: ":socialhost:/:session_prefix:_/widget/render/badge?usegapi=1"
            },
            ":socialhost:": "https://apis.google.com",
            ":im_socialhost:": "https://plus.googleapis.com",
            domains_suggest: {
                url: "https://domains.google.com/suggest/flow"
            },
            card: {
                params: {
                    s: "#",
                    userid: "&"
                },
                url: ":socialhost:/:session_prefix:_/hovercard/internalcard"
            },
            ":signuphost:": "https://plus.google.com",
            ":gplus_url:": "https://plus.google.com",
            plusone: {
                url: ":socialhost:/:session_prefix:_/+1/fastbutton?usegapi=1"
            },
            plus_share: {
                url: ":socialhost:/:session_prefix:_/+1/sharebutton?plusShare=true&usegapi=1"
            },
            plus_circle: {
                url: ":socialhost:/:session_prefix:_/widget/plus/circle?usegapi=1"
            },
            plus_followers: {
                url: ":socialhost:/_/im/_/widget/render/plus/followers?usegapi=1"
            },
            configurator: {
                url: ":socialhost:/:session_prefix:_/plusbuttonconfigurator?usegapi=1"
            },
            appcirclepicker: {
                url: ":socialhost:/:session_prefix:_/widget/render/appcirclepicker"
            },
            page: {
                url: ":socialhost:/:session_prefix:_/widget/render/page?usegapi=1"
            },
            person: {
                url: ":socialhost:/:session_prefix:_/widget/render/person?usegapi=1"
            },
            community: {
                url: ":ctx_socialhost:/:session_prefix::im_prefix:_/widget/render/community?usegapi=1"
            },
            follow: {
                url: ":socialhost:/:session_prefix:_/widget/render/follow?usegapi=1"
            },
            commentcount: {
                url: ":socialhost:/:session_prefix:_/widget/render/commentcount?usegapi=1"
            },
            comments: {
                url: ":socialhost:/:session_prefix:_/widget/render/comments?usegapi=1"
            },
            youtube: {
                url: ":socialhost:/:session_prefix:_/widget/render/youtube?usegapi=1"
            },
            reportabuse: {
                url: ":socialhost:/:session_prefix:_/widget/render/reportabuse?usegapi=1"
            },
            additnow: {
                url: ":socialhost:/additnow/additnow.html"
            },
            appfinder: {
                url: "https://workspace.google.com/:session_prefix:marketplace/appfinder?usegapi=1"
            },
            ":source:": "1p"
        },
        poclient: {
            update_session: "google.updateSessionCallback"
        },
        "googleapis.config": {
            rpc: "/rpc",
            root: "https://content.googleapis.com",
            "root-1p": "https://clients6.google.com",
            useGapiForXd3: !0,
            xd3: "/static/proxy.html",
            auth: {
                useInterimAuth: !1
            }
        },
        report: {
            apis: ["iframes\\..*", "gadgets\\..*", "gapi\\.appcirclepicker\\..*", "gapi\\.client\\..*"],
            rate: 1E-4
        },
        client: {
            perApiBatch: !0
        }
    });
    var nf = function(a) {
            var b = window.___jsl = window.___jsl || {};
            b[a] = b[a] || [];
            return b[a]
        },
        of = function(a) {
            var b = window.___jsl = window.___jsl || {};
            b.cfg = !a && b.cfg || {};
            return b.cfg
        },
        pf = function(a) {
            return typeof a === "object" && /\[native code\]/.test(a.push)
        },
        qf = function(a, b, c) {
            if (b && typeof b === "object")
                for (var d in b) !Object.prototype.hasOwnProperty.call(b, d) || c && d === "___goc" && typeof b[d] === "undefined" || (a[d] && b[d] && typeof a[d] === "object" && typeof b[d] === "object" && !pf(a[d]) && !pf(b[d]) ? qf(a[d], b[d]) : b[d] && typeof b[d] ===
                    "object" ? (a[d] = pf(b[d]) ? [] : {}, qf(a[d], b[d])) : a[d] = b[d])
        },
        tf = function(a, b) {
            if (a && !/^\s+$/.test(a)) {
                for (; a.charCodeAt(a.length - 1) == 0;) a = a.substring(0, a.length - 1);
                var c = "" + a,
                    d = nf("dm");
                d.push(20);
                try {
                    var e = window.JSON.parse(a)
                } catch (g) {}
                if (typeof e === "object") return d.push(21), e;
                try {
                    e = window.JSON.parse("{" + a + "}")
                } catch (g) {}
                if (typeof e === "object") return d.push(22), e;
                a = a.replace(RegExp("([^\"',{}\\s]+?)\\s*:\\s*(.*?)[,}\\s]", "g"), function(g, h, l) {
                    l = l.startsWith('"') ? "%DOUBLE_QUOTE%" + l.substring(1) : l;
                    l =
                        l.endsWith('"') ? l.slice(0, -1) + "%DOUBLE_QUOTE%" : l;
                    return "%DOUBLE_QUOTE%" + h + "%DOUBLE_QUOTE%:" + l
                });
                a = a.replace(/\\'/g, "%SINGLE_QUOTE%");
                a = a.replace(/"/g, '\\"');
                a = a.replace(/'/g, '"');
                a = a.replace(/%SINGLE_QUOTE%/g, "'");
                a = a.replace(/%DOUBLE_QUOTE%/g, '"');
                try {
                    e = window.JSON.parse(a)
                } catch (g) {}
                if (typeof e === "object") return d.push(23), e;
                try {
                    e = window.JSON.parse("{" + a + "}")
                } catch (g) {}
                if (typeof e === "object") return d.push(24), e;
                a = document.getElementsByTagName("script") || [];
                var f;
                a.length > 0 && (f = a[0].nonce || a[0].getAttribute("nonce"));
                if (f && f === b || !f && rf())
                    if (e = sf(c), d.push(25), typeof e === "object") return e;
                return {}
            }
        },
        rf = function() {
            var a = window.location.hostname;
            return a ? /(^|\.)(2mdn|ampproject|android|appspot|blogger|blogspot|chrome|chromium|doubleclick|gcpnode|ggpht|gmail|google|google-analytics|googleadservices|googleapis|googleapis-cn|googleoptimize|googlers|googlesource|googlesyndication|googletagmanager|googletagservices|googleusercontent|googlevideo|gstatic|tiltbrush|waze|withgoogle|youtube|ytimg)(\.com?|\.net|\.org)?(\.[a-z][a-z]|\.cat)?$/.test(a) :
                !1
        },
        sf = function(a) {
            try {
                var b = (new Function("return (" + a + "\n)"))()
            } catch (c) {}
            if (typeof b === "object") return b;
            try {
                b = (new Function("return ({" + a + "\n})"))()
            } catch (c) {}
            return b
        },
        uf = function(a, b) {
            var c = {
                ___goc: void 0
            };
            a.length && a[a.length - 1] && Object.hasOwnProperty.call(a[a.length - 1], "___goc") && typeof a[a.length - 1].___goc === "undefined" && (c = a.pop());
            qf(c, b);
            a.push(c)
        },
        vf = function(a) { of (!0);
            var b = window.___gcfg,
                c = nf("cu"),
                d = window.___gu;
            b && b !== d && (uf(c, b), window.___gu = b);
            b = nf("cu");
            var e = document.getElementsByTagName("script") || [];
            d = [];
            var f = [];
            f.push.apply(f, nf("us"));
            for (var g = 0; g < e.length; ++g)
                for (var h = e[g], l = 0; l < f.length; ++l) h.src && h.src.indexOf(f[l]) == 0 && d.push(h);
            d.length == 0 && e.length > 0 && e[e.length - 1].src && d.push(e[e.length - 1]);
            for (e = 0; e < d.length; ++e) d[e].getAttribute("gapi_processed") || (d[e].setAttribute("gapi_processed", !0), (f = d[e]) ? (g = f.nodeType, f = g == 3 || g == 4 ? f.nodeValue : f.textContent || "") : f = void 0, g = d[e].nonce || d[e].getAttribute("nonce"), (f = tf(f, g)) && b.push(f));
            a && uf(c, a);
            d = nf("cd");
            a = 0;
            for (b = d.length; a < b; ++a) qf( of (),
                d[a], !0);
            d = nf("ci");
            a = 0;
            for (b = d.length; a < b; ++a) qf( of (), d[a], !0);
            a = 0;
            for (b = c.length; a < b; ++a) qf( of (), c[a], !0)
        };
    var wf = function() {
        var a = window.__GOOGLEAPIS;
        a && (a.googleapis && !a["googleapis.config"] && (a["googleapis.config"] = a.googleapis), qd(Yd, "ci", []).push(a), window.__GOOGLEAPIS = void 0)
    };
    wf && wf();
    vf();
    t("gapi.config.get", function(a, b) {
        var c = of ();
        if (!a) return c;
        a = a.split("/");
        for (var d = 0, e = a.length; c && typeof c === "object" && d < e; ++d) c = c[a[d]];
        return d === a.length && c !== void 0 ? c : b
    });
    t("gapi.config.update", function(a, b) {
        var c;
        if (typeof a === "string") {
            var d = c = {};
            a = a.split("/");
            for (var e = 0, f = a.length; e < f - 1; ++e) {
                var g = {};
                d = d[a[e]] = g
            }
            d[a[e]] = b
        } else c = a;
        vf(c)
    });
    var xf = function(a) {
        if (!a) return "";
        if (/^about:(?:blank|srcdoc)$/.test(a)) return window.origin || "";
        a.indexOf("blob:") === 0 && (a = a.substring(5));
        a = a.split("#")[0].split("?")[0];
        a = a.toLowerCase();
        a.indexOf("//") == 0 && (a = window.location.protocol + a);
        /^[\w\-]*:\/\//.test(a) || (a = window.location.href);
        var b = a.substring(a.indexOf("://") + 3),
            c = b.indexOf("/");
        c != -1 && (b = b.substring(0, c));
        c = a.substring(0, a.indexOf("://"));
        if (!c) throw Error("URI is missing protocol: " + a);
        if (c !== "http" && c !== "https" && c !== "chrome-extension" &&
            c !== "moz-extension" && c !== "file" && c !== "android-app" && c !== "chrome-search" && c !== "chrome-untrusted" && c !== "chrome" && c !== "app" && c !== "devtools") throw Error("Invalid URI scheme in origin: " + c);
        a = "";
        var d = b.indexOf(":");
        if (d != -1) {
            var e = b.substring(d + 1);
            b = b.substring(0, d);
            if (c === "http" && e !== "80" || c === "https" && e !== "443") a = ":" + e
        }
        return c + "://" + b + a
    };
    var Af = function(a) {
        this.nb = a;
        this.Context = yf(a);
        this.Iframe = zf(a)
    };
    k = Af.prototype;
    k.CROSS_ORIGIN_IFRAMES_FILTER = function(a) {
        return this.nb().CROSS_ORIGIN_IFRAMES_FILTER(a)
    };
    k.SAME_ORIGIN_IFRAMES_FILTER = function(a) {
        return this.nb().SAME_ORIGIN_IFRAMES_FILTER(a)
    };
    k.create = function(a, b, c) {
        return this.nb().create(a, b, c)
    };
    k.getBeforeOpenStyle = function(a) {
        return this.nb().getBeforeOpenStyle(a)
    };
    k.getContext = function() {
        return this.nb().getContext()
    };
    k.getStyle = function(a) {
        return this.nb().getStyle(a)
    };
    k.makeWhiteListIframesFilter = function(a) {
        return this.nb().makeWhiteListIframesFilter(a)
    };
    k.registerBeforeOpenStyle = function(a, b) {
        return this.nb().registerBeforeOpenStyle(a, b)
    };
    k.registerIframesApi = function(a, b, c) {
        return this.nb().registerIframesApi(a, b, c)
    };
    k.registerIframesApiHandler = function(a, b, c) {
        return this.nb().registerIframesApiHandler(a, b, c)
    };
    k.registerStyle = function(a, b) {
        return this.nb().registerStyle(a, b)
    };

    function yf(a) {
        var b = function(c) {
            return new(a().Context)(c)
        };
        b.prototype.addOnConnectHandler = function(c, d, e, f) {
            return a().Context.prototype.addOnConnectHandler.apply(this, [c, d, e, f])
        };
        b.prototype.addOnOpenerHandler = function(c, d, e) {
            return a().Context.prototype.addOnOpenerHandler.apply(this, [c, d, e])
        };
        b.prototype.closeSelf = function(c, d, e) {
            return a().Context.prototype.closeSelf.apply(this, [c, d, e])
        };
        b.prototype.connectIframes = function(c, d) {
            a().Context.prototype.connectIframes.apply(this, [c, d])
        };
        b.prototype.getFrameName =
            function() {
                return a().Context.prototype.getFrameName.apply(this)
            };
        b.prototype.getGlobalParam = function(c) {
            a().Context.prototype.getGlobalParam.apply(this, [c])
        };
        b.prototype.getParentIframe = function() {
            return a().Context.prototype.getParentIframe.apply(this)
        };
        b.prototype.getWindow = function() {
            return a().Context.prototype.getWindow.apply(this)
        };
        b.prototype.isDisposed = function() {
            return a().Context.prototype.isDisposed.apply(this)
        };
        b.prototype.open = function(c, d) {
            return a().Context.prototype.open.apply(this, [c, d])
        };
        b.prototype.openChild = function(c) {
            return a().Context.prototype.openChild.apply(this, [c])
        };
        b.prototype.ready = function(c, d, e, f) {
            a().Context.prototype.ready.apply(this, [c, d, e, f])
        };
        b.prototype.removeOnConnectHandler = function(c) {
            a().Context.prototype.removeOnConnectHandler.apply(this, [c])
        };
        b.prototype.restyleSelf = function(c, d, e) {
            return a().Context.prototype.restyleSelf.apply(this, [c, d, e])
        };
        b.prototype.setCloseSelfFilter = function(c) {
            a().Context.prototype.setCloseSelfFilter.apply(this, [c])
        };
        b.prototype.setGlobalParam =
            function(c, d) {
                a().Context.prototype.setGlobalParam.apply(this, [c, d])
            };
        b.prototype.setRestyleSelfFilter = function(c) {
            a().Context.prototype.setRestyleSelfFilter.apply(this, [c])
        };
        return b
    }

    function zf(a) {
        var b = function(c, d, e, f) {
            return new(a().Iframe)(c, d, e, f)
        };
        b.prototype.applyIframesApi = function(c) {
            a().Iframe.prototype.applyIframesApi(c)
        };
        b.prototype.close = function(c, d) {
            return a().Iframe.prototype.close.apply(this, [c, d])
        };
        b.prototype.getContext = function() {
            return a().Iframe.prototype.getContext.apply(this, [])
        };
        b.prototype.getFrameName = function() {
            return a().Iframe.prototype.getFrameName.apply(this, [])
        };
        b.prototype.getId = function() {
            return a().Iframe.prototype.getId.apply(this, [])
        };
        b.prototype.getIframeEl =
            function() {
                return a().Iframe.prototype.getIframeEl.apply(this, [])
            };
        b.prototype.getOrigin = function() {
            return a().Iframe.prototype.getOrigin.apply(this, [])
        };
        b.prototype.getParam = function(c) {
            a().Iframe.prototype.getParam.apply(this, [c])
        };
        b.prototype.getSiteEl = function() {
            return a().Iframe.prototype.getSiteEl.apply(this, [])
        };
        b.prototype.getWindow = function() {
            return a().Iframe.prototype.getWindow.apply(this, [])
        };
        b.prototype.isDisposed = function() {
            return a().Iframe.prototype.isDisposed.apply(this, [])
        };
        b.prototype.ping =
            function(c, d) {
                return a().Iframe.prototype.ping.apply(this, [c, d])
            };
        b.prototype.register = function(c, d, e) {
            a().Iframe.prototype.register.apply(this, [c, d, e])
        };
        b.prototype.registerWasClosed = function(c, d) {
            a().Iframe.prototype.registerWasClosed.apply(this, [c, d])
        };
        b.prototype.registerWasRestyled = function(c, d) {
            a().Iframe.prototype.registerWasRestyled.apply(this, [c, d])
        };
        b.prototype.restyle = function(c, d) {
            return a().Iframe.prototype.restyle.apply(this, [c, d])
        };
        b.prototype.send = function(c, d, e, f) {
            return a().Iframe.prototype.send.apply(this, [c, d, e, f])
        };
        b.prototype.setParam = function(c, d) {
            a().Iframe.prototype.setParam.apply(this, [c, d])
        };
        b.prototype.setSiteEl = function(c) {
            a().Iframe.prototype.setSiteEl.apply(this, [c])
        };
        b.prototype.unregister = function(c, d) {
            a().Iframe.prototype.unregister.apply(this, [c, d])
        };
        return b
    };

    function Bf(a, b) {
        b = b === void 0 ? new Set : b;
        if (b.has(a)) return "(Recursive reference)";
        switch (typeof a) {
            case "object":
                if (a) {
                    var c = Object.getPrototypeOf(a);
                    switch (c) {
                        case Map.prototype:
                        case Set.prototype:
                        case Array.prototype:
                            b.add(a);
                            var d = "[" + Array.from(a, function(e) {
                                return Bf(e, b)
                            }).join(", ") + "]";
                            b.delete(a);
                            c !== Array.prototype && (d = Cf(c.constructor) + "(" + d + ")");
                            return d;
                        case Object.prototype:
                            return b.add(a), c = "{" + Object.entries(a).map(function(e) {
                                var f = la(e);
                                e = f.next().value;
                                f = f.next().value;
                                return e +
                                    ": " + Bf(f, b)
                            }).join(", ") + "}", b.delete(a), c;
                        default:
                            return d = "Object", c && c.constructor && (d = Cf(c.constructor)), typeof a.toString === "function" && a.toString !== Object.prototype.toString ? d + "(" + String(a) + ")" : "(object " + d + ")"
                    }
                }
                break;
            case "function":
                return "function " + Cf(a);
            case "number":
                if (!Number.isFinite(a)) return String(a);
                break;
            case "bigint":
                return a.toString(10) + "n";
            case "symbol":
                return a.toString()
        }
        return JSON.stringify(a)
    }

    function Cf(a) {
        var b = a.displayName;
        return b && typeof b === "string" || (b = a.name) && typeof b === "string" ? b : (a = /function\s+([^\(]+)/m.exec(String(a))) ? a[1] : "(Anonymous)"
    };

    function Df(a) {
        var b = Ef,
            c = Ff,
            d = [];
        Gf(b, a, d) || Hf.apply(null, [void 0, c, "Guard " + b.zi().trim() + " failed:"].concat(ma(d.reverse())))
    }

    function Gf(a, b, c) {
        var d = a(b, c);
        d || If(c, function() {
            var e = "";
            e.length > 0 && (e += ": ");
            return e + "Expected " + a.zi().trim() + ", got " + Bf(b)
        });
        return d
    }

    function If(a, b) {
        a == null || a.push((typeof b === "function" ? b() : b).trim())
    }
    var Ff = void 0;

    function Jf(a) {
        return typeof a === "function" ? a() : a
    }

    function Hf() {
        throw Error(ra.apply(0, arguments).map(Jf).filter(Boolean).join("\n").trim().replace(/:$/, ""));
    }
    var Ef = function(a, b) {
        a.Pm = !0;
        a.zi = typeof b === "function" ? b : function() {
            return b
        };
        return a
    }(function(a) {
        return a !== null && a !== void 0
    }, "exists");
    var Kf = function() {
        this.Fb = [];
        this.hi = this.kk = this.fk = !1
    };
    Kf.prototype.nb = function(a) {
        this.hi = !0;
        return this.Fb.length ? Lf(this, this.Fb[0], a) : void 0
    };
    var Lf = function(a, b, c) {
            c = c === void 0 ? function(d) {
                return new d
            } : c;
            if (!b.Ve) return b.instance;
            c = c(b.Ve);
            a.kk && (delete b.Ve, b.instance = c);
            return c
        },
        Mf = function() {
            Kf.apply(this, arguments)
        };
    q(Mf, Kf);
    var Of = function(a) {
        var b = Nf.fi;
        y(b.fk || !b.hi, "Cannot register new delegates after instantiation.");
        var c = a.priority,
            d = ~$b(b.Fb, function(f) {
                return f.priority < c ? -1 : 1
            }),
            e = d > 0 ? b.Fb[d - 1] : null;
        e && e.priority <= c && y(!1, "two delegates registered with same priority (%s): %s and %s", c, e.Ve || e.instance, a.Ve || a.instance);
        b.Fb.splice(d, 0, a)
    };
    var Nf = new function() {
        var a = this;
        this.fi = new Mf;
        this.instance = new Af(function() {
            var b = a.fi.nb();
            Df(b);
            return b()
        })
    };
    Of({
        instance: function() {
            var a = window.gapi;
            Df(a);
            a = a.iframes;
            Df(a);
            return a
        },
        priority: 1
    });
    var Pf = {
            height: !0,
            width: !0
        },
        Qf = /^(?!-*(?:expression|(?:moz-)?binding))(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[a-z]{1,2}|%)?|!important|)$/i,
        Rf = function(a) {
            typeof a === "number" && (a = String(a) + "px");
            return a
        };
    var Sf = typeof AsyncContext !== "undefined" && typeof AsyncContext.Snapshot === "function" ? function(a) {
        return a && AsyncContext.Snapshot.wrap(a)
    } : function(a) {
        return a
    };
    var Tf = function(a, b) {
        this.tl = 100;
        this.tk = a;
        this.Pl = b;
        this.zf = 0;
        this.ff = null
    };
    Tf.prototype.get = function() {
        if (this.zf > 0) {
            this.zf--;
            var a = this.ff;
            this.ff = a.next;
            a.next = null
        } else a = this.tk();
        return a
    };
    Tf.prototype.put = function(a) {
        this.Pl(a);
        this.zf < this.tl && (this.zf++, a.next = this.ff, this.ff = a)
    };

    function Uf(a) {
        r.setTimeout(function() {
            throw a;
        }, 0)
    };
    var Vf = function() {
        this.Xf = this.hd = null
    };
    Vf.prototype.add = function(a, b) {
        var c = Wf.get();
        c.set(a, b);
        this.Xf ? this.Xf.next = c : (y(!this.hd), this.hd = c);
        this.Xf = c
    };
    Vf.prototype.remove = function() {
        var a = null;
        this.hd && (a = this.hd, this.hd = this.hd.next, this.hd || (this.Xf = null), a.next = null);
        return a
    };
    var Wf = new Tf(function() {
            return new Xf
        }, function(a) {
            return a.reset()
        }),
        Xf = function() {
            this.next = this.scope = this.be = null
        };
    Xf.prototype.set = function(a, b) {
        this.be = a;
        this.scope = b;
        this.next = null
    };
    Xf.prototype.reset = function() {
        this.next = this.scope = this.be = null
    };
    var Yf = r.console && r.console.createTask ? r.console.createTask.bind(r.console) : void 0,
        Zf = Yf ? Symbol("consoleTask") : void 0;

    function $f(a, b) {
        function c() {
            var h = ra.apply(0, arguments),
                l = this;
            return g.run(function() {
                return a.call.apply(a, [l].concat(ma(h)))
            })
        }
        b = b === void 0 ? "anonymous" : b;
        if (Zf && a[Zf]) return a;
        var d = a,
            e, f = (e = ag) == null ? void 0 : e();
        a = function() {
            var h = ra.apply(0, arguments),
                l, m = (l = ag) == null ? void 0 : l();
            if (f !== m) throw Error(b + " was scheduled in '" + f + "' but called in '" + m + "'.\nMake sure your test awaits all async calls.\n\nTIP: To help investigate, debug the test in Chrome and look at the async portion\nof the call stack to see what originally scheduled the callback.  Then, make the\ntest wait for the relevant asynchronous work to finish.");
            return d.call.apply(d, [this].concat(ma(h)))
        };
        if (!Yf) return a;
        var g = Yf(a.name || b);
        c[Mb(Zf)] = g;
        return c
    }
    var ag;
    var bg, cg = !1,
        dg = new Vf,
        fg = function(a, b) {
            a = $f(a, "goog.async.run");
            bg || eg();
            cg || (bg(), cg = !0);
            dg.add(a, b)
        },
        eg = function() {
            var a = Promise.resolve(void 0);
            bg = function() {
                a.then(gg)
            }
        };

    function gg() {
        for (var a; a = dg.remove();) {
            try {
                a.be.call(a.scope)
            } catch (b) {
                Uf(b)
            }
            Wf.put(a)
        }
        cg = !1
    };
    var hg = function() {},
        ig = function(a) {
            return typeof a === "function"
        };
    var jg = function(a) {
        if (!a) return !1;
        try {
            return !!a.$goog_Thenable
        } catch (b) {
            return !1
        }
    };
    var G = function(a, b) {
            this.Ea = 0;
            this.Wa = void 0;
            this.kd = this.Zb = this.Ja = null;
            this.df = this.Bg = !1;
            if (a != hg) try {
                var c = this;
                a.call(b, function(d) {
                    kg(c, 2, d)
                }, function(d) {
                    if (!(d instanceof lg)) try {
                        if (d instanceof Error) throw d;
                        throw Error("Promise rejected.");
                    } catch (e) {}
                    kg(c, 3, d)
                })
            } catch (d) {
                kg(this, 3, d)
            }
        },
        mg = function() {
            this.next = this.context = this.zd = this.Sc = this.child = null;
            this.Ud = !1
        };
    mg.prototype.reset = function() {
        this.context = this.zd = this.Sc = this.child = null;
        this.Ud = !1
    };
    var ng = new Tf(function() {
            return new mg
        }, function(a) {
            a.reset()
        }),
        og = function(a, b, c) {
            var d = ng.get();
            d.Sc = a;
            d.zd = b;
            d.context = c;
            return d
        },
        H = function(a) {
            if (a instanceof G) return a;
            var b = new G(hg);
            kg(b, 2, a);
            return b
        },
        I = function(a) {
            return new G(function(b, c) {
                c(a)
            })
        },
        qg = function(a, b, c) {
            pg(a, b, c, null) || fg(Ba(b, a))
        },
        rg = function(a) {
            return new G(function(b, c) {
                var d = a.length,
                    e = [];
                if (d)
                    for (var f = function(m, p) {
                            d--;
                            e[m] = p;
                            d == 0 && b(e)
                        }, g = function(m) {
                            c(m)
                        }, h, l = 0; l < a.length; l++) h = a[l], qg(h, Ba(f, l), g);
                else b(e)
            })
        },
        sg =
        function(a) {
            return new G(function(b) {
                var c = a.length,
                    d = [];
                if (c)
                    for (var e = function(h, l, m) {
                            c--;
                            d[h] = l ? {
                                oi: !0,
                                value: m
                            } : {
                                oi: !1,
                                reason: m
                            };
                            c == 0 && b(d)
                        }, f, g = 0; g < a.length; g++) f = a[g], qg(f, Ba(e, g, !0), Ba(e, g, !1));
                else b(d)
            })
        };
    G.prototype.then = function(a, b, c) {
        a != null && Pb(a, "opt_onFulfilled should be a function.");
        b != null && Pb(b, "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?");
        return tg(this, Sf(typeof a === "function" ? a : null), Sf(typeof b === "function" ? b : null), c)
    };
    G.prototype.$goog_Thenable = !0;
    var vg = function(a, b, c, d) {
        b != null && Pb(b, "opt_onFulfilled should be a function.");
        c != null && Pb(c, "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?");
        ug(a, og(b || hg, c || null, d))
    };
    k = G.prototype;
    k.Dc = function(a, b) {
        a = Sf(a);
        b = og(a, a, b);
        b.Ud = !0;
        ug(this, b);
        return this
    };
    k.finally = function(a) {
        var b = this;
        a = Sf(a);
        return new G(function(c, d) {
            vg(b, function(e) {
                a();
                c(e)
            }, function(e) {
                a();
                d(e)
            })
        })
    };
    k.l = function(a, b) {
        return tg(this, null, Sf(a), b)
    };
    k.catch = G.prototype.l;
    k.cancel = function(a) {
        if (this.Ea == 0) {
            var b = new lg(a);
            fg(function() {
                wg(this, b)
            }, this)
        }
    };
    var wg = function(a, b) {
            if (a.Ea == 0)
                if (a.Ja) {
                    var c = a.Ja;
                    if (c.Zb) {
                        for (var d = 0, e = null, f = null, g = c.Zb; g && (g.Ud || (d++, g.child == a && (e = g), !(e && d > 1))); g = g.next) e || (f = g);
                        e && (c.Ea == 0 && d == 1 ? wg(c, b) : (f ? (d = f, y(c.Zb), y(d != null), d.next == c.kd && (c.kd = d), d.next = d.next.next) : xg(c), yg(c, e, 3, b)))
                    }
                    a.Ja = null
                } else kg(a, 3, b)
        },
        ug = function(a, b) {
            a.Zb || a.Ea != 2 && a.Ea != 3 || zg(a);
            y(b.Sc != null);
            a.kd ? a.kd.next = b : a.Zb = b;
            a.kd = b
        },
        tg = function(a, b, c, d) {
            b && (b = $f(b, "goog.Promise.then"));
            c && (c = $f(c, "goog.Promise.then"));
            var e = og(null, null, null);
            e.child = new G(function(f, g) {
                e.Sc = b ? function(h) {
                    try {
                        var l = b.call(d, h);
                        f(l)
                    } catch (m) {
                        g(m)
                    }
                } : f;
                e.zd = c ? function(h) {
                    try {
                        var l = c.call(d, h);
                        l === void 0 && h instanceof lg ? g(h) : f(l)
                    } catch (m) {
                        g(m)
                    }
                } : g
            });
            e.child.Ja = a;
            ug(a, e);
            return e.child
        };
    G.prototype.sm = function(a) {
        y(this.Ea == 1);
        this.Ea = 0;
        kg(this, 2, a)
    };
    G.prototype.tm = function(a) {
        y(this.Ea == 1);
        this.Ea = 0;
        kg(this, 3, a)
    };
    var kg = function(a, b, c) {
            a.Ea == 0 && (a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself")), a.Ea = 1, pg(c, a.sm, a.tm, a) || (a.Wa = c, a.Ea = b, a.Ja = null, zg(a), b != 3 || c instanceof lg || Ag(a, c)))
        },
        pg = function(a, b, c, d) {
            if (a instanceof G) return vg(a, b, c, d), !0;
            if (jg(a)) return a.then(b, c, d), !0;
            if (u(a)) try {
                var e = a.then;
                if (typeof e === "function") return Bg(a, e, b, c, d), !0
            } catch (f) {
                return c.call(d, f), !0
            }
            return !1
        },
        Bg = function(a, b, c, d, e) {
            var f = !1,
                g = function(l) {
                    f || (f = !0, c.call(e, l))
                },
                h = function(l) {
                    f || (f = !0, d.call(e, l))
                };
            try {
                b.call(a, g, h)
            } catch (l) {
                h(l)
            }
        },
        zg = function(a) {
            a.Bg || (a.Bg = !0, fg(a.Ck, a))
        },
        xg = function(a) {
            var b = null;
            a.Zb && (b = a.Zb, a.Zb = b.next, b.next = null);
            a.Zb || (a.kd = null);
            b != null && y(b.Sc != null);
            return b
        };
    G.prototype.Ck = function() {
        for (var a; a = xg(this);) yg(this, a, this.Ea, this.Wa);
        this.Bg = !1
    };
    var yg = function(a, b, c, d) {
            if (c == 3 && b.zd && !b.Ud)
                for (; a && a.df; a = a.Ja) a.df = !1;
            if (b.child) b.child.Ja = null, Cg(b, c, d);
            else try {
                b.Ud ? b.Sc.call(b.context) : Cg(b, c, d)
            } catch (e) {
                Dg.call(null, e)
            }
            ng.put(b)
        },
        Cg = function(a, b, c) {
            b == 2 ? a.Sc.call(a.context, c) : a.zd && a.zd.call(a.context, c)
        },
        Ag = function(a, b) {
            a.df = !0;
            fg(function() {
                a.df && Dg.call(null, b)
            })
        },
        Dg = Uf,
        lg = function(a) {
            Ib.call(this, a)
        };
    x(lg, Ib);
    lg.prototype.name = "cancel";
    var Eg, Fg, Gg, Hg = /^[\w\.\-]*$/,
        Ig = function(a) {
            return a.getOrigin() === a.getContext().getOrigin()
        },
        Jg = function() {
            return !0
        },
        Kg = function(a) {
            for (var b = Bd(), c = 0; c < a.length; c++) b[a[c]] = !0;
            return function(d) {
                return !!b[d.Mb]
            }
        },
        Mg = function(a, b, c) {
            return function(d) {
                if (!b.isDisposed()) {
                    var e = this.origin,
                        f = b.getOrigin();
                    F(e === f, "Wrong origin " + e + " != " + f);
                    e = this.callback;
                    d = Lg(a, d, b);
                    !c && d.length > 0 && rg(d).then(e)
                }
            }
        },
        Lg = function(a, b, c) {
            a = Eg[a];
            if (!a) return [];
            for (var d = [], e = 0; e < a.length; e++) d.push(H(a[e].call(c,
                b, c)));
            return d
        },
        Ng = function(a, b, c) {
            F(a != "_default", "Cannot update default api");
            Fg[a] = {
                map: b,
                filter: c
            }
        },
        Og = function(a, b, c) {
            F(a != "_default", "Cannot update default api");
            qd(Fg, a, {
                map: {},
                filter: Ig
            }).map[b] = c
        },
        Pg = function(a, b) {
            qd(Fg, "_default", {
                map: {},
                filter: Jg
            }).map[a] = b;
            ud(Gg.mb, function(c) {
                c.register(a, b, Jg)
            })
        },
        Qg = function() {
            return Gg
        },
        Rg = /^https?:\/\/[^\/%\\?#\s]+$/i,
        Sg = {
            longdesc: !0,
            name: !0,
            src: !0,
            frameborder: !0,
            marginwidth: !0,
            marginheight: !0,
            scrolling: !0,
            align: !0,
            height: !0,
            width: !0,
            id: !0,
            "class": !0,
            title: !0,
            tabindex: !0,
            hspace: !0,
            vspace: !0,
            allowtransparency: !0
        };
    var Tg = function() {
        Ea.apply(this, arguments)
    };
    q(Tg, Ea);
    var Na = function() {
        Ma.apply(this, arguments)
    };
    q(Na, Ma);
    var Ug = function() {
        Ra.apply(this, arguments)
    };
    q(Ug, Ra);
    var J = function(a) {
        Ug.call(this, a)
    };
    q(J, Ug);
    var Vg = function(a, b) {
        a.i.frameName = b;
        return a
    };
    J.prototype.getFrameName = function() {
        return this.i.frameName
    };
    var Wg = function(a, b) {
        a.i.rpcAddr = b;
        return a
    };
    J.prototype.tb = function() {
        return this.i.rpcAddr
    };
    var Xg = function(a, b) {
        a.i.retAddr = b;
        return a
    };
    J.prototype.Jb = function() {
        return this.i.retAddr
    };
    var Yg = function(a, b) {
        a.i.origin = b;
        return a
    };
    J.prototype.getOrigin = function() {
        return this.i.origin
    };
    J.prototype.jc = function(a) {
        this.i.setRpcReady = a;
        return this
    };
    var Zg = function(a, b) {
            a.i.context = b
        },
        $g = function(a, b) {
            a.i._rpcReadyFn = b
        };
    J.prototype.getIframeEl = function() {
        return this.i.iframeEl
    };
    var ah = function(a, b, c) {
        var d = a.tb(),
            e = b.Jb();
        Xg(Wg(c, a.Jb() + "/" + b.tb()), e + "/" + d);
        Yg(Vg(c, b.getFrameName()), b.getOrigin())
    };

    function bh(a) {
        return new G(a)
    }
    var dh = function(a) {
            this.resolve = this.reject = null;
            this.promise = bh(v(function(b, c) {
                this.resolve = b;
                this.reject = c
            }, this));
            a && (this.promise = ch(this.promise, a))
        },
        ch = function(a, b) {
            return a.then(function(c) {
                try {
                    b(c)
                } catch (d) {}
                return c
            })
        };
    var eh = function() {
        this.Bb = window.console
    };
    eh.prototype.log = function(a) {
        this.Bb && this.Bb.log && this.Bb.log(a)
    };
    eh.prototype.error = function(a) {
        this.Bb && (this.Bb.error ? this.Bb.error(a) : this.Bb.log && this.Bb.log(a))
    };
    eh.prototype.warn = function(a) {
        this.Bb && (this.Bb.warn ? this.Bb.warn(a) : this.Bb.log && this.Bb.log(a))
    };
    eh.prototype.debug = function() {};
    var fh = new eh;
    var nh = function() {
        this.Ie = {
            vj: gh ? "../" + gh : null,
            wk: hh,
            yi: ih,
            Qm: jh,
            getToken: kh,
            Sm: lh
        };
        this.Ab = E;
        this.mj = this.vk;
        this.Gk = /MSIE\s*[0-8](\D|$)/.test(window.navigator.userAgent);
        if (this.Ie.vj) {
            this.Ab = this.Ie.yi(this.Ab, this.Ie.vj);
            var a = this.Ab.document,
                b = a.createElement("script");
            b.setAttribute("type", "text/javascript");
            b.text = "window.doPostMsg=function(w,s,o) {window.setTimeout(function(){w.postMessage(s,o);},0);};";
            a.body.appendChild(b);
            this.mj = this.Ab.doPostMsg
        }
        this.Fh = {};
        this.Oh = {};
        a = v(this.Qk, this);
        Rd(this.Ab, "message", a);
        qd(Yd, "RPMQ", []).push(a);
        this.Ab != this.Ab.parent && mh(this, this.Ab.parent, this.Ri(this.Ab.name), "*")
    };
    nh.prototype.Ri = function(a) {
        return '{"h":"' + escape(a) + '"}'
    };
    var oh = function(a) {
            var b = null;
            a.indexOf('{"h":"') === 0 && a.indexOf('"}') === a.length - 2 && (b = unescape(a.substring(6, a.length - 2)));
            return b
        },
        ph = function(a) {
            if (!/^\s*{/.test(a)) return !1;
            a = Ee(a);
            return a !== null && typeof a === "object" && !!a.g
        };
    nh.prototype.Qk = function(a) {
        var b = String(a.data);
        fh.debug("gapix.rpc.receive(" + jh + "): " + (!b || b.length <= 512 ? b : b.substr(0, 512) + "... (" + b.length + " bytes)"));
        var c = b.indexOf("!_") !== 0;
        c || (b = b.substring(2));
        var d = ph(b);
        if (!c && !d) {
            if (!d && (c = oh(b))) {
                if (this.Fh[c]) this.Fh[c]();
                else this.Oh[c] = 1;
                return
            }
            var e = a.origin,
                f = this.Ie.wk;
            this.Gk ? E.setTimeout(function() {
                f(b, e)
            }, 0) : f(b, e)
        }
    };
    nh.prototype.setup = function(a, b) {
        a === ".." || this.Oh[a] ? (b(), delete this.Oh[a]) : this.Fh[a] = b
    };
    var mh = function(a, b, c, d) {
        var e = ph(c) ? "" : "!_";
        fh.debug("gapix.rpc.send(" + jh + "): " + (!c || c.length <= 512 ? c : c.substr(0, 512) + "... (" + c.length + " bytes)"));
        a.mj(b, e + c, d)
    };
    nh.prototype.vk = function(a, b, c) {
        a.postMessage(b, c)
    };
    nh.prototype.send = function(a, b, c) {
        (a = this.Ie.yi(this.Ab, a)) && !a.closed && mh(this, a, b, c)
    };
    var qh = 0,
        rh = [],
        sh = {},
        th = {},
        uh = E.location.href,
        vh = Ed(uh, "rpctoken"),
        wh = Ed(uh, "parent") || od.referrer,
        gh = Ed(uh, "rly"),
        jh = gh || (E !== E.top || E.opener) && E.name || "..",
        xh = null,
        yh = {},
        zh = function() {},
        Ah = {
            send: zh,
            setup: zh,
            Ri: zh
        },
        ih = function(a, b) {
            var c = a;
            b.charAt(0) == "/" && (b = b.substring(1), c = E.top);
            if (b.length === 0) return c;
            for (b = b.split("/"); b.length;) {
                a = b.shift();
                a.charAt(0) == "{" && a.charAt(a.length - 1) == "}" && (a = a.substring(1, a.length - 1));
                var d = a;
                if (d === "..") c = c == c.parent ? c.opener : c.parent;
                else if (d !== ".." && c.frames[d]) {
                    var e =
                        a = void 0,
                        f = c,
                        g = d;
                    c = c.frames[d];
                    if (!("postMessage" in c))
                        if (c instanceof HTMLIFrameElement && "contentWindow" in c) c = c.contentWindow != null && "postMessage" in c.contentWindow ? c.contentWindow : null;
                        else {
                            d = null;
                            f = la(f.document.getElementsByTagName("iframe"));
                            var h = f.next();
                            try {
                                for (; !h.done; h = f.next())
                                    if (a = h.value, a.getAttribute("id") == g || a.getAttribute("name") == g) d = a
                            } finally {
                                h && !h.done && (e = f.return) && e.call(f)
                            }
                            if (d && "contentWindow" in d) c = d.contentWindow != null ? d.contentWindow : null;
                            else throw Error(c + "is not a window for part " +
                                g);
                        }
                } else return null
            }
            return c
        },
        kh = function(a) {
            return (a = sh[a]) && a.token
        },
        Bh = function(a) {
            if (a.f in {}) return !1;
            var b = a.t,
                c = sh[a.r];
            a = a.origin;
            return c && (c.token === b || !c.token && !b) && (a === c.origin || c.origin === "*")
        },
        Ch = function(a) {
            var b = a.id.split("/"),
                c = b[b.length - 1],
                d = a.origin;
            return function(e) {
                var f = e.origin;
                return e.f == c && (d == f || d == "*")
            }
        },
        Fh = function(a, b, c) {
            a = Dh(a);
            th[a.name] = {
                be: b,
                ne: a.ne,
                Fa: c || Bh
            };
            Eh()
        },
        Gh = {},
        Hh = function(a, b) {
            (a = Gh["_" + a]) && a[1](this) && a[0].call(this, b)
        },
        Jh = function(a) {
            var b = a.c;
            if (!b) return zh;
            var c = a.r,
                d = a.g ? "legacy__" : "";
            return function() {
                var e = [].slice.call(arguments, 0);
                e.unshift(c, d + "__cb", null, b);
                Ih.apply(null, e)
            }
        },
        lh = function(a) {
            xh = a
        },
        Lh = function(a) {
            yh[a] || (yh[a] = E.setTimeout(function() {
                yh[a] = !1;
                Kh(a)
            }, 0))
        },
        Kh = function(a) {
            var b = sh[a];
            if (b && b.ready) {
                var c = b.queue;
                for (b.queue = []; c.length;) Ah.send(a, Fe(c.shift()), b.origin)
            }
        },
        Dh = function(a) {
            return a.indexOf("legacy__") === 0 ? {
                name: a.substring(8),
                ne: !0
            } : {
                name: a,
                ne: !1
            }
        },
        Eh = function() {
            for (var a = Td("rpc/residenceSec") || 60, b =
                    (new Date).getTime() / 1E3, c, d = 0; c = rh[d]; ++d) {
                var e = c.rpc;
                if (!e || a > 0 && b - c.timestamp > a) rh.splice(d, 1), --d;
                else {
                    var f = e.s,
                        g = th[f] || th["*"];
                    if (g)
                        if (rh.splice(d, 1), --d, e.origin = c.origin, c = Jh(e), e.callback = c, g.Fa(e)) {
                            if (f !== "__cb" && !!g.ne != !!e.g) break;
                            e = g.be.apply(e, e.a);
                            e !== void 0 && c(e)
                        } else fh.debug("gapix.rpc.rejected(" + jh + "): " + f)
                }
            }
        },
        Mh = function(a, b, c) {
            rh.push({
                rpc: a,
                origin: b,
                timestamp: (new Date).getTime() / 1E3
            });
            c || Eh()
        },
        hh = function(a, b) {
            a = Ee(a);
            Mh(a, b, !1)
        },
        Nh = function(a) {
            for (; a.length;) Mh(a.shift(),
                this.origin, !0);
            Eh()
        },
        Oh = function(a) {
            var b = !1;
            a = a.split("|");
            var c = a[0];
            c.indexOf("/") >= 0 && (b = !0);
            return {
                id: c,
                origin: a[1] || "*",
                Pg: b
            }
        },
        Ph = function(a, b, c, d) {
            var e = Oh(a);
            d && (E.frames[e.id] = E.frames[e.id] || d);
            a = e.id;
            if (!sh.hasOwnProperty(a)) {
                c = c || null;
                d = e.origin;
                if (a === "..") d = xf(wh), c = c || vh;
                else if (!e.Pg) {
                    var f = od.getElementById(a);
                    f && (f = f.src, d = xf(f), c = c || Ed(f, "rpctoken"))
                }
                e.origin === "*" && d || (d = e.origin);
                sh[a] = {
                    token: c,
                    queue: [],
                    origin: d,
                    Xl: b,
                    tj: function() {
                        var g = a;
                        sh[g].ready = 1;
                        Kh(g)
                    }
                };
                Ah.setup(a, sh[a].tj)
            }
            return sh[a].tj
        },
        Ih = function(a, b, c, d) {
            a = a || "..";
            Ph(a);
            a = a.split("|", 1)[0];
            var e = b,
                f = a,
                g = [].slice.call(arguments, 3),
                h = c,
                l = jh,
                m = vh,
                p = sh[f],
                w = l,
                z = Oh(f);
            if (p && f !== "..") {
                if (z.Pg) {
                    if (!(m = sh[f].Xl)) {
                        m = xh ? xh.substring(1).split("/") : [jh];
                        w = m.length - 1;
                        for (f = E.parent; f !== E.top;) {
                            var D = f.parent;
                            if (!w--) {
                                for (var Ca = null, Bc = D.frames.length, je = 0; je < Bc; ++je) D.frames[je] == f && (Ca = je);
                                m.unshift("{" + Ca + "}")
                            }
                            f = D
                        }
                        m = "/" + m.join("/")
                    }
                    w = m
                } else w = l = "..";
                m = p.token
            }
            p = w;
            h && z ? (w = Bh, z.Pg && (w = Ch(z)), Gh["_" + ++qh] = [h, w], h = qh) : h = null;
            g = {
                s: e,
                f: l,
                r: p,
                t: m,
                c: h,
                a: g
            };
            e = Dh(e);
            g.s = e.name;
            g.g = e.ne;
            sh[a].queue.push(g);
            Lh(a)
        };
    if (typeof E.postMessage === "function" || typeof E.postMessage === "object") Ah = new nh, Fh("__cb", Hh, function() {
        return !0
    }), Fh("_processBatch", Nh, function() {
        return !0
    }), Ph("..");
    var Qh = C("Safari") && !((Pc() ? Oc("Chromium") : (C("Chrome") || C("CriOS")) && (Pc() || !C("Edge")) || C("Silk")) || (Pc() ? 0 : C("Coast")) || (Pc() ? 0 : C("Opera")) || (Pc() ? 0 : C("Edge")) || (Pc() ? Oc("Microsoft Edge") : C("Edg/")) || (Pc() ? Oc("Opera") : C("OPR")) || C("Firefox") || C("FxiOS") || C("Silk") || C("Android")) && !(Qc() || C("iPad") || C("iPod"));
    var Sh = function(a, b, c) {
            a.setTimeout(function() {
                b.closed || c == 5 ? Rh(b) : (b.close(), c++, Sh(a, b, c))
            }, 1E3)
        },
        Rh = function(a) {
            if (!a.closed && a.document && a.document.body)
                if (a = a.document.body, y(a != null, "goog.dom.setTextContent expects a non-null value for node"), "textContent" in a) a.textContent = "Please close this window.";
                else if (a.nodeType == 3) a.data = "Please close this window.";
            else if (a.firstChild && a.firstChild.nodeType == 3) {
                for (; a.lastChild != a.firstChild;) a.removeChild(y(a.lastChild));
                a.firstChild.data = "Please close this window."
            } else {
                kd(a);
                var b = md(a);
                a.appendChild(b.createTextNode("Please close this window."))
            }
        };
    var K = function(a, b, c, d) {
        this.Gb = !1;
        this.Ue = a;
        this.uh = b;
        this.td = c;
        this.Ua = d;
        this.wj = this.Ua.Jb();
        this.Mb = this.Ua.getOrigin();
        this.dl = this.Ua.getIframeEl();
        this.Kj = this.Ua.i.where;
        this.Fb = [];
        this.applyIframesApi("_default");
        a = this.Ua.i.apis || [];
        for (b = 0; b < a.length; b++) this.applyIframesApi(a[b]);
        this.Ue.mb[c] = this
    };
    k = K.prototype;
    k.isDisposed = function() {
        return this.Gb
    };
    k.dispose = function() {
        if (!this.isDisposed()) {
            for (var a = 0; a < this.Fb.length; a++) this.unregister(this.Fb[a]);
            delete Gg.mb[this.getFrameName()];
            this.Gb = !0
        }
    };
    k.getContext = function() {
        return this.Ue
    };
    k.getOptions = function() {
        return this.Ua
    };
    k.tb = function() {
        return this.uh
    };
    k.Jb = function() {
        return this.wj
    };
    k.getFrameName = function() {
        return this.td
    };
    k.getIframeEl = function() {
        return this.dl
    };
    k.getSiteEl = function() {
        return this.Kj
    };
    k.setSiteEl = function(a) {
        this.Kj = a
    };
    k.jc = function() {
        (0, this.Ua.i._rpcReadyFn)()
    };
    k.setParam = function(a, b) {
        this.Ua.value()[a] = b
    };
    k.getParam = function(a) {
        return this.Ua.value()[a]
    };
    k.wi = function() {
        return this.Ua.value()
    };
    k.getId = function() {
        return this.Ua.getId()
    };
    k.getOrigin = function() {
        return this.Mb
    };
    var Th = function(a, b) {
        var c = a.td;
        a = a.Ue.getFrameName();
        return c + ":" + a + ":" + b
    };
    k = K.prototype;
    k.register = function(a, b, c) {
        F(!this.isDisposed(), "Cannot register handler on disposed iframe " + a);
        F((c || Ig)(this), "Rejecting untrusted message " + a);
        c = Th(this, a);
        qd(Eg, c, []).push(b) == 1 && (this.Fb.push(a), Fh(c, Mg(c, this, a === "_g_wasClosed")))
    };
    k.unregister = function(a, b) {
        var c = Th(this, a),
            d = Eg[c];
        d && (b ? (b = sd.call(d, b), b >= 0 && d.splice(b, 1)) : d.splice(0, d.length), d.length == 0 && (b = sd.call(this.Fb, a), b >= 0 && this.Fb.splice(b, 1), delete th[Dh(c).name]))
    };
    k.Lk = function() {
        return this.Fb
    };
    k.applyIframesApi = function(a) {
        this.ag = this.ag || [];
        if (!(sd.call(this.ag, a) >= 0)) {
            this.ag.push(a);
            a = Fg[a] || {
                map: {}
            };
            for (var b in a.map) td(a.map, b) && this.register(b, a.map[b], a.filter)
        }
    };
    k.getWindow = function() {
        if (!Ig(this)) return null;
        var a = this.Ua.i._popupWindow;
        if (a) return a;
        var b = this.uh.split("/");
        a = this.getContext().getWindow();
        for (var c = 0; c < b.length && a; c++) {
            var d = b[c];
            a = ".." === d ? a == a.parent ? a.opener : a.parent : a.frames[d]
        }
        return a
    };
    var Uh = function(a) {
        var b = {};
        if (a)
            for (var c in a) td(a, c) && td(Pf, c) && Qf.test(a[c]) && (b[c] = a[c]);
        return b
    };
    k = K.prototype;
    k.close = function(a, b) {
        return Vh(this, "_g_close", a, b)
    };
    k.restyle = function(a, b) {
        return Vh(this, "_g_restyle", a, b)
    };
    k.Tl = function(a, b) {
        return Vh(this, "_g_restyleDone", a, b)
    };
    k.lk = function(a) {
        return this.getContext().closeSelf(a, void 0, this)
    };
    k.Vl = function(a) {
        if (a && typeof a === "object") return this.getContext().restyleSelf(a, void 0, this)
    };
    k.Wl = function(a) {
        var b = this.Ua.i.onRestyle;
        b && b.call(this, a, this);
        a = a && typeof a === "object" ? Uh(a) : {};
        (b = this.getIframeEl()) && a && typeof a === "object" && (td(a, "height") && (a.height = Rf(a.height)), td(a, "width") && (a.width = Rf(a.width)), Cd(a, b.style))
    };
    k.mk = function(a) {
        var b = this.Ua.i.onClose;
        b && b.call(this, a, this);
        if (b = this.getOptions().i._popupWindow) {
            var c = this.getContext().getWindow().document.getElementById(this.getId());
            c && c.parentNode && c.parentNode.removeChild(c);
            c = this.getContext().getWindow();
            Wc && Qh && c ? (c.focus(), Sh(c, b, 0)) : (b.close(), Rh(b))
        }
        b || (b = this.getIframeEl()) && b.parentNode && b.parentNode.removeChild(b);
        if (b = this.Ua.i.controller) c = {}, c.frameName = this.getFrameName(), Vh(b, "_g_disposeControl", c);
        b = Th(this, "_g_wasClosed");
        Lg(b, a, this)
    };
    k.registerWasRestyled = function(a, b) {
        this.register("_g_wasRestyled", a, b)
    };
    k.registerWasClosed = function(a, b) {
        this.register("_g_wasClosed", a, b)
    };
    k.zm = function() {
        delete this.getContext().mb[this.getFrameName()];
        this.getContext().getWindow().setTimeout(v(function() {
            this.dispose()
        }, this), 0)
    };
    k.send = function(a, b, c, d) {
        F(!this.isDisposed(), "Cannot send message to disposed iframe - " + a);
        F((d || Ig)(this), "Wrong target for message " + a);
        c = new dh(c);
        a = this.Ue.getFrameName() + ":" + this.td + ":" + a;
        Ih(this.uh, a, c.resolve, b);
        return c.promise
    };
    var Vh = function(a, b, c, d) {
        return a.send(b, c, d, Jg)
    };
    k = K.prototype;
    k.Jl = function(a) {
        return a
    };
    k.ping = function(a, b) {
        return Vh(this, "_g_ping", b, a)
    };
    k.rk = function(a) {
        a = a && typeof a === "object" ? a : {};
        for (var b = a.rpcAddr, c = (this.tb() + "/" + b).split("/"), d = this.getContext().getWindow(), e;
            (e = c.shift()) && d;) d = e == ".." ? d.parent : d.frames[e];
        F(!!d, "Bad rpc address " + b);
        a._window = d;
        a._parentRpcAddr = this.tb();
        a._parentRetAddr = this.Jb();
        this.getContext();
        b = new L(a);
        this.Al && this.Al(b, a.controllerData);
        this.rg = this.rg || [];
        this.rg.push(b, a.controllerData)
    };
    k.xk = function(a) {
        a = (a || {}).frameName;
        for (var b = this.rg || [], c = 0; c < b.length; c++)
            if (b[c].getFrameName() === a) {
                a = b.splice(c, 1)[0];
                a.dispose();
                this.Bl && this.Bl(a);
                return
            }
        F(!1, "Unknown contolled iframe to dispose - " + a)
    };
    k.nk = function(a) {
        var b = new J(a);
        a = new Tg(b.value());
        if (a.i.selfConnect) var c = this;
        else(F(Rg.test(b.getOrigin()), "Illegal origin for connected iframe - " + b.getOrigin()), c = this.getContext().mb[b.getFrameName()], c) ? Ha(b) && (c.jc(), Vh(c, "_g_rpcReady")) : (b = Vg(Yg(Xg(Wg(new J, b.tb()), b.Jb()), b.getOrigin()), b.getFrameName()).jc(Ha(b)).Wc(Ia(b)), c = Wh(this.getContext(), b.value()));
        b = this.getContext();
        var d = a.i.role;
        a = a.i.data;
        Xh(b);
        d = d || "";
        qd(b.qg, d, []).push({
            kf: c,
            data: a
        });
        Yh(c, a, b.Wg[d])
    };
    k.Ej = function(a, b) {
        (new J(b)).i._relayedDepth || (b = {}, Ja(Fa(new Tg(b), "_opener")), Vh(a, "_g_connect", b))
    };
    k.ij = function(a) {
        var b = this,
            c = a.i.messageHandlers,
            d = a.i.messageHandlersFilter,
            e = a.i.onClose;
        Ua(Ta(Sa(a, null), null), null);
        return Vh(this, "_g_open", a.value()).then(function(f) {
            var g = new J(f[0]),
                h = g.getFrameName();
            f = new J;
            var l = b.Jb(),
                m = g.Jb();
            Xg(Wg(f, b.tb() + "/" + g.tb()), m + "/" + l);
            Vg(f, h);
            Yg(f, g.getOrigin());
            f.De(g.i.apis);
            f.Wc(Ia(a));
            Sa(f, c);
            Ta(f, d);
            Ua(f, e);
            (g = b.getContext().mb[h]) || (g = Wh(b.getContext(), f.value()));
            return g
        })
    };
    k.wh = function(a) {
        var b = a.getUrl();
        F(!b || Pd.test(b), "Illegal url for new iframe - " + b);
        var c = Va(a).value();
        b = {};
        for (var d in c) td(c, d) && td(Sg, d) && (b[d] = c[d]);
        td(c, "style") && (d = c.style, typeof d === "object" && (b.style = Uh(d)));
        a.value().attributes = b
    };
    k.Gl = function(a) {
        a = new J(a);
        this.wh(a);
        var b = a.i._relayedDepth || 0;
        a.i._relayedDepth = b + 1;
        a.i.openerIframe = this;
        var c = Ia(a);
        a.Wc(null);
        var d = this;
        return this.getContext().open(a.value()).then(function(e) {
            var f = (new J(e.wi())).i.apis,
                g = new J;
            ah(e, d, g);
            b == 0 && Fa(new Tg(g.value()), "_opener");
            g.jc(!0);
            g.Wc(c);
            Vh(e, "_g_connect", g.value());
            g = new J;
            Yg(Vg(Xg(Wg(g, e.tb()), e.wj), e.getFrameName()), e.getOrigin()).De(f);
            return g.value()
        })
    };
    k.Ul = function(a) {
        this.getContext().addOnOpenerHandler(function(b) {
            b.send("_g_wasRestyled", a, void 0, Jg)
        }, null, Jg)
    };
    var Zh = Bd(),
        $h = Bd(),
        ai = function(a, b) {
            Zh[a] = b
        },
        bi = function(a) {
            return Zh[a]
        },
        ci = function(a, b) {
            Dd.load("gapi.iframes.style." + a, b)
        },
        di = function(a, b) {
            $h[a] = b
        },
        ei = function(a) {
            return $h[a]
        };
    var fi = function() {
            function a(h, l) {
                h = window.getComputedStyle(h, "").getPropertyValue(l).match(/^([0-9]+)/);
                return parseInt(h[0], 10)
            }
            for (var b = 0, c = [document.body]; c.length > 0;) {
                var d = c.shift(),
                    e = d.childNodes;
                if (typeof d.style !== "undefined") {
                    var f = d.style.overflowY;
                    f || (f = (f = document.defaultView.getComputedStyle(d, null)) ? f.overflowY : null);
                    if (f != "visible" && f != "inherit" && (f = d.style.height, f || (f = (f = document.defaultView.getComputedStyle(d, null)) ? f.height : ""), f.length > 0 && f != "auto")) continue
                }
                for (d = 0; d < e.length; d++) {
                    f =
                        e[d];
                    if (typeof f.offsetTop !== "undefined" && typeof f.offsetHeight !== "undefined") {
                        var g = f.offsetTop + f.offsetHeight + a(f, "margin-bottom");
                        b = Math.max(b, g)
                    }
                    c.push(f)
                }
            }
            return b + a(document.body, "border-bottom") + a(document.body, "margin-bottom") + a(document.body, "padding-bottom")
        },
        gi = function() {
            var a = 0;
            self.innerHeight ? a = self.innerHeight : document.documentElement && document.documentElement.clientHeight ? a = document.documentElement.clientHeight : document.body && (a = document.body.clientHeight);
            var b = document.body,
                c = document.documentElement;
            if (document.compatMode === "CSS1Compat" && c.scrollHeight) return c.scrollHeight !== a ? c.scrollHeight : c.offsetHeight;
            if (navigator.userAgent.indexOf("AppleWebKit") >= 0) return fi();
            if (b && c) {
                var d = c.scrollHeight,
                    e = c.offsetHeight;
                c.clientHeight !== e && (d = b.scrollHeight, e = b.offsetHeight);
                return d > a ? d > e ? d : e : d < e ? d : e
            }
        };
    var L = function(a) {
        a = a || {};
        this.Gb = !1;
        this.Ba = Bd();
        this.mb = Bd();
        this.Ab = a._window || E;
        this.lb = this.Ab.location.href;
        this.kj = (this.dh = hi(this.lb, "parent")) ? hi(this.lb, "pfname") : "";
        this.Ra = this.dh ? hi(this.lb, "_gfid") || hi(this.lb, "id") : "";
        this.td = df(this.Ra, this.kj);
        this.Mb = xf(this.lb);
        if (this.Ra) {
            var b = new J;
            Wg(b, a._parentRpcAddr || "..");
            Xg(b, a._parentRetAddr || this.Ra);
            Yg(b, xf(this.dh || this.lb));
            Vg(b, this.kj);
            this.Ja = Wh(this, b.value())
        } else this.Ja = null
    };
    k = L.prototype;
    k.isDisposed = function() {
        return this.Gb
    };
    k.dispose = function() {
        if (!this.isDisposed()) {
            var a = la(Object.values(this.mb)),
                b = a.next(),
                c;
            try {
                for (; !b.done; b = a.next()) b.value.dispose()
            } finally {
                b && !b.done && (c = a.return) && c.call(a)
            }
            this.Gb = !0
        }
    };
    k.getFrameName = function() {
        return this.td
    };
    k.getOrigin = function() {
        return this.Mb
    };
    k.getWindow = function() {
        return this.Ab
    };
    k.setGlobalParam = function(a, b) {
        this.Ba[a] = b
    };
    k.getGlobalParam = function(a) {
        return this.Ba[a]
    };
    var Wh = function(a, b) {
        F(!a.isDisposed(), "Cannot attach iframe in disposed context");
        b = new J(b);
        b.tb() || Wg(b, b.getId());
        b.Jb() || Xg(b, "..");
        b.getOrigin() || Yg(b, xf(b.getUrl()));
        b.getFrameName() || Vg(b, df(b.getId(), a.td));
        var c = b.getFrameName();
        if (a.mb[c]) return a.mb[c];
        var d = b.tb(),
            e = d;
        b.getOrigin() && (e = d + "|" + b.getOrigin());
        var f = b.Jb(),
            g = Ia(b);
        g || (g = (g = b.getIframeEl()) && (g.getAttribute("data-postorigin") || g.src) || b.getUrl(), g = Ed(g, "rpctoken"));
        $g(b, Ph(e, f, g, b.i._popupWindow));
        e = ((window.gadgets || {}).rpc || {}).setAuthToken;
        g && e && e(d, g);
        var h = new K(a, d, c, b),
            l = b.i.messageHandlersFilter;
        ud(b.i.messageHandlers, function(m, p) {
            h.register(p, m, l)
        });
        Ha(b) && h.jc();
        Vh(h, "_g_rpcReady");
        return h
    };
    L.prototype.wh = function(a) {
        Vg(a, null);
        var b = a.getId();
        !b || Hg.test(b) && !this.getWindow().document.getElementById(b) || (fh.log("Ignoring requested iframe ID - " + b), a.i.id = null)
    };
    var hi = function(a, b) {
        var c = Ed(a, b);
        c || (c = Ee(Ed(a, "jcp", ""))[b]);
        return c || ""
    };
    L.prototype.openChild = function(a) {
        F(!this.isDisposed(), "Cannot open iframe in disposed context");
        var b = new J(a);
        ii(this, b);
        var c = b.getFrameName();
        if (c && this.mb[c]) return this.mb[c];
        this.wh(b);
        c = b.getUrl();
        F(c, "No url for new iframe");
        var d = b.i.queryParams || {};
        d.usegapi = "1";
        b.i.queryParams = d;
        d = this.Bi && this.Bi(c, b);
        d || (d = b.i.where, F(!!d, "No location for new iframe"), c = mf(c, d, a), b.i.iframeEl = c, d = c.getAttribute("id"));
        Wg(b, d).i.id = d;
        Yg(b, xf(b.i.eurl || ""));
        this.Si && this.Si(b, b.getIframeEl());
        c = Wh(this,
            a);
        c.Ej && c.Ej(c, a);
        (a = b.i.onCreate) && a(c);
        b.i.disableRelayOpen || c.applyIframesApi("_open");
        return c
    };
    var ji = function(a, b, c) {
            var d = b.i.canvasUrl;
            if (!d) return c;
            F(!b.i.allowPost && !b.i.forcePost, "Post is not supported when using canvas url");
            var e = b.getUrl();
            F(e && xf(e) === a.Mb && xf(d) === a.Mb, "Wrong origin for canvas or hidden url " + d);
            b.setUrl(d);
            b.i.waitForOnload = !0;
            b.i.canvasUrl = null;
            return function(f) {
                var g = f.getWindow(),
                    h = g.location.hash;
                h = lf(e) + (/#/.test(e) ? h.replace(/^#/, "&") : h);
                g.location.replace(h);
                c && c(f)
            }
        },
        ki = function(a, b, c) {
            var d = b.i.relayOpen;
            if (d) {
                var e = a.getParentIframe();
                d instanceof K ?
                    (e = d, b.i.relayOpen = 0) : Number(d) > 0 && (b.i.relayOpen = Number(d) - 1);
                if (e) {
                    F(!!e.ij, "Relaying iframe open is disabled");
                    if (d = b.getStyle())
                        if (d = $h[d]) Zg(b, a), d(b.value()), Zg(b, null);
                    b.i.openerIframe = null;
                    c.resolve(e.ij(b));
                    return !0
                }
            }
            return !1
        },
        li = function(a, b, c) {
            var d = b.getStyle();
            if (d)
                if (F(!!bi, "Defer style is disabled, when requesting style " + d), Zh[d]) ii(a, b);
                else return ci(d, function() {
                    F(!!Zh[d], "Fail to load style - " + d);
                    c.resolve(a.open(b.value()))
                }), !0;
            return !1
        };
    L.prototype.open = function(a, b) {
        F(!this.isDisposed(), "Cannot open iframe in disposed context");
        var c = new J(a);
        b = ji(this, c, b);
        var d = new dh(b);
        (b = c.getUrl()) && c.setUrl(lf(b));
        if (ki(this, c, d) || li(this, c, d) || ki(this, c, d)) return d.promise;
        if (Xa(c) != null) {
            var e = setTimeout(function() {
                    g.getIframeEl().src = "about:blank";
                    d.reject(Error("Exceeded time limit of: " + Xa(c) + " milliseconds"))
                }, Xa(c)),
                f = d.resolve;
            d.resolve = function(h) {
                clearTimeout(e);
                f(h)
            }
        }
        c.i.waitForOnload && La(Va(c), function() {
            d.resolve(g)
        });
        var g =
            this.openChild(a);
        c.i.waitForOnload || d.resolve(g);
        return d.promise
    };
    L.prototype.getParentIframe = function() {
        return this.Ja
    };
    var mi = function(a, b) {
        var c = a.getParentIframe(),
            d = !0;
        b.filter && (d = b.filter.call(b.kf, b.params));
        return H(d).then(function(e) {
            return e && c ? (b.jj && b.jj.call(a, b.params), e = b.sender ? b.sender(b.params) : Vh(c, b.message, b.params), b.ym ? e.then(function() {
                return !0
            }) : !0) : !1
        })
    };
    k = L.prototype;
    k.closeSelf = function(a, b, c) {
        a = mi(this, {
            sender: function(d) {
                var e = Gg.getParentIframe();
                ud(Gg.mb, function(f) {
                    f !== e && Vh(f, "_g_wasClosed", d)
                });
                return Vh(e, "_g_closeMe", d)
            },
            message: "_g_closeMe",
            params: a,
            kf: c,
            filter: this.getGlobalParam("onCloseSelfFilter")
        });
        b = new dh(b);
        b.resolve(a);
        return b.promise
    };
    k.restyleSelf = function(a, b, c) {
        a = a || {};
        b = new dh(b);
        b.resolve(mi(this, {
            message: "_g_restyleMe",
            params: a,
            kf: c,
            filter: this.getGlobalParam("onRestyleSelfFilter"),
            ym: !0,
            jj: this.Qj
        }));
        return b.promise
    };
    k.Qj = function(a) {
        a.height === "auto" && (a.height = gi())
    };
    k.setCloseSelfFilter = function(a) {
        this.setGlobalParam("onCloseSelfFilter", a)
    };
    k.setRestyleSelfFilter = function(a) {
        this.setGlobalParam("onRestyleSelfFilter", a)
    };
    var ii = function(a, b) {
        var c = b.getStyle();
        if (c) {
            b.Fj(null);
            var d = Zh[c];
            F(d, "No such style: " + c);
            Zg(b, a);
            d(b.value());
            Zg(b, null)
        }
    };
    L.prototype.ready = function(a, b, c, d) {
        var e = b || {},
            f = this.getParentIframe();
        this.addOnOpenerHandler(function(h) {
            ud(e, function(l, m) {
                h.register(m, l, d)
            }, this);
            h !== f && h.send("_ready", g, void 0, d)
        }, void 0, d);
        var g = a || {};
        g.height = g.height || "auto";
        this.Qj(g);
        f && f.send("_ready", g, c, Jg)
    };
    L.prototype.connectIframes = function(a, b) {
        a = new Tg(a);
        var c = new Tg(b),
            d = Ha(a);
        b = a.getIframe();
        var e = c.getIframe();
        if (e) {
            var f = Ia(a),
                g = new J;
            ah(b, e, g);
            Ga(Fa((new Tg(g.value())).Wc(f), a.i.role), a.i.data).jc(d);
            var h = new J;
            ah(e, b, h);
            Ga(Fa((new Tg(h.value())).Wc(f), c.i.role), c.i.data).jc(!0);
            Vh(b, "_g_connect", g.value(), function() {
                d || Vh(e, "_g_connect", h.value())
            });
            d && Vh(e, "_g_connect", h.value())
        } else c = {}, Ga(Fa(Ja(new Tg(c)), a.i.role), a.i.data), Vh(b, "_g_connect", c)
    };
    var Xh = function(a) {
        a.qg || (a.qg = Bd(), a.Wg = Bd())
    };
    L.prototype.addOnConnectHandler = function(a, b, c, d) {
        Xh(this);
        typeof a === "object" ? (b = new Na(a), c = b.i.role || "") : (b = Qa(Pa(Oa(a), b).De(c), d), c = a);
        d = this.qg[c] || [];
        a = !1;
        for (var e = 0; e < d.length && !a; e++) Yh(this.mb[d[e].kf.getFrameName()], d[e].data, [b]), a = b.i.runOnce;
        c = qd(this.Wg, c, []);
        a || b.i.dontWait || c.push(b)
    };
    L.prototype.removeOnConnectHandler = function(a, b) {
        a = qd(this.Wg, a, []);
        if (b)
            for (var c = !1, d = 0; !c && d < a.length; d++) a[d].i.handler === b && (c = !0, a.splice(d, 1));
        else a.splice(0, a.length)
    };
    var Yh = function(a, b, c) {
        c = c || [];
        for (var d = 0; d < c.length; d++) {
            var e = c[d];
            if (e && a) {
                var f = e.i.filter || Ig;
                if (a && f(a)) {
                    f = e.i.apis || [];
                    for (var g = 0; g < f.length; g++) a.applyIframesApi(f[g]);
                    e.i.handler && (0, e.i.handler)(a, b);
                    e.i.runOnce && (c.splice(d, 1), --d)
                }
            }
        }
    };
    L.prototype.addOnOpenerHandler = function(a, b, c) {
        var d = this.addOnConnectHandler;
        a = Qa(Pa(Oa("_opener"), a).De(b), c);
        a.i.runOnce = !0;
        d.call(this, a.value())
    };
    L.prototype.Si = function(a, b) {
        var c = a.i.controller;
        if (c) {
            F(c.Mb === a.getOrigin(), "Wrong controller origin " + this.Mb + " !== " + a.getOrigin());
            var d = a.tb();
            Wg(a, c.tb());
            Xg(a, c.Jb());
            var e = new J;
            Wa(Wg(e, d), a.i.controllerData);
            Rd(b, "load", function() {
                c.send("_g_control", e.value())
            })
        }
    };
    var ni = function(a, b, c) {
        a = a.getWindow();
        var d = a.document,
            e = c.i.reuseWindow;
        if (e) {
            var f = c.getId();
            if (!f) throw Error("If you provide a reuseWindow, you must also provide an ID");
        } else f = cf(d, c);
        var g = f,
            h = c.i.rpcRelayUrl;
        if (h) {
            h = Od(od, h.replace(jf, kf));
            g = c.i.fragmentParams || {};
            g.rly = f;
            c.i.fragmentParams = g;
            g = c.i.where || d.body;
            F(!!g, "Cannot open window in a page with no body");
            var l = {};
            l.src = h;
            l.style = "display:none;";
            l.id = f;
            l.name = f;
            gf(d, g, l, f);
            g = f + "_relay"
        }
        b = lf(b);
        var m = ef(d, b, f, c.value());
        c.i.eurl = m;
        b = c.i.openAsWindow;
        typeof b !== "string" && (b = void 0);
        c = window.navigator.userAgent || "";
        /Trident|MSIE/i.test(c) && /#/.test(c) && (m = "javascript:window.location.replace(" + E.JSON.stringify(m).replace(/#/g, "\\x23") + ")");
        if (e) {
            var p = e;
            setTimeout(function() {
                p.location.replace(m)
            })
        } else p = oc(a, m, g, b);
        return {
            id: f,
            Wj: p
        }
    };
    L.prototype.Bi = function(a, b) {
        if (b.i.openAsWindow) {
            a = ni(this, a, b);
            var c = a.id;
            F(!!a.Wj, "Open popup window failed");
            b.i._popupWindow = a.Wj
        }
        return c
    };
    Eg = Bd();
    Fg = Bd();
    Gg = new L;
    Pg("_g_rpcReady", K.prototype.jc);
    Pg("_g_discover", K.prototype.Lk);
    Pg("_g_ping", K.prototype.Jl);
    Pg("_g_close", K.prototype.lk);
    Pg("_g_closeMe", K.prototype.mk);
    Pg("_g_restyle", K.prototype.Vl);
    Pg("_g_restyleMe", K.prototype.Wl);
    Pg("_g_wasClosed", K.prototype.zm);
    Og("control", "_g_control", K.prototype.rk);
    Og("control", "_g_disposeControl", K.prototype.xk);
    var oi = Gg.getParentIframe();
    oi && oi.register("_g_restyleDone", K.prototype.Ul, Jg);
    Pg("_g_connect", K.prototype.nk);
    var pi = {};
    pi._g_open = K.prototype.Gl;
    Ng("_open", pi, Jg);
    var qi = {
        Context: L,
        Iframe: K,
        SAME_ORIGIN_IFRAMES_FILTER: Ig,
        CROSS_ORIGIN_IFRAMES_FILTER: Jg,
        makeWhiteListIframesFilter: Kg,
        getContext: Qg,
        registerIframesApi: Ng,
        registerIframesApiHandler: Og,
        registerStyle: ai,
        registerBeforeOpenStyle: di,
        getStyle: bi,
        getBeforeOpenStyle: ei,
        create: mf
    };
    Of({
        instance: function() {
            return qi
        },
        priority: 2
    });
    Og("gapi.load", "_g_gapi.load", function(a) {
        return new G(function(b) {
            Dd.load(a && typeof a === "object" && a.features || "", b)
        })
    });
    t("gapi.iframes.registerStyle", ai);
    t("gapi.iframes.registerBeforeOpenStyle", di);
    t("gapi.iframes.getStyle", bi);
    t("gapi.iframes.getBeforeOpenStyle", ei);
    t("gapi.iframes.registerIframesApi", Ng);
    t("gapi.iframes.registerIframesApiHandler", Og);
    t("gapi.iframes.getContext", Qg);
    t("gapi.iframes.SAME_ORIGIN_IFRAMES_FILTER", Ig);
    t("gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER", Jg);
    t("gapi.iframes.makeWhiteListIframesFilter", Kg);
    t("gapi.iframes.Context", L);
    t("gapi.iframes.Context.prototype.isDisposed", L.prototype.isDisposed);
    t("gapi.iframes.Context.prototype.getWindow", L.prototype.getWindow);
    t("gapi.iframes.Context.prototype.getFrameName", L.prototype.getFrameName);
    t("gapi.iframes.Context.prototype.getGlobalParam", L.prototype.getGlobalParam);
    t("gapi.iframes.Context.prototype.setGlobalParam", L.prototype.setGlobalParam);
    t("gapi.iframes.Context.prototype.open", L.prototype.open);
    t("gapi.iframes.Context.prototype.openChild", L.prototype.openChild);
    t("gapi.iframes.Context.prototype.getParentIframe", L.prototype.getParentIframe);
    t("gapi.iframes.Context.prototype.closeSelf", L.prototype.closeSelf);
    t("gapi.iframes.Context.prototype.restyleSelf", L.prototype.restyleSelf);
    t("gapi.iframes.Context.prototype.setCloseSelfFilter", L.prototype.setCloseSelfFilter);
    t("gapi.iframes.Context.prototype.setRestyleSelfFilter", L.prototype.setRestyleSelfFilter);
    t("gapi.iframes.Context.prototype.addOnConnectHandler", L.prototype.addOnConnectHandler);
    t("gapi.iframes.Context.prototype.removeOnConnectHandler", L.prototype.removeOnConnectHandler);
    t("gapi.iframes.Context.prototype.addOnOpenerHandler", L.prototype.addOnOpenerHandler);
    t("gapi.iframes.Context.prototype.connectIframes", L.prototype.connectIframes);
    t("gapi.iframes.Iframe", K);
    t("gapi.iframes.Iframe.prototype.isDisposed", K.prototype.isDisposed);
    t("gapi.iframes.Iframe.prototype.getContext", K.prototype.getContext);
    t("gapi.iframes.Iframe.prototype.getFrameName", K.prototype.getFrameName);
    t("gapi.iframes.Iframe.prototype.getId", K.prototype.getId);
    t("gapi.iframes.Iframe.prototype.register", K.prototype.register);
    t("gapi.iframes.Iframe.prototype.unregister", K.prototype.unregister);
    t("gapi.iframes.Iframe.prototype.send", K.prototype.send);
    t("gapi.iframes.Iframe.prototype.applyIframesApi", K.prototype.applyIframesApi);
    t("gapi.iframes.Iframe.prototype.getIframeEl", K.prototype.getIframeEl);
    t("gapi.iframes.Iframe.prototype.getSiteEl", K.prototype.getSiteEl);
    t("gapi.iframes.Iframe.prototype.setSiteEl", K.prototype.setSiteEl);
    t("gapi.iframes.Iframe.prototype.getWindow", K.prototype.getWindow);
    t("gapi.iframes.Iframe.prototype.getOrigin", K.prototype.getOrigin);
    t("gapi.iframes.Iframe.prototype.close", K.prototype.close);
    t("gapi.iframes.Iframe.prototype.restyle", K.prototype.restyle);
    t("gapi.iframes.Iframe.prototype.restyleDone", K.prototype.Tl);
    t("gapi.iframes.Iframe.prototype.registerWasRestyled", K.prototype.registerWasRestyled);
    t("gapi.iframes.Iframe.prototype.registerWasClosed", K.prototype.registerWasClosed);
    t("gapi.iframes.Iframe.prototype.getParam", K.prototype.getParam);
    t("gapi.iframes.Iframe.prototype.setParam", K.prototype.setParam);
    t("gapi.iframes.Iframe.prototype.ping", K.prototype.ping);
    t("gapi.iframes.Iframe.prototype.getOpenParams", K.prototype.wi);
    t("gapi.iframes.create", mf);

    function ri(a) {
        return Array.prototype.map.call(a, function(b) {
            b = b.toString(16);
            return b.length > 1 ? b : "0" + b
        }).join("")
    };
    var si = null;

    function ti(a) {
        var b = [];
        ui(a, function(c) {
            b.push(c)
        });
        return b
    }

    function ui(a, b) {
        function c(l) {
            for (; d < a.length;) {
                var m = a.charAt(d++),
                    p = si[m];
                if (p != null) return p;
                if (!/^[\s\xa0]*$/.test(m)) throw Error("Unknown base64 encoding at char: " + m);
            }
            return l
        }
        vi();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function vi() {
        if (!si) {
            si = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++)
                for (var d = a.concat(b[c].split("")), e = 0; e < d.length; e++) {
                    var f = d[e],
                        g = si[f];
                    g === void 0 ? si[f] = e : y(g === e)
                }
        }
    };

    function wi(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.Te = r.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.kc = this.vd = 0;
        this.oa = [];
        this.yl = a;
        this.Ji = b;
        this.xm = r.Int32Array ? new Int32Array(64) : Array(64);
        xi === void 0 && (xi = r.Int32Array ? new Int32Array(yi) : yi);
        this.reset()
    }
    x(wi, Je);
    for (var zi = [], Ai = 0; Ai < 63; Ai++) zi[Ai] = 0;
    var Bi = [].concat(128, zi);
    wi.prototype.reset = function() {
        this.kc = this.vd = 0;
        this.oa = r.Int32Array ? new Int32Array(this.Ji) : Zb(this.Ji)
    };
    var Ci = function(a) {
        var b = a.Te;
        y(b.length == a.blockSize);
        for (var c = a.xm, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (b = 16; b < 64; b++) d = c[b - 15] | 0, e = c[b - 2] | 0, c[b] = ((c[b - 16] | 0) + ((d >>> 7 | d << 25) ^ (d >>> 18 | d << 14) ^ d >>> 3) | 0) + ((c[b - 7] | 0) + ((e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10) | 0) | 0;
        b = a.oa[0] | 0;
        d = a.oa[1] | 0;
        e = a.oa[2] | 0;
        for (var f = a.oa[3] | 0, g = a.oa[4] | 0, h = a.oa[5] | 0, l = a.oa[6] | 0, m = a.oa[7] | 0, p = 0; p < 64; p++) {
            var w = ((b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10)) + (b & d ^ b & e ^ d & e) | 0,
                z = (m + ((g >>> 6 | g << 26) ^
                    (g >>> 11 | g << 21) ^ (g >>> 25 | g << 7)) | 0) + (((g & h ^ ~g & l) + (xi[p] | 0) | 0) + (c[p] | 0) | 0) | 0;
            m = l;
            l = h;
            h = g;
            g = f + z | 0;
            f = e;
            e = d;
            d = b;
            b = z + w | 0
        }
        a.oa[0] = a.oa[0] + b | 0;
        a.oa[1] = a.oa[1] + d | 0;
        a.oa[2] = a.oa[2] + e | 0;
        a.oa[3] = a.oa[3] + f | 0;
        a.oa[4] = a.oa[4] + g | 0;
        a.oa[5] = a.oa[5] + h | 0;
        a.oa[6] = a.oa[6] + l | 0;
        a.oa[7] = a.oa[7] + m | 0
    };
    wi.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.vd;
        if (typeof a === "string")
            for (; c < b;) this.Te[d++] = a.charCodeAt(c++), d == this.blockSize && (Ci(this), d = 0);
        else if (ya(a))
            for (; c < b;) {
                var e = a[c++];
                if (!("number" == typeof e && 0 <= e && 255 >= e && e == (e | 0))) throw Error("message must be a byte array");
                this.Te[d++] = e;
                d == this.blockSize && (Ci(this), d = 0)
            } else throw Error("message must be string or array");
        this.vd = d;
        this.kc += b
    };
    wi.prototype.digest = function() {
        var a = [],
            b = this.kc * 8;
        this.vd < 56 ? this.update(Bi, 56 - this.vd) : this.update(Bi, this.blockSize - (this.vd - 56));
        for (var c = 63; c >= 56; c--) this.Te[c] = b & 255, b /= 256;
        Ci(this);
        for (c = b = 0; c < this.yl; c++)
            for (var d = 24; d >= 0; d -= 8) a[b++] = this.oa[c] >> d & 255;
        return a
    };
    var yi = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        xi;

    function Di() {
        wi.call(this, 8, Ei)
    }
    x(Di, wi);
    var Ei = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];

    function Fi() {
        this.Gb = this.Gb;
        this.Af = this.Af
    }
    Fi.prototype.Gb = !1;
    Fi.prototype.isDisposed = function() {
        return this.Gb
    };
    Fi.prototype.dispose = function() {
        this.Gb || (this.Gb = !0, this.ae())
    };
    Fi.prototype[Symbol.dispose] = function() {
        this.dispose()
    };
    Fi.prototype.ae = function() {
        if (this.Af)
            for (; this.Af.length;) this.Af.shift()()
    };
    var Gi = function(a, b) {
        this.type = a;
        this.currentTarget = this.target = b;
        this.defaultPrevented = this.xe = !1
    };
    Gi.prototype.stopPropagation = function() {
        this.xe = !0
    };
    Gi.prototype.preventDefault = function() {
        this.defaultPrevented = !0
    };

    function Hi(a, b) {
        Gi.call(this, a ? a.type : "");
        this.relatedTarget = this.currentTarget = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
        this.key = "";
        this.charCode = this.keyCode = 0;
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.timeStamp = 0;
        this.ab = null;
        a && this.init(a, b)
    }
    x(Hi, Gi);
    Hi.prototype.init = function(a, b) {
        var c = this.type = a.type,
            d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
        this.target = a.target || a.srcElement;
        this.currentTarget = b;
        b = a.relatedTarget;
        b || (c == "mouseover" ? b = a.fromElement : c == "mouseout" && (b = a.toElement));
        this.relatedTarget = b;
        d ? (this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX, this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.offsetX = Vc || a.offsetX !== void 0 ? a.offsetX : a.layerX, this.offsetY =
            Vc || a.offsetY !== void 0 ? a.offsetY : a.layerY, this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX, this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
        this.button = a.button;
        this.keyCode = a.keyCode || 0;
        this.key = a.key || "";
        this.charCode = a.charCode || (c == "keypress" ? a.keyCode : 0);
        this.ctrlKey = a.ctrlKey;
        this.altKey = a.altKey;
        this.shiftKey = a.shiftKey;
        this.metaKey = a.metaKey;
        this.pointerId = a.pointerId || 0;
        this.pointerType = a.pointerType;
        this.state = a.state;
        this.timeStamp =
            a.timeStamp;
        this.ab = a;
        a.defaultPrevented && Hi.Od.preventDefault.call(this)
    };
    Hi.prototype.stopPropagation = function() {
        Hi.Od.stopPropagation.call(this);
        this.ab.stopPropagation ? this.ab.stopPropagation() : this.ab.cancelBubble = !0
    };
    Hi.prototype.preventDefault = function() {
        Hi.Od.preventDefault.call(this);
        var a = this.ab;
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };
    Hi.prototype.Ik = function() {
        return this.ab
    };
    var Ii = "closure_listenable_" + (Math.random() * 1E6 | 0);
    var Ji = 0;

    function Ki(a, b, c, d, e) {
        this.listener = a;
        this.proxy = null;
        this.src = b;
        this.type = c;
        this.capture = !!d;
        this.handler = e;
        this.key = ++Ji;
        this.Be = this.Qe = !1
    }
    var Li = function(a) {
        a.Be = !0;
        a.listener = null;
        a.proxy = null;
        a.src = null;
        a.handler = null
    };

    function Mi(a) {
        this.src = a;
        this.Sa = {};
        this.Je = 0
    }
    Mi.prototype.add = function(a, b, c, d, e) {
        var f = a.toString();
        a = this.Sa[f];
        a || (a = this.Sa[f] = [], this.Je++);
        var g = Ni(a, b, d, e);
        g > -1 ? (b = a[g], c || (b.Qe = !1)) : (b = new Ki(b, this.src, f, !!d, e), b.Qe = c, a.push(b));
        return b
    };
    Mi.prototype.remove = function(a, b, c, d) {
        a = a.toString();
        if (!(a in this.Sa)) return !1;
        var e = this.Sa[a];
        b = Ni(e, b, c, d);
        return b > -1 ? (Li(e[b]), Xb(e, b), e.length == 0 && (delete this.Sa[a], this.Je--), !0) : !1
    };
    var Oi = function(a, b) {
        var c = b.type;
        c in a.Sa && Wb(a.Sa[c], b) && (Li(b), a.Sa[c].length == 0 && (delete a.Sa[c], a.Je--))
    };
    Mi.prototype.removeAll = function(a) {
        a = a && a.toString();
        var b = 0,
            c;
        for (c in this.Sa)
            if (!a || c == a) {
                for (var d = this.Sa[c], e = 0; e < d.length; e++) ++b, Li(d[e]);
                delete this.Sa[c];
                this.Je--
            }
        return b
    };
    Mi.prototype.Fg = function(a, b, c, d) {
        a = this.Sa[a.toString()];
        var e = -1;
        a && (e = Ni(a, b, c, d));
        return e > -1 ? a[e] : null
    };
    Mi.prototype.hasListener = function(a, b) {
        var c = a !== void 0,
            d = c ? a.toString() : "",
            e = b !== void 0;
        return bc(this.Sa, function(f) {
            for (var g = 0; g < f.length; ++g)
                if (!(c && f[g].type != d || e && f[g].capture != b)) return !0;
            return !1
        })
    };
    var Ni = function(a, b, c, d) {
        for (var e = 0; e < a.length; ++e) {
            var f = a[e];
            if (!f.Be && f.listener == b && f.capture == !!c && f.handler == d) return e
        }
        return -1
    };
    var Pi = "closure_lm_" + (Math.random() * 1E6 | 0),
        Qi = {},
        Ri = 0,
        Ti = function(a, b, c, d, e) {
            if (d && d.once) Si(a, b, c, d, e);
            else if (Array.isArray(b))
                for (var f = 0; f < b.length; f++) Ti(a, b[f], c, d, e);
            else c = Ui(c), a && a[Ii] ? a.listen(b, c, u(d) ? !!d.capture : !!d, e) : Vi(a, b, c, !1, d, e)
        },
        Vi = function(a, b, c, d, e, f) {
            if (!b) throw Error("Invalid event type");
            var g = u(e) ? !!e.capture : !!e,
                h = Wi(a);
            h || (a[Pi] = h = new Mi(a));
            c = h.add(b, c, d, g, f);
            if (!c.proxy) {
                d = Xi();
                c.proxy = d;
                d.src = a;
                d.listener = c;
                if (a.addEventListener) Ie || (e = g), e === void 0 && (e = !1), a.addEventListener(b.toString(),
                    d, e);
                else if (a.attachEvent) a.attachEvent(Yi(b.toString()), d);
                else if (a.addListener && a.removeListener) y(b === "change", "MediaQueryList only has a change event"), a.addListener(d);
                else throw Error("addEventListener and attachEvent are unavailable.");
                Ri++
            }
        },
        Xi = function() {
            var a = Zi,
                b = function(c) {
                    return a.call(b.src, b.listener, c)
                };
            return b
        },
        Si = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var f = 0; f < b.length; f++) Si(a, b[f], c, d, e);
            else c = Ui(c), a && a[Ii] ? $i(a, b, c, u(d) ? !!d.capture : !!d, e) : Vi(a, b, c, !0, d, e)
        },
        aj = function(a,
            b, c, d, e) {
            if (Array.isArray(b))
                for (var f = 0; f < b.length; f++) aj(a, b[f], c, d, e);
            else d = u(d) ? !!d.capture : !!d, c = Ui(c), a && a[Ii] ? a.Ib.remove(String(b), c, d, e) : a && (a = Wi(a)) && (b = a.Fg(b, c, d, e)) && bj(b)
        },
        bj = function(a) {
            if (typeof a !== "number" && a && !a.Be) {
                var b = a.src;
                if (b && b[Ii]) Oi(b.Ib, a);
                else {
                    var c = a.type,
                        d = a.proxy;
                    b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Yi(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                    Ri--;
                    (c = Wi(b)) ? (Oi(c, a), c.Je == 0 && (c.src = null, b[Pi] = null)) :
                    Li(a)
                }
            }
        },
        Yi = function(a) {
            return a in Qi ? Qi[a] : Qi[a] = "on" + a
        },
        Zi = function(a, b) {
            if (a.Be) a = !0;
            else {
                b = new Hi(b, this);
                var c = a.listener,
                    d = a.handler || a.src;
                a.Qe && bj(a);
                a = c.call(d, b)
            }
            return a
        },
        Wi = function(a) {
            a = a[Pi];
            return a instanceof Mi ? a : null
        },
        cj = "__closure_events_fn_" + (Math.random() * 1E9 >>> 0),
        Ui = function(a) {
            y(a, "Listener can not be null.");
            if (typeof a === "function") return a;
            y(a.handleEvent, "An object listener must have handleEvent method.");
            a[cj] || (a[cj] = function(b) {
                return a.handleEvent(b)
            });
            return a[cj]
        };

    function dj() {
        Fi.call(this);
        this.Ib = new Mi(this);
        this.dk = this;
        this.ah = null
    }
    x(dj, Fi);
    dj.prototype[Ii] = !0;
    k = dj.prototype;
    k.addEventListener = function(a, b, c, d) {
        Ti(this, a, b, c, d)
    };
    k.removeEventListener = function(a, b, c, d) {
        aj(this, a, b, c, d)
    };
    k.dispatchEvent = function(a) {
        ej(this);
        var b = this.ah;
        if (b) {
            var c = [];
            for (var d = 1; b; b = b.ah) c.push(b), y(++d < 1E3, "infinite loop")
        }
        b = this.dk;
        d = a.type || a;
        if (typeof a === "string") a = new Gi(a, b);
        else if (a instanceof Gi) a.target = a.target || b;
        else {
            var e = a;
            a = new Gi(d, b);
            fc(a, e)
        }
        e = !0;
        var f;
        if (c)
            for (f = c.length - 1; !a.xe && f >= 0; f--) {
                var g = a.currentTarget = c[f];
                e = fj(g, d, !0, a) && e
            }
        a.xe || (g = a.currentTarget = b, e = fj(g, d, !0, a) && e, a.xe || (e = fj(g, d, !1, a) && e));
        if (c)
            for (f = 0; !a.xe && f < c.length; f++) g = a.currentTarget = c[f], e = fj(g, d, !1, a) &&
                e;
        return e
    };
    k.ae = function() {
        dj.Od.ae.call(this);
        this.Ib && this.Ib.removeAll(void 0);
        this.ah = null
    };
    k.listen = function(a, b, c, d) {
        ej(this);
        return this.Ib.add(String(a), b, !1, c, d)
    };
    var $i = function(a, b, c, d, e) {
            a.Ib.add(String(b), c, !0, d, e)
        },
        fj = function(a, b, c, d) {
            b = a.Ib.Sa[String(b)];
            if (!b) return !0;
            b = b.concat();
            for (var e = !0, f = 0; f < b.length; ++f) {
                var g = b[f];
                if (g && !g.Be && g.capture == c) {
                    var h = g.listener,
                        l = g.handler || g.src;
                    g.Qe && Oi(a.Ib, g);
                    e = h.call(l, d) !== !1 && e
                }
            }
            return e && !d.defaultPrevented
        };
    dj.prototype.Fg = function(a, b, c, d) {
        return this.Ib.Fg(String(a), b, c, d)
    };
    dj.prototype.hasListener = function(a, b) {
        return this.Ib.hasListener(a !== void 0 ? String(a) : void 0, b)
    };
    var ej = function(a) {
        y(a.Ib, "Event target is not initialized. Did you call the superclass (goog.events.EventTarget) constructor?")
    };

    function gj() {};
    var hj, ij = function() {};
    x(ij, gj);
    ij.prototype.Xd = function() {
        return new XMLHttpRequest
    };
    hj = new ij;

    function jj() {}
    x(jj, gj);
    jj.prototype.Xd = function() {
        var a = new XMLHttpRequest;
        if ("withCredentials" in a) return a;
        if (typeof XDomainRequest != "undefined") return new kj;
        throw Error("Unsupported browser");
    };
    var kj = function() {
        this.Ub = new XDomainRequest;
        this.readyState = 0;
        this.onreadystatechange = null;
        this.responseURL = this.responseType = this.responseText = this.response = "";
        this.status = -1;
        this.responseXML = null;
        this.statusText = "";
        this.Ub.onload = v(this.Pk, this);
        this.Ub.onerror = v(this.Ai, this);
        this.Ub.onprogress = v(this.Rk, this);
        this.Ub.ontimeout = v(this.Vk, this)
    };
    k = kj.prototype;
    k.open = function(a, b, c) {
        if (c != null && !c) throw Error("Only async requests are supported.");
        this.Ub.open(a, b)
    };
    k.send = function(a) {
        if (a)
            if (typeof a == "string") this.Ub.send(a);
            else throw Error("Only string data is supported");
        else this.Ub.send()
    };
    k.abort = function() {
        this.Ub.abort()
    };
    k.setRequestHeader = function() {};
    k.getResponseHeader = function(a) {
        return a.toLowerCase() == "content-type" ? this.Ub.contentType : ""
    };
    k.Pk = function() {
        this.status = 200;
        this.response = this.responseText = this.Ub.responseText;
        lj(this, 4)
    };
    k.Ai = function() {
        this.status = 500;
        this.response = this.responseText = "";
        lj(this, 4)
    };
    k.Vk = function() {
        this.Ai()
    };
    k.Rk = function() {
        this.status = 200;
        lj(this, 1)
    };
    var lj = function(a, b) {
        a.readyState = b;
        if (a.onreadystatechange) a.onreadystatechange()
    };
    kj.prototype.getAllResponseHeaders = function() {
        return "content-type: " + this.Ub.contentType
    };
    var mj = function(a) {
        this.Me = a.Am || null;
        this.Xc = a.Tm || !1;
        this.Nd = a.Um || !1;
        if (this.Xc && this.Nd) throw Error("streamBinaryChunks and streamTextChunks cannot both be true.");
        this.jd = this.Ic = void 0
    };
    x(mj, gj);
    mj.prototype.Xd = function(a) {
        var b = new nj(this.Me, this.Xc, this.Nd);
        this.Ic && b.zh(this.Ic);
        this.jd && b.Dj(this.jd);
        a && (b.Jd = a);
        return b
    };
    mj.prototype.zh = function(a) {
        this.Ic = a
    };
    mj.prototype.Dj = function(a) {
        this.jd = a
    };
    var nj = function(a, b, c) {
        dj.call(this);
        this.Me = a;
        this.Xc = b;
        this.Nd = c || !1;
        this.jd = this.Ic = void 0;
        this.status = this.readyState = 0;
        this.responseURL = this.responseType = this.responseText = this.response = this.statusText = "";
        this.onreadystatechange = this.responseXML = null;
        this.th = new Headers;
        this.Kd = null;
        this.Ui = "GET";
        this.lb = "";
        this.Vb = !1;
        this.Kh = this.Yd = this.Ye = null;
        this.Yf = new AbortController;
        this.Jd = void 0
    };
    x(nj, dj);
    nj.prototype.open = function(a, b, c) {
        y(!!c, "Only async requests are supported.");
        if (this.readyState != 0) throw this.abort(), Error("Error reopening a connection");
        this.Ui = a;
        this.lb = b;
        this.readyState = 1;
        oj(this)
    };
    nj.prototype.send = function(a) {
        if (this.readyState != 1) throw this.abort(), Error("need to call open() first. ");
        var b, c = ((b = this.Jd) == null ? 0 : b.signal) ? AbortSignal.any([this.Jd.signal, this.Yf.signal]) : this.Yf.signal;
        if (c.aborted) throw this.abort(), Error("Request was aborted.");
        this.Vb = !0;
        var d, e, f, g;
        b = Object.assign({}, this.Jd, {
            headers: this.th,
            method: this.Ui,
            credentials: (f = (d = this.Jd) == null ? void 0 : d.credentials) != null ? f : this.Ic,
            cache: (g = (e = this.Jd) == null ? void 0 : e.cache) != null ? g : this.jd,
            signal: c
        });
        a && (b.body =
            a);
        (this.Me || r).fetch(new Request(this.lb, b)).then(this.Uk.bind(this), this.ef.bind(this))
    };
    nj.prototype.abort = function() {
        var a = this;
        this.response = this.Xc || this.Nd ? [] : "";
        this.responseText = "";
        this.th = new Headers;
        this.status = 0;
        this.Yf.abort("Request was aborted.");
        this.Yd && this.Yd.cancel("Request was aborted.").catch(function(b) {
            var c = a.Ga;
            c && Fc(c, tc, "Fetch reader cancellation error.", b)
        });
        this.readyState >= 1 && this.Vb && this.readyState != 4 && (this.Vb = !1, pj(this));
        this.readyState = 0
    };
    nj.prototype.Uk = function(a) {
        if (this.Vb && (this.Ye = a, this.Kd || (this.status = this.Ye.status, this.statusText = this.Ye.statusText, this.Kd = a.headers, this.readyState = 2, oj(this)), this.Vb && (this.readyState = 3, oj(this), this.Vb)))
            if (this.responseType === "arraybuffer") a.arrayBuffer().then(this.Sk.bind(this), this.ef.bind(this));
            else if (a.body && r.ReadableStream) {
            this.Yd = a.body.getReader();
            if (this.Xc || this.Nd) {
                if (this.responseType) throw Error('responseType must be empty for "streamBinaryChunks" or "streamTextChunks" mode responses.');
                this.response = []
            } else this.response = this.responseText = "";
            this.Xc || (this.Kh = new TextDecoder);
            qj(this)
        } else a.text().then(this.Tk.bind(this), this.ef.bind(this))
    };
    var qj = function(a) {
        a.Yd.read().then(a.Nk.bind(a)).catch(a.ef.bind(a))
    };
    nj.prototype.Nk = function(a) {
        if (this.Vb) {
            var b = a.value;
            if (this.Xc) a.value && this.response.push(b || new Uint8Array(0));
            else if (b = b ? this.Kh.decode(b, {
                    stream: !a.done
                }) : "") this.Nd ? this.response.push(b) : this.response = this.responseText += b;
            a.done ? pj(this) : oj(this);
            this.readyState == 3 && qj(this)
        }
    };
    nj.prototype.Tk = function(a) {
        this.Vb && (this.response = this.responseText = a, pj(this))
    };
    nj.prototype.Sk = function(a) {
        this.Vb && (this.response = a, pj(this))
    };
    nj.prototype.ef = function(a) {
        var b = this.Ga;
        b && Fc(b, tc, "Failed to fetch url " + this.lb, a instanceof Error ? a : Error(a));
        this.Vb && pj(this)
    };
    var pj = function(a) {
        a.readyState = 4;
        a.Ye = null;
        a.Yd = null;
        a.Kh = null;
        oj(a)
    };
    k = nj.prototype;
    k.setRequestHeader = function(a, b) {
        this.th.append(a, b)
    };
    k.getResponseHeader = function(a) {
        return this.Kd ? this.Kd.get(a.toLowerCase()) || "" : ((a = this.Ga) && Fc(a, tc, "Attempting to get response header but no headers have been received for url: " + this.lb), "")
    };
    k.getAllResponseHeaders = function() {
        if (!this.Kd) {
            var a = this.Ga;
            a && Fc(a, tc, "Attempting to get all response headers but no headers have been received for url: " + this.lb);
            return ""
        }
        a = [];
        for (var b = this.Kd.entries(), c = b.next(); !c.done;) c = c.value, a.push(c[0] + ": " + c[1]), c = b.next();
        return a.join("\r\n")
    };
    k.zh = function(a) {
        this.Ic = a
    };
    k.Dj = function(a) {
        this.jd = a
    };
    var oj = function(a) {
        a.onreadystatechange && a.onreadystatechange.call(a)
    };
    Object.defineProperty(nj.prototype, "withCredentials", {
        get: function() {
            return this.Ic === "include"
        },
        set: function(a) {
            this.zh(a ? "include" : "same-origin")
        }
    });
    /*

     Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
     Copyright The Closure Library Authors.
     SPDX-License-Identifier: MIT
    */
    function rj(a, b) {
        this.Pf = [];
        this.Xi = a;
        this.ei = b || null;
        this.ie = this.rd = !1;
        this.Wa = void 0;
        this.Gh = this.Th = this.jg = !1;
        this.Vf = 0;
        this.Ja = null;
        this.kg = 0
    }
    rj.prototype.cancel = function(a) {
        if (this.rd) this.Wa instanceof rj && this.Wa.cancel();
        else {
            if (this.Ja) {
                var b = this.Ja;
                delete this.Ja;
                a ? b.cancel(a) : (b.kg--, b.kg <= 0 && b.cancel())
            }
            this.Xi ? this.Xi.call(this.ei, this) : this.Gh = !0;
            this.rd || sj(this, new tj(this))
        }
    };
    rj.prototype.Zh = function(a, b) {
        this.jg = !1;
        uj(this, a, b)
    };
    var uj = function(a, b, c) {
            a.rd = !0;
            a.Wa = c;
            a.ie = !b;
            vj(a)
        },
        xj = function(a) {
            if (a.rd) {
                if (!a.Gh) throw new wj(a);
                a.Gh = !1
            }
        };
    rj.prototype.callback = function(a) {
        xj(this);
        yj(a);
        uj(this, !0, a)
    };
    var sj = function(a, b) {
            xj(a);
            yj(b);
            uj(a, !1, b)
        },
        yj = function(a) {
            y(!(a instanceof rj), "An execution sequence may not be initiated with a blocking Deferred.")
        };
    rj.prototype.addCallback = function(a, b) {
        return zj(this, a, null, b)
    };
    var Aj = function(a, b) {
        zj(a, null, b)
    };
    rj.prototype.finally = function(a) {
        var b = this;
        return Bj(new Promise(function(c, d) {
            zj(b, function(e) {
                a();
                c(e)
            }, function(e) {
                a();
                d(e)
            })
        }))
    };
    var zj = function(a, b, c, d) {
        y(!a.Th, "Blocking Deferreds can not be re-used");
        var e = a.rd;
        e || (b === c ? b = c = Sf(b) : (b = Sf(b), c = Sf(c)));
        a.Pf.push([b, c, d]);
        e && vj(a);
        return a
    };
    rj.prototype.then = function(a, b, c) {
        var d, e, f = new G(function(g, h) {
            e = g;
            d = h
        });
        zj(this, e, function(g) {
            g instanceof tj ? f.cancel() : d(g);
            return Cj
        }, this);
        return f.then(a, b, c)
    };
    rj.prototype.$goog_Thenable = !0;
    var Dj = function(a) {
            return Ub(a.Pf, function(b) {
                return typeof b[1] === "function"
            })
        },
        Cj = {},
        vj = function(a) {
            if (a.Vf && a.rd && Dj(a)) {
                var b = a.Vf,
                    c = Ej[b];
                c && (r.clearTimeout(c.Ra), delete Ej[b]);
                a.Vf = 0
            }
            a.Ja && (a.Ja.kg--, delete a.Ja);
            b = a.Wa;
            for (var d = c = !1; a.Pf.length && !a.jg;) {
                var e = a.Pf.shift(),
                    f = e[0],
                    g = e[1];
                e = e[2];
                if (f = a.ie ? g : f) try {
                    var h = f.call(e || a.ei, b);
                    h === Cj && (h = void 0);
                    h !== void 0 && (a.ie = a.ie && (h == b || h instanceof Error), a.Wa = b = h);
                    if (jg(b) || typeof r.Promise === "function" && b instanceof r.Promise) d = !0, a.jg = !0
                } catch (l) {
                    b =
                        l, a.ie = !0, Dj(a) || (c = !0)
                }
            }
            a.Wa = b;
            d && (h = v(a.Zh, a, !0), d = v(a.Zh, a, !1), b instanceof rj ? (zj(b, h, d), b.Th = !0) : b.then(h, d));
            c && (b = new Fj(b), Ej[b.Ra] = b, a.Vf = b.Ra)
        },
        Bj = function(a) {
            var b = new rj;
            a.then(function(c) {
                b.callback(c)
            }, function(c) {
                sj(b, c)
            });
            return b
        },
        wj = function() {
            Ib.call(this)
        };
    x(wj, Ib);
    wj.prototype.message = "Deferred has already fired";
    wj.prototype.name = "AlreadyCalledError";
    var tj = function() {
        Ib.call(this)
    };
    x(tj, Ib);
    tj.prototype.message = "Deferred was canceled";
    tj.prototype.name = "CanceledError";
    var Fj = function(a) {
        this.Ra = r.setTimeout(v(this.rm, this), 0);
        this.Db = a
    };
    Fj.prototype.rm = function() {
        y(Ej[this.Ra], "Cannot throw an error that is not scheduled.");
        delete Ej[this.Ra];
        throw this.Db;
    };
    var Ej = {};
    var Kj = function(a) {
            var b = {},
                c = b.document || document,
                d = ub(a).toString(),
                e = (new nd(c)).createElement("SCRIPT"),
                f = {
                    yj: e,
                    Tf: void 0
                },
                g = new rj(Gj, f),
                h = null,
                l = b.timeout != null ? b.timeout : 5E3;
            l > 0 && (h = window.setTimeout(function() {
                Hj(e, !0);
                sj(g, new Ij(1, "Timeout reached for loading script " + d))
            }, l), f.Tf = h);
            e.onload = e.onreadystatechange = function() {
                e.readyState && e.readyState != "loaded" && e.readyState != "complete" || (Hj(e, b.Om || !1, h), g.callback(null))
            };
            e.onerror = function() {
                Hj(e, !0, h);
                sj(g, new Ij(0, "Error while loading script " +
                    d))
            };
            f = b.attributes || {};
            fc(f, {
                type: "text/javascript",
                charset: "UTF-8"
            });
            hd(e, f);
            pc(e, a);
            Jj(c).appendChild(e);
            return g
        },
        Jj = function(a) {
            var b;
            return (b = (a || document).getElementsByTagName("HEAD")) && b.length !== 0 ? b[0] : a.documentElement
        },
        Gj = function() {
            if (this && this.yj) {
                var a = this.yj;
                a && a.tagName == "SCRIPT" && Hj(a, !0, this.Tf)
            }
        },
        Hj = function(a, b, c) {
            c != null && r.clearTimeout(c);
            a.onload = function() {};
            a.onerror = function() {};
            a.onreadystatechange = function() {};
            b && window.setTimeout(function() {
                ld(a)
            }, 0)
        },
        Ij = function(a,
            b) {
            var c = "Jsloader error (code #" + a + ")";
            b && (c += ": " + b);
            Ib.call(this, c);
            this.code = a
        };
    x(Ij, Ib);
    var Lj = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Mj(a, b) {
        if (a) {
            a = a.split("&");
            for (var c = 0; c < a.length; c++) {
                var d = a[c].indexOf("="),
                    e = null;
                if (d >= 0) {
                    var f = a[c].substring(0, d);
                    e = a[c].substring(d + 1)
                } else f = a[c];
                b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
            }
        }
    };
    var Nj = function(a) {
        dj.call(this);
        this.headers = new Map;
        this.Yj = a || null;
        this.oc = !1;
        this.v = null;
        this.me = this.Pi = this.uf = "";
        this.Oc = this.Lg = this.nf = this.zg = !1;
        this.He = 0;
        this.Yc = null;
        this.Kf = "";
        this.Ll = this.Xj = !1;
        this.hg = this.Lh = null
    };
    x(Nj, dj);
    var Oj = /^https?$/i,
        Pj = ["POST", "PUT"];
    k = Nj.prototype;
    k.setTrustToken = function(a) {
        this.Lh = a
    };
    k.setAttributionReporting = function(a) {
        this.hg = a
    };
    k.send = function(a, b, c, d) {
        if (this.v) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.uf + "; newUri=" + a);
        if (typeof b === "string") var e = b;
        else if (b) {
            var f = b;
            e = f.method;
            c != null || (c = f.body);
            d != null || (d = f.headers)
        }
        e = e ? e.toUpperCase() : "GET";
        this.uf = a;
        this.me = "";
        this.Pi = e;
        this.zg = !1;
        this.oc = !0;
        this.v = this.Yj ? this.Yj.Xd(f) : hj.Xd();
        this.v.onreadystatechange = Sf(v(this.hj, this));
        this.Ll && "onprogress" in this.v && (this.v.onprogress = Sf(v(function(D) {
            this.fj(D, !0)
        }, this)), this.v.upload && (this.v.upload.onprogress =
            Sf(v(this.fj, this))));
        try {
            Gc(this.Ga, Qj(this, "Opening Xhr")), this.Lg = !0, this.v.open(e, String(a), !0), this.Lg = !1
        } catch (D) {
            Gc(this.Ga, Qj(this, "Error opening Xhr: " + D.message));
            this.Db(5, D);
            return
        }
        a = c || "";
        b = new Map(this.headers);
        if (d)
            if (Object.getPrototypeOf(d) === Object.prototype)
                for (var g in d) b.set(g, d[g]);
            else if (typeof d.keys === "function" && typeof d.get === "function") {
            g = la(d.keys());
            c = g.next();
            var h;
            try {
                for (; !c.done; c = g.next()) {
                    var l = c.value;
                    b.set(l, d.get(l))
                }
            } finally {
                c && !c.done && (h = g.return) && h.call(g)
            }
        } else throw Error("Unknown input type for opt_headers: " +
            String(d));
        d = Array.from(b.keys()).find(function(D) {
            return "content-type" == D.toLowerCase()
        });
        h = r.FormData && a instanceof r.FormData;
        !Vb(Pj, e) || d || h || b.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        e = la(b);
        d = e.next();
        var m;
        try {
            for (; !d.done; d = e.next()) {
                var p = la(d.value),
                    w = p.next().value,
                    z = p.next().value;
                this.v.setRequestHeader(w, z)
            }
        } finally {
            d && !d.done && (m = e.return) && m.call(e)
        }
        this.Kf && (this.v.responseType = this.Kf);
        "withCredentials" in this.v && this.v.withCredentials !== this.Xj && (this.v.withCredentials =
            this.Xj);
        if ("setTrustToken" in this.v && this.Lh) try {
            this.v.setTrustToken(this.Lh)
        } catch (D) {
            Gc(this.Ga, Qj(this, "Error SetTrustToken: " + D.message))
        }
        if ("setAttributionReporting" in this.v && this.hg) try {
            this.v.setAttributionReporting(this.hg)
        } catch (D) {
            Gc(this.Ga, Qj(this, "Error SetAttributionReporting: " + D.message))
        }
        try {
            this.Yc && (clearTimeout(this.Yc), this.Yc = null), this.He > 0 && (Gc(this.Ga, Qj(this, "Will abort after " + this.He + "ms if incomplete")), this.Yc = setTimeout(this.Tf.bind(this), this.He)), Gc(this.Ga, Qj(this,
                "Sending request")), this.nf = !0, this.v.send(a), this.nf = !1
        } catch (D) {
            Gc(this.Ga, Qj(this, "Send error: " + D.message)), this.Db(5, D)
        }
    };
    k.Tf = function() {
        typeof va != "undefined" && this.v && (this.me = "Timed out after " + this.He + "ms, aborting", Gc(this.Ga, Qj(this, this.me)), this.dispatchEvent("timeout"), this.abort(8))
    };
    k.Db = function(a, b) {
        this.oc = !1;
        this.v && (this.Oc = !0, this.v.abort(), this.Oc = !1);
        this.me = b;
        Rj(this);
        Sj(this)
    };
    var Rj = function(a) {
        a.zg || (a.zg = !0, a.dispatchEvent("complete"), a.dispatchEvent("error"))
    };
    Nj.prototype.abort = function() {
        this.v && this.oc && (Gc(this.Ga, Qj(this, "Aborting")), this.oc = !1, this.Oc = !0, this.v.abort(), this.Oc = !1, this.dispatchEvent("complete"), this.dispatchEvent("abort"), Sj(this))
    };
    Nj.prototype.ae = function() {
        this.v && (this.oc && (this.oc = !1, this.Oc = !0, this.v.abort(), this.Oc = !1), Sj(this, !0));
        Nj.Od.ae.call(this)
    };
    Nj.prototype.hj = function() {
        this.isDisposed() || (this.Lg || this.nf || this.Oc ? Tj(this) : this.El())
    };
    Nj.prototype.El = function() {
        Tj(this)
    };
    var Tj = function(a) {
        if (a.oc && typeof va != "undefined")
            if (a.nf && Uj(a) == 4) setTimeout(a.hj.bind(a), 0);
            else if (a.dispatchEvent("readystatechange"), Uj(a) == 4) {
            Gc(a.Ga, Qj(a, "Request complete"));
            a.oc = !1;
            try {
                var b = a.getStatus();
                a: switch (b) {
                    case 200:
                    case 201:
                    case 202:
                    case 204:
                    case 206:
                    case 304:
                    case 1223:
                        var c = !0;
                        break a;
                    default:
                        c = !1
                }
                var d;
                if (!(d = c)) {
                    var e;
                    if (e = b === 0) {
                        var f = String(a.uf).match(Lj)[1] || null;
                        !f && r.self && r.self.location && (f = r.self.location.protocol.slice(0, -1));
                        e = !Oj.test(f ? f.toLowerCase() : "")
                    }
                    d = e
                }
                if (d) a.dispatchEvent("complete"),
                    a.dispatchEvent("success");
                else {
                    try {
                        var g = Uj(a) > 2 ? a.v.statusText : ""
                    } catch (h) {
                        Gc(a.Ga, "Can not get status: " + h.message), g = ""
                    }
                    a.me = g + " [" + a.getStatus() + "]";
                    Rj(a)
                }
            } finally {
                Sj(a)
            }
        }
    };
    Nj.prototype.fj = function(a, b) {
        y(a.type === "progress", "goog.net.EventType.PROGRESS is of the same type as raw XHR progress.");
        this.dispatchEvent(Vj(a, "progress"));
        this.dispatchEvent(Vj(a, b ? "downloadprogress" : "uploadprogress"))
    };
    var Vj = function(a, b) {
            return {
                type: b,
                lengthComputable: a.lengthComputable,
                loaded: a.loaded,
                total: a.total
            }
        },
        Sj = function(a, b) {
            if (a.v) {
                a.Yc && (clearTimeout(a.Yc), a.Yc = null);
                var c = a.v;
                a.v = null;
                b || a.dispatchEvent("ready");
                try {
                    c.onreadystatechange = null
                } catch (d) {
                    (a = a.Ga) && Fc(a, sc, "Problem encountered resetting onreadystatechange: " + d.message)
                }
            }
        };
    Nj.prototype.isActive = function() {
        return !!this.v
    };
    var Uj = function(a) {
        return a.v ? a.v.readyState : 0
    };
    Nj.prototype.getStatus = function() {
        try {
            return Uj(this) > 2 ? this.v.status : -1
        } catch (a) {
            return -1
        }
    };
    Nj.prototype.getResponse = function() {
        try {
            if (!this.v) return null;
            if ("response" in this.v) return this.v.response;
            switch (this.Kf) {
                case "":
                case "text":
                    return this.v.responseText;
                case "arraybuffer":
                    if ("mozResponseArrayBuffer" in this.v) return this.v.mozResponseArrayBuffer
            }
            var a = this.Ga;
            a && Fc(a, sc, "Response type " + this.Kf + " is not supported on this browser");
            return null
        } catch (b) {
            return Gc(this.Ga, "Can not get response: " + b.message), null
        }
    };
    Nj.prototype.getResponseHeader = function(a) {
        if (this.v && Uj(this) == 4) return a = this.v.getResponseHeader(a), a === null ? void 0 : a
    };
    Nj.prototype.getAllResponseHeaders = function() {
        return this.v && Uj(this) >= 2 ? this.v.getAllResponseHeaders() || "" : ""
    };
    var Qj = function(a, b) {
        return b + " [" + a.Pi + " " + a.uf + " " + a.getStatus() + "]"
    };
    var Wj = function(a, b) {
            if (typeof a !== "function")
                if (a && typeof a.handleEvent == "function") a = v(a.handleEvent, a);
                else throw Error("Invalid listener argument");
            return Number(b) > 2147483647 ? -1 : r.setTimeout(a, b || 0)
        },
        Xj = function(a) {
            var b = null;
            return (new G(function(c, d) {
                b = Wj(function() {
                    c(void 0)
                }, a);
                b == -1 && d(Error("Failed to schedule timer."))
            })).l(function(c) {
                r.clearTimeout(b);
                throw c;
            })
        };
    var Yj = function(a) {
            if (a.Nc && typeof a.Nc == "function") return a.Nc();
            if (typeof Map !== "undefined" && a instanceof Map || typeof Set !== "undefined" && a instanceof Set) return Array.from(a.values());
            if (typeof a === "string") return a.split("");
            if (ya(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            b = [];
            c = 0;
            for (d in a) b[c++] = a[d];
            return b
        },
        Zj = function(a) {
            if (a.Eg && typeof a.Eg == "function") return a.Eg();
            if (!a.Nc || typeof a.Nc != "function") {
                if (typeof Map !== "undefined" && a instanceof Map) return Array.from(a.keys());
                if (!(typeof Set !== "undefined" && a instanceof Set)) {
                    if (ya(a) || typeof a === "string") {
                        var b = [];
                        a = a.length;
                        for (var c = 0; c < a; c++) b.push(c);
                        return b
                    }
                    b = [];
                    c = 0;
                    for (var d in a) b[c++] = d;
                    return b
                }
            }
        },
        ak = function(a, b, c) {
            if (a.forEach && typeof a.forEach == "function") a.forEach(b, c);
            else if (ya(a) || typeof a === "string") Array.prototype.forEach.call(a, b, c);
            else
                for (var d = Zj(a), e = Yj(a), f = e.length, g = 0; g < f; g++) b.call(c, e[g], d && d[g], a)
        };

    function bk(a) {
        this.Ia = this.Zc = this.Xa = "";
        this.Wb = null;
        this.Lc = this.Df = "";
        this.Eb = this.ol = !1;
        if (a instanceof bk) {
            this.Eb = a.Eb;
            ck(this, a.Xa);
            var b = a.Zc;
            dk(this);
            this.Zc = b;
            ek(this, a.Ia);
            fk(this, a.Wb);
            this.setPath(a.getPath());
            gk(this, a.wb.clone());
            a = a.Lc;
            dk(this);
            this.Lc = a
        } else a && (b = String(a).match(Lj)) ? (this.Eb = !1, ck(this, b[1] || "", !0), a = b[2] || "", dk(this), this.Zc = hk(a), ek(this, b[3] || "", !0), fk(this, b[4]), this.setPath(b[5] || "", !0), gk(this, b[6] || "", !0), a = b[7] || "", dk(this), this.Lc = hk(a)) : (this.Eb = !1, this.wb =
            new ik(null, this.Eb))
    }
    bk.prototype.toString = function() {
        var a = [],
            b = this.Xa;
        b && a.push(jk(b, kk, !0), ":");
        var c = this.Ia;
        if (c || b == "file") a.push("//"), (b = this.Zc) && a.push(jk(b, kk, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.Wb, c != null && a.push(":", String(c));
        if (c = this.getPath()) this.Ia && c.charAt(0) != "/" && a.push("/"), a.push(jk(c, c.charAt(0) == "/" ? lk : mk, !0));
        (c = this.wb.toString()) && a.push("?", c);
        (c = this.Lc) && a.push("#", jk(c, nk));
        return a.join("")
    };
    bk.prototype.resolve = function(a) {
        var b = this.clone(),
            c = !!a.Xa;
        c ? ck(b, a.Xa) : c = !!a.Zc;
        if (c) {
            var d = a.Zc;
            dk(b);
            b.Zc = d
        } else c = !!a.Ia;
        c ? ek(b, a.Ia) : c = a.Wb != null;
        d = a.getPath();
        if (c) fk(b, a.Wb);
        else if (c = !!a.Df) {
            if (d.charAt(0) != "/")
                if (this.Ia && !this.Df) d = "/" + d;
                else {
                    var e = b.getPath().lastIndexOf("/");
                    e != -1 && (d = b.getPath().slice(0, e + 1) + d)
                }
            e = d;
            if (e == ".." || e == ".") d = "";
            else if (B(e, "./") || B(e, "/.")) {
                d = e.lastIndexOf("/", 0) == 0;
                e = e.split("/");
                for (var f = [], g = 0; g < e.length;) {
                    var h = e[g++];
                    h == "." ? d && g == e.length && f.push("") :
                        h == ".." ? ((f.length > 1 || f.length == 1 && f[0] != "") && f.pop(), d && g == e.length && f.push("")) : (f.push(h), d = !0)
                }
                d = f.join("/")
            } else d = e
        }
        c ? b.setPath(d) : c = a.wb.toString() !== "";
        c ? gk(b, a.wb.clone()) : c = !!a.Lc;
        c && (a = a.Lc, dk(b), b.Lc = a);
        return b
    };
    bk.prototype.clone = function() {
        return new bk(this)
    };
    var ck = function(a, b, c) {
            dk(a);
            a.Xa = c ? hk(b, !0) : b;
            a.Xa && (a.Xa = a.Xa.replace(/:$/, ""))
        },
        ek = function(a, b, c) {
            dk(a);
            a.Ia = c ? hk(b, !0) : b
        },
        fk = function(a, b) {
            dk(a);
            if (b) {
                b = Number(b);
                if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
                a.Wb = b
            } else a.Wb = null
        };
    bk.prototype.getPath = function() {
        return this.Df
    };
    bk.prototype.setPath = function(a, b) {
        dk(this);
        this.Df = b ? hk(a, !0) : a;
        return this
    };
    var gk = function(a, b, c) {
        dk(a);
        b instanceof ik ? (a.wb = b, a.wb.Bh(a.Eb)) : (c || (b = jk(b, ok)), a.wb = new ik(b, a.Eb))
    };
    bk.prototype.getQuery = function() {
        return this.wb.toString()
    };
    var M = function(a, b, c) {
            dk(a);
            a.wb.set(b, c)
        },
        pk = function(a, b) {
            return a.wb.get(b)
        };
    bk.prototype.removeParameter = function(a) {
        dk(this);
        this.wb.remove(a);
        return this
    };
    var dk = function(a) {
        if (a.ol) throw Error("Tried to modify a read-only Uri");
    };
    bk.prototype.Bh = function(a) {
        this.Eb = a;
        this.wb && this.wb.Bh(a)
    };
    var N = function(a) {
            return a instanceof bk ? a.clone() : new bk(a)
        },
        qk = function(a, b, c, d) {
            var e = new bk(null);
            a && ck(e, a);
            b && ek(e, b);
            c && fk(e, c);
            d && e.setPath(d);
            return e
        },
        hk = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        },
        jk = function(a, b, c) {
            return typeof a === "string" ? (a = encodeURI(a).replace(b, rk), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        },
        rk = function(a) {
            a = a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        kk = /[#\/\?@]/g,
        mk = /[#\?:]/g,
        lk =
        /[#\?]/g,
        ok = /[#\?@]/g,
        nk = /#/g,
        ik = function(a, b) {
            this.Pa = this.va = null;
            this.ob = a || null;
            this.Eb = !!b
        },
        sk = function(a) {
            a.va || (a.va = new Map, a.Pa = 0, a.ob && Mj(a.ob, function(b, c) {
                a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
            }))
        },
        tk = function(a) {
            var b = Zj(a);
            if (typeof b == "undefined") throw Error("Keys are undefined");
            var c = new ik(null);
            a = Yj(a);
            for (var d = 0; d < b.length; d++) {
                var e = b[d],
                    f = a[d];
                Array.isArray(f) ? c.setValues(e, f) : c.add(e, f)
            }
            return c
        };
    ik.prototype.add = function(a, b) {
        sk(this);
        this.ob = null;
        a = this.rb(a);
        var c = this.va.get(a);
        c || this.va.set(a, c = []);
        c.push(b);
        this.Pa = Ob(this.Pa) + 1;
        return this
    };
    ik.prototype.remove = function(a) {
        sk(this);
        a = this.rb(a);
        return this.va.has(a) ? (this.ob = null, this.Pa = Ob(this.Pa) - this.va.get(a).length, this.va.delete(a)) : !1
    };
    ik.prototype.clear = function() {
        this.va = this.ob = null;
        this.Pa = 0
    };
    ik.prototype.isEmpty = function() {
        sk(this);
        return this.Pa == 0
    };
    var uk = function(a, b) {
        sk(a);
        b = a.rb(b);
        return a.va.has(b)
    };
    k = ik.prototype;
    k.forEach = function(a, b) {
        sk(this);
        this.va.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };
    k.Eg = function() {
        sk(this);
        for (var a = Array.from(this.va.values()), b = Array.from(this.va.keys()), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
        return c
    };
    k.Nc = function(a) {
        sk(this);
        var b = [];
        if (typeof a === "string") uk(this, a) && (b = b.concat(this.va.get(this.rb(a))));
        else {
            a = Array.from(this.va.values());
            for (var c = 0; c < a.length; c++) b = b.concat(a[c])
        }
        return b
    };
    k.set = function(a, b) {
        sk(this);
        this.ob = null;
        a = this.rb(a);
        uk(this, a) && (this.Pa = Ob(this.Pa) - this.va.get(a).length);
        this.va.set(a, [b]);
        this.Pa = Ob(this.Pa) + 1;
        return this
    };
    k.get = function(a, b) {
        if (!a) return b;
        a = this.Nc(a);
        return a.length > 0 ? String(a[0]) : b
    };
    k.setValues = function(a, b) {
        this.remove(a);
        b.length > 0 && (this.ob = null, this.va.set(this.rb(a), Zb(b)), this.Pa = Ob(this.Pa) + b.length)
    };
    k.toString = function() {
        if (this.ob) return this.ob;
        if (!this.va) return "";
        for (var a = [], b = Array.from(this.va.keys()), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.Nc(d);
            for (var f = 0; f < d.length; f++) {
                var g = e;
                d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
                a.push(g)
            }
        }
        return this.ob = a.join("&")
    };
    k.clone = function() {
        var a = new ik;
        a.ob = this.ob;
        this.va && (a.va = new Map(this.va), a.Pa = this.Pa);
        return a
    };
    k.rb = function(a) {
        a = String(a);
        this.Eb && (a = a.toLowerCase());
        return a
    };
    k.Bh = function(a) {
        a && !this.Eb && (sk(this), this.ob = null, this.va.forEach(function(b, c) {
            var d = c.toLowerCase();
            c != d && (this.remove(c), this.setValues(d, b))
        }, this));
        this.Eb = a
    };
    k.extend = function(a) {
        for (var b = 0; b < arguments.length; b++) ak(arguments[b], function(c, d) {
            this.add(d, c)
        }, this)
    };
    var vk = function(a) {
            var b = Error();
            b.name = "SecurityError";
            a = "Failed to read a named property '" + a + "' from 'Window': ";
            if ("location" in window) try {
                a += 'Blocked a frame with origin "' + window.location.href + '" from accessing a cross-origin frame.'
            } catch (c) {
                a += "An attempt was made to break through the security policy of the user agent."
            }
            b.message = a;
            throw b;
        },
        wk = function() {
            return {
                get opener() {
                    return null
                },
                set opener(a) {},
                get closed() {
                    return !0
                },
                get location() {
                    vk("location")
                },
                get document() {
                    vk("document")
                },
                postMessage: function() {},
                close: function() {},
                focus: function() {}
            }
        };
    var xk = {
        Dm: {
            Ze: "https://staging-identitytoolkit.sandbox.googleapis.com/identitytoolkit/v3/relyingparty/",
            Mf: "https://staging-securetoken.sandbox.googleapis.com/v1/token",
            jf: "https://staging-identitytoolkit.sandbox.googleapis.com/v2/",
            id: "b"
        },
        Jm: {
            Ze: "https://www.googleapis.com/identitytoolkit/v3/relyingparty/",
            Mf: "https://securetoken.googleapis.com/v1/token",
            jf: "https://identitytoolkit.googleapis.com/v2/",
            id: "p"
        },
        Km: {
            Ze: "https://staging-www.sandbox.googleapis.com/identitytoolkit/v3/relyingparty/",
            Mf: "https://staging-securetoken.sandbox.googleapis.com/v1/token",
            jf: "https://staging-identitytoolkit.sandbox.googleapis.com/v2/",
            id: "s"
        },
        Lm: {
            Ze: "https://www-googleapis-test.sandbox.google.com/identitytoolkit/v3/relyingparty/",
            Mf: "https://test-securetoken.sandbox.googleapis.com/v1/token",
            jf: "https://test-identitytoolkit.sandbox.googleapis.com/v2/",
            id: "t"
        }
    };

    function yk(a) {
        for (var b in xk)
            if (xk[b].id === a) return a = xk[b], {
                firebaseEndpoint: a.Ze,
                secureTokenEndpoint: a.Mf,
                identityPlatformEndpoint: a.jf
            };
        return null
    }
    var zk;
    zk = yk("__EID__") ? "__EID__" : void 0;
    var angular, Bk = function() {
            var a = Ak();
            return Sc && !!ed && ed == 11 || /Edge\/\d+/.test(a)
        },
        Ck = function() {
            return r.window && r.window.location.href || self && self.location && self.location.href || ""
        },
        Dk = function(a, b) {
            b = b || r.window;
            var c = "about:blank";
            a && (c = xb(Bb(a)));
            b.location.href = c
        },
        Ek = function(a, b) {
            var c = [],
                d;
            for (d in a) d in b ? typeof a[d] != typeof b[d] ? c.push(d) : typeof a[d] == "object" && a[d] != null && b[d] != null ? Ek(a[d], b[d]).length > 0 && c.push(d) : a[d] !== b[d] && c.push(d) : c.push(d);
            for (var e in b) e in a || c.push(e);
            return c
        },
        Gk = function() {
            var a = Ak();
            a = Fk(a) != "Chrome" ? null : (a = a.match(/\sChrome\/(\d+)/i)) && a.length == 2 ? parseInt(a[1], 10) : null;
            return a && a < 30 ? !1 : !Sc || !ed || ed > 9
        },
        Hk = function(a) {
            a = (a || Ak()).toLowerCase();
            return a.match(/android/) || a.match(/webos/) || a.match(/iphone|ipad|ipod/) || a.match(/blackberry/) || a.match(/windows phone/) || a.match(/iemobile/) ? !0 : !1
        },
        Ik = function(a) {
            a = a || r.window;
            try {
                a.close()
            } catch (b) {}
        },
        Jk = function(a, b, c) {
            var d = Math.floor(Math.random() * 1E9).toString();
            b = b || 500;
            c = c || 600;
            var e = (window.screen.availHeight -
                    c) / 2,
                f = (window.screen.availWidth - b) / 2;
            b = {
                width: b,
                height: c,
                top: e > 0 ? e : 0,
                left: f > 0 ? f : 0,
                location: !0,
                resizable: !0,
                statusbar: !0,
                toolbar: !1
            };
            c = Ak().toLowerCase();
            d && (b.target = d, B(c, "crios/") && (b.target = "_blank"));
            Fk(Ak()) == "Firefox" && (a = a || "http://localhost", b.scrollbars = !0);
            f = a || "";
            (d = b) || (d = {});
            a = window;
            b = f instanceof vb ? f : Bb(typeof f.href != "undefined" ? f.href : String(f));
            e = self.crossOriginIsolated !== void 0;
            c = "strict-origin-when-cross-origin";
            window.Request && (c = (new Request("/")).referrerPolicy);
            var g = d.noreferrer;
            if (e && g && c === "unsafe-url") throw Error("Cannot use the noreferrer option on a page that sets a referrer-policy of `unsafe-url` in modern browsers!");
            c = g && !e;
            f = d.target || f.target;
            g = [];
            var h = [],
                l = !1;
            for (p in d) {
                var m = d[p];
                switch (p) {
                    case "width":
                    case "height":
                    case "top":
                    case "left":
                        g.push(p + "=" + m);
                        break;
                    case "target":
                        break;
                    case "noopener":
                    case "noreferrer":
                        m ? h.push(p) : (l = !0, h.push(p + "=false"));
                        break;
                    case "attributionsrc":
                        g.push(p + (m ? "=" + m : ""));
                        break;
                    default:
                        g.push(p + "=" + (m ? 1 : 0))
                }
            }
            var p = f !== void 0 && !["_blank",
                "_self", "_top", "_parent", ""
            ].includes(f);
            p = (C("Firefox") || C("FxiOS")) && p;
            Kc && e && g.length === 0 && h.length > 0 && !p && !l ? (h.length === 2 && (h = ["noreferrer"]), oc(a, b, f, h[0]), p = wk()) : (p = g.join(","), (Qc() || C("iPad") || C("iPod")) && a.navigator && a.navigator.standalone && f && f != "_self" ? (p = jd(document, "A"), b = Eb(b), b !== void 0 && (p.href = b), p.target = f, c && (p.rel = "noreferrer"), ((d = d.attributionsrc) || d === "") && p.setAttribute("attributionsrc", d), d = document.createEvent("MouseEvent"), d.initMouseEvent("click", !0, !0, a, 1), p.dispatchEvent(d),
                p = wk()) : c ? (p = oc(a, "", f, p), a = xb(b), p && (p.opener = null, a === "" && (a = "javascript:''"), nc.test(a) && (a.indexOf("&") != -1 && (a = a.replace(hc, "&amp;")), a.indexOf("<") != -1 && (a = a.replace(ic, "&lt;")), a.indexOf(">") != -1 && (a = a.replace(jc, "&gt;")), a.indexOf('"') != -1 && (a = a.replace(kc, "&quot;")), a.indexOf("'") != -1 && (a = a.replace(lc, "&#39;")), a.indexOf("\x00") != -1 && (a = a.replace(mc, "&#0;"))), a = '<meta name="referrer" content="no-referrer"><meta http-equiv="refresh" content="0; url=' + a + '">', Hc("b/12014412, meta tag with sanitized URL"),
                a = qb(a), (d = p.document) && d.write && (d.write(rb(a)), d.close()))) : ((p = oc(a, b, f, p)) && d.noopener && (p.opener = null), p && d.noreferrer && (p.opener = null)));
            if (p) try {
                p.focus()
            } catch (w) {}
            return p
        },
        Kk = function(a) {
            return new G(function(b) {
                var c = function() {
                    Xj(2E3).then(function() {
                        if (!a || a.closed) b();
                        else return c()
                    })
                };
                return c()
            })
        },
        Mk = function(a, b) {
            var c = N(b);
            b = c.Xa;
            c = c.Ia;
            for (var d = 0; d < a.length; d++) {
                var e = a[d];
                e.indexOf("chrome-extension://") == 0 ? e = N(e).Ia == c && b == "chrome-extension" : b != "http" && b != "https" ? e = !1 : Lk.test(e) ?
                    e = c == e : (e = e.split(".").join("\\."), e = (new RegExp("^(.+\\." + e + "|" + e + ")$", "i")).test(c));
                if (e) return !0
            }
            return !1
        },
        Lk = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,
        Nk = /^[^@]+@[^@]+$/,
        Ok = function() {
            var a = null;
            return (new G(function(b) {
                r.document.readyState == "complete" ? b() : (a = function() {
                    b()
                }, Si(window, "load", a))
            })).l(function(b) {
                aj(window, "load", a);
                throw b;
            })
        },
        Qk = function() {
            return Pk() ? Ok().then(function() {
                return new G(function(a, b) {
                    var c = r.document,
                        d = setTimeout(function() {
                                b(Error("Cordova framework is not ready."))
                            },
                            1E3);
                    c.addEventListener("deviceready", function() {
                        clearTimeout(d);
                        a()
                    }, !1)
                })
            }) : I(Error("Cordova must run in an Android or iOS file scheme."))
        },
        Pk = function() {
            var a = Ak();
            return !(Rk() !== "file:" && Rk() !== "ionic:" || !a.toLowerCase().match(/iphone|ipad|ipod|android/))
        },
        Sk = function() {
            var a = r.window;
            try {
                return !(!a || a == a.top)
            } catch (b) {
                return !1
            }
        },
        Tk = function() {
            return typeof r.WorkerGlobalScope !== "undefined" && typeof r.importScripts === "function"
        },
        Uk = function() {
            return firebase.INTERNAL.hasOwnProperty("reactNative") ?
                "ReactNative" : firebase.INTERNAL.hasOwnProperty("node") ? "Node" : Tk() ? "Worker" : "Browser"
        },
        Vk = function() {
            var a = Uk();
            return a === "ReactNative" || a === "Node"
        },
        Wk = function() {
            for (var a = 50, b = []; a > 0;) b.push("1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(Math.floor(Math.random() * 62))), a--;
            return b.join("")
        },
        Fk = function(a) {
            var b = a.toLowerCase();
            if (B(b, "opera/") || B(b, "opr/") || B(b, "opios/")) return "Opera";
            if (B(b, "iemobile")) return "IEMobile";
            if (B(b, "msie") || B(b, "trident/")) return "IE";
            if (B(b,
                    "edge/")) return "Edge";
            if (B(b, "firefox/")) return "Firefox";
            if (B(b, "silk/")) return "Silk";
            if (B(b, "blackberry")) return "Blackberry";
            if (B(b, "webos")) return "Webos";
            if (!B(b, "safari/") || B(b, "chrome/") || B(b, "crios/") || B(b, "android"))
                if (!B(b, "chrome/") && !B(b, "crios/") || B(b, "edge/")) {
                    if (B(b, "android")) return "Android";
                    if ((a = a.match(RegExp("([a-zA-Z\\d\\.]+)/[a-zA-Z\\d\\.]*$"))) && a.length == 2) return a[1]
                } else return "Chrome";
            else return "Safari";
            return "Other"
        },
        Xk = {
            DEFAULT: "FirebaseCore-web",
            Fm: "FirebaseUI-web",
            Im: "gcip-iap"
        },
        Yk = function(a, b, c) {
            c = c || [];
            var d = [],
                e = {},
                f;
            for (f in Xk) e[Xk[f]] = !0;
            for (f = 0; f < c.length; f++) typeof e[c[f]] !== "undefined" && (delete e[c[f]], d.push(c[f]));
            d.sort();
            c = d;
            c.length || (c = ["FirebaseCore-web"]);
            d = Uk();
            return (d === "Browser" ? Fk(Ak()) : d === "Worker" ? Fk(Ak()) + "-" + d : d) + "/" + a + "/" + b + "/" + c.join(",")
        },
        Ak = function() {
            return r.navigator && r.navigator.userAgent || ""
        },
        O = function(a, b) {
            a = a.split(".");
            b = b || r;
            var c;
            for (c = 0; c < a.length && typeof b == "object" && b != null; c++) b = b[a[c]];
            c != a.length && (b = void 0);
            return b
        },
        $k = function() {
            try {
                var a =
                    r.localStorage,
                    b = Zk();
                if (a) return a.setItem(b, "1"), a.removeItem(b), Bk() ? !!r.indexedDB : !0
            } catch (c) {
                return Tk() && !!r.indexedDB
            }
            return !1
        },
        bl = function() {
            return (al() || Rk() === "chrome-extension:" || Pk()) && !Vk() && $k() && !Tk()
        },
        al = function() {
            return Rk() === "http:" || Rk() === "https:"
        },
        Rk = function() {
            return r.location && r.location.protocol || null
        },
        cl = function(a) {
            a = a || Ak();
            return Hk(a) || Fk(a) == "Firefox" ? !1 : !0
        },
        dl = function(a) {
            return typeof a === "undefined" ? null : JSON.stringify(a)
        },
        el = function(a) {
            var b = {},
                c;
            for (c in a) a.hasOwnProperty(c) &&
                a[c] !== null && a[c] !== void 0 && (b[c] = a[c]);
            return b
        },
        fl = function(a) {
            if (a !== null) return JSON.parse(a)
        },
        Zk = function(a) {
            return a ? a : "" + Math.floor(Math.random() * 1E9).toString()
        },
        gl = function(a) {
            a = a || Ak();
            return Fk(a) == "Safari" || a.toLowerCase().match(/iphone|ipad|ipod/) ? !1 : !0
        },
        hl = function() {
            var a = r.___jsl;
            if (a && a.H)
                for (var b in a.H)
                    if (a.H[b].r = a.H[b].r || [], a.H[b].L = a.H[b].L || [], a.H[b].r = a.H[b].L.concat(), a.CP)
                        for (var c = 0; c < a.CP.length; c++) a.CP[c] = null
        },
        il = function(a, b) {
            if (a > b) throw Error("Short delay should be less than long delay!");
            this.Ij = a;
            this.wl = b;
            a = Ak();
            b = Uk();
            this.nl = Hk(a) || b === "ReactNative"
        };
    il.prototype.get = function() {
        var a = r.navigator;
        return (a && typeof a.onLine === "boolean" && (al() || Rk() === "chrome-extension:" || typeof a.connection !== "undefined") ? a.onLine : 1) ? this.nl ? this.wl : this.Ij : Math.min(5E3, this.Ij)
    };
    var jl = function() {
            var a = r.document;
            return a && typeof a.visibilityState !== "undefined" ? a.visibilityState == "visible" : !0
        },
        kl = function() {
            var a = r.document,
                b = null;
            return jl() || !a ? H() : (new G(function(c) {
                b = function() {
                    jl() && (a.removeEventListener("visibilitychange", b, !1), c())
                };
                a.addEventListener("visibilitychange", b, !1)
            })).l(function(c) {
                a.removeEventListener("visibilitychange", b, !1);
                throw c;
            })
        },
        ll = function(a) {
            typeof console !== "undefined" && typeof console.warn === "function" && console.warn(a)
        },
        ml = function(a) {
            try {
                var b =
                    new Date(parseInt(a, 10));
                if (!isNaN(b.getTime()) && !/[^0-9]/.test(a)) return b.toUTCString()
            } catch (c) {}
            return null
        },
        nl = function() {
            return !(!O("fireauth.oauthhelper", r) && !O("fireauth.iframe", r))
        },
        ol = function() {
            var a = r.navigator;
            return a && a.serviceWorker && a.serviceWorker.controller || null
        },
        pl = function() {
            var a = r.navigator;
            return a && a.serviceWorker ? H().then(function() {
                return a.serviceWorker.ready
            }).then(function(b) {
                return b.active || null
            }).l(function() {
                return null
            }) : H(null)
        };
    var ql = {};

    function rl(a) {
        ql[a] || (ql[a] = !0, ll(a))
    };
    var sl;
    try {
        var tl = {};
        Object.defineProperty(tl, "abcd", {
            configurable: !0,
            enumerable: !0,
            value: 1
        });
        Object.defineProperty(tl, "abcd", {
            configurable: !0,
            enumerable: !0,
            value: 2
        });
        sl = tl.abcd == 2
    } catch (a) {
        sl = !1
    }
    var P = function(a, b, c) {
            sl ? Object.defineProperty(a, b, {
                configurable: !0,
                enumerable: !0,
                value: c
            }) : a[b] = c
        },
        ul = function(a, b) {
            if (b)
                for (var c in b) b.hasOwnProperty(c) && P(a, c, b[c])
        },
        vl = function(a) {
            var b = {};
            ul(b, a);
            return b
        },
        wl = function(a, b) {
            if (!b || !b.length) return !0;
            if (!a) return !1;
            for (var c = 0; c < b.length; c++) {
                var d = a[b[c]];
                if (d === void 0 || d === null || d === "") return !1
            }
            return !0
        },
        xl = function(a) {
            var b = a;
            if (typeof a == "object" && a != null) {
                b = "length" in a ? [] : {};
                for (var c in a) P(b, c, xl(a[c]))
            }
            return b
        };
    var yl = "oauth_consumer_key oauth_nonce oauth_signature oauth_signature_method oauth_timestamp oauth_token oauth_version".split(" "),
        zl = ["client_id", "response_type", "scope", "redirect_uri", "state"],
        Al = {
            Em: {
                le: "locale",
                Dd: 700,
                Cd: 600,
                providerId: "facebook.com",
                Hf: zl
            },
            Gm: {
                le: null,
                Dd: 500,
                Cd: 750,
                providerId: "github.com",
                Hf: zl
            },
            Hm: {
                le: "hl",
                Dd: 515,
                Cd: 680,
                providerId: "google.com",
                Hf: zl
            },
            Mm: {
                le: "lang",
                Dd: 485,
                Cd: 705,
                providerId: "twitter.com",
                Hf: yl
            },
            Cm: {
                le: "locale",
                Dd: 640,
                Cd: 600,
                providerId: "apple.com",
                Hf: []
            }
        };

    function Bl(a) {
        for (var b in Al)
            if (Al[b].providerId == a) return Al[b];
        return null
    };
    var Q = function(a, b, c) {
        this.code = "auth/" + a;
        this.message = b || Cl[a] || "";
        this.Aj = c || null
    };
    x(Q, Error);
    Q.prototype.U = function() {
        var a = {
            code: this.code,
            message: this.message
        };
        this.Aj && (a.serverResponse = this.Aj);
        return a
    };
    Q.prototype.toJSON = function() {
        return this.U()
    };
    var Dl = function(a) {
            var b = a && a.code;
            return b ? new Q(b.substring(5), a.message, a.serverResponse) : null
        },
        Cl = {
            "api-key-service-blocked": "The request is denied because it violates [API key HTTP restrictions](https://cloud.google.com/docs/authentication/api-keys#adding_http_restrictions).",
            "admin-restricted-operation": "This operation is restricted to administrators only.",
            "argument-error": "",
            "app-not-authorized": "This app, identified by the domain where it's hosted, is not authorized to use Firebase Authentication with the provided API key. Review your key configuration in the Google API console.",
            "app-not-installed": "The requested mobile application corresponding to the identifier (Android package name or iOS bundle ID) provided is not installed on this device.",
            "bad-request": "The requested action is invalid.",
            "captcha-check-failed": "The reCAPTCHA response token provided is either invalid, expired, already used or the domain associated with it does not match the list of whitelisted domains.",
            "code-expired": "The SMS code has expired. Please re-send the verification code to try again.",
            "cordova-not-ready": "Cordova framework is not ready.",
            "cors-unsupported": "This browser is not supported.",
            "credential-already-in-use": "This credential is already associated with a different user account.",
            "custom-token-mismatch": "The custom token corresponds to a different audience.",
            "requires-recent-login": "This operation is sensitive and requires recent authentication. Log in again before retrying this request.",
            "dynamic-link-not-activated": "Please activate Dynamic Links in the Firebase Console and agree to the terms and conditions.",
            "email-change-needs-verification": "Multi-factor users must always have a verified email.",
            "email-already-in-use": "The email address is already in use by another account.",
            "expired-action-code": "The action code has expired. ",
            "cancelled-popup-request": "This operation has been cancelled due to another conflicting popup being opened.",
            "internal-error": "An internal error has occurred.",
            "invalid-app-credential": "The phone verification request contains an invalid application verifier. The reCAPTCHA token response is either invalid or expired.",
            "invalid-app-id": "The mobile app identifier is not registed for the current project.",
            "invalid-user-token": "This user's credential isn't valid for this project. This can happen if the user's token has been tampered with, or if the user isn't for the project associated with this API key.",
            "invalid-auth-event": "An internal error has occurred.",
            "invalid-verification-code": "The SMS verification code used to create the phone auth credential is invalid. Please resend the verification code sms and be sure to use the verification code provided by the user.",
            "invalid-continue-uri": "The continue URL provided in the request is invalid.",
            "invalid-cordova-configuration": "The following Cordova plugins must be installed to enable OAuth sign-in: cordova-plugin-buildinfo, cordova-universal-links-plugin, cordova-plugin-browsertab, cordova-plugin-inappbrowser and cordova-plugin-customurlscheme.",
            "invalid-custom-token": "The custom token format is incorrect. Please check the documentation.",
            "invalid-dynamic-link-domain": "The provided dynamic link domain is not configured or authorized for the current project.",
            "invalid-email": "The email address is badly formatted.",
            "invalid-api-key": "Your API key is invalid, please check you have copied it correctly.",
            "invalid-cert-hash": "The SHA-1 certificate hash provided is invalid.",
            "invalid-credential": "The supplied auth credential is malformed or has expired.",
            "invalid-message-payload": "The email template corresponding to this action contains invalid characters in its message. Please fix by going to the Auth email templates section in the Firebase Console.",
            "invalid-multi-factor-session": "The request does not contain a valid proof of first factor successful sign-in.",
            "invalid-oauth-provider": "EmailAuthProvider is not supported for this operation. This operation only supports OAuth providers.",
            "invalid-oauth-client-id": "The OAuth client ID provided is either invalid or does not match the specified API key.",
            "unauthorized-domain": "This domain is not authorized for OAuth operations for your Firebase project. Edit the list of authorized domains from the Firebase console.",
            "invalid-action-code": "The action code is invalid. This can happen if the code is malformed, expired, or has already been used.",
            "wrong-password": "The password is invalid or the user does not have a password.",
            "invalid-persistence-type": "The specified persistence type is invalid. It can only be local, session or none.",
            "invalid-phone-number": "The format of the phone number provided is incorrect. Please enter the phone number in a format that can be parsed into E.164 format. E.164 phone numbers are written in the format [+][country code][subscriber number including area code].",
            "invalid-provider-id": "The specified provider ID is invalid.",
            "invalid-recipient-email": "The email corresponding to this action failed to send as the provided recipient email address is invalid.",
            "invalid-sender": "The email template corresponding to this action contains an invalid sender email or name. Please fix by going to the Auth email templates section in the Firebase Console.",
            "invalid-verification-id": "The verification ID used to create the phone auth credential is invalid.",
            "invalid-tenant-id": "The Auth instance's tenant ID is invalid.",
            "multi-factor-info-not-found": "The user does not have a second factor matching the identifier provided.",
            "multi-factor-auth-required": "Proof of ownership of a second factor is required to complete sign-in.",
            "missing-android-pkg-name": "An Android Package Name must be provided if the Android App is required to be installed.",
            "auth-domain-config-required": "Be sure to include authDomain when calling firebase.initializeApp(), by following the instructions in the Firebase console.",
            "missing-app-credential": "The phone verification request is missing an application verifier assertion. A reCAPTCHA response token needs to be provided.",
            "missing-verification-code": "The phone auth credential was created with an empty SMS verification code.",
            "missing-continue-uri": "A continue URL must be provided in the request.",
            "missing-iframe-start": "An internal error has occurred.",
            "missing-ios-bundle-id": "An iOS Bundle ID must be provided if an App Store ID is provided.",
            "missing-multi-factor-info": "No second factor identifier is provided.",
            "missing-multi-factor-session": "The request is missing proof of first factor successful sign-in.",
            "missing-or-invalid-nonce": "The request does not contain a valid nonce. This can occur if the SHA-256 hash of the provided raw nonce does not match the hashed nonce in the ID token payload.",
            "missing-phone-number": "To send verification codes, provide a phone number for the recipient.",
            "missing-verification-id": "The phone auth credential was created with an empty verification ID.",
            "app-deleted": "This instance of FirebaseApp has been deleted.",
            "account-exists-with-different-credential": "An account already exists with the same email address but different sign-in credentials. Sign in using a provider associated with this email address.",
            "network-request-failed": "A network error (such as timeout, interrupted connection or unreachable host) has occurred.",
            "no-auth-event": "An internal error has occurred.",
            "no-such-provider": "User was not linked to an account with the given provider.",
            "null-user": "A null user object was provided as the argument for an operation which requires a non-null user object.",
            "operation-not-allowed": "The given sign-in provider is disabled for this Firebase project. Enable it in the Firebase console, under the sign-in method tab of the Auth section.",
            "operation-not-supported-in-this-environment": 'This operation is not supported in the environment this application is running on. "location.protocol" must be http, https or chrome-extension and web storage must be enabled.',
            "password-does-not-meet-requirements": "The provided password does not meet the configured requirements.",
            "popup-blocked": "Unable to establish a connection with the popup. It may have been blocked by the browser.",
            "popup-closed-by-user": "The popup has been closed by the user before finalizing the operation.",
            "provider-already-linked": "User can only be linked to one identity for the given provider.",
            "quota-exceeded": "The project's quota for this operation has been exceeded.",
            "redirect-cancelled-by-user": "The redirect operation has been cancelled by the user before finalizing.",
            "redirect-operation-pending": "A redirect sign-in operation is already pending.",
            "rejected-credential": "The request contains malformed or mismatching credentials.",
            "second-factor-already-in-use": "The second factor is already enrolled on this account.",
            "maximum-second-factor-count-exceeded": "The maximum allowed number of second factors on a user has been exceeded.",
            "tenant-id-mismatch": "The provided tenant ID does not match the Auth instance's tenant ID",
            timeout: "The operation has timed out.",
            "user-token-expired": "The user's credential is no longer valid. The user must sign in again.",
            "too-many-requests": "We have blocked all requests from this device due to unusual activity. Try again later.",
            "unauthorized-continue-uri": "The domain of the continue URL is not whitelisted.  Please whitelist the domain in the Firebase console.",
            "unsupported-first-factor": "Enrolling a second factor or signing in with a multi-factor account requires sign-in with a supported first factor.",
            "unsupported-persistence-type": "The current environment does not support the specified persistence type.",
            "unsupported-tenant-operation": "This operation is not supported in a multi-tenant context.",
            "unverified-email": "The operation requires a verified email.",
            "user-cancelled": "The user did not grant your application the permissions it requested.",
            "user-not-found": "There is no user record corresponding to this identifier. The user may have been deleted.",
            "user-disabled": "The user account has been disabled by an administrator.",
            "user-mismatch": "The supplied credentials do not correspond to the previously signed in user.",
            "user-signed-out": "",
            "weak-password": "The password must be 6 characters long or more.",
            "web-storage-unsupported": "This browser is not supported or 3rd party cookies and data may be disabled."
        };
    var El = function(a, b, c, d, e, f, g) {
        this.Mh = a;
        this.La = b || null;
        this.Qd = c || null;
        this.Ce = d || null;
        this.ih = f || null;
        this.na = g || null;
        this.Db = e || null;
        if (this.Qd || this.Db) {
            if (this.Qd && this.Db) throw new Q("invalid-auth-event");
            if (this.Qd && !this.Ce) throw new Q("invalid-auth-event");
        } else throw new Q("invalid-auth-event");
    };
    k = El.prototype;
    k.getType = function() {
        return this.Mh
    };
    k.getUid = function() {
        var a = [];
        a.push(this.Mh);
        this.La && a.push(this.La);
        this.Ce && a.push(this.Ce);
        this.na && a.push(this.na);
        return a.join("-")
    };
    k.fe = function() {
        return this.Ce
    };
    k.getError = function() {
        return this.Db
    };
    k.U = function() {
        return {
            type: this.Mh,
            eventId: this.La,
            urlResponse: this.Qd,
            sessionId: this.Ce,
            postBody: this.ih,
            tenantId: this.na,
            error: this.Db && this.Db.U()
        }
    };
    var Fl = function(a) {
        a = a || {};
        return a.type ? new El(a.type, a.eventId, a.urlResponse, a.sessionId, a.error && Dl(a.error), a.postBody, a.tenantId) : null
    };
    var Gl = function(a, b) {
        if (!b || !a || !a.mfaEnrollmentId) throw new Q("internal-error", "Internal assert: invalid MultiFactorInfo object");
        P(this, "uid", a.mfaEnrollmentId);
        P(this, "displayName", a.displayName || null);
        P(this, "enrollmentTime", a.enrolledAt ? (new Date(a.enrolledAt)).toUTCString() : null);
        P(this, "factorId", b)
    };
    Gl.prototype.U = function() {
        return {
            uid: this.uid,
            displayName: this.displayName,
            factorId: this.factorId,
            enrollmentTime: this.enrollmentTime
        }
    };
    var Jl = function(a) {
            try {
                if (a.phoneInfo) return new Hl(a);
                if (a.totpInfo) return new Il(a)
            } catch (b) {}
            return null
        },
        Hl = function(a) {
            var b = a.phoneInfo;
            if (!b) throw new Q("internal-error", "Internal assert: invalid Phone MultiFactorInfo object");
            Gl.call(this, a, "phone");
            P(this, "phoneNumber", b)
        };
    q(Hl, Gl);
    Hl.prototype.U = function() {
        var a = Gl.prototype.U.call(this);
        a.phoneNumber = this.phoneNumber;
        return a
    };
    var Il = function(a) {
        var b = a.totpInfo;
        if (!b) throw new Q("internal-error", "Internal assert: invalid TOTP MultiFactorInfo object");
        Gl.call(this, a, "totp");
        P(this, "totpInfo", b)
    };
    q(Il, Gl);
    Il.prototype.U = function() {
        var a = Gl.prototype.U.call(this);
        a.totpInfo = this.totpInfo;
        return a
    };
    var Kl = function(a) {
        var b = {},
            c = a.email,
            d = a.newEmail,
            e = a.requestType;
        a = Jl(a.mfaInfo);
        if (!e || e != "EMAIL_SIGNIN" && e != "VERIFY_AND_CHANGE_EMAIL" && !c || e == "VERIFY_AND_CHANGE_EMAIL" && !d || e == "REVERT_SECOND_FACTOR_ADDITION" && !a) throw Error("Invalid checkActionCode response!");
        e == "VERIFY_AND_CHANGE_EMAIL" ? (b.fromEmail = c || null, b.previousEmail = c || null, b.email = d) : (b.fromEmail = d || null, b.previousEmail = d || null, b.email = c || null);
        b.multiFactorInfo = a || null;
        P(this, "operation", e);
        P(this, "data", xl(b))
    };
    var Ml = function(a) {
            a = N(a);
            var b = pk(a, "apiKey") || null,
                c = pk(a, "oobCode") || null,
                d = pk(a, "mode") || null;
            d = d ? Ll[d] || null : null;
            if (!b || !c || !d) throw new Q("argument-error", "apiKey, oobCodeand mode are required in a valid action code URL.");
            ul(this, {
                apiKey: b,
                operation: d,
                code: c,
                continueUrl: pk(a, "continueUrl") || null,
                languageCode: pk(a, "languageCode") || null,
                tenantId: pk(a, "tenantId") || null
            })
        },
        Nl = function(a) {
            try {
                return new Ml(a)
            } catch (b) {
                return null
            }
        },
        Ll = {
            recoverEmail: "RECOVER_EMAIL",
            resetPassword: "PASSWORD_RESET",
            revertSecondFactorAddition: "REVERT_SECOND_FACTOR_ADDITION",
            signIn: "EMAIL_SIGNIN",
            verifyAndChangeEmail: "VERIFY_AND_CHANGE_EMAIL",
            verifyEmail: "VERIFY_EMAIL"
        };
    var Ol = function(a) {
        var b = N(a),
            c = pk(b, "link"),
            d = pk(N(c), "link");
        b = pk(b, "deep_link_id");
        return pk(N(b), "link") || b || d || c || a
    };
    var Pl = function(a) {
        var b = "unauthorized-domain",
            c = void 0,
            d = N(a);
        a = d.Ia;
        d = d.Xa;
        d == "chrome-extension" ? c = Ic("This chrome extension ID (chrome-extension://%s) is not authorized to run this operation. If you are the app developer, add it to the OAuth redirect domains list in the Firebase console -> Auth section -> Sign in method tab.", a) : d == "http" || d == "https" ? c = Ic("This domain (%s) is not authorized to run this operation. If you are the app developer, add it to the OAuth redirect domains list in the Firebase console -> Auth section -> Sign in method tab.",
            a) : b = "operation-not-supported-in-this-environment";
        Q.call(this, b, c)
    };
    q(Pl, Q);
    var Rl = function(a) {
        var b = Ql(a);
        if (!(b && b.sub && b.iss && b.aud && b.exp)) throw Error("Invalid JWT");
        this.rl = a;
        this.Cg = b.exp;
        this.ul = b.sub;
        a = Date.now() / 1E3;
        this.al = b.iat || (a > this.Cg ? this.Cg : a);
        this.Jc = b.email || null;
        this.mh = b.provider_id || b.firebase && b.firebase.sign_in_provider || null;
        this.na = b.firebase && b.firebase.tenant || null;
        this.hk = !!b.is_anonymous || this.mh == "anonymous"
    };
    Rl.prototype.getEmail = function() {
        return this.Jc
    };
    Rl.prototype.isAnonymous = function() {
        return this.hk
    };
    Rl.prototype.toString = function() {
        return this.rl
    };
    var Sl = function(a) {
            try {
                return new Rl(a)
            } catch (b) {
                return null
            }
        },
        Ql = function(a) {
            if (!a) return null;
            a = a.split(".");
            if (a.length != 3) return null;
            a = a[1];
            for (var b = (4 - a.length % 4) % 4, c = 0; c < b; c++) a += ".";
            try {
                var d = ti(a);
                a = [];
                for (c = b = 0; b < d.length;) {
                    var e = d[b++];
                    if (e < 128) a[c++] = String.fromCharCode(e);
                    else if (e > 191 && e < 224) {
                        var f = d[b++];
                        a[c++] = String.fromCharCode((e & 31) << 6 | f & 63)
                    } else if (e > 239 && e < 365) {
                        var g = d[b++],
                            h = d[b++],
                            l = d[b++],
                            m = ((e & 7) << 18 | (g & 63) << 12 | (h & 63) << 6 | l & 63) - 65536;
                        a[c++] = String.fromCharCode(55296 + (m >>
                            10));
                        a[c++] = String.fromCharCode(56320 + (m & 1023))
                    } else {
                        var p = d[b++],
                            w = d[b++];
                        a[c++] = String.fromCharCode((e & 15) << 12 | (p & 63) << 6 | w & 63)
                    }
                }
                return JSON.parse(a.join(""))
            } catch (z) {}
            return null
        };
    var Tl = function(a) {
        var b = Ql(a);
        if (!(b && b.exp && b.auth_time && b.iat)) throw new Q("internal-error", "An internal error occurred. The token obtained by Firebase appears to be malformed. Please retry the operation.");
        ul(this, {
            token: a,
            expirationTime: ml(b.exp * 1E3),
            authTime: ml(b.auth_time * 1E3),
            issuedAtTime: ml(b.iat * 1E3),
            signInProvider: b.firebase && b.firebase.sign_in_provider ? b.firebase.sign_in_provider : null,
            signInSecondFactor: b.firebase && b.firebase.sign_in_second_factor ? b.firebase.sign_in_second_factor : null,
            claims: b
        })
    };
    var Ul = function(a, b) {
        if (!a && !b) throw new Q("internal-error", "Internal assert: no raw session string available");
        if (a && b) throw new Q("internal-error", "Internal assert: unable to determine the session type");
        this.hf = a || null;
        this.Vi = b || null;
        this.type = this.hf ? "enroll" : "signin"
    };
    Ul.prototype.ee = function() {
        return this.hf ? H(this.hf) : H(this.Vi)
    };
    Ul.prototype.U = function() {
        return this.type == "enroll" ? {
            multiFactorSession: {
                idToken: this.hf
            }
        } : {
            multiFactorSession: {
                pendingCredential: this.Vi
            }
        }
    };
    var Vl = function() {};
    Vl.prototype.Mc = function() {};
    Vl.prototype.yd = function() {};
    Vl.prototype.oe = function() {};
    Vl.prototype.U = function() {};
    var Wl = function(a, b) {
            return a.then(function(c) {
                if (c.idToken) {
                    var d = Sl(c.idToken);
                    if (!d || b != d.ul) throw new Q("user-mismatch");
                    return c
                }
                throw new Q("user-mismatch");
            }).l(function(c) {
                throw c && c.code && c.code == "auth/user-not-found" ? new Q("user-mismatch") : c;
            })
        },
        Xl = function(a, b) {
            if (b) this.ac = b;
            else throw new Q("internal-error", "failed to construct a credential");
            P(this, "providerId", a);
            P(this, "signInMethod", a)
        };
    k = Xl.prototype;
    k.Mc = function(a) {
        return Yl(a, this.Qc())
    };
    k.yd = function(a, b) {
        var c = this.Qc();
        c.idToken = b;
        return Zl(a, c)
    };
    k.oe = function(a, b) {
        var c = this.Qc();
        return Wl($l(a, c), b)
    };
    k.Qc = function() {
        return {
            pendingToken: this.ac,
            requestUri: "http://localhost"
        }
    };
    k.U = function() {
        return {
            providerId: this.providerId,
            signInMethod: this.signInMethod,
            pendingToken: this.ac
        }
    };
    var am = function(a) {
            if (a && a.providerId && a.signInMethod && a.providerId.indexOf("saml.") == 0 && a.pendingToken) try {
                return new Xl(a.providerId, a.pendingToken)
            } catch (b) {}
            return null
        },
        bm = function(a, b, c) {
            this.ac = null;
            if (b.idToken || b.accessToken) b.idToken && P(this, "idToken", b.idToken), b.accessToken && P(this, "accessToken", b.accessToken), b.nonce && !b.pendingToken && P(this, "nonce", b.nonce), b.pendingToken && (this.ac = b.pendingToken);
            else if (b.oauthToken && b.oauthTokenSecret) P(this, "accessToken", b.oauthToken), P(this, "secret",
                b.oauthTokenSecret);
            else throw new Q("internal-error", "failed to construct a credential");
            P(this, "providerId", a);
            P(this, "signInMethod", c)
        };
    k = bm.prototype;
    k.Mc = function(a) {
        return Yl(a, this.Qc())
    };
    k.yd = function(a, b) {
        var c = this.Qc();
        c.idToken = b;
        return Zl(a, c)
    };
    k.oe = function(a, b) {
        var c = this.Qc();
        return Wl($l(a, c), b)
    };
    k.Qc = function() {
        var a = {};
        this.idToken && (a.id_token = this.idToken);
        this.accessToken && (a.access_token = this.accessToken);
        this.secret && (a.oauth_token_secret = this.secret);
        a.providerId = this.providerId;
        this.nonce && !this.ac && (a.nonce = this.nonce);
        a = {
            postBody: tk(a).toString(),
            requestUri: "http://localhost"
        };
        this.ac && (delete a.postBody, a.pendingToken = this.ac);
        return a
    };
    k.U = function() {
        var a = {
            providerId: this.providerId,
            signInMethod: this.signInMethod
        };
        this.idToken && (a.oauthIdToken = this.idToken);
        this.accessToken && (a.oauthAccessToken = this.accessToken);
        this.secret && (a.oauthTokenSecret = this.secret);
        this.nonce && (a.nonce = this.nonce);
        this.ac && (a.pendingToken = this.ac);
        return a
    };
    var cm = function(a) {
            if (a && a.providerId && a.signInMethod) {
                var b = {
                    idToken: a.oauthIdToken,
                    accessToken: a.oauthTokenSecret ? null : a.oauthAccessToken,
                    oauthTokenSecret: a.oauthTokenSecret,
                    oauthToken: a.oauthTokenSecret && a.oauthAccessToken,
                    nonce: a.nonce,
                    pendingToken: a.pendingToken
                };
                try {
                    return new bm(a.providerId, b, a.signInMethod)
                } catch (c) {}
            }
            return null
        },
        dm = function(a, b) {
            this.Ol = b || [];
            ul(this, {
                providerId: a,
                isOAuthProvider: !0
            });
            this.ci = {};
            this.Rg = (Bl(a) || {}).le || null;
            this.wg = null
        };
    dm.prototype.setCustomParameters = function(a) {
        this.ci = dc(a);
        return this
    };
    var em = function(a) {
        if (typeof a !== "string" || a.indexOf("saml.") != 0) throw new Q("argument-error", 'SAML provider IDs must be prefixed with "saml."');
        dm.call(this, a, [])
    };
    x(em, dm);
    var fm = function(a) {
        dm.call(this, a, zl);
        this.xh = []
    };
    x(fm, dm);
    fm.prototype.addScope = function(a) {
        Vb(this.xh, a) || this.xh.push(a);
        return this
    };
    fm.prototype.xi = function() {
        return Zb(this.xh)
    };
    fm.prototype.credential = function(a, b) {
        a = u(a) ? {
            idToken: a.idToken || null,
            accessToken: a.accessToken || null,
            nonce: a.rawNonce || null
        } : {
            idToken: a || null,
            accessToken: b || null
        };
        if (!a.idToken && !a.accessToken) throw new Q("argument-error", "credential failed: must provide the ID token and/or the access token.");
        return new bm(this.providerId, a, this.providerId)
    };
    var gm = function() {
        fm.call(this, "facebook.com")
    };
    x(gm, fm);
    P(gm, "PROVIDER_ID", "facebook.com");
    P(gm, "FACEBOOK_SIGN_IN_METHOD", "facebook.com");
    var hm = function(a) {
            if (!a) throw new Q("argument-error", "credential failed: expected 1 argument (the OAuth access token).");
            var b = a;
            u(a) && (b = a.accessToken);
            return (new gm).credential({
                accessToken: b
            })
        },
        im = function() {
            fm.call(this, "github.com")
        };
    x(im, fm);
    P(im, "PROVIDER_ID", "github.com");
    P(im, "GITHUB_SIGN_IN_METHOD", "github.com");
    var jm = function(a) {
            if (!a) throw new Q("argument-error", "credential failed: expected 1 argument (the OAuth access token).");
            var b = a;
            u(a) && (b = a.accessToken);
            return (new im).credential({
                accessToken: b
            })
        },
        km = function() {
            fm.call(this, "google.com");
            this.addScope("profile")
        };
    x(km, fm);
    P(km, "PROVIDER_ID", "google.com");
    P(km, "GOOGLE_SIGN_IN_METHOD", "google.com");
    var lm = function(a, b) {
            var c = a;
            u(a) && (c = a.idToken, b = a.accessToken);
            return (new km).credential({
                idToken: c,
                accessToken: b
            })
        },
        mm = function() {
            dm.call(this, "twitter.com", yl)
        };
    x(mm, dm);
    P(mm, "PROVIDER_ID", "twitter.com");
    P(mm, "TWITTER_SIGN_IN_METHOD", "twitter.com");
    var nm = function(a, b) {
            var c = a;
            u(c) || (c = {
                oauthToken: a,
                oauthTokenSecret: b
            });
            if (!c.oauthToken || !c.oauthTokenSecret) throw new Q("argument-error", "credential failed: expected 2 arguments (the OAuth access token and secret).");
            return new bm("twitter.com", c, "twitter.com")
        },
        pm = function(a, b, c) {
            this.Jc = a;
            this.qe = b;
            P(this, "providerId", "password");
            P(this, "signInMethod", c === om.EMAIL_LINK_SIGN_IN_METHOD ? om.EMAIL_LINK_SIGN_IN_METHOD : om.EMAIL_PASSWORD_SIGN_IN_METHOD)
        };
    pm.prototype.Mc = function(a) {
        return this.signInMethod == om.EMAIL_LINK_SIGN_IN_METHOD ? R(a, qm, {
            email: this.Jc,
            oobCode: this.qe
        }) : R(a, rm, {
            email: this.Jc,
            password: this.qe
        })
    };
    pm.prototype.yd = function(a, b) {
        return this.signInMethod == om.EMAIL_LINK_SIGN_IN_METHOD ? R(a, sm, {
            idToken: b,
            email: this.Jc,
            oobCode: this.qe
        }) : R(a, tm, {
            idToken: b,
            email: this.Jc,
            password: this.qe
        })
    };
    pm.prototype.oe = function(a, b) {
        return Wl(this.Mc(a), b)
    };
    pm.prototype.U = function() {
        return {
            email: this.Jc,
            password: this.qe,
            signInMethod: this.signInMethod
        }
    };
    var um = function(a) {
            return a && a.email && a.password ? new pm(a.email, a.password, a.signInMethod) : null
        },
        om = function() {
            ul(this, {
                providerId: "password",
                isOAuthProvider: !1
            })
        },
        wm = function(a, b) {
            b = vm(b);
            if (!b) throw new Q("argument-error", "Invalid email link!");
            return new pm(a, b.code, om.EMAIL_LINK_SIGN_IN_METHOD)
        },
        vm = function(a) {
            a = Ol(a);
            return (a = Nl(a)) && a.operation === "EMAIL_SIGNIN" ? a : null
        };
    ul(om, {
        PROVIDER_ID: "password"
    });
    ul(om, {
        EMAIL_LINK_SIGN_IN_METHOD: "emailLink"
    });
    ul(om, {
        EMAIL_PASSWORD_SIGN_IN_METHOD: "password"
    });
    var xm = function(a) {
        if (!(a.verificationId && a.Wf || a.Ge && a.phoneNumber)) throw new Q("internal-error");
        this.Ba = a;
        P(this, "providerId", "phone");
        this.providerId = "phone";
        P(this, "signInMethod", "phone")
    };
    xm.prototype.Mc = function(a) {
        return a.verifyPhoneNumber(ym(this))
    };
    xm.prototype.yd = function(a, b) {
        var c = ym(this);
        c.idToken = b;
        return R(a, zm, c)
    };
    xm.prototype.oe = function(a, b) {
        var c = ym(this);
        c.operation = "REAUTH";
        a = R(a, Am, c);
        return Wl(a, b)
    };
    xm.prototype.U = function() {
        var a = {
            providerId: "phone"
        };
        this.Ba.verificationId && (a.verificationId = this.Ba.verificationId);
        this.Ba.Wf && (a.verificationCode = this.Ba.Wf);
        this.Ba.Ge && (a.temporaryProof = this.Ba.Ge);
        this.Ba.phoneNumber && (a.phoneNumber = this.Ba.phoneNumber);
        return a
    };
    var Bm = function(a) {
            if (a && a.providerId === "phone" && (a.verificationId && a.verificationCode || a.temporaryProof && a.phoneNumber)) {
                var b = {};
                A(["verificationId", "verificationCode", "temporaryProof", "phoneNumber"], function(c) {
                    a[c] && (b[c] = a[c])
                });
                return new xm(b)
            }
            return null
        },
        ym = function(a) {
            return a.Ba.Ge && a.Ba.phoneNumber ? {
                temporaryProof: a.Ba.Ge,
                phoneNumber: a.Ba.phoneNumber
            } : {
                sessionInfo: a.Ba.verificationId,
                code: a.Ba.Wf
            }
        },
        Cm = function(a) {
            try {
                this.Pe = a || firebase.auth()
            } catch (b) {
                throw new Q("argument-error", "Either an instance of firebase.auth.Auth must be passed as an argument to the firebase.auth.PhoneAuthProvider constructor, or the default firebase App instance must be initialized via firebase.initializeApp().");
            }
            ul(this, {
                providerId: "phone",
                isOAuthProvider: !1
            })
        };
    Cm.prototype.verifyPhoneNumber = function(a, b) {
        var c = this.Pe.o;
        return H(b.verify()).then(function(d) {
            if (typeof d !== "string") throw new Q("argument-error", "An implementation of firebase.auth.ApplicationVerifier.prototype.verify() must return a firebase.Promise that resolves with a string.");
            switch (b.type) {
                case "recaptcha":
                    var e = u(a) ? a.session : null,
                        f = u(a) ? a.phoneNumber : a;
                    return (e && e.type == "enroll" ? e.ee().then(function(g) {
                            return Dm(c, {
                                idToken: g,
                                phoneEnrollmentInfo: {
                                    phoneNumber: f,
                                    recaptchaToken: d
                                }
                            })
                        }) : e &&
                        e.type == "signin" ? e.ee().then(function(g) {
                            return Em(c, {
                                mfaPendingCredential: g,
                                mfaEnrollmentId: a.multiFactorHint && a.multiFactorHint.uid || a.multiFactorUid,
                                phoneSignInInfo: {
                                    recaptchaToken: d
                                }
                            })
                        }) : Fm(c, {
                            phoneNumber: f,
                            recaptchaToken: d
                        })).then(function(g) {
                        typeof b.reset === "function" && b.reset();
                        return g
                    }, function(g) {
                        typeof b.reset === "function" && b.reset();
                        throw g;
                    });
                default:
                    throw new Q("argument-error", 'Only firebase.auth.ApplicationVerifiers with type="recaptcha" are currently supported.');
            }
        })
    };
    var Gm = function(a, b) {
        if (!a) throw new Q("missing-verification-id");
        if (!b) throw new Q("missing-verification-code");
        return new xm({
            verificationId: a,
            Wf: b
        })
    };
    ul(Cm, {
        PROVIDER_ID: "phone"
    });
    ul(Cm, {
        PHONE_SIGN_IN_METHOD: "phone"
    });
    var Hm = function(a) {
            if (a.temporaryProof && a.phoneNumber) return new xm({
                Ge: a.temporaryProof,
                phoneNumber: a.phoneNumber
            });
            var b = a && a.providerId;
            if (!b || b === "password") return null;
            var c = a && a.oauthAccessToken,
                d = a && a.oauthTokenSecret,
                e = a && a.nonce,
                f = a && a.oauthIdToken,
                g = a && a.pendingToken;
            try {
                switch (b) {
                    case "google.com":
                        return lm(f, c);
                    case "facebook.com":
                        return hm(c);
                    case "github.com":
                        return jm(c);
                    case "twitter.com":
                        return nm(c, d);
                    default:
                        return c || d || f || g ? g ? b.indexOf("saml.") == 0 ? new Xl(b, g) : new bm(b, {
                            pendingToken: g,
                            idToken: a.oauthIdToken,
                            accessToken: a.oauthAccessToken
                        }, b) : (new fm(b)).credential({
                            idToken: f,
                            accessToken: c,
                            rawNonce: e
                        }) : null
                }
            } catch (h) {
                return null
            }
        },
        Im = function(a) {
            if (!a.isOAuthProvider) throw new Q("invalid-oauth-provider");
        };
    var Jm = function(a, b, c) {
        Q.call(this, a, c);
        a = b || {};
        a.email && P(this, "email", a.email);
        a.phoneNumber && P(this, "phoneNumber", a.phoneNumber);
        a.credential && P(this, "credential", a.credential);
        a.tenantId && P(this, "tenantId", a.tenantId)
    };
    q(Jm, Q);
    Jm.prototype.U = function() {
        var a = {
            code: this.code,
            message: this.message
        };
        this.email && (a.email = this.email);
        this.phoneNumber && (a.phoneNumber = this.phoneNumber);
        this.tenantId && (a.tenantId = this.tenantId);
        var b = this.credential && this.credential.U();
        b && fc(a, b);
        return a
    };
    Jm.prototype.toJSON = function() {
        return this.U()
    };
    var Km = function(a) {
        if (a.code) {
            var b = a.code || "";
            b.indexOf("auth/") == 0 && (b = b.substring(5));
            var c = {
                credential: Hm(a),
                tenantId: a.tenantId
            };
            if (a.email) c.email = a.email;
            else if (a.phoneNumber) c.phoneNumber = a.phoneNumber;
            else if (!c.credential) return new Q(b, a.message || void 0);
            return new Jm(b, c, a.message)
        }
        return null
    };
    var Lm = oa(["https://apis.google.com/js/client.js?onload=", ""]),
        Mm = function(a) {
            this.Bm = a
        };
    q(Mm, gj);
    Mm.prototype.Xd = function() {
        return new this.Bm
    };
    var Rm = function(a, b, c) {
            this.ka = a;
            b = b || {};
            this.zj = b.secureTokenEndpoint || "https://securetoken.googleapis.com/v1/token";
            this.hm = b.secureTokenTimeout || Nm;
            this.Nf = dc(b.secureTokenHeaders || Om);
            this.mi = b.firebaseEndpoint || "https://www.googleapis.com/identitytoolkit/v3/relyingparty/";
            this.Gi = b.identityPlatformEndpoint || "https://identitytoolkit.googleapis.com/v2/";
            this.Fk = b.firebaseTimeout || Pm;
            this.qd = dc(b.firebaseHeaders || Qm);
            c && (this.qd["X-Client-Version"] = c, this.Nf["X-Client-Version"] = c);
            a = Uk() == "Node";
            a = r.XMLHttpRequest || a && firebase.INTERNAL.node && firebase.INTERNAL.node.XMLHttpRequest;
            if (!a && !Tk()) throw new Q("internal-error", "The XMLHttpRequest compatibility library was not found.");
            this.Lf = void 0;
            Tk() ? this.Lf = new mj({
                Am: self
            }) : Vk() ? this.Lf = new Mm(a) : this.Lf = new jj;
            this.na = null
        },
        Sm, Tm = function(a, b) {
            b ? a.qd["X-Firebase-Locale"] = b : delete a.qd["X-Firebase-Locale"]
        },
        Vm = function(a, b) {
            b && (a.zj = Um("https://securetoken.googleapis.com/v1/token", b), a.mi = Um("https://www.googleapis.com/identitytoolkit/v3/relyingparty/",
                b), a.Gi = Um("https://identitytoolkit.googleapis.com/v2/", b))
        },
        Um = function(a, b) {
            a = N(a);
            b = N(b.url);
            a.setPath(a.Ia + a.getPath());
            ck(a, b.Xa);
            ek(a, b.Ia);
            fk(a, b.Wb);
            return a.toString()
        },
        Wm = function(a, b) {
            b ? (a.qd["X-Client-Version"] = b, a.Nf["X-Client-Version"] = b) : (delete a.qd["X-Client-Version"], delete a.Nf["X-Client-Version"])
        },
        Ym = function(a, b, c, d, e, f, g) {
            Gk() || Tk() ? a = v(a.jm, a) : (Sm || (Sm = new G(function(h, l) {
                Xm(h, l)
            })), a = v(a.im, a));
            a(b, c, d, e, f, g)
        };
    Rm.prototype.jm = function(a, b, c, d, e, f) {
        if (Tk() && (typeof r.fetch === "undefined" || typeof r.Headers === "undefined" || typeof r.Request === "undefined")) throw new Q("operation-not-supported-in-this-environment", "fetch, Headers and Request native APIs or equivalent Polyfills must be available to support HTTP requests from a Worker environment.");
        var g = new Nj(this.Lf);
        if (f) {
            g.He = Math.max(0, f);
            var h = setTimeout(function() {
                g.dispatchEvent("timeout")
            }, f)
        }
        g.listen("complete", function() {
            h && clearTimeout(h);
            var l = null;
            try {
                var m = JSON,
                    p = m.parse;
                try {
                    var w = this.v ? this.v.responseText : ""
                } catch (z) {
                    Gc(this.Ga, "Can not get responseText: " + z.message), w = ""
                }
                l = p.call(m, w) || null
            } catch (z) {
                l = null
            }
            b && b(l)
        });
        $i(g, "ready", function() {
            h && clearTimeout(h);
            this.dispose()
        });
        $i(g, "timeout", function() {
            h && clearTimeout(h);
            this.dispose();
            b && b(null)
        });
        g.send(a, c, d, e)
    };
    var Xm = function(a, b) {
        if (((window.gapi || {}).client || {}).request) a();
        else {
            r[Zm] = function() {
                ((window.gapi || {}).client || {}).request ? a() : b(Error("CORS_UNSUPPORTED"))
            };
            var c = Hb(Lm, Zm);
            Aj(Kj(c), function() {
                b(Error("CORS_UNSUPPORTED"))
            })
        }
    };
    Rm.prototype.im = function(a, b, c, d, e) {
        var f = this;
        Sm.then(function() {
            window.gapi.client.setApiKey(f.ka);
            var g = window.gapi.auth.getToken();
            window.gapi.auth.setToken(null);
            window.gapi.client.request({
                path: a,
                method: c,
                body: d,
                headers: e,
                authType: "none",
                callback: function(h) {
                    window.gapi.auth.setToken(g);
                    b && b(h)
                }
            })
        }).l(function(g) {
            b && b({
                error: {
                    message: g && g.message || "CORS_UNSUPPORTED"
                }
            })
        })
    };
    var an = function(a, b) {
            return new G(function(c, d) {
                b.grant_type == "refresh_token" && b.refresh_token || b.grant_type == "authorization_code" && b.code ? Ym(a, a.zj + "?key=" + encodeURIComponent(a.ka), function(e) {
                    e ? e.error ? d($m(e)) : e.access_token && e.refresh_token ? c(e) : d(new Q("internal-error")) : d(new Q("network-request-failed"))
                }, "POST", tk(b).toString(), a.Nf, a.hm.get()) : d(new Q("internal-error"))
            })
        },
        bn = function(a, b, c, d, e, f, g) {
            var h = N(b + c);
            M(h, "key", a.ka);
            g && M(h, "cb", Date.now().toString());
            var l = d == "GET";
            if (l)
                for (var m in e) e.hasOwnProperty(m) &&
                    M(h, m, e[m]);
            return new G(function(p, w) {
                Ym(a, h.toString(), function(z) {
                    z ? z.error ? w($m(z, f || {})) : p(z) : w(new Q("network-request-failed"))
                }, d, l ? void 0 : JSON.stringify(el(e)), a.qd, a.Fk.get())
            })
        },
        cn = function(a) {
            a = a.email;
            if (typeof a !== "string" || !Nk.test(a)) throw new Q("invalid-email");
        },
        dn = function(a) {
            "email" in a && cn(a)
        },
        fn = function(a, b) {
            return R(a, en, {
                identifier: b,
                continueUri: al() ? Ck() : "http://localhost"
            }).then(function(c) {
                return c.signinMethods || []
            })
        },
        hn = function(a) {
            return R(a, gn, {}).then(function(b) {
                return b.authorizedDomains || []
            })
        },
        jn = function(a) {
            if (!a.idToken) {
                if (a.mfaPendingCredential) throw new Q("multi-factor-auth-required", null, dc(a));
                throw new Q("internal-error");
            }
        },
        kn = function(a) {
            if (a.phoneNumber || a.temporaryProof) {
                if (!a.phoneNumber || !a.temporaryProof) throw new Q("internal-error");
            } else {
                if (!a.sessionInfo) throw new Q("missing-verification-id");
                if (!a.code) throw new Q("missing-verification-code");
            }
        };
    k = Rm.prototype;
    k.signInAnonymously = function() {
        return R(this, ln, {})
    };
    k.updateEmail = function(a, b) {
        return R(this, mn, {
            idToken: a,
            email: b
        })
    };
    k.updatePassword = function(a, b) {
        return R(this, tm, {
            idToken: a,
            password: b
        })
    };
    k.updateProfile = function(a, b) {
        var c = {
                idToken: a
            },
            d = [];
        ac(nn, function(e, f) {
            var g = b[f];
            g === null ? d.push(e) : f in b && (c[f] = g)
        });
        d.length && (c.deleteAttribute = d);
        return R(this, mn, c)
    };
    k.sendPasswordResetEmail = function(a, b) {
        a = {
            requestType: "PASSWORD_RESET",
            email: a
        };
        fc(a, b);
        return R(this, on, a)
    };
    k.sendSignInLinkToEmail = function(a, b) {
        a = {
            requestType: "EMAIL_SIGNIN",
            email: a
        };
        fc(a, b);
        return R(this, pn, a)
    };
    k.sendEmailVerification = function(a, b) {
        a = {
            requestType: "VERIFY_EMAIL",
            idToken: a
        };
        fc(a, b);
        return R(this, qn, a)
    };
    k.verifyBeforeUpdateEmail = function(a, b, c) {
        a = {
            requestType: "VERIFY_AND_CHANGE_EMAIL",
            idToken: a,
            newEmail: b
        };
        fc(a, c);
        return R(this, rn, a)
    };
    var Fm = function(a, b) {
        return R(a, sn, b)
    };
    Rm.prototype.verifyPhoneNumber = function(a) {
        return R(this, tn, a)
    };
    var Dm = function(a, b) {
            return R(a, un, b).then(function(c) {
                return c.phoneSessionInfo.sessionInfo
            })
        },
        vn = function(a) {
            if (!a.phoneVerificationInfo) throw new Q("internal-error");
            if (!a.phoneVerificationInfo.sessionInfo) throw new Q("missing-verification-id");
            if (!a.phoneVerificationInfo.code) throw new Q("missing-verification-code");
        },
        Em = function(a, b) {
            return R(a, wn, b).then(function(c) {
                return c.phoneResponseInfo.sessionInfo
            })
        },
        yn = function(a, b, c) {
            return R(a, xn, {
                idToken: b,
                deleteProvider: c
            })
        },
        zn = function(a) {
            if (!a.requestUri ||
                !a.sessionId && !a.postBody && !a.pendingToken) throw new Q("internal-error");
        },
        An = function(a, b) {
            b.oauthIdToken && b.providerId && b.providerId.indexOf("oidc.") == 0 && !b.pendingToken && (a.sessionId ? b.nonce = a.sessionId : a.postBody && (a = new ik(a.postBody), uk(a, "nonce") && (b.nonce = a.get("nonce"))));
            return b
        },
        Cn = function(a) {
            var b = null;
            a.needConfirmation ? (a.code = "account-exists-with-different-credential", b = Km(a)) : a.errorMessage == "FEDERATED_USER_ID_ALREADY_LINKED" ? (a.code = "credential-already-in-use", b = Km(a)) : a.errorMessage ==
                "EMAIL_EXISTS" ? (a.code = "email-already-in-use", b = Km(a)) : a.errorMessage && (b = Bn(a.errorMessage));
            if (b) throw b;
            jn(a)
        },
        Yl = function(a, b) {
            b.returnIdpCredential = !0;
            return R(a, Dn, b)
        },
        Zl = function(a, b) {
            b.returnIdpCredential = !0;
            return R(a, En, b)
        },
        $l = function(a, b) {
            b.returnIdpCredential = !0;
            b.autoCreate = !1;
            return R(a, Fn, b)
        },
        Gn = function(a) {
            if (!a.oobCode) throw new Q("invalid-action-code");
        };
    Rm.prototype.confirmPasswordReset = function(a, b) {
        return R(this, Hn, {
            oobCode: a,
            newPassword: b
        })
    };
    Rm.prototype.checkActionCode = function(a) {
        return R(this, In, {
            oobCode: a
        })
    };
    Rm.prototype.applyActionCode = function(a) {
        return R(this, Jn, {
            oobCode: a
        })
    };
    var R = function(a, b, c) {
            if (!wl(c, b.Oa)) return I(new Q("internal-error"));
            var d = !!b.Ke,
                e = b.httpMethod || "POST",
                f;
            return H(c).then(b.ua).then(function() {
                b.Qb && (c.returnSecureToken = !0);
                b.wa && a.na && typeof c.tenantId === "undefined" && (c.tenantId = a.na);
                return d ? bn(a, a.Gi, b.endpoint, e, c, b.bi, b.mg || !1) : bn(a, a.mi, b.endpoint, e, c, b.bi, b.mg || !1)
            }).then(function(g) {
                f = g;
                return b.If ? b.If(c, f) : f
            }).then(b.Da).then(function() {
                if (!b.hc) return f;
                if (!(b.hc in f)) throw new Q("internal-error");
                return f[b.hc]
            })
        },
        Bn = function(a) {
            return $m({
                error: {
                    errors: [{
                        message: a
                    }],
                    code: 400,
                    reason: a
                }
            })
        },
        $m = function(a, b) {
            var c = (a.error && a.error.errors && a.error.errors[0] || {}).reason || "";
            var d = {
                keyInvalid: "invalid-api-key",
                ipRefererBlocked: "app-not-authorized"
            };
            if (c = d[c] ? new Q(d[c]) : null) return c;
            c = a.error && (a.error.reason || a.error.message) || "";
            d = {
                INVALID_CUSTOM_TOKEN: "invalid-custom-token",
                CREDENTIAL_MISMATCH: "custom-token-mismatch",
                MISSING_CUSTOM_TOKEN: "internal-error",
                INVALID_IDENTIFIER: "invalid-email",
                MISSING_CONTINUE_URI: "internal-error",
                INVALID_EMAIL: "invalid-email",
                INVALID_PASSWORD: "wrong-password",
                USER_DISABLED: "user-disabled",
                MISSING_PASSWORD: "internal-error",
                EMAIL_EXISTS: "email-already-in-use",
                PASSWORD_LOGIN_DISABLED: "operation-not-allowed",
                INVALID_IDP_RESPONSE: "invalid-credential",
                INVALID_PENDING_TOKEN: "invalid-credential",
                FEDERATED_USER_ID_ALREADY_LINKED: "credential-already-in-use",
                MISSING_OR_INVALID_NONCE: "missing-or-invalid-nonce",
                INVALID_MESSAGE_PAYLOAD: "invalid-message-payload",
                INVALID_RECIPIENT_EMAIL: "invalid-recipient-email",
                INVALID_SENDER: "invalid-sender",
                EMAIL_NOT_FOUND: "user-not-found",
                RESET_PASSWORD_EXCEED_LIMIT: "too-many-requests",
                EXPIRED_OOB_CODE: "expired-action-code",
                INVALID_OOB_CODE: "invalid-action-code",
                MISSING_OOB_CODE: "internal-error",
                INVALID_PROVIDER_ID: "invalid-provider-id",
                CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "requires-recent-login",
                INVALID_ID_TOKEN: "invalid-user-token",
                TOKEN_EXPIRED: "user-token-expired",
                USER_NOT_FOUND: "user-token-expired",
                CORS_UNSUPPORTED: "cors-unsupported",
                DYNAMIC_LINK_NOT_ACTIVATED: "dynamic-link-not-activated",
                INVALID_APP_ID: "invalid-app-id",
                TOO_MANY_ATTEMPTS_TRY_LATER: "too-many-requests",
                WEAK_PASSWORD: "weak-password",
                PASSWORD_DOES_NOT_MEET_REQUIREMENTS: "password-does-not-meet-requirements",
                OPERATION_NOT_ALLOWED: "operation-not-allowed",
                USER_CANCELLED: "user-cancelled",
                CAPTCHA_CHECK_FAILED: "captcha-check-failed",
                INVALID_APP_CREDENTIAL: "invalid-app-credential",
                INVALID_CODE: "invalid-verification-code",
                INVALID_PHONE_NUMBER: "invalid-phone-number",
                INVALID_SESSION_INFO: "invalid-verification-id",
                INVALID_TEMPORARY_PROOF: "invalid-credential",
                INVALID_TENANT_ID: "invalid-tenant-id",
                MISSING_APP_CREDENTIAL: "missing-app-credential",
                MISSING_CODE: "missing-verification-code",
                MISSING_PHONE_NUMBER: "missing-phone-number",
                MISSING_SESSION_INFO: "missing-verification-id",
                QUOTA_EXCEEDED: "quota-exceeded",
                SESSION_EXPIRED: "code-expired",
                REJECTED_CREDENTIAL: "rejected-credential",
                INVALID_CONTINUE_URI: "invalid-continue-uri",
                MISSING_ANDROID_PACKAGE_NAME: "missing-android-pkg-name",
                MISSING_IOS_BUNDLE_ID: "missing-ios-bundle-id",
                UNAUTHORIZED_DOMAIN: "unauthorized-continue-uri",
                INVALID_DYNAMIC_LINK_DOMAIN: "invalid-dynamic-link-domain",
                INVALID_OAUTH_CLIENT_ID: "invalid-oauth-client-id",
                INVALID_CERT_HASH: "invalid-cert-hash",
                UNSUPPORTED_TENANT_OPERATION: "unsupported-tenant-operation",
                TENANT_ID_MISMATCH: "tenant-id-mismatch",
                ADMIN_ONLY_OPERATION: "admin-restricted-operation",
                INVALID_MFA_PENDING_CREDENTIAL: "invalid-multi-factor-session",
                MFA_ENROLLMENT_NOT_FOUND: "multi-factor-info-not-found",
                MISSING_MFA_PENDING_CREDENTIAL: "missing-multi-factor-session",
                MISSING_MFA_ENROLLMENT_ID: "missing-multi-factor-info",
                EMAIL_CHANGE_NEEDS_VERIFICATION: "email-change-needs-verification",
                SECOND_FACTOR_EXISTS: "second-factor-already-in-use",
                SECOND_FACTOR_LIMIT_EXCEEDED: "maximum-second-factor-count-exceeded",
                UNSUPPORTED_FIRST_FACTOR: "unsupported-first-factor",
                UNVERIFIED_EMAIL: "unverified-email",
                API_KEY_SERVICE_BLOCKED: "api-key-service-blocked"
            };
            b = b || {};
            fc(d, b);
            b = (b = c.match(/^[^\s]+\s*:\s*([\s\S]*)$/)) && b.length > 1 ? b[1] : void 0;
            for (var e in d)
                if (c.indexOf(e) === 0) return new Q(d[e], b);
            !b && a && (b = dl(a));
            return new Q("internal-error", b)
        },
        Nm = new il(3E4, 6E4),
        Om = {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        Pm = new il(3E4, 6E4),
        Qm = {
            "Content-Type": "application/json"
        },
        Zm = "__fcb" + Math.floor(Math.random() * 1E6).toString(),
        nn = {
            displayName: "DISPLAY_NAME",
            photoUrl: "PHOTO_URL"
        },
        Jn = {
            endpoint: "setAccountInfo",
            ua: Gn,
            hc: "email",
            wa: !0
        },
        In = {
            endpoint: "resetPassword",
            ua: Gn,
            Da: function(a) {
                var b = a.requestType;
                if (!b || !a.email && b != "EMAIL_SIGNIN" && b != "VERIFY_AND_CHANGE_EMAIL") throw new Q("internal-error");
            },
            wa: !0
        },
        Kn = {
            endpoint: "signupNewUser",
            ua: function(a) {
                cn(a);
                if (!a.password) throw new Q("weak-password");
            },
            Da: jn,
            Qb: !0,
            wa: !0
        },
        en = {
            endpoint: "createAuthUri",
            wa: !0
        },
        Ln = {
            endpoint: "deleteAccount",
            Oa: ["idToken"]
        },
        xn = {
            endpoint: "setAccountInfo",
            Oa: ["idToken", "deleteProvider"],
            ua: function(a) {
                if (!Array.isArray(a.deleteProvider)) throw new Q("internal-error");
            }
        },
        qm = {
            endpoint: "emailLinkSignin",
            Oa: ["email", "oobCode"],
            ua: cn,
            Da: jn,
            Qb: !0,
            wa: !0
        },
        sm = {
            endpoint: "emailLinkSignin",
            Oa: ["idToken", "email", "oobCode"],
            ua: cn,
            Da: jn,
            Qb: !0
        },
        Mn = {
            endpoint: "accounts/mfaEnrollment:finalize",
            Oa: ["idToken", "phoneVerificationInfo"],
            ua: vn,
            Da: jn,
            wa: !0,
            Ke: !0
        },
        Nn = {
            endpoint: "accounts/mfaSignIn:finalize",
            Oa: ["mfaPendingCredential",
                "phoneVerificationInfo"
            ],
            ua: vn,
            Da: jn,
            wa: !0,
            Ke: !0
        },
        On = {
            endpoint: "getAccountInfo"
        },
        pn = {
            endpoint: "getOobConfirmationCode",
            Oa: ["requestType"],
            ua: function(a) {
                if (a.requestType != "EMAIL_SIGNIN") throw new Q("internal-error");
                cn(a)
            },
            hc: "email",
            wa: !0
        },
        qn = {
            endpoint: "getOobConfirmationCode",
            Oa: ["idToken", "requestType"],
            ua: function(a) {
                if (a.requestType != "VERIFY_EMAIL") throw new Q("internal-error");
            },
            hc: "email",
            wa: !0
        },
        rn = {
            endpoint: "getOobConfirmationCode",
            Oa: ["idToken", "newEmail", "requestType"],
            ua: function(a) {
                if (a.requestType !=
                    "VERIFY_AND_CHANGE_EMAIL") throw new Q("internal-error");
            },
            hc: "email",
            wa: !0
        },
        on = {
            endpoint: "getOobConfirmationCode",
            Oa: ["requestType"],
            ua: function(a) {
                if (a.requestType != "PASSWORD_RESET") throw new Q("internal-error");
                cn(a)
            },
            hc: "email",
            wa: !0
        },
        gn = {
            mg: !0,
            endpoint: "getProjectConfig",
            httpMethod: "GET"
        },
        Pn = {
            mg: !0,
            endpoint: "getRecaptchaParam",
            httpMethod: "GET",
            Da: function(a) {
                if (!a.recaptchaSiteKey) throw new Q("internal-error");
            }
        },
        Hn = {
            endpoint: "resetPassword",
            ua: Gn,
            hc: "email",
            wa: !0
        },
        sn = {
            endpoint: "sendVerificationCode",
            Oa: ["phoneNumber", "recaptchaToken"],
            hc: "sessionInfo",
            wa: !0
        },
        mn = {
            endpoint: "setAccountInfo",
            Oa: ["idToken"],
            ua: dn,
            Qb: !0
        },
        tm = {
            endpoint: "setAccountInfo",
            Oa: ["idToken"],
            ua: function(a) {
                dn(a);
                if (!a.password) throw new Q("weak-password");
            },
            Da: jn,
            Qb: !0
        },
        ln = {
            endpoint: "signupNewUser",
            Da: jn,
            Qb: !0,
            wa: !0
        },
        un = {
            endpoint: "accounts/mfaEnrollment:start",
            Oa: ["idToken", "phoneEnrollmentInfo"],
            ua: function(a) {
                if (!a.phoneEnrollmentInfo) throw new Q("internal-error");
                if (!a.phoneEnrollmentInfo.phoneNumber) throw new Q("missing-phone-number");
                if (!a.phoneEnrollmentInfo.recaptchaToken) throw new Q("missing-app-credential");
            },
            Da: function(a) {
                if (!a.phoneSessionInfo || !a.phoneSessionInfo.sessionInfo) throw new Q("internal-error");
            },
            wa: !0,
            Ke: !0
        },
        wn = {
            endpoint: "accounts/mfaSignIn:start",
            Oa: ["mfaPendingCredential", "mfaEnrollmentId", "phoneSignInInfo"],
            ua: function(a) {
                if (!a.phoneSignInInfo || !a.phoneSignInInfo.recaptchaToken) throw new Q("missing-app-credential");
            },
            Da: function(a) {
                if (!a.phoneResponseInfo || !a.phoneResponseInfo.sessionInfo) throw new Q("internal-error");
            },
            wa: !0,
            Ke: !0
        },
        Dn = {
            endpoint: "verifyAssertion",
            ua: zn,
            If: An,
            Da: Cn,
            Qb: !0,
            wa: !0
        },
        Fn = {
            endpoint: "verifyAssertion",
            ua: zn,
            If: An,
            Da: function(a) {
                if (a.errorMessage && a.errorMessage == "USER_NOT_FOUND") throw new Q("user-not-found");
                if (a.errorMessage) throw Bn(a.errorMessage);
                jn(a)
            },
            Qb: !0,
            wa: !0
        },
        En = {
            endpoint: "verifyAssertion",
            ua: function(a) {
                zn(a);
                if (!a.idToken) throw new Q("internal-error");
            },
            If: An,
            Da: Cn,
            Qb: !0
        },
        Qn = {
            endpoint: "verifyCustomToken",
            ua: function(a) {
                if (!a.token) throw new Q("invalid-custom-token");
            },
            Da: jn,
            Qb: !0,
            wa: !0
        },
        rm = {
            endpoint: "verifyPassword",
            ua: function(a) {
                cn(a);
                if (!a.password) throw new Q("wrong-password");
            },
            Da: jn,
            Qb: !0,
            wa: !0
        },
        tn = {
            endpoint: "verifyPhoneNumber",
            ua: kn,
            Da: jn,
            wa: !0
        },
        zm = {
            endpoint: "verifyPhoneNumber",
            ua: function(a) {
                if (!a.idToken) throw new Q("internal-error");
                kn(a)
            },
            Da: function(a) {
                if (a.temporaryProof) throw a.code = "credential-already-in-use", Km(a);
                jn(a)
            }
        },
        Am = {
            bi: {
                USER_NOT_FOUND: "user-not-found"
            },
            endpoint: "verifyPhoneNumber",
            ua: kn,
            Da: jn,
            wa: !0
        },
        Rn = {
            endpoint: "accounts/mfaEnrollment:withdraw",
            Oa: ["idToken", "mfaEnrollmentId"],
            Da: function(a) {
                if (!!a.idToken ^ !!a.refreshToken) throw new Q("internal-error");
            },
            wa: !0,
            Ke: !0
        };
    var Sn = oa(["https://apis.google.com/js/api.js?onload=", ""]),
        Un = function(a) {
            this.lb = a;
            this.mf = null;
            this.Xg = Tn(this)
        };
    Un.prototype.onReady = function() {
        return this.Xg
    };
    var Tn = function(a) {
        return Vn().then(function() {
            return new G(function(b, c) {
                O("gapi.iframes.getContext")().open({
                    where: document.body,
                    url: a.lb,
                    messageHandlersFilter: O("gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER"),
                    attributes: {
                        style: {
                            position: "absolute",
                            top: "-100px",
                            width: "1px",
                            height: "1px"
                        }
                    },
                    dontclear: !0
                }, function(d) {
                    a.mf = d;
                    a.mf.restyle({
                        setHideOnLeave: !1
                    });
                    var e = setTimeout(function() {
                            c(Error("Network Error"))
                        }, Wn.get()),
                        f = function() {
                            clearTimeout(e);
                            b()
                        };
                    d.ping(f).then(f, function() {
                        c(Error("Network Error"))
                    })
                })
            })
        })
    };
    Un.prototype.sendMessage = function(a) {
        var b = this;
        return this.Xg.then(function() {
            return new G(function(c) {
                b.mf.send(a.type, a, c, O("gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER"))
            })
        })
    };
    Un.prototype.oh = function(a, b) {
        var c = this;
        this.Xg.then(function() {
            c.mf.register(a, b, O("gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER"))
        })
    };
    var Vn = function() {
            return Xn ? Xn : Xn = (new G(function(a, b) {
                var c = function() {
                    hl();
                    O("gapi.load")("gapi.iframes", {
                        callback: a,
                        ontimeout: function() {
                            hl();
                            b(Error("Network Error"))
                        },
                        timeout: Yn.get()
                    })
                };
                if (O("gapi.iframes.Iframe")) a();
                else if (O("gapi.load")) c();
                else {
                    var d = "__iframefcb" + Math.floor(Math.random() * 1E6).toString();
                    r[d] = function() {
                        O("gapi.load") ? c() : b(Error("Network Error"))
                    };
                    d = Hb(Sn, d);
                    H(Kj(d)).l(function() {
                        b(Error("Network Error"))
                    })
                }
            })).l(function(a) {
                Xn = null;
                throw a;
            })
        },
        Yn = new il(3E4, 6E4),
        Wn = new il(5E3,
            15E3),
        Xn = null;
    var Zn = function(a, b, c, d) {
        this.Ca = a;
        this.ka = b;
        this.ma = c;
        this.N = d;
        this.ad = null;
        this.N ? (a = N(this.N.url), a = qk(a.Xa, a.Ia, a.Wb, "/emulator/auth/iframe")) : a = qk("https", this.Ca, null, "/__/auth/iframe");
        this.mc = a;
        M(this.mc, "apiKey", this.ka);
        M(this.mc, "appName", this.ma);
        this.Ka = null;
        this.Qa = []
    };
    Zn.prototype.Dh = function(a) {
        this.ad = a;
        return this
    };
    Zn.prototype.Ah = function(a) {
        this.Ka = a;
        return this
    };
    Zn.prototype.toString = function() {
        this.ad ? M(this.mc, "v", this.ad) : this.mc.removeParameter("v");
        this.Ka ? M(this.mc, "eid", this.Ka) : this.mc.removeParameter("eid");
        this.Qa.length ? M(this.mc, "fw", this.Qa.join(",")) : this.mc.removeParameter("fw");
        return this.mc.toString()
    };
    var $n = function(a, b, c, d, e, f) {
        this.Ca = a;
        this.ka = b;
        this.ma = c;
        this.jk = d;
        this.N = f;
        this.ad = this.La = this.nh = null;
        this.Fd = e;
        this.na = this.Ka = null
    };
    $n.prototype.Ch = function(a) {
        this.na = a;
        return this
    };
    $n.prototype.Dh = function(a) {
        this.ad = a;
        return this
    };
    $n.prototype.Ah = function(a) {
        this.Ka = a;
        return this
    };
    $n.prototype.toString = function() {
        if (this.N) {
            var a = N(this.N.url);
            a = qk(a.Xa, a.Ia, a.Wb, "/emulator/auth/handler")
        } else a = qk("https", this.Ca, null, "/__/auth/handler");
        M(a, "apiKey", this.ka);
        M(a, "appName", this.ma);
        M(a, "authType", this.jk);
        if (this.Fd.isOAuthProvider) {
            var b = this.Fd;
            try {
                var c = firebase.app(this.ma).auth().Kb
            } catch (h) {
                c = null
            }
            b.wg = c;
            M(a, "providerId", this.Fd.providerId);
            c = this.Fd;
            b = el(c.ci);
            for (var d in b) b[d] = b[d].toString();
            d = c.Ol;
            b = dc(b);
            for (var e = 0; e < d.length; e++) {
                var f = d[e];
                f in b && delete b[f]
            }
            c.Rg &&
                c.wg && !b[c.Rg] && (b[c.Rg] = c.wg);
            cc(b) || M(a, "customParameters", dl(b))
        }
        typeof this.Fd.xi === "function" && (c = this.Fd.xi(), c.length && M(a, "scopes", c.join(",")));
        this.nh ? M(a, "redirectUrl", this.nh) : a.removeParameter("redirectUrl");
        this.La ? M(a, "eventId", this.La) : a.removeParameter("eventId");
        this.ad ? M(a, "v", this.ad) : a.removeParameter("v");
        if (this.Ne)
            for (var g in this.Ne) this.Ne.hasOwnProperty(g) && !pk(a, g) && M(a, g, this.Ne[g]);
        this.na ? M(a, "tid", this.na) : a.removeParameter("tid");
        this.Ka ? M(a, "eid", this.Ka) : a.removeParameter("eid");
        g = ao(this.ma);
        g.length && M(a, "fw", g.join(","));
        return a.toString()
    };
    var ao = function(a) {
            try {
                return bo(firebase.app(a).auth())
            } catch (b) {
                return []
            }
        },
        co = function(a, b, c, d, e, f) {
            this.Ca = a;
            this.ka = b;
            this.ma = c;
            this.N = f;
            this.Hc = d || null;
            this.Ka = e || null;
            this.o = this.Kg = this.ri = null;
            this.Yb = [];
            this.qf = this.Lb = null
        },
        eo = function(a) {
            var b = b || Ck();
            return hn(a).then(function(c) {
                if (!Mk(c, b)) throw new Pl(Ck());
            })
        };
    k = co.prototype;
    k.initialize = function() {
        if (this.qf) return this.qf;
        var a = this;
        return this.qf = Ok().then(function() {
            if (!a.Kg) {
                var b = a.Ca,
                    c = a.ka,
                    d = a.ma,
                    e = a.Hc,
                    f = a.Ka,
                    g = ao(a.ma);
                b = (new Zn(b, c, d, a.N)).Dh(e).Ah(f);
                b.Qa = Zb(g || []);
                a.Kg = b.toString()
            }
            a.lf = new Un(a.Kg);
            a.qh()
        })
    };
    k.Ee = function(a, b, c) {
        var d = new Q("popup-closed-by-user"),
            e = new Q("web-storage-unsupported"),
            f = this,
            g = !1;
        return this.Pc().then(function() {
            fo(f).then(function(h) {
                h || (a && Ik(a), b(e), g = !0)
            })
        }).l(function() {}).then(function() {
            if (!g) return Kk(a)
        }).then(function() {
            if (!g) return Xj(c).then(function() {
                b(d)
            })
        })
    };
    k.Jj = function() {
        var a = Ak();
        return !cl(a) && !gl(a)
    };
    k.Ci = function() {
        return !1
    };
    k.ve = function(a, b, c, d, e, f, g, h) {
        if (!a) return I(new Q("popup-blocked"));
        if (g && !cl()) return this.Pc().l(function(m) {
            Ik(a);
            e(m)
        }), d(), H();
        this.Lb || (this.Lb = eo(go(this)));
        var l = this;
        return this.Lb.then(function() {
            var m = l.Pc().l(function(p) {
                Ik(a);
                e(p);
                throw p;
            });
            d();
            return m
        }).then(function() {
            Im(c);
            if (!g) {
                var m = ho(l.Ca, l.ka, l.ma, b, c, null, f, l.Hc, void 0, l.Ka, h, l.N);
                Dk(m, a)
            }
        }).l(function(m) {
            m.code == "auth/network-request-failed" && (l.Lb = null);
            throw m;
        })
    };
    var go = function(a) {
        a.o || (a.ri = a.Hc ? Yk("JsCore", a.Hc, ao(a.ma)) : null, a.o = new Rm(a.ka, yk(a.Ka), a.ri), a.N && Vm(a.o, a.N));
        return a.o
    };
    co.prototype.we = function(a, b, c, d) {
        this.Lb || (this.Lb = eo(go(this)));
        var e = this;
        return this.Lb.then(function() {
            Im(b);
            var f = ho(e.Ca, e.ka, e.ma, a, b, Ck(), c, e.Hc, void 0, e.Ka, d, e.N);
            Dk(f)
        }).l(function(f) {
            f.code == "auth/network-request-failed" && (e.Lb = null);
            throw f;
        })
    };
    co.prototype.Pc = function() {
        var a = this;
        return this.initialize().then(function() {
            return a.lf.onReady()
        }).l(function() {
            a.Lb = null;
            throw new Q("network-request-failed");
        })
    };
    co.prototype.Oj = function() {
        return !0
    };
    var ho = function(a, b, c, d, e, f, g, h, l, m, p, w) {
        a = new $n(a, b, c, d, e, w);
        a.nh = f;
        a.La = g;
        f = a.Dh(h);
        f.Ne = dc(l || null);
        return f.Ah(m).Ch(p).toString()
    };
    co.prototype.qh = function() {
        if (!this.lf) throw Error("IfcHandler must be initialized!");
        var a = this;
        this.lf.oh("authEvent", function(b) {
            var c = {};
            if (b && b.authEvent) {
                var d = !1;
                b = Fl(b.authEvent);
                for (c = 0; c < a.Yb.length; c++) d = a.Yb[c](b) || d;
                c = {};
                c.status = d ? "ACK" : "ERROR";
                return H(c)
            }
            c.status = "ERROR";
            return H(c)
        })
    };
    var fo = function(a) {
        var b = {
            type: "webStorageSupport"
        };
        return a.initialize().then(function() {
            return a.lf.sendMessage(b)
        }).then(function(c) {
            if (c && c.length && typeof c[0].webStorageSupport !== "undefined") return c[0].webStorageSupport;
            throw Error();
        })
    };
    co.prototype.Fc = function(a) {
        this.Yb.push(a)
    };
    co.prototype.Id = function(a) {
        Yb(this.Yb, function(b) {
            return b == a
        })
    };

    function io() {}
    io.prototype.render = function() {};
    io.prototype.reset = function() {};
    io.prototype.getResponse = function() {};
    io.prototype.execute = function() {};
    var jo = oa(["https://www.google.com/recaptcha/api.js?trustedtypes=true&onload=", "&render=explicit&hl=", ""]),
        ko = function() {
            this.md = r.grecaptcha ? Infinity : 0;
            this.Ei = null;
            this.og = "__rcb" + Math.floor(Math.random() * 1E6).toString()
        };
    ko.prototype.Qi = function(a) {
        var b = this;
        return new G(function(c, d) {
            var e = setTimeout(function() {
                d(new Q("network-request-failed"))
            }, lo.get());
            if (!r.grecaptcha || a !== b.Ei && !b.md) {
                r[b.og] = function() {
                    if (r.grecaptcha) {
                        b.Ei = a;
                        var g = r.grecaptcha.render;
                        r.grecaptcha.render = function(h, l) {
                            h = g(h, l);
                            b.md++;
                            return h
                        };
                        clearTimeout(e);
                        c(r.grecaptcha)
                    } else clearTimeout(e), d(new Q("internal-error"));
                    delete r[b.og]
                };
                var f = Hb(jo, b.og, a || "");
                H(Kj(f)).l(function() {
                    clearTimeout(e);
                    d(new Q("internal-error", "Unable to load external reCAPTCHA dependencies!"))
                })
            } else clearTimeout(e),
                c(r.grecaptcha)
        })
    };
    ko.prototype.Wh = function() {
        this.md--
    };
    var lo = new il(3E4, 6E4),
        mo = null;
    var no = function() {
        this.kb = {};
        this.md = 1E12
    };
    no.prototype.render = function(a, b) {
        this.kb[this.md.toString()] = new oo(a, b);
        return this.md++
    };
    no.prototype.reset = function(a) {
        var b = po(this, a);
        a = qo(a);
        b && a && (b.delete(), delete this.kb[a])
    };
    no.prototype.getResponse = function(a) {
        return (a = po(this, a)) ? a.getResponse() : null
    };
    no.prototype.execute = function(a) {
        (a = po(this, a)) && a.execute()
    };
    var po = function(a, b) {
            return (b = qo(b)) ? a.kb[b] || null : null
        },
        qo = function(a) {
            return (a = typeof a === "undefined" ? 1E12 : a) ? a.toString() : null
        },
        ro = null,
        oo = function(a, b) {
            this.Cb = !1;
            this.Ba = b;
            this.Pd = this.Jf = null;
            this.Mi = this.Ba.size !== "invisible";
            this.ii = fd(a);
            var c = this;
            this.Yi = function() {
                c.execute()
            };
            this.Mi ? this.execute() : Ti(this.ii, "click", this.Yi)
        };
    oo.prototype.getResponse = function() {
        so(this);
        return this.Jf
    };
    oo.prototype.execute = function() {
        so(this);
        var a = this;
        this.Pd || (this.Pd = setTimeout(function() {
            a.Jf = Wk();
            var b = a.Ba.callback,
                c = a.Ba["expired-callback"];
            if (b) try {
                b(a.Jf)
            } catch (d) {}
            a.Pd = setTimeout(function() {
                a.Pd = null;
                a.Jf = null;
                if (c) try {
                    c()
                } catch (d) {}
                a.Mi && a.execute()
            }, 6E4)
        }, 500))
    };
    oo.prototype.delete = function() {
        so(this);
        this.Cb = !0;
        clearTimeout(this.Pd);
        this.Pd = null;
        aj(this.ii, "click", this.Yi)
    };
    var so = function(a) {
        if (a.Cb) throw Error("reCAPTCHA mock was already deleted!");
    };
    var to = function() {};
    to.prototype.Qi = function() {
        ro || (ro = new no);
        return H(ro)
    };
    to.prototype.Wh = function() {};
    var uo = null;
    var vo = function(a, b, c, d, e, f, g) {
        P(this, "type", "recaptcha");
        this.Td = this.Wd = null;
        this.nd = !1;
        this.Yh = b;
        this.he = null;
        g ? (uo || (uo = new to), g = uo) : (mo || (mo = new ko), g = mo);
        this.uj = g;
        this.wc = c || {
            theme: "light",
            type: "image"
        };
        this.Ma = [];
        if (this.wc.sitekey) throw new Q("argument-error", "sitekey should not be provided for reCAPTCHA as one is automatically provisioned for the current project.");
        this.rf = this.wc.size === "invisible";
        if (!r.document) throw new Q("operation-not-supported-in-this-environment", "RecaptchaVerifier is only supported in a browser HTTP/HTTPS environment with DOM support.");
        if (!fd(b) || !this.rf && fd(b).hasChildNodes()) throw new Q("argument-error", "reCAPTCHA container is either not found or already contains inner elements!");
        this.o = new Rm(a, f || null, e || null);
        this.Kk = d || function() {
            return null
        };
        var h = this;
        this.Uf = [];
        var l = this.wc.callback;
        this.wc.callback = function(p) {
            h.Zd(p);
            if (typeof l === "function") l(p);
            else if (typeof l === "string") {
                var w = O(l, r);
                typeof w === "function" && w(p)
            }
        };
        var m = this.wc["expired-callback"];
        this.wc["expired-callback"] = function() {
            h.Zd(null);
            if (typeof m ===
                "function") m();
            else if (typeof m === "string") {
                var p = O(m, r);
                typeof p === "function" && p()
            }
        }
    };
    vo.prototype.Zd = function(a) {
        for (var b = 0; b < this.Uf.length; b++) try {
            this.Uf[b](a)
        } catch (c) {}
    };
    var wo = function(a, b) {
        Yb(a.Uf, function(c) {
            return c == b
        })
    };
    k = vo.prototype;
    k.u = function(a) {
        var b = this;
        this.Ma.push(a);
        a.Dc(function() {
            Wb(b.Ma, a)
        });
        return a
    };
    k.ke = function() {
        var a = this;
        return this.Wd ? this.Wd : this.Wd = this.u(H().then(function() {
            if (al() && !Tk()) return Ok();
            throw new Q("operation-not-supported-in-this-environment", "RecaptchaVerifier is only supported in a browser HTTP/HTTPS environment.");
        }).then(function() {
            return a.uj.Qi(a.Kk())
        }).then(function(b) {
            a.he = b;
            return R(a.o, Pn, {})
        }).then(function(b) {
            a.wc.sitekey = b.recaptchaSiteKey
        }).l(function(b) {
            a.Wd = null;
            throw b;
        }))
    };
    k.render = function() {
        xo(this);
        var a = this;
        return this.u(this.ke().then(function() {
            if (a.Td === null) {
                var b = a.Yh;
                if (!a.rf) {
                    var c = fd(b);
                    b = jd(document, "DIV");
                    c.appendChild(b)
                }
                a.Td = a.he.render(b, a.wc)
            }
            return a.Td
        }))
    };
    k.verify = function() {
        xo(this);
        var a = this;
        return this.u(this.render().then(function(b) {
            return new G(function(c) {
                var d = a.he.getResponse(b);
                if (d) c(d);
                else {
                    var e = function(f) {
                        f && (wo(a, e), c(f))
                    };
                    a.Uf.push(e);
                    a.rf && a.he.execute(a.Td)
                }
            })
        }))
    };
    k.reset = function() {
        xo(this);
        this.Td !== null && this.he.reset(this.Td)
    };
    var xo = function(a) {
        if (a.nd) throw new Q("internal-error", "RecaptchaVerifier instance has been destroyed.");
    };
    vo.prototype.clear = function() {
        xo(this);
        this.nd = !0;
        this.uj.Wh();
        for (var a = 0; a < this.Ma.length; a++) this.Ma[a].cancel("RecaptchaVerifier instance has been destroyed.");
        this.rf || kd(fd(this.Yh))
    };
    var yo = function(a, b, c) {
        var d = !1;
        try {
            this.V = c || firebase.app()
        } catch (g) {
            throw new Q("argument-error", "No firebase.app.App instance is currently initialized.");
        }
        if (this.V.options && this.V.options.apiKey) c = this.V.options.apiKey;
        else throw new Q("invalid-api-key");
        var e = this,
            f = null;
        try {
            f = bo(this.V.auth())
        } catch (g) {}
        try {
            d = this.V.auth().settings.appVerificationDisabledForTesting
        } catch (g) {}
        f = firebase.SDK_VERSION ? Yk("JsCore", firebase.SDK_VERSION, f) : null;
        vo.call(this, c, a, b, function() {
            try {
                var g = e.V.auth().Kb
            } catch (h) {
                g =
                    null
            }
            return g
        }, f, yk(zk), d)
    };
    x(yo, vo);
    var zo = function(a) {
        this.Me = a
    };
    zo.prototype.postMessage = function(a, b) {
        this.Me.postMessage(a, b)
    };
    var Ao = function(a) {
        this.Kl = a;
        this.Xh = !1;
        this.wf = []
    };
    Ao.prototype.send = function(a, b, c) {
        b = b === void 0 ? null : b;
        c = c === void 0 ? !1 : c;
        var d = this,
            e;
        b = b || {};
        var f, g, h, l = null;
        if (this.Xh) return I(Error("connection_unavailable"));
        var m = c ? 800 : 50,
            p = typeof MessageChannel !== "undefined" ? new MessageChannel : null;
        return (new G(function(w, z) {
            p ? (e = "" + Math.floor(Math.random() * 1E20).toString(), p.port1.start(), g = setTimeout(function() {
                z(Error("unsupported_event"))
            }, m), f = function(D) {
                D.data.eventId === e && (D.data.status === "ack" ? (clearTimeout(g), h = setTimeout(function() {
                        z(Error("timeout"))
                    },
                    3E3)) : D.data.status === "done" ? (clearTimeout(h), typeof D.data.response !== "undefined" ? w(D.data.response) : z(Error("unknown_error"))) : (clearTimeout(g), clearTimeout(h), z(Error("invalid_response"))))
            }, l = {
                messageChannel: p,
                onMessage: f
            }, d.wf.push(l), p.port1.addEventListener("message", f), d.Kl.postMessage({
                eventType: a,
                eventId: e,
                data: b
            }, [p.port2])) : z(Error("connection_unavailable"))
        })).then(function(w) {
            Bo(d, l);
            return w
        }).l(function(w) {
            Bo(d, l);
            throw w;
        })
    };
    var Bo = function(a, b) {
        if (b) {
            var c = b.messageChannel,
                d = b.onMessage;
            c && (c.port1.removeEventListener("message", d), c.port1.close());
            Yb(a.wf, function(e) {
                return e == b
            })
        }
    };
    Ao.prototype.close = function() {
        for (; this.wf.length > 0;) Bo(this, this.wf[0]);
        this.Xh = !0
    };
    var Co = function(a) {
            this.Ag = a;
            this.Hb = {};
            this.Ti = v(this.Ok, this)
        },
        Eo = function(a) {
            A(Do, function(c) {
                c.Ag == a && (b = c)
            });
            if (!b) {
                var b = new Co(a);
                Do.push(b)
            }
            return b
        };
    Co.prototype.Ok = function(a) {
        var b = a.data.eventType,
            c = a.data.eventId,
            d = this.Hb[b];
        if (d && d.length > 0) {
            a.ports[0].postMessage({
                status: "ack",
                eventId: c,
                eventType: b,
                response: null
            });
            var e = [];
            A(d, function(f) {
                e.push(H().then(function() {
                    return f(a.origin, a.data.data)
                }))
            });
            sg(e).then(function(f) {
                var g = [];
                A(f, function(h) {
                    g.push({
                        fulfilled: h.oi,
                        value: h.value,
                        reason: h.reason ? h.reason.message : void 0
                    })
                });
                A(g, function(h) {
                    for (var l in h) typeof h[l] === "undefined" && delete h[l]
                });
                a.ports[0].postMessage({
                    status: "done",
                    eventId: c,
                    eventType: b,
                    response: g
                })
            })
        }
    };
    Co.prototype.subscribe = function(a, b) {
        cc(this.Hb) && this.Ag.addEventListener("message", this.Ti);
        typeof this.Hb[a] === "undefined" && (this.Hb[a] = []);
        this.Hb[a].push(b)
    };
    Co.prototype.unsubscribe = function(a, b) {
        typeof this.Hb[a] !== "undefined" && b ? (Yb(this.Hb[a], function(c) {
            return c == b
        }), this.Hb[a].length == 0 && delete this.Hb[a]) : b || delete this.Hb[a];
        cc(this.Hb) && this.Ag.removeEventListener("message", this.Ti)
    };
    var Do = [];
    var Fo = function(a) {
        this.yb = a || firebase.INTERNAL.reactNative && firebase.INTERNAL.reactNative.AsyncStorage;
        if (!this.yb) throw new Q("internal-error", "The React Native compatibility library was not found.");
        this.type = "asyncStorage"
    };
    k = Fo.prototype;
    k.get = function(a) {
        return H(this.yb.getItem(a)).then(function(b) {
            return b && fl(b)
        })
    };
    k.set = function(a, b) {
        return H(this.yb.setItem(a, dl(b)))
    };
    k.remove = function(a) {
        return H(this.yb.removeItem(a))
    };
    k.qc = function() {};
    k.Cc = function() {};

    function Go() {
        this.storage = {};
        this.type = "inMemory"
    }
    k = Go.prototype;
    k.get = function(a) {
        return H(this.storage[a])
    };
    k.set = function(a, b) {
        this.storage[a] = b;
        return H()
    };
    k.remove = function(a) {
        delete this.storage[a];
        return H()
    };
    k.qc = function() {};
    k.Cc = function() {};
    var Jo = function() {
            if (!Ho()) {
                if (Uk() == "Node") throw new Q("internal-error", "The LocalStorage compatibility library was not found.");
                throw new Q("web-storage-unsupported");
            }
            this.yb = Io() || firebase.INTERNAL.node.localStorage;
            this.type = "localStorage"
        },
        Io = function() {
            try {
                var a = r.localStorage,
                    b = Zk();
                a && (a.setItem(b, "1"), a.removeItem(b));
                return a
            } catch (c) {
                return null
            }
        },
        Ho = function() {
            var a = Uk() == "Node";
            a = Io() || a && firebase.INTERNAL.node && firebase.INTERNAL.node.localStorage;
            if (!a) return !1;
            try {
                return a.setItem("__sak",
                    "1"), a.removeItem("__sak"), !0
            } catch (b) {
                return !1
            }
        };
    k = Jo.prototype;
    k.get = function(a) {
        var b = this;
        return H().then(function() {
            var c = b.yb.getItem(a);
            return fl(c)
        })
    };
    k.set = function(a, b) {
        var c = this;
        return H().then(function() {
            var d = dl(b);
            d === null ? c.remove(a) : c.yb.setItem(a, d)
        })
    };
    k.remove = function(a) {
        var b = this;
        return H().then(function() {
            b.yb.removeItem(a)
        })
    };
    k.qc = function(a) {
        r.window && Ti(r.window, "storage", a)
    };
    k.Cc = function(a) {
        r.window && aj(r.window, "storage", a)
    };
    var Ko = function() {
        this.yb = {};
        this.type = "nullStorage"
    };
    k = Ko.prototype;
    k.get = function() {
        return H(null)
    };
    k.set = function() {
        return H()
    };
    k.remove = function() {
        return H()
    };
    k.qc = function() {};
    k.Cc = function() {};
    var No = function() {
            if (!Lo()) {
                if (Uk() == "Node") throw new Q("internal-error", "The SessionStorage compatibility library was not found.");
                throw new Q("web-storage-unsupported");
            }
            this.yb = Mo() || firebase.INTERNAL.node.sessionStorage;
            this.type = "sessionStorage"
        },
        Mo = function() {
            try {
                var a = r.sessionStorage,
                    b = Zk();
                a && (a.setItem(b, "1"), a.removeItem(b));
                return a
            } catch (c) {
                return null
            }
        },
        Lo = function() {
            var a = Uk() == "Node";
            a = Mo() || a && firebase.INTERNAL.node && firebase.INTERNAL.node.sessionStorage;
            if (!a) return !1;
            try {
                return a.setItem("__sak",
                    "1"), a.removeItem("__sak"), !0
            } catch (b) {
                return !1
            }
        };
    k = No.prototype;
    k.get = function(a) {
        var b = this;
        return H().then(function() {
            var c = b.yb.getItem(a);
            return fl(c)
        })
    };
    k.set = function(a, b) {
        var c = this;
        return H().then(function() {
            var d = dl(b);
            d === null ? c.remove(a) : c.yb.setItem(a, d)
        })
    };
    k.remove = function(a) {
        var b = this;
        return H().then(function() {
            b.yb.removeItem(a)
        })
    };
    k.qc = function() {};
    k.Cc = function() {};
    var Qo = function() {
            if (!Oo()) throw new Q("web-storage-unsupported");
            this.di = "firebaseLocalStorageDb";
            this.yf = "firebaseLocalStorage";
            this.vg = "fbase_key";
            this.Uj = "value";
            this.wm = 1;
            this.Ta = {};
            this.Xb = [];
            this.re = 0;
            this.Ii = r.indexedDB;
            this.type = "indexedDB";
            this.Of = this.xc = this.Ff = this.fh = null;
            this.Bj = !1;
            this.Zf = null;
            var a = this;
            Tk() && self ? (this.xc = Eo(Tk() ? self : null), this.xc.subscribe("keyChanged", function(b, c) {
                    return Po(a).then(function(d) {
                        d.length > 0 && A(a.Xb, function(e) {
                            e(d)
                        });
                        return {
                            keyProcessed: Vb(d, c.key)
                        }
                    })
                }),
                this.xc.subscribe("ping", function() {
                    return H(["keyChanged"])
                })) : pl().then(function(b) {
                if (a.Zf = b) a.Of = new Ao(new zo(b)), a.Of.send("ping", null, !0).then(function(c) {
                    c[0].fulfilled && Vb(c[0].value, "keyChanged") && (a.Bj = !0)
                }).l(function() {})
            })
        },
        Ro, So = function(a) {
            return new G(function(b, c) {
                var d = a.Ii.deleteDatabase(a.di);
                d.onsuccess = function() {
                    b()
                };
                d.onerror = function(e) {
                    c(Error(e.target.error))
                }
            })
        },
        To = function(a) {
            return new G(function(b, c) {
                var d = a.Ii.open(a.di, a.wm);
                d.onerror = function(e) {
                    try {
                        e.preventDefault()
                    } catch (f) {}
                    c(Error(e.target.error))
                };
                d.onupgradeneeded = function(e) {
                    e = e.target.result;
                    try {
                        e.createObjectStore(a.yf, {
                            keyPath: a.vg
                        })
                    } catch (f) {
                        c(f)
                    }
                };
                d.onsuccess = function(e) {
                    e = e.target.result;
                    e.objectStoreNames.contains(a.yf) ? b(e) : So(a).then(function() {
                        return To(a)
                    }).then(function(f) {
                        b(f)
                    }).l(function(f) {
                        c(f)
                    })
                }
            })
        },
        Uo = function(a) {
            a.Mg || (a.Mg = To(a));
            return a.Mg
        },
        Vo = function(a, b) {
            var c = 0,
                d = function(e, f) {
                    Uo(a).then(b).then(e).l(function(g) {
                        if (++c > 3) f(g);
                        else return Uo(a).then(function(h) {
                            h.close();
                            a.Mg = void 0;
                            return d(e, f)
                        }).l(function(h) {
                            f(h)
                        })
                    })
                };
            return new G(d)
        },
        Oo = function() {
            try {
                return !!r.indexedDB
            } catch (a) {
                return !1
            }
        },
        Wo = function(a, b) {
            return b.objectStore(a.yf)
        },
        Xo = function(a, b, c) {
            return b.transaction([a.yf], c ? "readwrite" : "readonly")
        },
        Yo = function(a) {
            return new G(function(b, c) {
                a.onsuccess = function(d) {
                    d && d.target ? b(d.target.result) : b()
                };
                a.onerror = function(d) {
                    c(d.target.error)
                }
            })
        };
    Qo.prototype.set = function(a, b) {
        var c = this,
            d = !1;
        return Vo(this, function(e) {
            e = Wo(c, Xo(c, e, !0));
            return Yo(e.get(a))
        }).then(function(e) {
            return Vo(c, function(f) {
                f = Wo(c, Xo(c, f, !0));
                if (e) return e.value = b, Yo(f.put(e));
                c.re++;
                d = !0;
                var g = {};
                g[c.vg] = a;
                g[c.Uj] = b;
                return Yo(f.add(g))
            })
        }).then(function() {
            c.Ta[a] = b;
            return Zo(c, a)
        }).Dc(function() {
            d && c.re--
        })
    };
    var Zo = function(a, b) {
        return a.Of && a.Zf && ol() === a.Zf ? a.Of.send("keyChanged", {
            key: b
        }, a.Bj).then(function() {}).l(function() {}) : H()
    };
    Qo.prototype.get = function(a) {
        var b = this;
        return Vo(this, function(c) {
            return Yo(Wo(b, Xo(b, c, !1)).get(a))
        }).then(function(c) {
            return c && c.value
        })
    };
    Qo.prototype.remove = function(a) {
        var b = !1,
            c = this;
        return Vo(this, function(d) {
            b = !0;
            c.re++;
            return Yo(Wo(c, Xo(c, d, !0))["delete"](a))
        }).then(function() {
            delete c.Ta[a];
            return Zo(c, a)
        }).Dc(function() {
            b && c.re--
        })
    };
    var Po = function(a) {
        return Uo(a).then(function(b) {
            var c = Wo(a, Xo(a, b, !1));
            return c.getAll ? Yo(c.getAll()) : new G(function(d, e) {
                var f = [],
                    g = c.openCursor();
                g.onsuccess = function(h) {
                    (h = h.target.result) ? (f.push(h.value), h["continue"]()) : d(f)
                };
                g.onerror = function(h) {
                    e(h.target.error)
                }
            })
        }).then(function(b) {
            var c = {},
                d = [];
            if (a.re == 0) {
                for (d = 0; d < b.length; d++) c[b[d][a.vg]] = b[d][a.Uj];
                d = Ek(a.Ta, c);
                a.Ta = c
            }
            return d
        })
    };
    Qo.prototype.qc = function(a) {
        this.Xb.length == 0 && this.Hh();
        this.Xb.push(a)
    };
    Qo.prototype.Cc = function(a) {
        Yb(this.Xb, function(b) {
            return b == a
        });
        this.Xb.length == 0 && this.Rf()
    };
    Qo.prototype.Hh = function() {
        var a = this;
        this.Rf();
        var b = function() {
            a.Ff = setTimeout(function() {
                a.fh = Po(a).then(function(c) {
                    c.length > 0 && A(a.Xb, function(d) {
                        d(c)
                    })
                }).then(function() {
                    b()
                }).l(function(c) {
                    c.message != "STOP_EVENT" && b()
                })
            }, 800)
        };
        b()
    };
    Qo.prototype.Rf = function() {
        this.fh && this.fh.cancel("STOP_EVENT");
        this.Ff && (clearTimeout(this.Ff), this.Ff = null)
    };

    function $o(a) {
        var b = this,
            c = null;
        this.Xb = [];
        this.type = "indexedDB";
        this.ji = a;
        this.Nh = H().then(function() {
            if (Oo()) {
                var d = Zk(),
                    e = "__sak" + d;
                Ro || (Ro = new Qo);
                c = Ro;
                return c.set(e, d).then(function() {
                    return c.get(e)
                }).then(function(f) {
                    if (f !== d) throw Error("indexedDB not supported!");
                    return c.remove(e)
                }).then(function() {
                    return c
                }).l(function() {
                    return b.ji
                })
            }
            return b.ji
        }).then(function(d) {
            b.type = d.type;
            d.qc(function(e) {
                A(b.Xb, function(f) {
                    f(e)
                })
            });
            return d
        })
    }
    k = $o.prototype;
    k.get = function(a) {
        return this.Nh.then(function(b) {
            return b.get(a)
        })
    };
    k.set = function(a, b) {
        return this.Nh.then(function(c) {
            return c.set(a, b)
        })
    };
    k.remove = function(a) {
        return this.Nh.then(function(b) {
            return b.remove(a)
        })
    };
    k.qc = function(a) {
        this.Xb.push(a)
    };
    k.Cc = function(a) {
        Yb(this.Xb, function(b) {
            return b == a
        })
    };
    var ep = function() {
            this.yg = {
                Browser: ap,
                Node: bp,
                ReactNative: cp,
                Worker: dp
            }[Uk()]
        },
        fp, ap = {
            ya: Jo,
            Sf: No
        },
        bp = {
            ya: Jo,
            Sf: No
        },
        cp = {
            ya: Fo,
            Sf: Ko
        },
        dp = {
            ya: Jo,
            Sf: Ko
        };
    var gp = function() {
        this.eg = !1;
        Object.defineProperty(this, "appVerificationDisabled", {
            get: function() {
                return this.eg
            },
            set: function(a) {
                this.eg = a
            },
            enumerable: !1
        })
    };
    var hp = function(a) {
        this.Og(a)
    };
    hp.prototype.Og = function(a) {
        var b = a.url;
        if (typeof b === "undefined") throw new Q("missing-continue-uri");
        if (typeof b !== "string" || typeof b === "string" && !b.length) throw new Q("invalid-continue-uri");
        this.qk = b;
        this.Qh = this.dg = null;
        this.Ki = !1;
        var c = a.android;
        if (c && typeof c === "object") {
            b = c.packageName;
            var d = c.installApp;
            c = c.minimumVersion;
            if (typeof b === "string" && b.length) {
                this.dg = b;
                if (typeof d !== "undefined" && typeof d !== "boolean") throw new Q("argument-error", "installApp property must be a boolean when specified.");
                this.Ki = !!d;
                if (typeof c !== "undefined" && (typeof c !== "string" || typeof c === "string" && !c.length)) throw new Q("argument-error", "minimumVersion property must be a non empty string when specified.");
                this.Qh = c || null
            } else {
                if (typeof b !== "undefined") throw new Q("argument-error", "packageName property must be a non empty string when specified.");
                if (typeof d !== "undefined" || typeof c !== "undefined") throw new Q("missing-android-pkg-name");
            }
        } else if (typeof c !== "undefined") throw new Q("argument-error", "android property must be a non null object when specified.");
        this.Fi = null;
        if ((b = a.iOS) && typeof b === "object")
            if (b = b.bundleId, typeof b === "string" && b.length) this.Fi = b;
            else {
                if (typeof b !== "undefined") throw new Q("argument-error", "bundleId property must be a non empty string when specified.");
            }
        else if (typeof b !== "undefined") throw new Q("argument-error", "iOS property must be a non null object when specified.");
        b = a.handleCodeInApp;
        if (typeof b !== "undefined" && typeof b !== "boolean") throw new Q("argument-error", "handleCodeInApp property must be a boolean when specified.");
        this.Vh = !!b;
        a = a.dynamicLinkDomain;
        if (typeof a !== "undefined" && (typeof a !== "string" || typeof a === "string" && !a.length)) throw new Q("argument-error", "dynamicLinkDomain property must be a non empty string when specified.");
        this.yk = a || null
    };
    var ip = function(a) {
        var b = {};
        b.continueUrl = a.qk;
        b.canHandleCodeInApp = a.Vh;
        if (b.androidPackageName = a.dg) b.androidMinimumVersion = a.Qh, b.androidInstallApp = a.Ki;
        b.iOSBundleId = a.Fi;
        b.dynamicLinkDomain = a.yk;
        for (var c in b) b[c] === null && delete b[c];
        return b
    };
    var jp = function(a, b) {
        this.uk = b;
        P(this, "verificationId", a)
    };
    jp.prototype.confirm = function(a) {
        a = Gm(this.verificationId, a);
        return this.uk(a)
    };
    var kp = function(a, b, c, d) {
        return (new Cm(a)).verifyPhoneNumber(b, c).then(function(e) {
            return new jp(e, d)
        })
    };
    var lp = function(a, b, c) {
        this.Hl = a;
        this.Yl = b;
        this.Mk = c;
        this.vf = 3E4;
        this.Ph = 96E4;
        this.Zl = !1;
        this.Bd = null;
        this.Rc = this.vf;
        if (this.Ph < this.vf) throw Error("Proactive refresh lower bound greater than upper bound!");
    };
    lp.prototype.start = function() {
        this.Rc = this.vf;
        mp(this, !0)
    };
    var np = function(a, b) {
            if (b) return a.Rc = a.vf, a.Mk();
            b = a.Rc;
            a.Rc *= 2;
            a.Rc > a.Ph && (a.Rc = a.Ph);
            return b
        },
        mp = function(a, b) {
            a.stop();
            a.Bd = Xj(np(a, b)).then(function() {
                return a.Zl ? H() : kl()
            }).then(function() {
                return a.Hl()
            }).then(function() {
                mp(a, !0)
            }).l(function(c) {
                a.Yl(c) && mp(a, !1)
            })
        };
    lp.prototype.stop = function() {
        this.Bd && (this.Bd.cancel(), this.Bd = null)
    };
    var up = function(a) {
            var b = {};
            b["facebook.com"] = op;
            b["google.com"] = pp;
            b["github.com"] = qp;
            b["twitter.com"] = rp;
            var c = a && a.providerId;
            try {
                if (c) return b[c] ? new b[c](a) : new sp(a);
                if (typeof a.idToken !== "undefined") return new tp(a)
            } catch (d) {}
            return null
        },
        tp = function(a) {
            var b = a.providerId;
            if (!b && a.idToken) {
                var c = Sl(a.idToken);
                c && c.mh && (b = c.mh)
            }
            if (!b) throw Error("Invalid additional user info!");
            if (b == "anonymous" || b == "custom") b = null;
            c = !1;
            typeof a.isNewUser !== "undefined" ? c = !!a.isNewUser : a.kind === "identitytoolkit#SignupNewUserResponse" &&
                (c = !0);
            P(this, "providerId", b);
            P(this, "isNewUser", c)
        },
        sp = function(a) {
            tp.call(this, a);
            a = fl(a.rawUserInfo || "{}");
            P(this, "profile", xl(a || {}))
        };
    q(sp, tp);
    var op = function(a) {
        sp.call(this, a);
        if (this.providerId != "facebook.com") throw Error("Invalid provider ID!");
    };
    q(op, sp);
    var qp = function(a) {
        sp.call(this, a);
        if (this.providerId != "github.com") throw Error("Invalid provider ID!");
        P(this, "username", this.profile && this.profile.login || null)
    };
    q(qp, sp);
    var pp = function(a) {
        sp.call(this, a);
        if (this.providerId != "google.com") throw Error("Invalid provider ID!");
    };
    q(pp, sp);
    var rp = function(a) {
        sp.call(this, a);
        if (this.providerId != "twitter.com") throw Error("Invalid provider ID!");
        P(this, "username", a.screenName || null)
    };
    q(rp, sp);
    var vp = {
        LOCAL: "local",
        NONE: "none",
        SESSION: "session"
    };

    function wp(a) {
        var b = new Q("invalid-persistence-type"),
            c = new Q("unsupported-persistence-type");
        a: {
            for (d in vp)
                if (vp[d] == a) {
                    var d = !0;
                    break a
                }
            d = !1
        }
        if (!d || typeof a !== "string") throw b;
        switch (Uk()) {
            case "ReactNative":
                if (a === "session") throw c;
                break;
            case "Node":
                if (a !== "none") throw c;
                break;
            case "Worker":
                if (a === "session" || !Oo() && a !== "none") throw c;
                break;
            default:
                if (!$k() && a !== "none") throw c;
        }
    }
    var xp = function() {
            var a = !gl(Ak()) && Sk() ? !0 : !1,
                b = cl(),
                c = $k();
            this.Wi = "firebase";
            this.yh = ":";
            this.am = a;
            this.xj = b;
            this.Vj = c;
            this.hb = {};
            fp || (fp = new ep);
            a = fp;
            try {
                this.lj = !Bk() && nl() || !r.indexedDB ? new a.yg.ya : new $o(Tk() ? new Go : new a.yg.ya)
            } catch (d) {
                this.lj = new Go, this.xj = !0
            }
            try {
                this.Nj = new a.yg.Sf
            } catch (d) {
                this.Nj = new Go
            }
            this.fl = new Go;
            this.Jh = v(this.Lj, this);
            this.Ta = {}
        },
        yp, zp = function() {
            yp || (yp = new xp);
            return yp
        },
        Ap = function(a, b) {
            switch (b) {
                case "session":
                    return a.Nj;
                case "none":
                    return a.fl;
                default:
                    return a.lj
            }
        };
    xp.prototype.rb = function(a, b) {
        return this.Wi + this.yh + a.name + (b ? this.yh + b : "")
    };
    var Bp = function(a, b, c) {
        var d = a.rb(b, c),
            e = Ap(a, b.ya);
        return a.get(b, c).then(function(f) {
            var g = null;
            try {
                g = fl(r.localStorage.getItem(d))
            } catch (h) {}
            if (g && !f) return r.localStorage.removeItem(d), a.set(b, g, c);
            g && f && e.type != "localStorage" && r.localStorage.removeItem(d)
        })
    };
    k = xp.prototype;
    k.get = function(a, b) {
        return Ap(this, a.ya).get(this.rb(a, b))
    };
    k.remove = function(a, b) {
        b = this.rb(a, b);
        a.ya == "local" && (this.Ta[b] = null);
        return Ap(this, a.ya).remove(b)
    };
    k.set = function(a, b, c) {
        var d = this.rb(a, c),
            e = this,
            f = Ap(this, a.ya);
        return f.set(d, b).then(function() {
            return f.get(d)
        }).then(function(g) {
            a.ya == "local" && (e.Ta[d] = g)
        })
    };
    k.addListener = function(a, b, c) {
        a = this.rb(a, b);
        this.Vj && (this.Ta[a] = r.localStorage.getItem(a));
        cc(this.hb) && this.Hh();
        this.hb[a] || (this.hb[a] = []);
        this.hb[a].push(c)
    };
    k.removeListener = function(a, b, c) {
        a = this.rb(a, b);
        this.hb[a] && (Yb(this.hb[a], function(d) {
            return d == c
        }), this.hb[a].length == 0 && delete this.hb[a]);
        cc(this.hb) && this.Rf()
    };
    k.Hh = function() {
        Ap(this, "local").qc(this.Jh);
        this.xj || (Bk() || !nl()) && r.indexedDB || !this.Vj || Cp(this)
    };
    var Cp = function(a) {
            Dp(a);
            a.Tg = setInterval(function() {
                for (var b in a.hb) {
                    var c = r.localStorage.getItem(b),
                        d = a.Ta[b];
                    c != d && (a.Ta[b] = c, c = new Hi({
                        type: "storage",
                        key: b,
                        target: window,
                        oldValue: d,
                        newValue: c,
                        eh: !0
                    }), a.Lj(c))
                }
            }, 1E3)
        },
        Dp = function(a) {
            a.Tg && (clearInterval(a.Tg), a.Tg = null)
        };
    xp.prototype.Rf = function() {
        Ap(this, "local").Cc(this.Jh);
        Dp(this)
    };
    xp.prototype.Lj = function(a) {
        if (a && a.Ik) {
            var b = a.ab.key;
            if (b == null)
                for (var c in this.hb) {
                    var d = this.Ta[c];
                    typeof d === "undefined" && (d = null);
                    var e = r.localStorage.getItem(c);
                    e !== d && (this.Ta[c] = e, this.ng(c))
                } else if (b.indexOf(this.Wi + this.yh) == 0 && this.hb[b]) {
                    typeof a.ab.eh !== "undefined" ? Ap(this, "local").Cc(this.Jh) : Dp(this);
                    if (this.am)
                        if (c = r.localStorage.getItem(b), d = a.ab.newValue, d !== c) d !== null ? r.localStorage.setItem(b, d) : r.localStorage.removeItem(b);
                        else if (this.Ta[b] === d && typeof a.ab.eh === "undefined") return;
                    var f = this;
                    c = function() {
                        if (typeof a.ab.eh !== "undefined" || f.Ta[b] !== r.localStorage.getItem(b)) f.Ta[b] = r.localStorage.getItem(b), f.ng(b)
                    };
                    Sc && ed && ed == 10 && r.localStorage.getItem(b) !== a.ab.newValue && a.ab.newValue !== a.ab.oldValue ? setTimeout(c, 10) : c()
                }
        } else A(a, v(this.ng, this))
    };
    xp.prototype.ng = function(a) {
        this.hb[a] && A(this.hb[a], function(b) {
            b()
        })
    };
    var Ep = function(a) {
            this.W = a;
            this.O = zp()
        },
        Gp = function(a) {
            return a.O.get(Fp, a.W).then(function(b) {
                return Fl(b)
            })
        },
        Hp = function(a) {
            return a.O.remove(Fp, a.W)
        };
    Ep.prototype.Fc = function(a) {
        this.O.addListener(Fp, this.W, a)
    };
    Ep.prototype.Id = function(a) {
        this.O.removeListener(Fp, this.W, a)
    };
    var Jp = function(a) {
            return a.O.get(Ip, a.W).then(function(b) {
                return Fl(b)
            })
        },
        Fp = {
            name: "authEvent",
            ya: "local"
        },
        Ip = {
            name: "redirectEvent",
            ya: "session"
        };
    var Kp = function() {
        this.O = zp()
    };
    Kp.prototype.fe = function() {
        return this.O.get(Lp, void 0)
    };
    var Lp = {
        name: "sessionId",
        ya: "session"
    };
    var Mp = function() {
        this.Ug = null;
        this.Se = []
    };
    Mp.prototype.subscribe = function(a) {
        var b = this;
        this.Se.push(a);
        this.Ug || (this.Ug = function(c) {
            for (var d = 0; d < b.Se.length; d++) b.Se[d](c)
        }, a = O("universalLinks.subscribe", r), typeof a === "function" && a(null, this.Ug))
    };
    Mp.prototype.unsubscribe = function(a) {
        Yb(this.Se, function(b) {
            return b == a
        })
    };
    var Np = null;
    var Op = function(a, b, c, d, e, f) {
            this.Ca = a;
            this.ka = b;
            this.ma = c;
            this.N = f;
            this.Hc = d || null;
            this.Ka = e || null;
            this.Mj = b + ":" + c;
            this.dm = new Kp;
            this.ui = new Ep(this.Mj);
            this.Ng = null;
            this.Yb = [];
            this.ll = 500;
            this.Ml = 2E3;
            this.je = this.Ef = null
        },
        Pp = function(a) {
            return new Q("invalid-cordova-configuration", a)
        };
    Op.prototype.Pc = function() {
        return this.ke ? this.ke : this.ke = Qk().then(function() {
            if (typeof O("universalLinks.subscribe", r) !== "function") throw Pp("cordova-universal-links-plugin-fix is not installed");
            if (typeof O("BuildInfo.packageName", r) === "undefined") throw Pp("cordova-plugin-buildinfo is not installed");
            if (typeof O("cordova.plugins.browsertab.openUrl", r) !== "function") throw Pp("cordova-plugin-browsertab is not installed");
            if (typeof O("cordova.InAppBrowser.open", r) !== "function") throw Pp("cordova-plugin-inappbrowser is not installed");
        }, function() {
            throw new Q("cordova-not-ready");
        })
    };
    var Qp = function() {
            for (var a = 20, b = []; a > 0;) b.push("1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(Math.floor(Math.random() * 62))), a--;
            return b.join("")
        },
        Rp = function(a) {
            var b = new Di;
            b.update(a);
            return ri(b.digest())
        };
    k = Op.prototype;
    k.Ee = function(a, b) {
        b(new Q("operation-not-supported-in-this-environment"));
        return H()
    };
    k.ve = function() {
        return I(new Q("operation-not-supported-in-this-environment"))
    };
    k.Oj = function() {
        return !1
    };
    k.Jj = function() {
        return !0
    };
    k.Ci = function() {
        return !0
    };
    k.we = function(a, b, c, d) {
        if (this.Ef) return I(new Q("redirect-operation-pending"));
        var e = this,
            f = r.document,
            g = null,
            h = null,
            l = null,
            m = null;
        return this.Ef = H().then(function() {
            Im(b);
            return Sp(e)
        }).then(function() {
            return Tp(e, a, b, c, d)
        }).then(function() {
            return (new G(function(p, w) {
                h = function() {
                    var z = O("cordova.plugins.browsertab.close", r);
                    p();
                    typeof z === "function" && z();
                    e.je && typeof e.je.close === "function" && (e.je.close(), e.je = null);
                    return !1
                };
                e.Fc(h);
                l = function() {
                    g || (g = Xj(e.Ml).then(function() {
                        w(new Q("redirect-cancelled-by-user"))
                    }))
                };
                m =
                    function() {
                        jl() && l()
                    };
                f.addEventListener("resume", l, !1);
                Ak().toLowerCase().match(/android/) || f.addEventListener("visibilitychange", m, !1)
            })).l(function(p) {
                return Up(e).then(function() {
                    throw p;
                })
            })
        }).Dc(function() {
            l && f.removeEventListener("resume", l, !1);
            m && f.removeEventListener("visibilitychange", m, !1);
            g && g.cancel();
            h && e.Id(h);
            e.Ef = null
        })
    };
    var Tp = function(a, b, c, d, e) {
        var f = Qp(),
            g = new El(b, d, null, f, new Q("no-auth-event"), null, e),
            h = O("BuildInfo.packageName", r);
        if (typeof h !== "string") throw new Q("invalid-cordova-configuration");
        var l = O("BuildInfo.displayName", r),
            m = {};
        if (Ak().toLowerCase().match(/iphone|ipad|ipod/)) m.ibi = h;
        else if (Ak().toLowerCase().match(/android/)) m.apn = h;
        else return I(new Q("operation-not-supported-in-this-environment"));
        l && (m.appDisplayName = l);
        f = Rp(f);
        m.sessionId = f;
        var p = ho(a.Ca, a.ka, a.ma, b, c, null, d, a.Hc, m, a.Ka, e, a.N);
        return a.Pc().then(function() {
            var w = a.Mj;
            return a.dm.O.set(Fp, g.U(), w)
        }).then(function() {
            var w = O("cordova.plugins.browsertab.isAvailable", r);
            if (typeof w !== "function") throw new Q("invalid-cordova-configuration");
            var z = null;
            w(function(D) {
                if (D) {
                    z = O("cordova.plugins.browsertab.openUrl", r);
                    if (typeof z !== "function") throw new Q("invalid-cordova-configuration");
                    z(p)
                } else {
                    z = O("cordova.InAppBrowser.open", r);
                    if (typeof z !== "function") throw new Q("invalid-cordova-configuration");
                    D = z;
                    var Ca = Ak();
                    Ca = !(!Ca.match(/(iPad|iPhone|iPod).*OS 7_\d/i) &&
                        !Ca.match(/(iPad|iPhone|iPod).*OS 8_\d/i));
                    a.je = D(p, Ca ? "_blank" : "_system", "location=yes")
                }
            })
        })
    };
    Op.prototype.Zd = function(a) {
        for (var b = 0; b < this.Yb.length; b++) try {
            this.Yb[b](a)
        } catch (c) {}
    };
    var Sp = function(a) {
            a.Ng || (a.Ng = a.Pc().then(function() {
                return new G(function(b) {
                    var c = function(d) {
                        b(d);
                        a.Id(c);
                        return !1
                    };
                    a.Fc(c);
                    Vp(a)
                })
            }));
            return a.Ng
        },
        Up = function(a) {
            var b = null;
            return Gp(a.ui).then(function(c) {
                b = c;
                return Hp(a.ui)
            }).then(function() {
                return b
            })
        },
        Vp = function(a) {
            var b = new El("unknown", null, null, null, new Q("no-auth-event")),
                c = !1,
                d = Xj(a.ll).then(function() {
                    return Up(a).then(function() {
                        c || a.Zd(b)
                    })
                }),
                e = function(g) {
                    c = !0;
                    d && d.cancel();
                    Up(a).then(function(h) {
                        var l = b;
                        if (h && g && g.url) {
                            var m = null;
                            l = Ol(g.url);
                            l.indexOf("/__/auth/callback") != -1 && (m = N(l), m = fl(pk(m, "firebaseError") || null), m = (m = typeof m === "object" ? Dl(m) : null) ? new El(h.getType(), h.La, null, null, m, null, h.na) : new El(h.getType(), h.La, l, h.fe(), null, null, h.na));
                            l = m || b
                        }
                        a.Zd(l)
                    })
                },
                f = r.handleOpenURL;
            r.handleOpenURL = function(g) {
                g.toLowerCase().indexOf(O("BuildInfo.packageName", r).toLowerCase() + "://") == 0 && e({
                    url: g
                });
                if (typeof f === "function") try {
                    f(g)
                } catch (h) {
                    console.error(h)
                }
            };
            Np || (Np = new Mp);
            Np.subscribe(e)
        };
    Op.prototype.Fc = function(a) {
        this.Yb.push(a);
        Sp(this).l(function(b) {
            b.code === "auth/invalid-cordova-configuration" && (b = new El("unknown", null, null, null, new Q("no-auth-event")), a(b))
        })
    };
    Op.prototype.Id = function(a) {
        Yb(this.Yb, function(b) {
            return b == a
        })
    };
    var Wp = function(a) {
            this.W = a;
            this.O = zp()
        },
        Yp = function(a) {
            return a.O.set(Xp, "pending", a.W)
        },
        Zp = function(a) {
            return a.O.remove(Xp, a.W)
        },
        $p = function(a) {
            return a.O.get(Xp, a.W).then(function(b) {
                return b == "pending"
            })
        },
        Xp = {
            name: "pendingRedirect",
            ya: "session"
        };
    var eq = function(a, b, c, d) {
            this.Gf = {};
            this.Sg = 0;
            this.Ca = a;
            this.ka = b;
            this.ma = c;
            this.N = d;
            this.Fe = [];
            this.xd = !1;
            this.ig = v(this.Hg, this);
            this.yc = new aq(this);
            this.hh = new bq(this);
            this.te = new Wp(cq(this.ka, this.ma));
            this.Ec = {};
            this.Ec.unknown = this.yc;
            this.Ec.signInViaRedirect = this.yc;
            this.Ec.linkViaRedirect = this.yc;
            this.Ec.reauthViaRedirect = this.yc;
            this.Ec.signInViaPopup = this.hh;
            this.Ec.linkViaPopup = this.hh;
            this.Ec.reauthViaPopup = this.hh;
            this.ub = dq(this.Ca, this.ka, this.ma, zk, this.N)
        },
        dq = function(a, b, c, d,
            e) {
            var f = firebase.SDK_VERSION || null;
            return Pk() ? new Op(a, b, c, f, d, e) : new co(a, b, c, f, d, e)
        };
    eq.prototype.reset = function() {
        this.xd = !1;
        this.ub.Id(this.ig);
        this.ub = dq(this.Ca, this.ka, this.ma, null, this.N);
        this.Gf = {}
    };
    eq.prototype.ld = function() {
        this.yc.ld()
    };
    eq.prototype.initialize = function() {
        var a = this;
        this.xd || (this.xd = !0, this.ub.Fc(this.ig));
        var b = this.ub;
        return this.ub.Pc().l(function(c) {
            a.ub == b && a.reset();
            throw c;
        })
    };
    var hq = function(a) {
        a.ub.Jj() && a.initialize().l(function(b) {
            var c = new El("unknown", null, null, null, new Q("operation-not-supported-in-this-environment"));
            fq(b) && a.Hg(c)
        });
        a.ub.Ci() || gq(a.yc)
    };
    k = eq.prototype;
    k.subscribe = function(a) {
        Vb(this.Fe, a) || this.Fe.push(a);
        if (!this.xd) {
            var b = this;
            $p(this.te).then(function(c) {
                c ? Zp(b.te).then(function() {
                    b.initialize().l(function(d) {
                        var e = new El("unknown", null, null, null, new Q("operation-not-supported-in-this-environment"));
                        fq(d) && b.Hg(e)
                    })
                }) : hq(b)
            }).l(function() {
                hq(b)
            })
        }
    };
    k.unsubscribe = function(a) {
        Yb(this.Fe, function(b) {
            return b == a
        })
    };
    k.Hg = function(a) {
        if (!a) throw new Q("invalid-auth-event");
        Date.now() - this.Sg >= 6E5 && (this.Gf = {}, this.Sg = 0);
        if (a && a.getUid() && this.Gf.hasOwnProperty(a.getUid())) return !1;
        for (var b = !1, c = 0; c < this.Fe.length; c++) {
            var d = this.Fe[c];
            if (d.Uh(a.getType(), a.La)) {
                if (b = this.Ec[a.getType()]) b.rj(a, d), a && (a.fe() || a.La) && (this.Gf[a.getUid()] = !0, this.Sg = Date.now());
                b = !0;
                break
            }
        }
        gq(this.yc);
        return b
    };
    k.getRedirectResult = function() {
        return this.yc.getRedirectResult()
    };
    k.ve = function(a, b, c, d, e, f) {
        var g = this;
        return this.ub.ve(a, b, c, function() {
            g.xd || (g.xd = !0, g.ub.Fc(g.ig))
        }, function() {
            g.reset()
        }, d, e, f)
    };
    var fq = function(a) {
        return a && a.code == "auth/cordova-not-ready" ? !0 : !1
    };
    eq.prototype.we = function(a, b, c, d) {
        var e = this,
            f;
        return Yp(this.te).then(function() {
            return e.ub.we(a, b, c, d).l(function(g) {
                if (fq(g)) throw new Q("operation-not-supported-in-this-environment");
                f = g;
                return Zp(e.te).then(function() {
                    throw f;
                })
            }).then(function() {
                return e.ub.Oj() ? new G(function() {}) : Zp(e.te).then(function() {
                    return e.getRedirectResult()
                }).then(function() {}).l(function() {})
            })
        })
    };
    eq.prototype.Ee = function(a, b, c, d) {
        return this.ub.Ee(c, function(e) {
            a.Vc(b, null, e, d)
        }, iq.get())
    };
    var cq = function(a, b, c) {
            a = a + ":" + b;
            c && (a = a + ":" + c.url);
            return a
        },
        kq = function(a, b, c, d) {
            var e = cq(b, c, d);
            jq[e] || (jq[e] = new eq(a, b, c, d));
            return jq[e]
        },
        iq = new il(2E3, 1E4),
        lq = new il(3E4, 6E4),
        jq = {},
        aq = function(a) {
            this.O = a;
            this.Hd = null;
            this.ze = [];
            this.ye = [];
            this.Gd = null;
            this.Pj = this.Ae = !1
        };
    aq.prototype.reset = function() {
        this.Hd = null;
        this.Gd && (this.Gd.cancel(), this.Gd = null)
    };
    aq.prototype.rj = function(a, b) {
        if (a) {
            this.reset();
            this.Ae = !0;
            var c = a.getType(),
                d = a.La,
                e = a.getError() && a.getError().code == "auth/web-storage-unsupported",
                f = a.getError() && a.getError().code == "auth/operation-not-supported-in-this-environment";
            this.Pj = !(!e && !f);
            c != "unknown" || e || f ? a.Db ? this.jh(a, b) : b.de(c, d) ? this.kh(a, b) : I(new Q("invalid-auth-event")) : (mq(this, !1, null, null), H())
        } else I(new Q("invalid-auth-event"))
    };
    var gq = function(a) {
        a.Ae || (a.Ae = !0, mq(a, !1, null, null))
    };
    aq.prototype.ld = function() {
        this.Ae && !this.Pj && mq(this, !1, null, null)
    };
    aq.prototype.jh = function(a) {
        mq(this, !0, null, a.getError());
        H()
    };
    aq.prototype.kh = function(a, b) {
        var c = this,
            d = a.La,
            e = a.getType();
        b = b.de(e, d);
        d = a.Qd;
        e = a.fe();
        var f = a.ih,
            g = a.na,
            h = !!a.getType().match(/Redirect$/);
        b(d, e, g, f).then(function(l) {
            mq(c, h, l, null)
        }).l(function(l) {
            mq(c, h, null, l)
        })
    };
    var nq = function(a, b) {
            a.Hd = function() {
                return I(b)
            };
            if (a.ye.length)
                for (var c = 0; c < a.ye.length; c++) a.ye[c](b)
        },
        oq = function(a, b) {
            a.Hd = function() {
                return H(b)
            };
            if (a.ze.length)
                for (var c = 0; c < a.ze.length; c++) a.ze[c](b)
        },
        mq = function(a, b, c, d) {
            b ? d ? nq(a, d) : oq(a, c) : oq(a, {
                user: null
            });
            a.ze = [];
            a.ye = []
        };
    aq.prototype.getRedirectResult = function() {
        var a = this;
        return new G(function(b, c) {
            a.Hd ? a.Hd().then(b, c) : (a.ze.push(b), a.ye.push(c), pq(a))
        })
    };
    var pq = function(a) {
            var b = new Q("timeout");
            a.Gd && a.Gd.cancel();
            a.Gd = Xj(lq.get()).then(function() {
                a.Hd || (a.Ae = !0, mq(a, !0, null, b))
            })
        },
        bq = function(a) {
            this.O = a
        };
    bq.prototype.rj = function(a, b) {
        if (a) {
            var c = a.getType(),
                d = a.La;
            a.Db ? this.jh(a, b) : b.de(c, d) ? this.kh(a, b) : I(new Q("invalid-auth-event"))
        } else I(new Q("invalid-auth-event"))
    };
    bq.prototype.jh = function(a, b) {
        var c = a.La,
            d = a.getType();
        b.Vc(d, null, a.getError(), c);
        H()
    };
    bq.prototype.kh = function(a, b) {
        var c = a.La,
            d = a.getType(),
            e = b.de(d, c),
            f = a.Qd,
            g = a.fe();
        e(f, g, a.na, a.ih).then(function(h) {
            b.Vc(d, h, null, c)
        }).l(function(h) {
            b.Vc(d, null, h, c)
        })
    };
    var qq = function(a, b, c) {
        var d = b && b.mfaPendingCredential;
        if (!d) throw new Q("argument-error", "Internal assert: Invalid MultiFactorResolver");
        this.Pe = a;
        this.zk = dc(b);
        this.Dl = c;
        this.Cj = new Ul(null, d);
        this.Di = [];
        var e = this;
        A(b.mfaInfo || [], function(f) {
            (f = Jl(f)) && e.Di.push(f)
        });
        P(this, "auth", this.Pe);
        P(this, "session", this.Cj);
        P(this, "hints", this.Di)
    };
    qq.prototype.resolveSignIn = function(a) {
        var b = this;
        return a.process(this.Pe.o, this.Cj).then(function(c) {
            var d = dc(b.zk);
            delete d.mfaInfo;
            delete d.mfaPendingCredential;
            fc(d, c);
            return b.Dl(d)
        })
    };
    var rq = function(a, b, c, d) {
        Q.call(this, "multi-factor-auth-required", d, b);
        this.Sl = new qq(a, b, c);
        P(this, "resolver", this.Sl)
    };
    q(rq, Q);
    var sq = function(a, b, c) {
        if (a && u(a.serverResponse) && a.code === "auth/multi-factor-auth-required") try {
            return new rq(b, a.serverResponse, c, a.message)
        } catch (d) {}
        return null
    };
    var tq = function() {};
    tq.prototype.process = function(a, b, c) {
        return b.type == "enroll" ? uq(this, a, b, c) : vq(this, a, b)
    };
    var uq = function(a, b, c, d) {
            return c.ee().then(function(e) {
                e = {
                    idToken: e
                };
                typeof d !== "undefined" && (e.displayName = d);
                fc(e, {
                    phoneVerificationInfo: ym(a.Vg)
                });
                return R(b, Mn, e)
            })
        },
        vq = function(a, b, c) {
            return c.ee().then(function(d) {
                d = {
                    mfaPendingCredential: d
                };
                fc(d, {
                    phoneVerificationInfo: ym(a.Vg)
                });
                return R(b, Nn, d)
            })
        },
        wq = function(a) {
            P(this, "factorId", a.providerId);
            this.Vg = a
        };
    x(wq, tq);
    var xq = function(a) {
        wq.call(this, a);
        if (this.Vg.providerId != Cm.PROVIDER_ID) throw new Q("argument-error", "firebase.auth.PhoneMultiFactorAssertion requires a valid firebase.auth.PhoneAuthCredential");
    };
    x(xq, wq);
    var yq = function(a, b) {
        Gi.call(this, a);
        for (var c in b) this[c] = b[c]
    };
    q(yq, Gi);
    var Aq = function(a, b) {
            this.nc = a;
            this.Xe = [];
            this.um = v(this.Yk, this);
            Ti(this.nc, "userReloaded", this.um);
            var c = [];
            b && b.multiFactor && b.multiFactor.enrolledFactors && A(b.multiFactor.enrolledFactors, function(d) {
                var e = null,
                    f = {};
                if (d) {
                    d.uid && (f.mfaEnrollmentId = d.uid);
                    d.displayName && (f.displayName = d.displayName);
                    d.enrollmentTime && (f.enrolledAt = (new Date(d.enrollmentTime)).toISOString());
                    if (d.phoneNumber) {
                        f.phoneInfo = d.phoneNumber;
                        try {
                            e = new Hl(f)
                        } catch (g) {}
                    } else if (d.totpInfo) {
                        f.totpInfo = d.totpInfo;
                        try {
                            e = new Il(f)
                        } catch (g) {}
                    } else e =
                        null;
                    d = e
                } else d = null;
                d && c.push(d)
            });
            zq(this, c)
        },
        Bq = function(a) {
            var b = [];
            A(a.mfaInfo || [], function(c) {
                (c = Jl(c)) && b.push(c)
            });
            return b
        };
    Aq.prototype.Yk = function(a) {
        zq(this, Bq(a.vm))
    };
    var zq = function(a, b) {
        a.Xe = b;
        P(a, "enrolledFactors", b)
    };
    k = Aq.prototype;
    k.copy = function(a) {
        zq(this, a.Xe)
    };
    k.getSession = function() {
        return this.nc.getIdToken().then(function(a) {
            return new Ul(a, null)
        })
    };
    k.enroll = function(a, b) {
        var c = this,
            d = this.nc.o;
        return this.getSession().then(function(e) {
            return a.process(d, e, b)
        }).then(function(e) {
            Cq(c.nc, e);
            return c.nc.reload()
        })
    };
    k.unenroll = function(a) {
        var b = this,
            c = typeof a === "string" ? a : a.uid,
            d = this.nc.o;
        return this.nc.getIdToken().then(function(e) {
            return R(d, Rn, {
                idToken: e,
                mfaEnrollmentId: c
            })
        }).then(function(e) {
            var f = Sb(b.Xe, function(g) {
                return g.uid != c
            });
            zq(b, f);
            Cq(b.nc, e);
            return b.nc.reload().l(function(g) {
                if (g.code != "auth/user-token-expired") throw g;
            })
        })
    };
    k.U = function() {
        return {
            multiFactor: {
                enrolledFactors: Tb(this.Xe, function(a) {
                    return a.U()
                })
            }
        }
    };
    var Dq = function(a) {
        this.o = a;
        this.Ya = this.Va = null;
        this.od = Date.now()
    };
    Dq.prototype.U = function() {
        return {
            apiKey: this.o.ka,
            refreshToken: this.Va,
            accessToken: this.Ya && this.Ya.toString(),
            expirationTime: this.od
        }
    };
    var Eq = function(a, b) {
            typeof b === "undefined" && (a.Ya ? (b = a.Ya, b = b.Cg - b.al) : b = 0);
            a.od = Date.now() + b * 1E3
        },
        Fq = function(a, b) {
            a.Ya = Sl(b.idToken || "");
            a.Va = b.refreshToken;
            b = b.expiresIn;
            Eq(a, typeof b !== "undefined" ? Number(b) : void 0)
        };
    Dq.prototype.copy = function(a) {
        this.Ya = a.Ya;
        this.Va = a.Va;
        this.od = a.od
    };
    var Gq = function(a, b) {
        return an(a.o, b).then(function(c) {
            a.Ya = Sl(c.access_token);
            a.Va = c.refresh_token;
            Eq(a, c.expires_in);
            return {
                accessToken: a.Ya.toString(),
                refreshToken: a.Va
            }
        }).l(function(c) {
            c.code == "auth/user-token-expired" && (a.Va = null);
            throw c;
        })
    };
    Dq.prototype.getToken = function(a) {
        a = !!a;
        return this.Ya && !this.Va ? I(new Q("user-token-expired")) : a || !this.Ya || Date.now() > this.od - 3E4 ? this.Va ? Gq(this, {
            grant_type: "refresh_token",
            refresh_token: this.Va
        }) : H(null) : H({
            accessToken: this.Ya.toString(),
            refreshToken: this.Va
        })
    };
    var Hq = function(a, b) {
        this.ai = a || null;
        this.Oi = b || null;
        ul(this, {
            lastSignInTime: ml(b || null),
            creationTime: ml(a || null)
        })
    };
    Hq.prototype.clone = function() {
        return new Hq(this.ai, this.Oi)
    };
    Hq.prototype.U = function() {
        return {
            lastLoginAt: this.Oi,
            createdAt: this.ai
        }
    };
    var Iq = function(a, b, c, d, e, f) {
            ul(this, {
                uid: a,
                displayName: d || null,
                photoURL: e || null,
                email: c || null,
                phoneNumber: f || null,
                providerId: b
            })
        },
        S = function(a, b, c) {
            dj.call(this);
            this.Ma = [];
            this.ka = a.apiKey;
            this.ma = a.appName;
            this.Ca = a.authDomain || null;
            var d = firebase.SDK_VERSION ? Yk("JsCore", firebase.SDK_VERSION) : null;
            this.o = new Rm(this.ka, yk(zk), d);
            (this.N = a.emulatorConfig || null) && Vm(this.o, this.N);
            this.Rb = new Dq(this.o);
            Jq(this, b.idToken);
            Fq(this.Rb, b);
            P(this, "refreshToken", this.Rb.Va);
            Kq(this, c || {});
            this.ue = !1;
            this.Ca && bl() && (this.ha = kq(this.Ca, this.ka, this.ma, this.N));
            this.Qf = [];
            this.Sb = null;
            this.Ed = Lq(this);
            this.Sd = v(this.Jg, this);
            var e = this;
            this.Kb = null;
            this.cj = function(f) {
                e.Ld(f.languageCode)
            };
            this.Qg = null;
            this.Zi = function(f) {
                Mq(e, f.emulatorConfig)
            };
            this.xg = null;
            this.Qa = [];
            this.aj = function(f) {
                Nq(e, f.Hk)
            };
            this.Dg = null;
            this.xf = new Aq(this, c);
            P(this, "multiFactor", this.xf)
        };
    q(S, dj);
    S.prototype.Ld = function(a) {
        this.Kb = a;
        Tm(this.o, a)
    };
    var Mq = function(a, b) {
            a.N = b;
            Vm(a.o, b);
            a.ha && (b = a.ha, a.ha = kq(a.Ca, a.ka, a.ma, a.N), a.ue && (b.unsubscribe(a), a.ha.subscribe(a)))
        },
        Oq = function(a, b) {
            a.Qg && aj(a.Qg, "languageCodeChanged", a.cj);
            (a.Qg = b) && Ti(b, "languageCodeChanged", a.cj)
        },
        Pq = function(a, b) {
            a.xg && aj(a.xg, "emulatorConfigChanged", a.Zi);
            (a.xg = b) && Ti(b, "emulatorConfigChanged", a.Zi)
        },
        Nq = function(a, b) {
            a.Qa = b;
            Wm(a.o, firebase.SDK_VERSION ? Yk("JsCore", firebase.SDK_VERSION, a.Qa) : null)
        },
        bo = function(a) {
            return Zb(a.Qa)
        },
        Qq = function(a, b) {
            a.Dg && aj(a.Dg, "frameworkChanged",
                a.aj);
            (a.Dg = b) && Ti(b, "frameworkChanged", a.aj)
        };
    S.prototype.Jg = function() {
        this.Ed.Bd && (this.Ed.stop(), this.Ed.start())
    };
    var Rq = function(a) {
            try {
                return firebase.app(a.ma).auth()
            } catch (b) {
                throw new Q("internal-error", "No firebase.auth.Auth instance is available for the Firebase App '" + a.ma + "'!");
            }
        },
        Lq = function(a) {
            return new lp(function() {
                return a.getIdToken(!0)
            }, function(b) {
                return b && b.code == "auth/network-request-failed" ? !0 : !1
            }, function() {
                var b = a.Rb.od - Date.now() - 3E5;
                return b > 0 ? b : 0
            })
        },
        Sq = function(a) {
            a.nd || a.Ed.Bd || (a.Ed.start(), aj(a, "tokenChanged", a.Sd), Ti(a, "tokenChanged", a.Sd))
        },
        Tq = function(a) {
            aj(a, "tokenChanged", a.Sd);
            a.Ed.stop()
        },
        Jq = function(a, b) {
            a.Ni = b;
            P(a, "_lat", b)
        },
        Uq = function(a, b) {
            Yb(a.Qf, function(c) {
                return c == b
            })
        },
        Vq = function(a) {
            for (var b = [], c = 0; c < a.Qf.length; c++) b.push(a.Qf[c](a));
            return sg(b).then(function() {
                return a
            })
        },
        Wq = function(a) {
            a.ha && !a.ue && (a.ue = !0, a.ha.subscribe(a))
        },
        Kq = function(a, b) {
            ul(a, {
                uid: b.uid,
                displayName: b.displayName || null,
                photoURL: b.photoURL || null,
                email: b.email || null,
                emailVerified: b.emailVerified || !1,
                phoneNumber: b.phoneNumber || null,
                isAnonymous: b.isAnonymous || !1,
                tenantId: b.tenantId || null,
                metadata: new Hq(b.createdAt, b.lastLoginAt),
                providerData: []
            });
            a.o.na = a.tenantId
        },
        Xq = function() {},
        Yq = function(a) {
            return H().then(function() {
                if (a.nd) throw new Q("app-deleted");
            })
        },
        Zq = function(a) {
            return Tb(a.providerData, function(b) {
                return b.providerId
            })
        },
        ar = function(a, b) {
            b && ($q(a, b.providerId), a.providerData.push(b))
        },
        $q = function(a, b) {
            Yb(a.providerData, function(c) {
                return c.providerId == b
            })
        },
        br = function(a, b, c) {
            (b != "uid" || c) && a.hasOwnProperty(b) && P(a, b, c)
        };
    S.prototype.copy = function(a) {
        var b = this;
        b != a && (ul(this, {
            uid: a.uid,
            displayName: a.displayName,
            photoURL: a.photoURL,
            email: a.email,
            emailVerified: a.emailVerified,
            phoneNumber: a.phoneNumber,
            isAnonymous: a.isAnonymous,
            tenantId: a.tenantId,
            providerData: []
        }), a.metadata ? P(this, "metadata", a.metadata.clone()) : P(this, "metadata", new Hq), A(a.providerData, function(c) {
            ar(b, c)
        }), this.Rb.copy(a.Rb), P(this, "refreshToken", this.Rb.Va), this.xf.copy(a.xf))
    };
    S.prototype.reload = function() {
        var a = this;
        return this.u(Yq(this).then(function() {
            return cr(a).then(function() {
                return Vq(a)
            }).then(Xq)
        }))
    };
    var cr = function(a) {
        return a.getIdToken().then(function(b) {
            var c = a.isAnonymous;
            return R(a.o, On, {
                idToken: b
            }).then(v(a.Il, a)).then(function() {
                c || br(a, "isAnonymous", !1);
                return b
            })
        })
    };
    S.prototype.getIdTokenResult = function(a) {
        return this.getIdToken(a).then(function(b) {
            return new Tl(b)
        })
    };
    S.prototype.getIdToken = function(a) {
        var b = this;
        return this.u(Yq(this).then(function() {
            return b.Rb.getToken(a)
        }).then(function(c) {
            if (!c) throw new Q("internal-error");
            c.accessToken != b.Ni && (Jq(b, c.accessToken), b.vc());
            br(b, "refreshToken", c.refreshToken);
            return c.accessToken
        }))
    };
    var Cq = function(a, b) {
        b.idToken && a.Ni != b.idToken && (Fq(a.Rb, b), a.vc(), Jq(a, b.idToken), br(a, "refreshToken", a.Rb.Va))
    };
    S.prototype.vc = function() {
        this.dispatchEvent(new yq("tokenChanged"))
    };
    S.prototype.Il = function(a) {
        a = a.users;
        if (!a || !a.length) throw new Q("internal-error");
        a = a[0];
        Kq(this, {
            uid: a.localId,
            displayName: a.displayName,
            photoURL: a.photoUrl,
            email: a.email,
            emailVerified: !!a.emailVerified,
            phoneNumber: a.phoneNumber,
            lastLoginAt: a.lastLoginAt,
            createdAt: a.createdAt,
            tenantId: a.tenantId
        });
        for (var b = dr(a), c = 0; c < b.length; c++) ar(this, b[c]);
        br(this, "isAnonymous", !(this.email && a.passwordHash) && !(this.providerData && this.providerData.length));
        this.dispatchEvent(new yq("userReloaded", {
            vm: a
        }))
    };
    var dr = function(a) {
        return (a = a.providerUserInfo) && a.length ? Tb(a, function(b) {
            return new Iq(b.rawId, b.providerId, b.email, b.displayName, b.photoUrl, b.phoneNumber)
        }) : []
    };
    S.prototype.reauthenticateAndRetrieveDataWithCredential = function(a) {
        rl("firebase.User.prototype.reauthenticateAndRetrieveDataWithCredential is deprecated. Please use firebase.User.prototype.reauthenticateWithCredential instead.");
        return this.reauthenticateWithCredential(a)
    };
    S.prototype.reauthenticateWithCredential = function(a) {
        var b = this,
            c = null;
        return this.u(a.oe(this.o, this.uid).then(function(d) {
            Cq(b, d);
            c = er(b, d, "reauthenticate");
            b.Sb = null;
            return b.reload()
        }).then(function() {
            return c
        }), !0)
    };
    var fr = function(a, b) {
        return cr(a).then(function() {
            if (Vb(Zq(a), b)) return Vq(a).then(function() {
                throw new Q("provider-already-linked");
            })
        })
    };
    S.prototype.linkAndRetrieveDataWithCredential = function(a) {
        rl("firebase.User.prototype.linkAndRetrieveDataWithCredential is deprecated. Please use firebase.User.prototype.linkWithCredential instead.");
        return this.linkWithCredential(a)
    };
    S.prototype.linkWithCredential = function(a) {
        var b = this,
            c = null;
        return this.u(fr(this, a.providerId).then(function() {
            return b.getIdToken()
        }).then(function(d) {
            return a.yd(b.o, d)
        }).then(function(d) {
            c = er(b, d, "link");
            return gr(b, d)
        }).then(function() {
            return c
        }))
    };
    S.prototype.linkWithPhoneNumber = function(a, b) {
        var c = this;
        return this.u(fr(this, "phone").then(function() {
            return kp(Rq(c), a, b, v(c.linkWithCredential, c))
        }))
    };
    S.prototype.reauthenticateWithPhoneNumber = function(a, b) {
        var c = this;
        return this.u(H().then(function() {
            return kp(Rq(c), a, b, v(c.reauthenticateWithCredential, c))
        }), !0)
    };
    var er = function(a, b, c) {
            var d = Hm(b);
            b = up(b);
            return vl({
                user: a,
                credential: d,
                additionalUserInfo: b,
                operationType: c
            })
        },
        gr = function(a, b) {
            Cq(a, b);
            return a.reload().then(function() {
                return a
            })
        };
    k = S.prototype;
    k.updateEmail = function(a) {
        var b = this;
        return this.u(this.getIdToken().then(function(c) {
            return b.o.updateEmail(c, a)
        }).then(function(c) {
            Cq(b, c);
            return b.reload()
        }))
    };
    k.updatePhoneNumber = function(a) {
        var b = this;
        return this.u(this.getIdToken().then(function(c) {
            return a.yd(b.o, c)
        }).then(function(c) {
            Cq(b, c);
            return b.reload()
        }))
    };
    k.updatePassword = function(a) {
        var b = this;
        return this.u(this.getIdToken().then(function(c) {
            return b.o.updatePassword(c, a)
        }).then(function(c) {
            Cq(b, c);
            return b.reload()
        }))
    };
    k.updateProfile = function(a) {
        if (a.displayName === void 0 && a.photoURL === void 0) return Yq(this);
        var b = this;
        return this.u(this.getIdToken().then(function(c) {
            return b.o.updateProfile(c, {
                displayName: a.displayName,
                photoUrl: a.photoURL
            })
        }).then(function(c) {
            Cq(b, c);
            br(b, "displayName", c.displayName || null);
            br(b, "photoURL", c.photoUrl || null);
            A(b.providerData, function(d) {
                d.providerId === "password" && (P(d, "displayName", b.displayName), P(d, "photoURL", b.photoURL))
            });
            return Vq(b)
        }).then(Xq))
    };
    k.unlink = function(a) {
        var b = this;
        return this.u(cr(this).then(function(c) {
            return Vb(Zq(b), a) ? yn(b.o, c, [a]).then(function(d) {
                var e = {};
                A(d.providerUserInfo || [], function(f) {
                    e[f.providerId] = !0
                });
                A(Zq(b), function(f) {
                    e[f] || $q(b, f)
                });
                e[Cm.PROVIDER_ID] || P(b, "phoneNumber", null);
                return Vq(b)
            }) : Vq(b).then(function() {
                throw new Q("no-such-provider");
            })
        }))
    };
    k.delete = function() {
        var a = this;
        return this.u(this.getIdToken().then(function(b) {
            return R(a.o, Ln, {
                idToken: b
            })
        }).then(function() {
            a.dispatchEvent(new yq("userDeleted"))
        })).then(function() {
            a.destroy()
        })
    };
    k.Uh = function(a, b) {
        return a == "linkViaPopup" && (this.Ob || null) == b && this.Nb || a == "reauthViaPopup" && (this.Ob || null) == b && this.Nb || a == "linkViaRedirect" && (this.zc || null) == b || a == "reauthViaRedirect" && (this.zc || null) == b ? !0 : !1
    };
    k.Vc = function(a, b, c, d) {
        a != "linkViaPopup" && a != "reauthViaPopup" || d != (this.Ob || null) || (c && this.Tc ? this.Tc(c) : b && !c && this.Nb && this.Nb(b), this.Na && (this.Na.cancel(), this.Na = null), delete this.Nb, delete this.Tc)
    };
    k.de = function(a, b) {
        return a == "linkViaPopup" && b == (this.Ob || null) ? v(this.ki, this) : a == "reauthViaPopup" && b == (this.Ob || null) ? v(this.li, this) : a == "linkViaRedirect" && (this.zc || null) == b ? v(this.ki, this) : a == "reauthViaRedirect" && (this.zc || null) == b ? v(this.li, this) : null
    };
    k.af = function() {
        return Zk(this.uid + ":::")
    };
    k.linkWithPopup = function(a) {
        var b = this;
        return hr(this, "linkViaPopup", a, function() {
            return fr(b, a.providerId).then(function() {
                return Vq(b)
            })
        }, !1)
    };
    k.reauthenticateWithPopup = function(a) {
        return hr(this, "reauthViaPopup", a, function() {
            return H()
        }, !0)
    };
    var hr = function(a, b, c, d, e) {
        if (!bl()) return I(new Q("operation-not-supported-in-this-environment"));
        if (a.Sb && !e) return I(a.Sb);
        var f = Bl(c.providerId),
            g = a.af(),
            h = null;
        (!cl() || Sk()) && a.Ca && c.isOAuthProvider && (h = ho(a.Ca, a.ka, a.ma, b, c, null, g, firebase.SDK_VERSION || null, null, null, a.tenantId, a.N));
        var l = Jk(h, f && f.Dd, f && f.Cd);
        d = d().then(function() {
            ir(a);
            if (!e) return a.getIdToken().then(function() {})
        }).then(function() {
            return a.ha.ve(l, b, c, g, !!h, a.tenantId)
        }).then(function() {
            return new G(function(m, p) {
                a.Vc(b,
                    null, new Q("cancelled-popup-request"), a.Ob || null);
                a.Nb = m;
                a.Tc = p;
                a.Ob = g;
                a.Na = a.ha.Ee(a, b, l, g)
            })
        }).then(function(m) {
            l && Ik(l);
            return m ? vl(m) : null
        }).l(function(m) {
            l && Ik(l);
            throw m;
        });
        return a.u(d, e)
    };
    S.prototype.linkWithRedirect = function(a) {
        var b = this;
        return jr(this, "linkViaRedirect", a, function() {
            return fr(b, a.providerId)
        }, !1)
    };
    S.prototype.reauthenticateWithRedirect = function(a) {
        return jr(this, "reauthViaRedirect", a, function() {
            return H()
        }, !0)
    };
    var jr = function(a, b, c, d, e) {
            if (!bl()) return I(new Q("operation-not-supported-in-this-environment"));
            if (a.Sb && !e) return I(a.Sb);
            var f = null,
                g = a.af();
            d = d().then(function() {
                ir(a);
                if (!e) return a.getIdToken().then(function() {})
            }).then(function() {
                a.zc = g;
                return Vq(a)
            }).then(function(h) {
                a.Ac && (h = a.Ac, h = h.O.set(kr, a.U(), h.W));
                return h
            }).then(function() {
                return a.ha.we(b, c, g, a.tenantId)
            }).l(function(h) {
                f = h;
                if (a.Ac) return lr(a.Ac);
                throw f;
            }).then(function() {
                if (f) throw f;
            });
            return a.u(d, e)
        },
        ir = function(a) {
            if (!a.ha ||
                !a.ue) {
                if (a.ha && !a.ue) throw new Q("internal-error");
                throw new Q("auth-domain-config-required");
            }
        };
    k = S.prototype;
    k.ki = function(a, b, c, d) {
        var e = this;
        this.Na && (this.Na.cancel(), this.Na = null);
        var f = null;
        c = this.getIdToken().then(function(g) {
            return Zl(e.o, {
                requestUri: a,
                postBody: d,
                sessionId: b,
                idToken: g
            })
        }).then(function(g) {
            f = er(e, g, "link");
            return gr(e, g)
        }).then(function() {
            return f
        });
        return this.u(c)
    };
    k.li = function(a, b, c, d) {
        var e = this;
        this.Na && (this.Na.cancel(), this.Na = null);
        var f = null,
            g = H().then(function() {
                return Wl($l(e.o, {
                    requestUri: a,
                    sessionId: b,
                    postBody: d,
                    tenantId: c
                }), e.uid)
            }).then(function(h) {
                f = er(e, h, "reauthenticate");
                Cq(e, h);
                e.Sb = null;
                return e.reload()
            }).then(function() {
                return f
            });
        return this.u(g, !0)
    };
    k.sendEmailVerification = function(a) {
        var b = this,
            c = null;
        return this.u(this.getIdToken().then(function(d) {
            c = d;
            return typeof a === "undefined" || cc(a) ? {} : ip(new hp(a))
        }).then(function(d) {
            return b.o.sendEmailVerification(c, d)
        }).then(function(d) {
            if (b.email != d) return b.reload()
        }).then(function() {}))
    };
    k.verifyBeforeUpdateEmail = function(a, b) {
        var c = this,
            d = null;
        return this.u(this.getIdToken().then(function(e) {
            d = e;
            return typeof b === "undefined" || cc(b) ? {} : ip(new hp(b))
        }).then(function(e) {
            return c.o.verifyBeforeUpdateEmail(d, a, e)
        }).then(function(e) {
            if (c.email != e) return c.reload()
        }).then(function() {}))
    };
    k.destroy = function() {
        for (var a = 0; a < this.Ma.length; a++) this.Ma[a].cancel("app-deleted");
        Oq(this, null);
        Pq(this, null);
        Qq(this, null);
        this.Ma = [];
        this.nd = !0;
        Tq(this);
        P(this, "refreshToken", null);
        this.ha && this.ha.unsubscribe(this)
    };
    k.u = function(a, b) {
        var c = this,
            d = mr(this, a, b);
        this.Ma.push(d);
        d.Dc(function() {
            Wb(c.Ma, d)
        });
        return d.l(function(e) {
            var f = null;
            e && e.code === "auth/multi-factor-auth-required" && (f = sq(e.U(), Rq(c), v(c.Ig, c)));
            throw f || e;
        })
    };
    k.Ig = function(a) {
        var b = null,
            c = this;
        a = Wl(H(a), c.uid).then(function(d) {
            b = er(c, d, "reauthenticate");
            Cq(c, d);
            c.Sb = null;
            return c.reload()
        }).then(function() {
            return b
        });
        return this.u(a, !0)
    };
    var mr = function(a, b, c) {
        return a.Sb && !c ? (b.cancel(), I(a.Sb)) : b.l(function(d) {
            !d || d.code != "auth/user-disabled" && d.code != "auth/user-token-expired" || (a.Sb || a.dispatchEvent(new yq("userInvalidated")), a.Sb = d);
            throw d;
        })
    };
    S.prototype.toJSON = function() {
        return this.U()
    };
    S.prototype.U = function() {
        var a = {
            uid: this.uid,
            displayName: this.displayName,
            photoURL: this.photoURL,
            email: this.email,
            emailVerified: this.emailVerified,
            phoneNumber: this.phoneNumber,
            isAnonymous: this.isAnonymous,
            tenantId: this.tenantId,
            providerData: [],
            apiKey: this.ka,
            appName: this.ma,
            authDomain: this.Ca,
            stsTokenManager: this.Rb.U(),
            redirectEventId: this.zc || null
        };
        this.metadata && fc(a, this.metadata.U());
        A(this.providerData, function(b) {
            var c = a.providerData,
                d = c.push,
                e = {},
                f;
            for (f in b) b.hasOwnProperty(f) && (e[f] = b[f]);
            d.call(c, e)
        });
        fc(a, this.xf.U());
        return a
    };
    var nr = function(a) {
            if (!a.apiKey) return null;
            var b = {
                    apiKey: a.apiKey,
                    authDomain: a.authDomain,
                    appName: a.appName,
                    emulatorConfig: a.emulatorConfig
                },
                c = {};
            if (a.stsTokenManager && a.stsTokenManager.accessToken) {
                c.idToken = a.stsTokenManager.accessToken;
                c.refreshToken = a.stsTokenManager.refreshToken || null;
                var d = a.stsTokenManager.expirationTime;
                d && (c.expiresIn = (d - Date.now()) / 1E3)
            } else return null;
            var e = new S(b, c, a);
            a.providerData && A(a.providerData, function(f) {
                f && ar(e, vl(f))
            });
            a.redirectEventId && (e.zc = a.redirectEventId);
            return e
        },
        or = function(a, b, c, d) {
            var e = new S(a, b);
            c && (e.Ac = c);
            d && Nq(e, d);
            return e.reload().then(function() {
                return e
            })
        },
        pr = function(a, b, c, d) {
            b = b || {
                apiKey: a.ka,
                authDomain: a.Ca,
                appName: a.ma
            };
            var e = a.Rb,
                f = {};
            f.idToken = e.Ya && e.Ya.toString();
            f.refreshToken = e.Va;
            b = new S(b, f);
            c && (b.Ac = c);
            d && Nq(b, d);
            b.copy(a);
            return b
        };
    P(S.prototype, "providerId", "firebase");
    var qr = function(a) {
            this.W = a;
            this.O = zp()
        },
        lr = function(a) {
            return a.O.remove(kr, a.W)
        },
        rr = function(a, b) {
            return a.O.get(kr, a.W).then(function(c) {
                c && b && (c.authDomain = b);
                return nr(c || {})
            })
        },
        kr = {
            name: "redirectUser",
            ya: "session"
        };
    var tr = function(a) {
        this.W = a;
        this.O = zp();
        this.Za = null;
        this.Yg = this.Og();
        this.O.addListener(sr("local"), this.W, v(this.nm, this))
    };
    tr.prototype.nm = function() {
        var a = this,
            b = sr("local");
        ur(this, function() {
            return H().then(function() {
                return a.Za && a.Za.ya != "local" ? a.O.get(b, a.W) : null
            }).then(function(c) {
                if (c) return vr(a, "local").then(function() {
                    a.Za = b
                })
            })
        })
    };
    var vr = function(a, b) {
        var c = [],
            d;
        for (d in vp) vp[d] !== b && c.push(a.O.remove(sr(vp[d]), a.W));
        c.push(a.O.remove(wr, a.W));
        return rg(c)
    };
    tr.prototype.Og = function() {
        var a = this,
            b = sr("local"),
            c = sr("session"),
            d = sr("none");
        return Bp(this.O, b, this.W).then(function() {
            return a.O.get(c, a.W)
        }).then(function(e) {
            return e ? c : a.O.get(d, a.W).then(function(f) {
                return f ? d : a.O.get(b, a.W).then(function(g) {
                    return g ? b : a.O.get(wr, a.W).then(function(h) {
                        return h ? sr(h) : b
                    })
                })
            })
        }).then(function(e) {
            a.Za = e;
            return vr(a, e.ya)
        }).l(function() {
            a.Za || (a.Za = b)
        })
    };
    var sr = function(a) {
        return {
            name: "authUser",
            ya: a
        }
    };
    tr.prototype.setPersistence = function(a) {
        var b = null,
            c = this;
        wp(a);
        return ur(this, function() {
            return a != c.Za.ya ? c.O.get(c.Za, c.W).then(function(d) {
                b = d;
                return vr(c, a)
            }).then(function() {
                c.Za = sr(a);
                if (b) return c.O.set(c.Za, b, c.W)
            }) : H()
        })
    };
    var xr = function(a) {
            return ur(a, function() {
                return a.O.set(wr, a.Za.ya, a.W)
            })
        },
        yr = function(a, b) {
            return ur(a, function() {
                return a.O.set(a.Za, b.U(), a.W)
            })
        },
        zr = function(a) {
            return ur(a, function() {
                return a.O.remove(a.Za, a.W)
            })
        },
        Ar = function(a, b, c) {
            return ur(a, function() {
                return a.O.get(a.Za, a.W).then(function(d) {
                    d && b && (d.authDomain = b);
                    d && c && (d.emulatorConfig = c);
                    return nr(d || {})
                })
            })
        },
        ur = function(a, b) {
            a.Yg = a.Yg.then(b, b);
            return a.Yg
        },
        wr = {
            name: "persistence",
            ya: "session"
        };
    var T = function(a) {
        dj.call(this);
        this.Cb = !1;
        this.Gj = new gp;
        P(this, "settings", this.Gj);
        P(this, "app", a);
        if (this.V().options && this.V().options.apiKey) a = firebase.SDK_VERSION ? Yk("JsCore", firebase.SDK_VERSION) : null, this.o = new Rm(this.V().options && this.V().options.apiKey, yk(zk), a);
        else throw new Q("invalid-api-key");
        this.Ma = [];
        this.Gc = [];
        this.Rd = [];
        this.Cl = firebase.INTERNAL.createSubscribe(v(this.jl, this));
        this.Le = void 0;
        this.Fl = firebase.INTERNAL.createSubscribe(v(this.kl, this));
        Br(this, null);
        a = this.V().options.apiKey;
        var b = this.V().name;
        this.Tb = new tr(a + ":" + b);
        a = this.V().options.apiKey;
        b = this.V().name;
        this.Uc = new qr(a + ":" + b);
        this.Oe = this.u(Cr(this));
        this.Pb = this.u(Dr(this));
        this.tf = !1;
        this.Gg = v(this.om, this);
        this.Tj = v(this.tc, this);
        this.Sd = v(this.Jg, this);
        this.Rj = v(this.Wk, this);
        this.Sj = v(this.Xk, this);
        this.ha = null;
        Er(this);
        this.INTERNAL = {};
        this.INTERNAL["delete"] = v(this.delete, this);
        this.INTERNAL.logFramework = v(this.vl, this);
        this.Kc = 0;
        Fr(this);
        this.Qa = [];
        this.N = null
    };
    q(T, dj);
    T.prototype.setPersistence = function(a) {
        a = this.Tb.setPersistence(a);
        return this.u(a)
    };
    T.prototype.Ld = function(a) {
        this.Kb === a || this.Cb || (this.Kb = a, Tm(this.o, this.Kb), this.dispatchEvent(new Gr(this.Kb)))
    };
    T.prototype.useDeviceLanguage = function() {
        var a = r.navigator;
        this.Ld(a ? a.languages && a.languages[0] || a.language || a.userLanguage || null : null)
    };
    T.prototype.useEmulator = function(a, b) {
        if (!this.N) {
            if (this.ha) throw new Q("argument-error", "useEmulator() must be called immediately following firebase.auth() initialization.");
            b = b ? !!b.disableWarnings : !1;
            Hr(b);
            this.N = {
                url: a,
                disableWarnings: b
            };
            this.Gj.eg = !0;
            Vm(this.o, this.N);
            this.dispatchEvent(new Ir(this.N))
        }
    };
    var Hr = function(a) {
        typeof console !== "undefined" && typeof console.info === "function" && console.info("WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials.");
        r.document && !a && Ok().then(function() {
            var b = r.document.createElement("p");
            b.innerText = "Running in emulator mode. Do not use with production credentials.";
            b.style.position = "fixed";
            b.style.width = "100%";
            b.style.backgroundColor = "#ffffff";
            b.style.border = ".1em solid #000000";
            b.style.color =
                "#b50000";
            b.style.bottom = "0px";
            b.style.left = "0px";
            b.style.margin = "0px";
            b.style.zIndex = 1E4;
            b.style.textAlign = "center";
            b.classList.add("firebase-emulator-warning");
            r.document.body.appendChild(b)
        })
    };
    T.prototype.vl = function(a) {
        this.Qa.push(a);
        Wm(this.o, firebase.SDK_VERSION ? Yk("JsCore", firebase.SDK_VERSION, this.Qa) : null);
        this.dispatchEvent(new Jr(this.Qa))
    };
    T.prototype.Ch = function(a) {
        this.na === a || this.Cb || (this.na = a, this.o.na = this.na)
    };
    var Fr = function(a) {
        Object.defineProperty(a, "lc", {
            get: function() {
                return this.Kb
            },
            set: function(b) {
                this.Ld(b)
            },
            enumerable: !1
        });
        a.Kb = null;
        Object.defineProperty(a, "ti", {
            get: function() {
                return this.na
            },
            set: function(b) {
                this.Ch(b)
            },
            enumerable: !1
        });
        a.na = null;
        Object.defineProperty(a, "emulatorConfig", {
            get: function() {
                if (this.N) {
                    var b = N(this.N.url);
                    b = vl({
                        protocol: b.Xa,
                        host: b.Ia,
                        port: b.Wb,
                        options: vl({
                            disableWarnings: this.N.disableWarnings
                        })
                    })
                } else b = null;
                return b
            },
            enumerable: !1
        })
    };
    T.prototype.toJSON = function() {
        return {
            apiKey: this.V().options.apiKey,
            authDomain: this.V().options.authDomain,
            appName: this.V().name,
            currentUser: U(this) && U(this).U()
        }
    };
    var Kr = function(a) {
            return a.Ak || I(new Q("auth-domain-config-required"))
        },
        Er = function(a) {
            var b = a.V().options.authDomain,
                c = a.V().options.apiKey;
            b && bl() && (a.Ak = a.Oe.then(function() {
                if (!a.Cb) {
                    a.ha = kq(b, c, a.V().name, a.N);
                    a.ha.subscribe(a);
                    U(a) && Wq(U(a));
                    if (a.Bc) {
                        Wq(a.Bc);
                        var d = a.Bc;
                        d.Ld(a.Kb);
                        Oq(d, a);
                        d = a.Bc;
                        Nq(d, a.Qa);
                        Qq(d, a);
                        d = a.Bc;
                        Mq(d, a.N);
                        Pq(d, a);
                        a.Bc = null
                    }
                    return a.ha
                }
            }))
        };
    k = T.prototype;
    k.Uh = function(a, b) {
        switch (a) {
            case "unknown":
            case "signInViaRedirect":
                return !0;
            case "signInViaPopup":
                return this.Ob == b && !!this.Nb;
            default:
                return !1
        }
    };
    k.Vc = function(a, b, c, d) {
        a == "signInViaPopup" && this.Ob == d && (c && this.Tc ? this.Tc(c) : b && !c && this.Nb && this.Nb(b), this.Na && (this.Na.cancel(), this.Na = null), delete this.Nb, delete this.Tc)
    };
    k.de = function(a, b) {
        return a == "signInViaRedirect" || a == "signInViaPopup" && this.Ob == b && this.Nb ? v(this.Ek, this) : null
    };
    k.Ek = function(a, b, c, d) {
        var e = this,
            f = {
                requestUri: a,
                postBody: d,
                sessionId: b,
                tenantId: c
            };
        this.Na && (this.Na.cancel(), this.Na = null);
        return e.Oe.then(function() {
            return Lr(e, Yl(e.o, f))
        })
    };
    k.af = function() {
        return Zk()
    };
    k.signInWithPopup = function(a) {
        if (!bl()) return I(new Q("operation-not-supported-in-this-environment"));
        var b = this,
            c = Bl(a.providerId),
            d = this.af(),
            e = null;
        (!cl() || Sk()) && this.V().options.authDomain && a.isOAuthProvider && (e = ho(this.V().options.authDomain, this.V().options.apiKey, this.V().name, "signInViaPopup", a, null, d, firebase.SDK_VERSION || null, null, null, this.na, this.N));
        var f = Jk(e, c && c.Dd, c && c.Cd);
        c = Kr(this).then(function(g) {
            return g.ve(f, "signInViaPopup", a, d, !!e, b.na)
        }).then(function() {
            return new G(function(g,
                h) {
                b.Vc("signInViaPopup", null, new Q("cancelled-popup-request"), b.Ob);
                b.Nb = g;
                b.Tc = h;
                b.Ob = d;
                b.Na = b.ha.Ee(b, "signInViaPopup", f, d)
            })
        }).then(function(g) {
            f && Ik(f);
            return g ? vl(g) : null
        }).l(function(g) {
            f && Ik(f);
            throw g;
        });
        return this.u(c)
    };
    k.signInWithRedirect = function(a) {
        if (!bl()) return I(new Q("operation-not-supported-in-this-environment"));
        var b = this,
            c = Kr(this).then(function() {
                return xr(b.Tb)
            }).then(function() {
                return b.ha.we("signInViaRedirect", a, void 0, b.na)
            });
        return this.u(c)
    };
    var Mr = function(a) {
        if (!bl()) return I(new Q("operation-not-supported-in-this-environment"));
        var b = Kr(a).then(function() {
            return a.ha.getRedirectResult()
        }).then(function(c) {
            return c ? vl(c) : null
        });
        return a.u(b)
    };
    T.prototype.getRedirectResult = function() {
        var a = this;
        return Mr(this).then(function(b) {
            a.ha && a.ha.ld();
            return b
        }).l(function(b) {
            a.ha && a.ha.ld();
            throw b;
        })
    };
    T.prototype.updateCurrentUser = function(a) {
        if (!a) return I(new Q("null-user"));
        if (this.na != a.tenantId) return I(new Q("tenant-id-mismatch"));
        var b = this,
            c = {};
        c.apiKey = this.V().options.apiKey;
        c.authDomain = this.V().options.authDomain;
        c.appName = this.V().name;
        var d = pr(a, c, b.Uc, bo(b));
        return this.u(this.Pb.then(function() {
            if (b.V().options.apiKey != a.ka) return d.reload()
        }).then(function() {
            if (U(b) && a.uid == U(b).uid) return U(b).copy(a), b.tc(a);
            Br(b, d);
            Wq(d);
            return b.tc(d)
        }).then(function() {
            b.vc()
        }))
    };
    var Nr = function(a, b) {
            var c = {};
            c.apiKey = a.V().options.apiKey;
            c.authDomain = a.V().options.authDomain;
            c.appName = a.V().name;
            a.N && (c.emulatorConfig = a.N);
            return a.Oe.then(function() {
                return or(c, b, a.Uc, bo(a))
            }).then(function(d) {
                if (U(a) && d.uid == U(a).uid) return U(a).copy(d), a.tc(d);
                Br(a, d);
                Wq(d);
                return a.tc(d)
            }).then(function() {
                a.vc()
            })
        },
        Br = function(a, b) {
            U(a) && (Uq(U(a), a.Tj), aj(U(a), "tokenChanged", a.Sd), aj(U(a), "userDeleted", a.Rj), aj(U(a), "userInvalidated", a.Sj), Tq(U(a)));
            b && (b.Qf.push(a.Tj), Ti(b, "tokenChanged",
                a.Sd), Ti(b, "userDeleted", a.Rj), Ti(b, "userInvalidated", a.Sj), a.Kc > 0 && Sq(b));
            P(a, "currentUser", b);
            b && (b.Ld(a.Kb), Oq(b, a), Nq(b, a.Qa), Qq(b, a), Mq(b, a.N), Pq(b, a))
        };
    T.prototype.signOut = function() {
        var a = this,
            b = this.Pb.then(function() {
                a.ha && a.ha.ld();
                if (!U(a)) return H();
                Br(a, null);
                return zr(a.Tb).then(function() {
                    a.vc()
                })
            });
        return this.u(b)
    };
    var Or = function(a) {
            var b = a.V().options.authDomain;
            b = rr(a.Uc, b).then(function(c) {
                if (a.Bc = c) c.Ac = a.Uc;
                return lr(a.Uc)
            });
            return a.u(b)
        },
        Cr = function(a) {
            var b = a.V().options.authDomain,
                c = Or(a).then(function() {
                    return Ar(a.Tb, b, a.N)
                }).then(function(d) {
                    return d ? (d.Ac = a.Uc, a.Bc && (a.Bc.zc || null) == (d.zc || null) ? d : d.reload().then(function() {
                        return yr(a.Tb, d).then(function() {
                            return d
                        })
                    }).l(function(e) {
                        return e.code == "auth/network-request-failed" ? d : zr(a.Tb)
                    })) : null
                }).then(function(d) {
                    Br(a, d || null)
                });
            return a.u(c)
        },
        Dr = function(a) {
            return a.Oe.then(function() {
                return Mr(a)
            }).l(function() {}).then(function() {
                if (!a.Cb) return a.Gg()
            }).l(function() {}).then(function() {
                if (!a.Cb) {
                    a.tf = !0;
                    var b = a.Tb;
                    b.O.addListener(sr("local"), b.W, a.Gg)
                }
            })
        };
    k = T.prototype;
    k.om = function() {
        var a = this,
            b = this.V().options.authDomain;
        return Ar(this.Tb, b).then(function(c) {
            if (!a.Cb) {
                var d;
                if (d = U(a) && c) {
                    d = U(a).uid;
                    var e = c.uid;
                    d = d === void 0 || d === null || d === "" || e === void 0 || e === null || e === "" ? !1 : d == e
                }
                if (d) return U(a).copy(c), U(a).getIdToken();
                if (U(a) || c) Br(a, c), c && (Wq(c), c.Ac = a.Uc), a.ha && a.ha.subscribe(a), a.vc()
            }
        })
    };
    k.tc = function(a) {
        return yr(this.Tb, a)
    };
    k.Jg = function() {
        this.vc();
        this.tc(U(this))
    };
    k.Wk = function() {
        this.signOut()
    };
    k.Xk = function() {
        this.signOut()
    };
    var Lr = function(a, b) {
        var c = null,
            d = null;
        return a.u(b.then(function(e) {
            c = Hm(e);
            d = up(e);
            return Nr(a, e)
        }, function(e) {
            var f = null;
            e && e.code === "auth/multi-factor-auth-required" && (f = sq(e.U(), a, v(a.Ig, a)));
            throw f || e;
        }).then(function() {
            return vl({
                user: U(a),
                credential: c,
                additionalUserInfo: d,
                operationType: "signIn"
            })
        }))
    };
    k = T.prototype;
    k.Ig = function(a) {
        var b = this;
        return this.Pb.then(function() {
            return Lr(b, H(a))
        })
    };
    k.jl = function(a) {
        var b = this;
        this.addAuthTokenListener(function() {
            a.next(U(b))
        })
    };
    k.kl = function(a) {
        var b = this;
        Pr(this, function() {
            a.next(U(b))
        })
    };
    k.onIdTokenChanged = function(a, b, c) {
        var d = this;
        this.tf && firebase.Promise.resolve().then(function() {
            typeof a === "function" ? a(U(d)) : typeof a.next === "function" && a.next(U(d))
        });
        return this.Cl(a, b, c)
    };
    k.onAuthStateChanged = function(a, b, c) {
        var d = this;
        this.tf && firebase.Promise.resolve().then(function() {
            d.Le = d.getUid();
            typeof a === "function" ? a(U(d)) : typeof a.next === "function" && a.next(U(d))
        });
        return this.Fl(a, b, c)
    };
    k.Jk = function(a) {
        var b = this,
            c = this.Pb.then(function() {
                return U(b) ? U(b).getIdToken(a).then(function(d) {
                    return {
                        accessToken: d
                    }
                }) : null
            });
        return this.u(c)
    };
    k.signInWithCustomToken = function(a) {
        var b = this;
        return this.Pb.then(function() {
            return Lr(b, R(b.o, Qn, {
                token: a
            }))
        }).then(function(c) {
            var d = c.user;
            br(d, "isAnonymous", !1);
            b.tc(d);
            return c
        })
    };
    k.signInWithEmailAndPassword = function(a, b) {
        var c = this;
        return this.Pb.then(function() {
            return Lr(c, R(c.o, rm, {
                email: a,
                password: b
            }))
        })
    };
    k.createUserWithEmailAndPassword = function(a, b) {
        var c = this;
        return this.Pb.then(function() {
            return Lr(c, R(c.o, Kn, {
                email: a,
                password: b
            }))
        })
    };
    k.signInWithCredential = function(a) {
        var b = this;
        return this.Pb.then(function() {
            return Lr(b, a.Mc(b.o))
        })
    };
    k.signInAndRetrieveDataWithCredential = function(a) {
        rl("firebase.auth.Auth.prototype.signInAndRetrieveDataWithCredential is deprecated. Please use firebase.auth.Auth.prototype.signInWithCredential instead.");
        return this.signInWithCredential(a)
    };
    k.signInAnonymously = function() {
        var a = this;
        return this.Pb.then(function() {
            var b = U(a);
            if (b && b.isAnonymous) {
                var c = vl({
                    providerId: null,
                    isNewUser: !1
                });
                return vl({
                    user: b,
                    credential: null,
                    additionalUserInfo: c,
                    operationType: "signIn"
                })
            }
            return Lr(a, a.o.signInAnonymously()).then(function(d) {
                var e = d.user;
                br(e, "isAnonymous", !0);
                a.tc(e);
                return d
            })
        })
    };
    k.V = function() {
        return this.app
    };
    var U = function(a) {
        return a.currentUser
    };
    T.prototype.getUid = function() {
        return U(this) && U(this).uid || null
    };
    var Qr = function(a) {
        return U(a) && U(a)._lat || null
    };
    k = T.prototype;
    k.vc = function() {
        if (this.tf) {
            for (var a = 0; a < this.Gc.length; a++)
                if (this.Gc[a]) this.Gc[a](Qr(this));
            if (this.Le !== this.getUid() && this.Rd.length)
                for (this.Le = this.getUid(), a = 0; a < this.Rd.length; a++)
                    if (this.Rd[a]) this.Rd[a](Qr(this))
        }
    };
    k.ek = function(a) {
        this.addAuthTokenListener(a);
        this.Kc++;
        this.Kc > 0 && U(this) && Sq(U(this))
    };
    k.Nl = function(a) {
        var b = this;
        A(this.Gc, function(c) {
            c == a && b.Kc--
        });
        this.Kc < 0 && (this.Kc = 0);
        this.Kc == 0 && U(this) && Tq(U(this));
        this.removeAuthTokenListener(a)
    };
    k.addAuthTokenListener = function(a) {
        var b = this;
        this.Gc.push(a);
        this.u(this.Pb.then(function() {
            b.Cb || Vb(b.Gc, a) && a(Qr(b))
        }))
    };
    k.removeAuthTokenListener = function(a) {
        Yb(this.Gc, function(b) {
            return b == a
        })
    };
    var Pr = function(a, b) {
        a.Rd.push(b);
        a.u(a.Pb.then(function() {
            !a.Cb && Vb(a.Rd, b) && a.Le !== a.getUid() && (a.Le = a.getUid(), b(Qr(a)))
        }))
    };
    k = T.prototype;
    k.delete = function() {
        this.Cb = !0;
        for (var a = 0; a < this.Ma.length; a++) this.Ma[a].cancel("app-deleted");
        this.Ma = [];
        this.Tb && (a = this.Tb, a.O.removeListener(sr("local"), a.W, this.Gg));
        this.ha && (this.ha.unsubscribe(this), this.ha.ld());
        return firebase.Promise.resolve()
    };
    k.u = function(a) {
        var b = this;
        this.Ma.push(a);
        a.Dc(function() {
            Wb(b.Ma, a)
        });
        return a
    };
    k.fetchSignInMethodsForEmail = function(a) {
        return this.u(fn(this.o, a))
    };
    k.isSignInWithEmailLink = function(a) {
        return !!vm(a)
    };
    k.sendSignInLinkToEmail = function(a, b) {
        var c = this;
        return this.u(H().then(function() {
            var d = new hp(b);
            if (!d.Vh) throw new Q("argument-error", "handleCodeInApp must be true when sending sign in link to email");
            return ip(d)
        }).then(function(d) {
            return c.o.sendSignInLinkToEmail(a, d)
        }).then(function() {}))
    };
    k.verifyPasswordResetCode = function(a) {
        return this.checkActionCode(a).then(function(b) {
            return b.data.email
        })
    };
    k.confirmPasswordReset = function(a, b) {
        return this.u(this.o.confirmPasswordReset(a, b).then(function() {}))
    };
    k.checkActionCode = function(a) {
        return this.u(this.o.checkActionCode(a).then(function(b) {
            return new Kl(b)
        }))
    };
    k.applyActionCode = function(a) {
        return this.u(this.o.applyActionCode(a).then(function() {}))
    };
    k.sendPasswordResetEmail = function(a, b) {
        var c = this;
        return this.u(H().then(function() {
            return typeof b === "undefined" || cc(b) ? {} : ip(new hp(b))
        }).then(function(d) {
            return c.o.sendPasswordResetEmail(a, d)
        }).then(function() {}))
    };
    k.signInWithPhoneNumber = function(a, b) {
        return this.u(kp(this, a, b, v(this.signInWithCredential, this)))
    };
    k.signInWithEmailLink = function(a, b) {
        var c = this;
        return this.u(H().then(function() {
            b = b || Ck();
            var d = wm(a, b),
                e = vm(b);
            if (!e) throw new Q("argument-error", "Invalid email link!");
            if (e.tenantId !== c.na) throw new Q("tenant-id-mismatch");
            return c.signInWithCredential(d)
        }))
    };
    var Gr = function(a) {
        Gi.call(this, "languageCodeChanged");
        this.languageCode = a
    };
    q(Gr, Gi);
    var Ir = function(a) {
        Gi.call(this, "emulatorConfigChanged");
        this.emulatorConfig = a
    };
    q(Ir, Gi);
    var Jr = function(a) {
        Gi.call(this, "frameworkChanged");
        this.Hk = a
    };
    q(Jr, Gi);
    var Sr = function(a, b, c, d) {
            a: {
                c = Array.prototype.slice.call(c);
                var e = 0;
                for (var f = !1, g = 0; g < b.length; g++)
                    if (b[g].optional) f = !0;
                    else {
                        if (f) throw new Q("internal-error", "Argument validator encountered a required argument after an optional argument.");
                        e++
                    }
                f = b.length;
                if (c.length < e || f < c.length) d = "Expected " + (e == f ? e == 1 ? "1 argument" : e + " arguments" : e + "-" + f + " arguments") + " but got " + c.length + ".";
                else {
                    for (e = 0; e < c.length; e++)
                        if (f = b[e].optional && c[e] === void 0, !b[e].Fa(c[e]) && !f) {
                            c = e;
                            b = b[e];
                            if (c < 0 || c >= Rr.length) throw new Q("internal-error",
                                "Argument validator received an unsupported number of arguments.");
                            c = Rr[c];
                            d = (d ? "" : c + " argument ") + (b.name ? '"' + b.name + '" ' : "") + "must be " + b.Ha + ".";
                            break a
                        }
                    d = null
                }
            }
            if (d) throw new Q("argument-error", a + " failed: " + d);
        },
        Rr = "First Second Third Fourth Fifth Sixth Seventh Eighth Ninth".split(" "),
        V = function(a, b) {
            return {
                name: a || "",
                Ha: "a valid string",
                optional: !!b,
                Fa: function(c) {
                    return typeof c === "string"
                }
            }
        },
        Tr = function(a, b) {
            return {
                name: a || "",
                Ha: "a boolean",
                optional: !!b,
                Fa: function(c) {
                    return typeof c === "boolean"
                }
            }
        },
        W = function(a, b) {
            return {
                name: a || "",
                Ha: "a valid object",
                optional: !!b,
                Fa: u
            }
        },
        Ur = function(a, b) {
            return {
                name: a || "",
                Ha: "a function",
                optional: !!b,
                Fa: ig
            }
        },
        Vr = function(a, b) {
            return {
                name: a || "",
                Ha: "null",
                optional: !!b,
                Fa: function(c) {
                    return c === null
                }
            }
        },
        Wr = function() {
            return {
                name: "",
                Ha: "an HTML element",
                optional: !1,
                Fa: function(a) {
                    return !!(a && a instanceof Element)
                }
            }
        },
        Xr = function() {
            return {
                name: "auth",
                Ha: "an instance of Firebase Auth",
                optional: !0,
                Fa: function(a) {
                    return !!(a && a instanceof T)
                }
            }
        },
        Yr = function() {
            return {
                name: "app",
                Ha: "an instance of Firebase App",
                optional: !0,
                Fa: function(a) {
                    return !!(a && a instanceof firebase.app.App)
                }
            }
        },
        Zr = function(a) {
            return {
                name: a ? a + "Credential" : "credential",
                Ha: a ? "a valid " + a + " credential" : "a valid credential",
                optional: !1,
                Fa: function(b) {
                    if (!b) return !1;
                    var c = !a || b.providerId === a;
                    return !(!b.Mc || !c)
                }
            }
        },
        $r = function() {
            return {
                name: "multiFactorAssertion",
                Ha: "a valid multiFactorAssertion",
                optional: !1,
                Fa: function(a) {
                    return a ? !!a.process : !1
                }
            }
        },
        as = function() {
            return {
                name: "authProvider",
                Ha: "a valid Auth provider",
                optional: !1,
                Fa: function(a) {
                    return !!(a && a.providerId && a.hasOwnProperty && a.hasOwnProperty("isOAuthProvider"))
                }
            }
        },
        bs = function(a, b) {
            return u(a) && typeof a.type === "string" && a.type === b && typeof a.ee === "function"
        },
        cs = function(a) {
            return u(a) && typeof a.uid === "string"
        },
        ds = function() {
            return {
                name: "applicationVerifier",
                Ha: "an implementation of firebase.auth.ApplicationVerifier",
                optional: !1,
                Fa: function(a) {
                    return !(!a || typeof a.type !== "string" || typeof a.verify !== "function")
                }
            }
        },
        X = function(a, b, c, d) {
            return {
                name: c || "",
                Ha: a.Ha + " or " + b.Ha,
                optional: !!d,
                Fa: function(e) {
                    return a.Fa(e) || b.Fa(e)
                }
            }
        };
    var Y = function(a, b) {
            for (var c in b) {
                var d = b[c].name;
                a[d] = es(d, a[c], b[c].j)
            }
        },
        fs = function(a, b) {
            for (var c in b) {
                var d = b[c].name;
                d !== c && Object.defineProperty(a, d, {
                    get: Ba(function(e) {
                        return this[e]
                    }, c),
                    set: Ba(function(e, f, g, h) {
                        Sr(e, [g], [h], !0);
                        this[f] = h
                    }, d, c, b[c].fg),
                    enumerable: !0
                })
            }
        },
        Z = function(a, b, c, d) {
            a[b] = es(b, c, d)
        },
        es = function(a, b, c) {
            if (!c) return b;
            var d = gs(a);
            a = function() {
                var g = Array.prototype.slice.call(arguments);
                Sr(d, c, g);
                return b.apply(this, g)
            };
            for (var e in b) a[e] = b[e];
            for (var f in b.prototype) a.prototype[f] =
                b.prototype[f];
            return a
        },
        gs = function(a) {
            a = a.split(".");
            return a[a.length - 1]
        };

    function hs() {}
    P(hs, "FACTOR_ID", "phone");
    Y(T.prototype, {
        applyActionCode: {
            name: "applyActionCode",
            j: [V("code")]
        },
        checkActionCode: {
            name: "checkActionCode",
            j: [V("code")]
        },
        confirmPasswordReset: {
            name: "confirmPasswordReset",
            j: [V("code"), V("newPassword")]
        },
        createUserWithEmailAndPassword: {
            name: "createUserWithEmailAndPassword",
            j: [V("email"), V("password")]
        },
        fetchSignInMethodsForEmail: {
            name: "fetchSignInMethodsForEmail",
            j: [V("email")]
        },
        getRedirectResult: {
            name: "getRedirectResult",
            j: []
        },
        isSignInWithEmailLink: {
            name: "isSignInWithEmailLink",
            j: [V("emailLink")]
        },
        onAuthStateChanged: {
            name: "onAuthStateChanged",
            j: [X(W(), Ur(), "nextOrObserver"), Ur("opt_error", !0), Ur("opt_completed", !0)]
        },
        onIdTokenChanged: {
            name: "onIdTokenChanged",
            j: [X(W(), Ur(), "nextOrObserver"), Ur("opt_error", !0), Ur("opt_completed", !0)]
        },
        sendPasswordResetEmail: {
            name: "sendPasswordResetEmail",
            j: [V("email"), X(W("opt_actionCodeSettings", !0), Vr(null, !0), "opt_actionCodeSettings", !0)]
        },
        sendSignInLinkToEmail: {
            name: "sendSignInLinkToEmail",
            j: [V("email"), W("actionCodeSettings")]
        },
        setPersistence: {
            name: "setPersistence",
            j: [V("persistence")]
        },
        signInAndRetrieveDataWithCredential: {
            name: "signInAndRetrieveDataWithCredential",
            j: [Zr()]
        },
        signInAnonymously: {
            name: "signInAnonymously",
            j: []
        },
        signInWithCredential: {
            name: "signInWithCredential",
            j: [Zr()]
        },
        signInWithCustomToken: {
            name: "signInWithCustomToken",
            j: [V("token")]
        },
        signInWithEmailAndPassword: {
            name: "signInWithEmailAndPassword",
            j: [V("email"), V("password")]
        },
        signInWithEmailLink: {
            name: "signInWithEmailLink",
            j: [V("email"), V("emailLink", !0)]
        },
        signInWithPhoneNumber: {
            name: "signInWithPhoneNumber",
            j: [V("phoneNumber"), ds()]
        },
        signInWithPopup: {
            name: "signInWithPopup",
            j: [as()]
        },
        signInWithRedirect: {
            name: "signInWithRedirect",
            j: [as()]
        },
        updateCurrentUser: {
            name: "updateCurrentUser",
            j: [X(function(a) {
                return {
                    name: "user",
                    Ha: "an instance of Firebase User",
                    optional: !!a,
                    Fa: function(b) {
                        return !!(b && b instanceof S)
                    }
                }
            }(), Vr(), "user")]
        },
        signOut: {
            name: "signOut",
            j: []
        },
        toJSON: {
            name: "toJSON",
            j: [V(null, !0)]
        },
        useDeviceLanguage: {
            name: "useDeviceLanguage",
            j: []
        },
        useEmulator: {
            name: "useEmulator",
            j: [V("url"), W("options", !0)]
        },
        verifyPasswordResetCode: {
            name: "verifyPasswordResetCode",
            j: [V("code")]
        }
    });
    fs(T.prototype, {
        lc: {
            name: "languageCode",
            fg: X(V(), Vr(), "languageCode")
        },
        ti: {
            name: "tenantId",
            fg: X(V(), Vr(), "tenantId")
        }
    });
    T.Persistence = vp;
    T.Persistence.LOCAL = "local";
    T.Persistence.SESSION = "session";
    T.Persistence.NONE = "none";
    Y(S.prototype, {
        "delete": {
            name: "delete",
            j: []
        },
        getIdTokenResult: {
            name: "getIdTokenResult",
            j: [Tr("opt_forceRefresh", !0)]
        },
        getIdToken: {
            name: "getIdToken",
            j: [Tr("opt_forceRefresh", !0)]
        },
        linkAndRetrieveDataWithCredential: {
            name: "linkAndRetrieveDataWithCredential",
            j: [Zr()]
        },
        linkWithCredential: {
            name: "linkWithCredential",
            j: [Zr()]
        },
        linkWithPhoneNumber: {
            name: "linkWithPhoneNumber",
            j: [V("phoneNumber"), ds()]
        },
        linkWithPopup: {
            name: "linkWithPopup",
            j: [as()]
        },
        linkWithRedirect: {
            name: "linkWithRedirect",
            j: [as()]
        },
        reauthenticateAndRetrieveDataWithCredential: {
            name: "reauthenticateAndRetrieveDataWithCredential",
            j: [Zr()]
        },
        reauthenticateWithCredential: {
            name: "reauthenticateWithCredential",
            j: [Zr()]
        },
        reauthenticateWithPhoneNumber: {
            name: "reauthenticateWithPhoneNumber",
            j: [V("phoneNumber"), ds()]
        },
        reauthenticateWithPopup: {
            name: "reauthenticateWithPopup",
            j: [as()]
        },
        reauthenticateWithRedirect: {
            name: "reauthenticateWithRedirect",
            j: [as()]
        },
        reload: {
            name: "reload",
            j: []
        },
        sendEmailVerification: {
            name: "sendEmailVerification",
            j: [X(W("opt_actionCodeSettings", !0), Vr(null, !0), "opt_actionCodeSettings", !0)]
        },
        toJSON: {
            name: "toJSON",
            j: [V(null, !0)]
        },
        unlink: {
            name: "unlink",
            j: [V("provider")]
        },
        updateEmail: {
            name: "updateEmail",
            j: [V("email")]
        },
        updatePassword: {
            name: "updatePassword",
            j: [V("password")]
        },
        updatePhoneNumber: {
            name: "updatePhoneNumber",
            j: [Zr("phone")]
        },
        updateProfile: {
            name: "updateProfile",
            j: [W("profile")]
        },
        verifyBeforeUpdateEmail: {
            name: "verifyBeforeUpdateEmail",
            j: [V("email"), X(W("opt_actionCodeSettings", !0), Vr(null, !0), "opt_actionCodeSettings", !0)]
        }
    });
    Y(no.prototype, {
        execute: {
            name: "execute"
        },
        render: {
            name: "render"
        },
        reset: {
            name: "reset"
        },
        getResponse: {
            name: "getResponse"
        }
    });
    Y(io.prototype, {
        execute: {
            name: "execute"
        },
        render: {
            name: "render"
        },
        reset: {
            name: "reset"
        },
        getResponse: {
            name: "getResponse"
        }
    });
    Y(G.prototype, {
        Dc: {
            name: "finally"
        },
        l: {
            name: "catch"
        },
        then: {
            name: "then"
        }
    });
    fs(gp.prototype, {
        appVerificationDisabled: {
            name: "appVerificationDisabledForTesting",
            fg: Tr("appVerificationDisabledForTesting")
        }
    });
    Y(jp.prototype, {
        confirm: {
            name: "confirm",
            j: [V("verificationCode")]
        }
    });
    Z(Vl, "fromJSON", function(a) {
        a = typeof a === "string" ? JSON.parse(a) : a;
        for (var b, c = [cm, um, Bm, am], d = 0; d < c.length; d++)
            if (b = c[d](a)) return b;
        return null
    }, [X(V(), W(), "json")]);
    Z(om, "credential", function(a, b) {
        return new pm(a, b)
    }, [V("email"), V("password")]);
    Y(pm.prototype, {
        U: {
            name: "toJSON",
            j: [V(null, !0)]
        }
    });
    Y(gm.prototype, {
        addScope: {
            name: "addScope",
            j: [V("scope")]
        },
        setCustomParameters: {
            name: "setCustomParameters",
            j: [W("customOAuthParameters")]
        }
    });
    Z(gm, "credential", hm, [X(V(), W(), "token")]);
    Z(om, "credentialWithLink", wm, [V("email"), V("emailLink")]);
    Y(im.prototype, {
        addScope: {
            name: "addScope",
            j: [V("scope")]
        },
        setCustomParameters: {
            name: "setCustomParameters",
            j: [W("customOAuthParameters")]
        }
    });
    Z(im, "credential", jm, [X(V(), W(), "token")]);
    Y(km.prototype, {
        addScope: {
            name: "addScope",
            j: [V("scope")]
        },
        setCustomParameters: {
            name: "setCustomParameters",
            j: [W("customOAuthParameters")]
        }
    });
    Z(km, "credential", lm, [X(V(), X(W(), Vr()), "idToken"), X(V(), Vr(), "accessToken", !0)]);
    Y(mm.prototype, {
        setCustomParameters: {
            name: "setCustomParameters",
            j: [W("customOAuthParameters")]
        }
    });
    Z(mm, "credential", nm, [X(V(), W(), "token"), V("secret", !0)]);
    Y(fm.prototype, {
        addScope: {
            name: "addScope",
            j: [V("scope")]
        },
        credential: {
            name: "credential",
            j: [X(V(), X(W(), Vr()), "optionsOrIdToken"), X(V(), Vr(), "accessToken", !0)]
        },
        setCustomParameters: {
            name: "setCustomParameters",
            j: [W("customOAuthParameters")]
        }
    });
    Y(bm.prototype, {
        U: {
            name: "toJSON",
            j: [V(null, !0)]
        }
    });
    Y(Xl.prototype, {
        U: {
            name: "toJSON",
            j: [V(null, !0)]
        }
    });
    Z(Cm, "credential", Gm, [V("verificationId"), V("verificationCode")]);
    Y(Cm.prototype, {
        verifyPhoneNumber: {
            name: "verifyPhoneNumber",
            j: [X(V(), function(a, b) {
                    return {
                        name: a || "phoneInfoOptions",
                        Ha: "valid phone info options",
                        optional: !!b,
                        Fa: function(c) {
                            return c ? c.session && c.phoneNumber ? bs(c.session, "enroll") && typeof c.phoneNumber === "string" : c.session && c.multiFactorHint ? bs(c.session, "signin") && cs(c.multiFactorHint) : c.session && c.multiFactorUid ? bs(c.session, "signin") && typeof c.multiFactorUid === "string" : c.phoneNumber ? typeof c.phoneNumber === "string" : !1 : !1
                        }
                    }
                }(), "phoneInfoOptions"),
                ds()
            ]
        }
    });
    Y(xm.prototype, {
        U: {
            name: "toJSON",
            j: [V(null, !0)]
        }
    });
    Y(Q.prototype, {
        toJSON: {
            name: "toJSON",
            j: [V(null, !0)]
        }
    });
    Y(Jm.prototype, {
        toJSON: {
            name: "toJSON",
            j: [V(null, !0)]
        }
    });
    Y(Pl.prototype, {
        toJSON: {
            name: "toJSON",
            j: [V(null, !0)]
        }
    });
    Y(rq.prototype, {
        toJSON: {
            name: "toJSON",
            j: [V(null, !0)]
        }
    });
    Y(qq.prototype, {
        resolveSignIn: {
            name: "resolveSignIn",
            j: [$r()]
        }
    });
    Y(Aq.prototype, {
        getSession: {
            name: "getSession",
            j: []
        },
        enroll: {
            name: "enroll",
            j: [$r(), V("displayName", !0)]
        },
        unenroll: {
            name: "unenroll",
            j: [X({
                name: "multiFactorInfo",
                Ha: "a valid multiFactorInfo",
                optional: !1,
                Fa: cs
            }, V(), "multiFactorInfoIdentifier")]
        }
    });
    Y(yo.prototype, {
        clear: {
            name: "clear",
            j: []
        },
        render: {
            name: "render",
            j: []
        },
        verify: {
            name: "verify",
            j: []
        }
    });
    Z(Ml, "parseLink", Nl, [V("link")]);
    Z(hs, "assertion", function(a) {
        return new xq(a)
    }, [Zr("phone")]);
    (function() {
        if (typeof firebase !== "undefined" && firebase.INTERNAL && firebase.INTERNAL.registerService) {
            var a = {
                ActionCodeInfo: {
                    Operation: {
                        EMAIL_SIGNIN: "EMAIL_SIGNIN",
                        PASSWORD_RESET: "PASSWORD_RESET",
                        RECOVER_EMAIL: "RECOVER_EMAIL",
                        REVERT_SECOND_FACTOR_ADDITION: "REVERT_SECOND_FACTOR_ADDITION",
                        VERIFY_AND_CHANGE_EMAIL: "VERIFY_AND_CHANGE_EMAIL",
                        VERIFY_EMAIL: "VERIFY_EMAIL"
                    }
                },
                Auth: T,
                AuthCredential: Vl,
                Error: Q
            };
            Z(a, "EmailAuthProvider", om, []);
            Z(a, "FacebookAuthProvider", gm, []);
            Z(a, "GithubAuthProvider", im, []);
            Z(a,
                "GoogleAuthProvider", km, []);
            Z(a, "TwitterAuthProvider", mm, []);
            Z(a, "OAuthProvider", fm, [V("providerId")]);
            Z(a, "SAMLAuthProvider", em, [V("providerId")]);
            Z(a, "PhoneAuthProvider", Cm, [Xr()]);
            Z(a, "RecaptchaVerifier", yo, [X(V(), Wr(), "recaptchaContainer"), W("recaptchaParameters", !0), Yr()]);
            Z(a, "ActionCodeURL", Ml, []);
            Z(a, "PhoneMultiFactorGenerator", hs, []);
            firebase.INTERNAL.registerService("auth", function(b, c) {
                b = new T(b);
                c({
                    INTERNAL: {
                        getUid: v(b.getUid, b),
                        getToken: v(b.Jk, b),
                        addAuthTokenListener: v(b.ek, b),
                        removeAuthTokenListener: v(b.Nl,
                            b)
                    }
                });
                return b
            }, a, function(b, c) {
                if (b === "create") try {
                    c.auth()
                } catch (d) {}
            });
            firebase.INTERNAL.extendNamespace({
                User: S
            })
        } else throw Error("Cannot find the firebase namespace; be sure to include firebase-app.js before this library.");
    })();
    var is = function(a) {
        this.Zg = Gg.getParentIframe();
        this.Mb = this.Zg.getOrigin();
        this.Lb = a;
        this.Ih = !1
    };
    is.prototype.ud = function() {
        return this.Mb
    };
    is.prototype.start = function() {
        var a = this;
        return this.Lb(this.Mb).then(function() {
            a.Ih = !0
        }).l(function(b) {
            throw b;
        })
    };
    is.prototype.sendMessage = function(a) {
        var b = this;
        if (this.Ih) return new G(function(c) {
            b.Zg.send(a.type, a, c, Jg)
        });
        throw new Q("missing-iframe-start");
    };
    is.prototype.oh = function(a, b) {
        if (this.Ih) this.Zg.register(a, b, Jg);
        else throw new Q("missing-iframe-start");
    };
    var js = function(a) {
        this.Cf = new is(a)
    };
    js.prototype.ud = function() {
        return this.Cf.ud()
    };
    js.prototype.start = function() {
        var a = this;
        return this.Cf.start().then(function() {
            a.qh()
        })
    };
    var ks = function(a, b) {
        return a.Cf.sendMessage({
            type: "authEvent",
            authEvent: b && b.U()
        }).then(function(c) {
            if (!c || !c.length || c[c.length - 1].status != "ACK") throw new Q("internal-error");
        })
    };
    js.prototype.qh = function() {
        this.Cf.oh("webStorageSupport", function() {
            return H({
                status: "ACK",
                webStorageSupport: !0
            })
        })
    };
    var ls = function(a, b, c) {
        var d = (pk(N(Ck()), "fw") || "").split(","),
            e = this;
        this.ka = a;
        this.ma = b;
        this.Ka = c || null;
        this.Qa = d || [];
        this.Md = new Ep(this.ka + ":" + this.ma);
        this.zl = new Kp;
        this.o = new Rm(a, yk(this.Ka), Yk("Iframe", "2.20.9", this.Qa));
        this.uc = new js(function(f) {
            return hn(e.o).then(function(g) {
                if (!Mk(g, f)) throw e.destroy(), new Pl(f);
            })
        });
        this.xc = Eo(r);
        this.Hi = !1;
        this.xc.subscribe("getParentOrigin", function(f) {
            if (f === r.window.location.origin) return H(e.uc.ud());
            throw Error("Invalid origin");
        });
        this.xc.subscribe("sendAuthEvent", function(f, g) {
            var h = g.storageKey,
                l = null;
            try {
                l = Fl(g.authEvent)
            } catch (m) {}
            if (f === r.window.location.origin && h === e.ka + ":" + e.ma && l) return e.Hi ? ks(e.uc, l).then(function() {
                return !0
            }).l(function() {
                return !1
            }) : e.zl.O.set(Fp, l.U(), h).then(function() {
                return !0
            }).l(function() {
                return !1
            });
            throw Error("Invalid origin or request");
        })
    };
    ls.prototype.ud = function() {
        return this.uc.ud()
    };
    ls.prototype.start = function() {
        var a = this;
        return this.uc.start().then(function() {
            a.Hi = !0;
            a.ej = a.dj.bind(a);
            return ms(a).Dc(function() {
                a.Md.Fc(a.ej);
                a.dj(!1)
            })
        })
    };
    ls.prototype.dj = function(a) {
        var b = this,
            c = null;
        return Gp(this.Md).then(function(d) {
            if (c = d) return ks(b.uc, d);
            if (a) return ks(b.uc, new El("unknown", null, null, null, new Q("no-auth-event")))
        }).then(function() {
            if (c) return Hp(b.Md)
        }).l(function() {})
    };
    var ms = function(a) {
        var b = null;
        return Jp(a.Md).then(function(c) {
            if (b = c) return ks(a.uc, c);
            c = $k() ? "no-auth-event" : "web-storage-unsupported";
            return ks(a.uc, new El("unknown", null, null, null, new Q(c)))
        }).then(function() {
            if (b) {
                var c = a.Md;
                return c.O.remove(Ip, c.W)
            }
        }).l(function() {})
    };
    ls.prototype.destroy = function() {
        this.nd = !0;
        this.Md.Id(this.ej);
        this.xc.unsubscribe("getParentOrigin");
        this.xc.unsubscribe("sendAuthEvent")
    };
    var ns = null,
        os = function() {
            var a = pk(N(Ck()), "apiKey"),
                b = pk(N(Ck()), "appName") || "";
            if (!a) throw new Q("invalid-api-key");
            var c = pk(N(Ck()), "eid") || null;
            ns = new ls(a, b, c);
            ns.start().l(function(d) {
                if (d && d.code == "auth/unauthorized-domain") d = N(ns.ud()), d = d.Xa == "chrome-extension" ? Ic("Info: The current chrome extension ID is not authorized for OAuth operations. This will prevent signInWithPopup and linkWithPopup from working. Add your chrome extension (chrome-extension://%s) to the OAuth redirect domains list in the Firebase console -> Auth section -> Sign in method tab.",
                    d.Ia) : Ic("Info: The current domain is not authorized for OAuth operations. This will prevent signInWithPopup, signInWithRedirect, linkWithPopup and linkWithRedirect from working. Add your domain (%s) to the OAuth redirect domains list in the Firebase console -> Authentication -> Settings -> Authorized domains tab.", d.Ia), ll(d);
                else if (d && d.message) ll(d.message);
                else throw d;
            })
        };
    t("fireauth.iframe.AuthRelay.initialize", function() {
        r.document.readyState == "complete" ? os() : Si(window, "load", function() {
            os()
        })
    });
}).call(this);