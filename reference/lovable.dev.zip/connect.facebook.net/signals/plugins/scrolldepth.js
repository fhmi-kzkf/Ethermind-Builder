/**
 * Copyright (c) 2017-present, Facebook, Inc. All rights reserved.
 *
 * You are hereby granted a non-exclusive, worldwide, royalty-free license to use,
 * copy, modify, and distribute this software in source code or binary form for use
 * in connection with the web services and APIs provided by Facebook.
 *
 * As with any software that integrates with the Facebook platform, your use of
 * this software is subject to the Facebook Platform Policy
 * [http://developers.facebook.com/policy/]. This copyright notice shall be
 * included in all copies or substantial portions of the software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
(function(e, t, n, r) {
    var o = {
            exports: {}
        },
        a = o.exports;
    (function() {
        var a = e.fbq;
        a.execStart = e.performance && e.performance.now && e.performance.now(), (function() {
            var t = e.postMessage || function() {};
            return a ? !0 : (t({
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage: "Pixel code is not installed correctly on this page"
            }, "*"), "error" in console, !1)
        })() && (a.__fbeventsModules || (a.__fbeventsModules = {}, a.__fbeventsResolvedModules = {}, a.getFbeventsModules = function(e) {
            return a.__fbeventsResolvedModules[e] || (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()), a.__fbeventsResolvedModules[e]
        }, a.fbIsModuleLoaded = function(e) {
            return !!a.__fbeventsModules[e]
        }, a.ensureModuleRegistered = function(e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t)
        }), a.ensureModuleRegistered("signalsFBEventsGetIwlUrl", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var t = a.getFbeventsModules("signalsFBEventsCreateTrustedTypePolicy"),
                        n = a.getFbeventsModules("signalsFBEventsGetTier"),
                        r = t("facebook.com/signals/iwl", function(t) {
                            var n = typeof e.URL == "function" ? e.URL : e.webkitURL,
                                r = new n(t),
                                o = r.hostname.endsWith(".facebook.com") && r.pathname == "/signals/iwl.js";
                            if (!o) throw new Error("Disallowed script URL");
                            return t
                        });
                    o.exports = function(t, o, a, i, l) {
                        var e = n(o),
                            s = e == null ? "www.facebook.com" : "www.".concat(e, ".facebook.com"),
                            u = "https://".concat(s, "/signals/iwl.js?pixel_id=").concat(encodeURIComponent(t), "&access_token=").concat(encodeURIComponent(a));
                        return i === !0 && (u += "&from_extension=true"), l != null && l !== "" && (u += "&page_domain=".concat(encodeURIComponent(l))), r != null ? r.createScriptURL(u) : u
                    }
                })(), o.exports
            })(e, t, n, r)
        }), a.ensureModuleRegistered("signalsFBEventsGetTier", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    a = o.exports;
                return (function() {
                    "use strict";
                    var e = /^https:\/\/www\.([A-Za-z0-9\.]+)\.facebook\.com\/tr\/?$/,
                        t = ["https://www.facebook.com/tr", "https://www.facebook.com/tr/"];
                    o.exports = function(r) {
                        if (t.indexOf(r) !== -1) return null;
                        var n = e.exec(r);
                        if (n == null) throw new Error("Malformed tier: ".concat(r));
                        return n[1]
                    }
                })(), o.exports
            })(e, t, n, r)
        }), a.ensureModuleRegistered("SignalsFBEvents.plugins.iwlbootstrapper", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var n = a.getFbeventsModules("SignalsFBEventsIWLBootStrapEvent"),
                        r = a.getFbeventsModules("SignalsFBEventsLogging"),
                        i = a.getFbeventsModules("SignalsFBEventsNetworkConfig"),
                        l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                        s = a.getFbeventsModules("SignalsFBEventsUtils"),
                        u = s.hasOwn,
                        c = a.getFbeventsModules("signalsFBEventsGetIwlUrl"),
                        d = a.getFbeventsModules("signalsFBEventsGetTier"),
                        m = r.logUserError;

                    function p() {
                        return typeof performance != "undefined" ? performance.now() : Date.now()
                    }
                    var _ = /^https:\/\/.*\.facebook\.com$/i,
                        f = /^https:\/\/.*\.internalfb\.com$/i,
                        g = "FACEBOOK_IWL_CONFIG_STORAGE_KEY",
                        h = "signals-browser-extension",
                        y = {
                            getItem: function(t) {
                                return null
                            },
                            removeItem: function(t) {},
                            setItem: function(t, n) {}
                        },
                        C = y;
                    o.exports = new l(function(r, o) {
                        try {
                            C = e.sessionStorage ? e.sessionStorage : y
                        } catch (e) {
                            return
                        }
                        var a = !1,
                            l = null;

                        function s(n, r, o, l, s) {
                            var u = t.createElement("script");
                            u.async = !0, u.onload = function() {
                                if (e.__iwlBootstrapTiming && (e.__iwlBootstrapTiming.scriptLoadEnd = p()), !e.FacebookIWL || !e.FacebookIWL.init) {
                                    delete e.__iwlBootstrapTiming;
                                    return
                                }
                                var t = d(i.ENDPOINT);
                                t != null && e.FacebookIWL.set && e.FacebookIWL.set("tier", t), o()
                            }, e.FacebookIWLSessionEnd = function() {
                                C.removeItem(g), l ? (a = !1, l()) : e.close()
                            }, u.src = c(n, i.ENDPOINT, r, s, typeof e != "undefined" && e.location != null ? e.location.hostname : void 0);
                            var m = t.body;
                            m && (e.__iwlBootstrapTiming && (e.__iwlBootstrapTiming.scriptLoadStart = p()), m.appendChild(u))
                        }
                        var b = function(t) {
                            return !!(o && o.pixelsByID && u(o.pixelsByID, t))
                        };

                        function v(t, n) {
                            if (!a) {
                                var r = C.getItem(g);
                                if (!(r == null || r === "")) {
                                    var o = JSON.parse(r),
                                        i = o.pixelID,
                                        l = o.graphToken,
                                        u = o.sessionStartTime,
                                        c = o.valueCurrencyDiagnostics,
                                        d = o.deepLinkContext;
                                    a = !0, s(i, l, function() {
                                        var t = b(i) ? i.toString() : null;
                                        e.__iwlBootstrapTiming && (e.__iwlBootstrapTiming.initStart = p());
                                        try {
                                            e.FacebookIWL.init(t, l, u, c, d)
                                        } finally {
                                            e.__iwlBootstrapTiming && (e.__iwlBootstrapTiming.initEnd = p()), e.FacebookIWL.logBootstrapTiming && e.FacebookIWL.logBootstrapTiming(), delete e.__iwlBootstrapTiming
                                        }
                                    }, t, n)
                                }
                            }
                        }

                        function S(t, n, r) {
                            a || s(t, n, function() {
                                return e.FacebookIWL.showConfirmModal(t)
                            }, void 0, r)
                        }

                        function R(e, t, n, r, o, a, i) {
                            C.setItem(g, JSON.stringify({
                                graphToken: e,
                                pixelID: t,
                                sessionStartTime: n,
                                valueCurrencyDiagnostics: a != null ? a : void 0,
                                deepLinkContext: i != null ? i : void 0
                            })), v(r, o)
                        }
                        n.listen(function(t) {
                            var n = t.graphToken,
                                r = t.pixelID;
                            R(n, r), e.FacebookIWLSessionEnd = function() {
                                return C.removeItem(g)
                            }
                        });

                        function L(t) {
                            var n = t.data,
                                r = n.graphToken,
                                a = n.msg_type,
                                i = n.pixelID,
                                s = n.sessionStartTime,
                                c = n.source,
                                d = n.valueCurrencyDiagnostics,
                                y = n.deepLinkContext;
                            if (o && o.pixelsByID && o.pixelsByID[i] && o.pixelsByID[i].codeless === "false") {
                                m({
                                    pixelID: i,
                                    type: "SITE_CODELESS_OPT_OUT"
                                });
                                return
                            }
                            var b = _.test(t.origin) || f.test(t.origin) || c === h && t.source === e;
                            if (!(C.getItem(g) || !b || !(t.data && (a === "FACEBOOK_IWL_BOOTSTRAP" || a === "FACEBOOK_IWL_CONFIRM_DOMAIN")))) {
                                if (!u(o.pixelsByID, i)) {
                                    t.source.postMessage("FACEBOOK_IWL_ERROR_PIXEL_DOES_NOT_MATCH", t.origin);
                                    return
                                }
                                switch (a) {
                                    case "FACEBOOK_IWL_BOOTSTRAP":
                                        {
                                            e.__iwlBootstrapTiming = {
                                                listenerReadyAt: l,
                                                bootstrapReceivedAt: p()
                                            },
                                            t.source.postMessage("FACEBOOK_IWL_BOOTSTRAP_ACK", t.origin);
                                            var v = c === h && t.source === e,
                                                L = v ? function() {
                                                    return t.source.postMessage("FACEBOOK_IWL_SESSION_ENDED", t.origin)
                                                } : void 0;R(r, i, s, L, v, d, y);
                                            break
                                        }
                                    case "FACEBOOK_IWL_CONFIRM_DOMAIN":
                                        {
                                            t.source.postMessage("FACEBOOK_IWL_CONFIRM_DOMAIN_ACK", t.origin),
                                            S(i, r);
                                            break
                                        }
                                }
                            }
                        }
                        if (C.getItem(g)) {
                            v();
                            return
                        }
                        l = p(), e.addEventListener("message", L)
                    })
                })(), o.exports
            })(e, t, n, r)
        }), o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.iwlbootstrapper"), a.registerPlugin && a.registerPlugin("fbevents.plugins.iwlbootstrapper", o.exports), a.ensureModuleRegistered("fbevents.plugins.iwlbootstrapper", function() {
            return o.exports
        }))
    })()
})(window, document, location, history);
(function(e, t, n, r) {
    var o = {
            exports: {}
        },
        a = o.exports;
    (function() {
        var a = e.fbq;
        a.execStart = e.performance && e.performance.now && e.performance.now(), (function() {
            var t = e.postMessage || function() {};
            return a ? !0 : (t({
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage: "Pixel code is not installed correctly on this page"
            }, "*"), "error" in console, !1)
        })() && (a.__fbeventsModules || (a.__fbeventsModules = {}, a.__fbeventsResolvedModules = {}, a.getFbeventsModules = function(e) {
            return a.__fbeventsResolvedModules[e] || (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()), a.__fbeventsResolvedModules[e]
        }, a.fbIsModuleLoaded = function(e) {
            return !!a.__fbeventsModules[e]
        }, a.ensureModuleRegistered = function(e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t)
        }), a.ensureModuleRegistered("sha256_with_dependencies_new", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    a = o.exports;
                return (function() {
                    "use strict";

                    function e(e) {
                        for (var t = "", n, r, o = 0; o < e.length; o++) n = e.charCodeAt(o), r = o + 1 < e.length ? e.charCodeAt(o + 1) : 0, n >= 55296 && n <= 56319 && r >= 56320 && r <= 57343 && (n = 65536 + ((n & 1023) << 10) + (r & 1023), o++), n <= 127 ? t += String.fromCharCode(n) : n <= 2047 ? t += String.fromCharCode(192 | n >>> 6 & 31, 128 | n & 63) : n <= 65535 ? t += String.fromCharCode(224 | n >>> 12 & 15, 128 | n >>> 6 & 63, 128 | n & 63) : n <= 2097151 && (t += String.fromCharCode(240 | n >>> 18 & 7, 128 | n >>> 12 & 63, 128 | n >>> 6 & 63, 128 | n & 63));
                        return t
                    }

                    function t(e, t) {
                        return t >>> e | t << 32 - e
                    }

                    function n(e, t, n) {
                        return e & t ^ ~e & n
                    }

                    function r(e, t, n) {
                        return e & t ^ e & n ^ t & n
                    }

                    function a(e) {
                        return t(2, e) ^ t(13, e) ^ t(22, e)
                    }

                    function i(e) {
                        return t(6, e) ^ t(11, e) ^ t(25, e)
                    }

                    function l(e) {
                        return t(7, e) ^ t(18, e) ^ e >>> 3
                    }

                    function s(e) {
                        return t(17, e) ^ t(19, e) ^ e >>> 10
                    }

                    function u(e, t) {
                        return e[t & 15] += s(e[t + 14 & 15]) + e[t + 9 & 15] + l(e[t + 1 & 15])
                    }
                    var c = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298],
                        d = new Array(8),
                        m = new Array(2),
                        p = new Array(64),
                        _ = new Array(16),
                        f = "0123456789abcdef";

                    function g(e, t) {
                        var n = (e & 65535) + (t & 65535),
                            r = (e >> 16) + (t >> 16) + (n >> 16);
                        return r << 16 | n & 65535
                    }

                    function h() {
                        m[0] = m[1] = 0, d[0] = 1779033703, d[1] = 3144134277, d[2] = 1013904242, d[3] = 2773480762, d[4] = 1359893119, d[5] = 2600822924, d[6] = 528734635, d[7] = 1541459225
                    }

                    function y() {
                        var e, t, o, l, s, m, f, h, y, C;
                        o = d[0], l = d[1], s = d[2], m = d[3], f = d[4], h = d[5], y = d[6], C = d[7];
                        for (var b = 0; b < 16; b++) _[b] = p[(b << 2) + 3] | p[(b << 2) + 2] << 8 | p[(b << 2) + 1] << 16 | p[b << 2] << 24;
                        for (var v = 0; v < 64; v++) e = C + i(f) + n(f, h, y) + c[v], v < 16 ? e += _[v] : e += u(_, v), t = a(o) + r(o, l, s), C = y, y = h, h = f, f = g(m, e), m = s, s = l, l = o, o = g(e, t);
                        d[0] += o, d[1] += l, d[2] += s, d[3] += m, d[4] += f, d[5] += h, d[6] += y, d[7] += C
                    }

                    function C(e, t) {
                        var n, r, o = 0;
                        r = m[0] >> 3 & 63;
                        var a = t & 63;
                        for ((m[0] += t << 3) < t << 3 && m[1]++, m[1] += t >> 29, n = 0; n + 63 < t; n += 64) {
                            for (var i = r; i < 64; i++) p[i] = e.charCodeAt(o++);
                            y(), r = 0
                        }
                        for (var l = 0; l < a; l++) p[l] = e.charCodeAt(o++)
                    }

                    function b() {
                        var e = m[0] >> 3 & 63;
                        if (p[e++] = 128, e <= 56)
                            for (var t = e; t < 56; t++) p[t] = 0;
                        else {
                            for (var n = e; n < 64; n++) p[n] = 0;
                            y();
                            for (var r = 0; r < 56; r++) p[r] = 0
                        }
                        p[56] = m[1] >>> 24 & 255, p[57] = m[1] >>> 16 & 255, p[58] = m[1] >>> 8 & 255, p[59] = m[1] & 255, p[60] = m[0] >>> 24 & 255, p[61] = m[0] >>> 16 & 255, p[62] = m[0] >>> 8 & 255, p[63] = m[0] & 255, y()
                    }

                    function v() {
                        for (var e = "", t = 0; t < 8; t++)
                            for (var n = 28; n >= 0; n -= 4) e += f.charAt(d[t] >>> n & 15);
                        return e
                    }

                    function S(e) {
                        for (var t = 0, n = 0; n < 8; n++)
                            for (var r = 28; r >= 0; r -= 4) e[t++] = f.charCodeAt(d[n] >>> r & 15)
                    }

                    function R(e, t) {
                        if (h(), C(e, e.length), b(), t) S(t);
                        else return v()
                    }

                    function L(t) {
                        var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0,
                            r = arguments.length > 2 ? arguments[2] : void 0;
                        if (t == null) return null;
                        var o = t;
                        return n && (o = e(t)), R(o, r)
                    }
                    o.exports = L
                })(), o.exports
            })(e, t, n, r)
        }), a.ensureModuleRegistered("SignalsFBEvents.plugins.prohibitedsources", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var t = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                        n = a.getFbeventsModules("SignalsFBEventsEvents"),
                        r = n.configLoaded,
                        i = a.getFbeventsModules("SignalsFBEventsLogging"),
                        l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                        s = a.getFbeventsModules("SignalsFBEventsUtils"),
                        u = s.filter,
                        c = a.getFbeventsModules("sha256_with_dependencies_new"),
                        d = new l(function(n, o) {
                            r.listen(function(n) {
                                var r = o.optIns.isOptedIn(n, "ProhibitedSources");
                                if (r) {
                                    var a = o.getPixel(n);
                                    if (a != null) {
                                        var l = t.get(a.id, "prohibitedSources");
                                        if (l != null) {
                                            var s = u(l.prohibitedSources, function(t) {
                                                return t.domain != null && t.domain === c(e.location.hostname)
                                            }).length > 0;
                                            s && (o.locks.lock("prohibited_sources_".concat(n)), i.consoleWarn("[fbpixel] " + a.id + " is unavailable. Go to Events Manager to learn more"))
                                        }
                                    }
                                }
                            })
                        });
                    o.exports = d
                })(), o.exports
            })(e, t, n, r)
        }), o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.prohibitedsources"), a.registerPlugin && a.registerPlugin("fbevents.plugins.prohibitedsources", o.exports), a.ensureModuleRegistered("fbevents.plugins.prohibitedsources", function() {
            return o.exports
        }))
    })()
})(window, document, location, history);
(function(e, t, n, r) {
    var o = {
            exports: {}
        },
        a = o.exports;
    (function() {
        var a = e.fbq;
        a.execStart = e.performance && e.performance.now && e.performance.now(), (function() {
            var t = e.postMessage || function() {};
            return a ? !0 : (t({
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage: "Pixel code is not installed correctly on this page"
            }, "*"), "error" in console, !1)
        })() && (a.__fbeventsModules || (a.__fbeventsModules = {}, a.__fbeventsResolvedModules = {}, a.getFbeventsModules = function(e) {
            return a.__fbeventsResolvedModules[e] || (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()), a.__fbeventsResolvedModules[e]
        }, a.fbIsModuleLoaded = function(e) {
            return !!a.__fbeventsModules[e]
        }, a.ensureModuleRegistered = function(e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t)
        }), a.ensureModuleRegistered("SignalsFBEvents.plugins.unwanteddata", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var e = a.getFbeventsModules("SignalsFBEventsEvents"),
                        t = e.validateCustomParameters,
                        n = e.validateUrlParameters,
                        r = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                        i = a.getFbeventsModules("SignalsFBEventsLogging"),
                        l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                        s = a.getFbeventsModules("SignalsFBEventsUtils"),
                        u = a.getFbeventsModules("sha256_with_dependencies_new"),
                        c = s.map,
                        d = !1;
                    o.exports = new l(function(e, o) {
                        t.listen(function(t, n, a) {
                            if (t == null) return {};
                            e.performanceMark("fbevents:start:unwantedDataProcessing", t.id);
                            var l = o.optIns.isOptedIn(t.id, "UnwantedData");
                            if (!l) return {};
                            var d = o.optIns.isOptedIn(t.id, "ProtectedDataMode"),
                                m = r.get(t.id, "unwantedData");
                            if (m == null) return {};
                            var p = !1,
                                _ = [],
                                f = [],
                                g = {};
                            if (m.blacklisted_keys != null) {
                                var h = m.blacklisted_keys[a];
                                if (h != null) {
                                    var y = h.cd;
                                    c(y, function(e) {
                                        s.hasOwn(n, e) && (p = !0, _.push(e), delete n[e])
                                    })
                                }
                            }
                            if (m.sensitive_keys != null) {
                                var C = m.sensitive_keys[a];
                                if (C != null) {
                                    var b = C.cd;
                                    Object.keys(n).forEach(function(e) {
                                        c(b, function(t) {
                                            u(e) === t && (p = !0, f.push(t), delete n[e])
                                        })
                                    })
                                }
                            }
                            if (g.unwantedParams = _, g.restrictedParams = f, p && !d) {
                                var v = _.length > 0,
                                    S = f.length > 0;
                                if (v || S) {
                                    e.performanceMark("fbevents:end:unwantedDataProcessing", t.id), i.logUserError({
                                        type: "UNWANTED_CUSTOM_DATA"
                                    });
                                    var R = {};
                                    return v && (R.up = _.join(",")), S && (R.rp = f.join(",")), R
                                }
                            }
                            return e.performanceMark("fbevents:end:unwantedDataProcessing", t.id), {}
                        });

                        function a(e, t, n, r, o) {
                            var a = new URLSearchParams(t.search),
                                i = [],
                                l = [],
                                s = {};
                            if (n.blacklisted_keys != null) {
                                var m = n.blacklisted_keys[r];
                                if (m != null) {
                                    var p = m.url;
                                    c(p, function(e) {
                                        a.has(e) && (d = !0, i.push(e), a.set(e, "_removed_"))
                                    })
                                }
                            }
                            if (n.sensitive_keys != null) {
                                var _ = n.sensitive_keys[r];
                                if (_ != null) {
                                    var f = _.url;
                                    a.forEach(function(e, t) {
                                        c(f, function(e) {
                                            u(t) === e && (d = !0, l.push(e), a.set(t, "_removed_"))
                                        })
                                    })
                                }
                            }
                            return s.unwantedParams = i, s.restrictedParams = l, d ? (o || (i.length > 0 && e.append("up_url", i.join(",")), l.length > 0 && e.append("rp_url", l.join(","))), a.toString()) : ""
                        }
                        n.listen(function(t, n, l, u) {
                            if (t != null) {
                                e.performanceMark("fbevents:start:validateUrlProcessing", t.id);
                                var c = o.optIns.isOptedIn(t.id, "UnwantedData");
                                if (c) {
                                    var m = o.optIns.isOptedIn(t.id, "ProtectedDataMode"),
                                        p = r.get(t.id, "unwantedData");
                                    p != null && (d = !1, ["dl", "rl"].forEach(function(e) {
                                        if (s.hasOwn(n, e) && n[e].length > 0) {
                                            var t = new URL(n[e]),
                                                r = a(u, t, p, l, m);
                                            d && r.length > 0 && (t.search = r, n[e] = t.toString())
                                        }
                                    }), d && i.logUserError({
                                        type: "UNWANTED_URL_DATA"
                                    }), e.performanceMark("fbevents:end:validateUrlProcessing", t.id))
                                }
                            }
                        })
                    })
                })(), o.exports
            })(e, t, n, r)
        }), o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.unwanteddata"), a.registerPlugin && a.registerPlugin("fbevents.plugins.unwanteddata", o.exports), a.ensureModuleRegistered("fbevents.plugins.unwanteddata", function() {
            return o.exports
        }))
    })()
})(window, document, location, history);
(function(e, t, n, r) {
    var o = {
            exports: {}
        },
        a = o.exports;
    (function() {
        var a = e.fbq;
        a.execStart = e.performance && e.performance.now && e.performance.now(), (function() {
            var t = e.postMessage || function() {};
            return a ? !0 : (t({
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage: "Pixel code is not installed correctly on this page"
            }, "*"), "error" in console, !1)
        })() && (a.__fbeventsModules || (a.__fbeventsModules = {}, a.__fbeventsResolvedModules = {}, a.getFbeventsModules = function(e) {
            return a.__fbeventsResolvedModules[e] || (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()), a.__fbeventsResolvedModules[e]
        }, a.fbIsModuleLoaded = function(e) {
            return !!a.__fbeventsModules[e]
        }, a.ensureModuleRegistered = function(e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t)
        }), a.ensureModuleRegistered("SignalsFBEvents.plugins.eventvalidation", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var e = a.getFbeventsModules("SignalsFBEventsPlugin"),
                        t = a.getFbeventsModules("SignalsFBEventsSendEventEvent"),
                        n = a.getFbeventsModules("SignalsFBEventsTyped"),
                        r = n.coerce,
                        i = n.Typed,
                        l = a.getFbeventsModules("SignalsFBEventsLogging"),
                        s = l.logUserError,
                        u = a.getFbeventsModules("sha256_with_dependencies_new"),
                        c = new e(function(e, n) {
                            t.listen(function(e) {
                                var t = e.id,
                                    o = e.eventName,
                                    a = r(t, i.fbid());
                                if (a == null) return !1;
                                var l = n.optIns.isOptedIn(a, "EventValidation");
                                if (!l) return !1;
                                var c = n.pluginConfig.get(a, "eventValidation");
                                if (c == null) return !1;
                                var d = c.unverifiedEventNames,
                                    m = c.restrictedEventNames,
                                    p = !1,
                                    _ = !1,
                                    f = u(o);
                                return d && (p = d.includes(o) || f != null && d.includes(f), p && s({
                                    type: "UNVERIFIED_EVENT"
                                })), m && (_ = m.includes(o) || f != null && m.includes(f), _ && s({
                                    type: "RESTRICTED_EVENT"
                                })), p || _
                            })
                        });
                    o.exports = c
                })(), o.exports
            })(e, t, n, r)
        }), o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.eventvalidation"), a.registerPlugin && a.registerPlugin("fbevents.plugins.eventvalidation", o.exports), a.ensureModuleRegistered("fbevents.plugins.eventvalidation", function() {
            return o.exports
        }))
    })()
})(window, document, location, history);
(function(e, t, n, r) {
    var o = {
            exports: {}
        },
        a = o.exports;
    (function() {
        var a = e.fbq;
        if (a.execStart = e.performance && e.performance.now && e.performance.now(), !(function() {
                var t = e.postMessage || function() {};
                return a ? !0 : (t({
                    action: "FB_LOG",
                    logType: "Facebook Pixel Error",
                    logMessage: "Pixel code is not installed correctly on this page"
                }, "*"), "error" in console, !1)
            })()) return;

        function i(e, t) {
            var n = typeof Symbol != "undefined" && e[typeof Symbol == "function" ? Symbol.iterator : "@@iterator"] || e["@@iterator"];
            if (!n) {
                if (Array.isArray(e) || (n = l(e)) || t && e && typeof e.length == "number") {
                    n && (e = n);
                    var r = 0,
                        o = function() {};
                    return {
                        s: o,
                        n: function() {
                            return r >= e.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: e[r++]
                            }
                        },
                        e: function(t) {
                            throw t
                        },
                        f: o
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            var a, i = !0,
                s = !1;
            return {
                s: function() {
                    n = n.call(e)
                },
                n: function() {
                    var e = n.next();
                    return i = e.done, e
                },
                e: function(t) {
                    s = !0, a = t
                },
                f: function() {
                    try {
                        i || n.return == null || n.return()
                    } finally {
                        if (s) throw a
                    }
                }
            }
        }

        function l(e, t) {
            if (e) {
                if (typeof e == "string") return s(e, t);
                var n = {}.toString.call(e).slice(8, -1);
                return n === "Object" && e.constructor && (n = e.constructor.name), n === "Map" || n === "Set" ? Array.from(e) : n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? s(e, t) : void 0
            }
        }

        function s(e, t) {
            (t == null || t > e.length) && (t = e.length);
            for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
            return r
        }
        a.__fbeventsModules || (a.__fbeventsModules = {}, a.__fbeventsResolvedModules = {}, a.getFbeventsModules = function(e) {
            return a.__fbeventsResolvedModules[e] || (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()), a.__fbeventsResolvedModules[e]
        }, a.fbIsModuleLoaded = function(e) {
            return !!a.__fbeventsModules[e]
        }, a.ensureModuleRegistered = function(e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t)
        }), a.ensureModuleRegistered("SignalsFBEventsClientHintTypedef", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var e = a.getFbeventsModules("SignalsFBEventsTyped"),
                        t = e.Typed,
                        n = t.objectWithFields({
                            brands: t.array(),
                            platform: t.allowNull(t.string()),
                            getHighEntropyValues: t.func()
                        }),
                        r = t.objectWithFields({
                            model: t.allowNull(t.string()),
                            platformVersion: t.allowNull(t.string()),
                            fullVersionList: t.array()
                        });
                    o.exports = {
                        userAgentDataTypedef: n,
                        highEntropyResultTypedef: r
                    }
                })(), o.exports
            })(e, t, n, r)
        }), a.ensureModuleRegistered("SignalsFBEventsGetIsAndroidChrome", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var e = a.getFbeventsModules("signalsFBEventsGetIsChrome");

                    function t(e) {
                        return e === void 0 ? !1 : e.platform === "Android" && e.brands.map(function(e) {
                            return e.brand
                        }).join(", ").includes("Chrome")
                    }

                    function n(t) {
                        var n = t.indexOf("Android") >= 0,
                            r = e();
                        return n && r
                    }
                    o.exports = {
                        checkIsAndroidChromeWithClientHint: t,
                        checkIsAndroidChrome: n
                    }
                })(), o.exports
            })(e, t, n, r)
        }), a.ensureModuleRegistered("SignalsFBEvents.plugins.clienthint", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    l = o.exports;
                return (function() {
                    "use strict";
                    var t = a.getFbeventsModules("SignalsFBEventsPlugin"),
                        n = a.getFbeventsModules("SignalsParamList"),
                        r = a.getFbeventsModules("SignalsFBEventsLogging"),
                        l = r.logWarning,
                        s = r.logInfo,
                        u = r.META_PIXEL_PRODUCT_NAME,
                        c = a.getFbeventsModules("SignalsFBEventsTyped"),
                        d = c.coerce,
                        m = a.getFbeventsModules("SignalsFBEventsClientHintTypedef"),
                        p = m.userAgentDataTypedef,
                        _ = m.highEntropyResultTypedef,
                        f = a.getFbeventsModules("SignalsFBEventsGetIsAndroidChrome"),
                        g = f.checkIsAndroidChrome,
                        h = "chmd",
                        y = "chpv",
                        C = "chfv",
                        b = [h, y, C],
                        v = "clientHint",
                        S = "clienthint";

                    function R(e) {
                        var t = d(e, _);
                        if (t == null) return s(new Error("[ClientHint Error] getHighEntropyValues returned null from Android Chrome source"), u, S), new Map;
                        var n = new Map;
                        n.set(h, String(t.model)), n.set(y, String(t.platformVersion));
                        var r, o, a = i(t.fullVersionList),
                            l;
                        try {
                            for (a.s(); !(l = a.n()).done;) o = l.value, o.brand.includes("Chrome") && (r = o.version)
                        } catch (e) {
                            a.e(e)
                        } finally {
                            a.f()
                        }
                        return n.set(C, String(r)), n
                    }

                    function L(e, t) {
                        var n = i(b),
                            r;
                        try {
                            for (n.s(); !(r = n.n()).done;) {
                                var o = r.value;
                                e.get(o) == null && e.append(o, t.get(o))
                            }
                        } catch (e) {
                            n.e(e)
                        } finally {
                            n.f()
                        }
                    }

                    function E(e, t, r) {
                        var o = R(e),
                            a = t.customParams || new n;
                        L(a, o), t.customParams = a
                    }
                    var k = new t(function(t, n) {
                        var r = d(e.navigator.userAgentData, p);
                        if (r == null) {
                            e.navigator.userAgentData != null && l(new Error("[ClientHint Error] UserAgentData coerce error"), u, S);
                            return
                        } else if (!g(e.navigator.userAgent)) return;
                        var o = e.navigator.userAgentData.getHighEntropyValues(["model", "platformVersion", "fullVersionList"]).then(function(e) {
                            var t = n.asyncParamFetchers.get(v);
                            return t != null && t.result == null && (t.result = e, n.asyncParamFetchers.set(v, t)), e
                        }).catch(function(e) {
                            var t = e instanceof Error ? e.message : String(e);
                            l(new Error("[ClientHint Error] Fetch error: ".concat(t)), u, S)
                        });
                        n.asyncParamFetchers.set(v, {
                            request: o,
                            callback: E
                        }), n.asyncParamPromisesAllSettled = !1
                    });
                    o.exports = k
                })(), o.exports
            })(e, t, n, r)
        }), o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.clienthint"), a.registerPlugin && a.registerPlugin("fbevents.plugins.clienthint", o.exports), a.ensureModuleRegistered("fbevents.plugins.clienthint", function() {
            return o.exports
        })
    })()
})(window, document, location, history);
(function(e, t, n, r) {
    var o = {
            exports: {}
        },
        a = o.exports;
    (function() {
        var a = e.fbq;
        a.execStart = e.performance && e.performance.now && e.performance.now(), (function() {
            var t = e.postMessage || function() {};
            return a ? !0 : (t({
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage: "Pixel code is not installed correctly on this page"
            }, "*"), "error" in console, !1)
        })() && (a.__fbeventsModules || (a.__fbeventsModules = {}, a.__fbeventsResolvedModules = {}, a.getFbeventsModules = function(e) {
            return a.__fbeventsResolvedModules[e] || (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()), a.__fbeventsResolvedModules[e]
        }, a.fbIsModuleLoaded = function(e) {
            return !!a.__fbeventsModules[e]
        }, a.ensureModuleRegistered = function(e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t)
        }), a.ensureModuleRegistered("SignalsFBEvents.plugins.unwantedparams", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var e = a.getFbeventsModules("SignalsFBEventsEvents"),
                        t = e.validateCustomParameters,
                        n = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                        r = a.getFbeventsModules("SignalsFBEventsPlugin"),
                        i = a.getFbeventsModules("SignalsFBEventsUtils"),
                        l = i.each,
                        s = i.hasOwn;
                    o.exports = new r(function(e, r) {
                        t.listen(function(t, o, a) {
                            if (t == null) return {};
                            e.performanceMark("fbevents:start:unwantedParamsProcessing", t.id);
                            var i = r.optIns.isOptedIn(t.id, "UnwantedParams");
                            if (!i) return {};
                            var u = n.get(t.id, "unwantedParams");
                            if (u == null || u.unwantedParams == null) return {};
                            var c = [];
                            return l(u.unwantedParams, function(e) {
                                s(o, e) && (c.push(e), delete o[e])
                            }), e.performanceMark("fbevents:end:unwantedParamsProcessing", t.id), c.length > 0 ? {
                                spb: c.join(",")
                            } : {}
                        })
                    })
                })(), o.exports
            })(e, t, n, r)
        }), o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.unwantedparams"), a.registerPlugin && a.registerPlugin("fbevents.plugins.unwantedparams", o.exports), a.ensureModuleRegistered("fbevents.plugins.unwantedparams", function() {
            return o.exports
        }))
    })()
})(window, document, location, history);
(function(e, t, n, r) {
    var o = {
            exports: {}
        },
        a = o.exports;
    (function() {
        var a = e.fbq;
        a.execStart = e.performance && e.performance.now && e.performance.now(), (function() {
            var t = e.postMessage || function() {};
            return a ? !0 : (t({
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage: "Pixel code is not installed correctly on this page"
            }, "*"), "error" in console, !1)
        })() && (a.__fbeventsModules || (a.__fbeventsModules = {}, a.__fbeventsResolvedModules = {}, a.getFbeventsModules = function(e) {
            return a.__fbeventsResolvedModules[e] || (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()), a.__fbeventsResolvedModules[e]
        }, a.fbIsModuleLoaded = function(e) {
            return !!a.__fbeventsModules[e]
        }, a.ensureModuleRegistered = function(e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t)
        }), a.ensureModuleRegistered("SignalsFBEvents.plugins.standardparamchecks", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var e = a.getFbeventsModules("SignalsFBEventsLogging"),
                        t = e.logUserError,
                        n = a.getFbeventsModules("SignalsFBEventsEvents"),
                        r = n.lateValidateCustomParameters,
                        i = a.getFbeventsModules("SignalsFBEventsConfigStore"),
                        l = a.getFbeventsModules("SignalsFBEventsPlugin"),
                        s = a.getFbeventsModules("SignalsFBEventsUtils"),
                        u = s.each,
                        c = s.some,
                        d = s.keys;

                    function m(e, t) {
                        var n;
                        if (!t) return !1;
                        if (t.require_exact_match) {
                            var r;
                            return c((r = t.potential_matches) !== null && r !== void 0 ? r : [], function(t) {
                                return t.toLowerCase() === e.toLowerCase()
                            })
                        }
                        return c((n = t.potential_matches) !== null && n !== void 0 ? n : [], function(t) {
                            return new RegExp(t).test(e)
                        })
                    }
                    o.exports = new l(function(e, n) {
                        r.listen(function(e, r, o) {
                            var a = n.optIns.isOptedIn(e, "StandardParamChecks");
                            if (!a) return {};
                            var l = i.get(e, "standardParamChecks");
                            if (l == null || l.standardParamChecks == null) return {};
                            var s = [];
                            return u(d(r), function(n) {
                                var o = l.standardParamChecks ? l.standardParamChecks[n] || [] : [];
                                if (!o || o.length == 0) return {};
                                var a = c(o, function(e) {
                                    return m(String(r[n]), e)
                                });
                                a || (s.push(n), t({
                                    invalidParamName: n,
                                    pixelID: e,
                                    type: "INVALID_PARAM_FORMAT"
                                }))
                            }), u(s, function(e) {
                                delete r[e]
                            }), s.length > 0 ? {
                                rks: s.join(",")
                            } : {}
                        })
                    })
                })(), o.exports
            })(e, t, n, r)
        }), o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.standardparamchecks"), a.registerPlugin && a.registerPlugin("fbevents.plugins.standardparamchecks", o.exports), a.ensureModuleRegistered("fbevents.plugins.standardparamchecks", function() {
            return o.exports
        }))
    })()
})(window, document, location, history);
(function(e, t, n, r) {
    var o = {
            exports: {}
        },
        a = o.exports;
    (function() {
        var a = e.fbq;
        a.execStart = e.performance && e.performance.now && e.performance.now(), (function() {
            var t = e.postMessage || function() {};
            return a ? !0 : (t({
                action: "FB_LOG",
                logType: "Facebook Pixel Error",
                logMessage: "Pixel code is not installed correctly on this page"
            }, "*"), "error" in console, !1)
        })() && (a.__fbeventsModules || (a.__fbeventsModules = {}, a.__fbeventsResolvedModules = {}, a.getFbeventsModules = function(e) {
            return a.__fbeventsResolvedModules[e] || (a.__fbeventsResolvedModules[e] = a.__fbeventsModules[e]()), a.__fbeventsResolvedModules[e]
        }, a.fbIsModuleLoaded = function(e) {
            return !!a.__fbeventsModules[e]
        }, a.ensureModuleRegistered = function(e, t) {
            a.fbIsModuleLoaded(e) || (a.__fbeventsModules[e] = t)
        }), a.ensureModuleRegistered("SignalsFBEvents.plugins.gating", function() {
            return (function(e, t, n, r) {
                var o = {
                        exports: {}
                    },
                    i = o.exports;
                return (function() {
                    "use strict";
                    var e = a.getFbeventsModules("SignalsFBEventsPlugin"),
                        t = a.getFbeventsModules("SignalsFBEventsEvents"),
                        n = t.gateCheckEvent,
                        r = t.configLoaded,
                        i = a.getFbeventsModules("signalsFBEventsFeatureGate"),
                        l = a.getFbeventsModules("SignalsFBEventsUtils"),
                        s = l.each,
                        u = l.keys;
                    o.exports = new e(function(e, t) {
                        var o = [];

                        function a(e, t, n, r) {
                            var o = i(e, r),
                                a = o ? t : n;
                            try {
                                a(e, r)
                            } catch (e) {}
                        }

                        function l(e, t, n, r, a) {
                            o.push({
                                gateName: e,
                                onEnabled: t,
                                onDisabled: n,
                                pixelID: r,
                                checkedPixels: a
                            })
                        }

                        function c(e, n, r, o) {
                            if (t.configsLoaded[o]) {
                                a(e, n, r, o);
                                return
                            }
                            l(e, n, r, o, new Set)
                        }

                        function d(e, n, r) {
                            var o = new Set,
                                i = u(t.pixelsByID);
                            s(i, function(i) {
                                t.configsLoaded[i] && (a(e, n, r, i), o.add(i))
                            }), l(e, n, r, null, o)
                        }

                        function m(e, t) {
                            var n = e.gateName,
                                r = e.onEnabled,
                                o = e.onDisabled,
                                i = e.pixelID;
                            return i !== t ? !1 : (a(n, r, o, t), !0)
                        }

                        function p(e, t) {
                            var n = e.gateName,
                                r = e.onEnabled,
                                o = e.onDisabled,
                                i = e.checkedPixels;
                            i.has(t) || (a(n, r, o, t), i.add(t))
                        }
                        n.listen(function(e, t, n, r) {
                            r != null ? c(e, t, n, r) : d(e, t, n)
                        }), r.listen(function(e) {
                            var t = [];
                            s(o, function(n) {
                                if (n.pixelID != null) {
                                    var r = m(n, e);
                                    r || t.push(n)
                                } else p(n, e), t.push(n)
                            }), o.length = 0, s(t, function(e) {
                                return o.push(e)
                            })
                        })
                    })
                })(), o.exports
            })(e, t, n, r)
        }), o.exports = a.getFbeventsModules("SignalsFBEvents.plugins.gating"), a.registerPlugin && a.registerPlugin("fbevents.plugins.gating", o.exports), a.ensureModuleRegistered("fbevents.plugins.gating", function() {
            return o.exports
        }))
    })()
})(window, document, location, history);
fbq.registerPlugin("fbevents.plugins.scrolldepth", {
    __fbEventsPlugin: 1,
    plugin: function(fbq, instance, config) { /* empty plugin */ }
});